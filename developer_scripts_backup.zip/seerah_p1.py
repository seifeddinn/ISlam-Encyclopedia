import codecs
f = codecs.open("seerah.html","w","utf-8")
f.write("""<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>موسوعة السيرة النبوية الشريفة الشاملة - الموسوعة الإسلامية</title>
<meta name="description" content="أكبر مرجع رقمي للسيرة النبوية الشريفة: الشمائل، الغزوات، الصحابة الكرام، أمهات المؤمنين، السيرة في القرآن الكريم.">
<meta name="keywords" content="سيرة نبوية، محمد رسول الله، صحابة، غزوات، شمائل محمدية، أم المؤمنين">
<link href="https://fonts.googleapis.com/css2?family=Amiri:ital,wght@0,400;0,700;1,400&family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
<style>
:root{--gold:#d4af37;--gd:#aa8a2a;--dk:#450a0a;--pr:#b91c1c;--light-red:#fef2f2;}
*{box-sizing:border-box;}
body{font-family:'Cairo',sans-serif;background:#f8fafc;color:#1e293b;overflow-x:hidden;}
.amiri,h1,h2,h3,h4{font-family:'Amiri',serif;}
.lh-xl{line-height:2.1;}

/* NAV */
.navbar{background:linear-gradient(135deg,var(--dk),var(--pr))!important;box-shadow:0 4px 30px rgba(0,0,0,.5);border-bottom:2px solid rgba(212,175,55,.2);}
.navbar-brand{font-family:'Amiri',serif;font-size:1.8rem;color:#fff!important;}
.nav-link{color:rgba(255,255,255,.8)!important;font-weight:700;transition:.3s;}
.nav-link:hover,.nav-link.active{color:var(--gold)!important;}

/* HERO */
.seerah-hero{min-height:96vh;background:radial-gradient(ellipse at 60% 40%,#7f1d1d 0%,var(--dk) 75%);display:flex;align-items:center;position:relative;overflow:hidden;}
.hero-arabesque{position:absolute;inset:0;background:url('https://www.transparenttextures.com/patterns/arabesque.png');opacity:.09;}
.orb{position:absolute;border-radius:50%;filter:blur(100px);opacity:.22;animation:float 12s ease-in-out infinite alternate;}
.orb1{width:550px;height:550px;background:var(--gold);top:-120px;right:-100px;}
.orb2{width:450px;height:450px;background:#dc2626;bottom:-100px;left:-80px;animation-delay:5s;}
@keyframes float{to{transform:translate(45px,45px) scale(1.12);}}
.hero-content{position:relative;z-index:2;text-align:center;}
.hero-pill{display:inline-block;background:linear-gradient(90deg,var(--gd),var(--gold));color:#1a0000;padding:9px 32px;border-radius:50px;font-weight:700;font-size:1rem;margin-bottom:28px;box-shadow:0 4px 20px rgba(212,175,55,.4);}
.hero-h1{font-size:clamp(2.6rem,6.5vw,5.8rem);color:#fff;font-weight:900;text-shadow:0 8px 30px rgba(0,0,0,.8);line-height:1.15;}
.hero-h1 em{font-style:normal;background:linear-gradient(135deg,#fff,var(--gold));-webkit-background-clip:text;-webkit-text-fill-color:transparent;}
.hero-ayah{color:rgba(255,255,255,.9);font-size:clamp(1.1rem,2.5vw,1.5rem);font-family:'Amiri',serif;line-height:2;max-width:780px;margin:0 auto 30px;}
.hero-ayah span{color:var(--gold);}
.hero-badges{display:flex;justify-content:center;gap:12px;flex-wrap:wrap;margin-top:28px;}
.hero-badge{background:rgba(255,255,255,.08);border:1px solid rgba(212,175,55,.35);border-radius:18px;padding:16px 28px;color:#fff;backdrop-filter:blur(6px);transition:.3s;}
.hero-badge:hover{background:rgba(212,175,55,.15);border-color:var(--gold);}
.hero-badge strong{display:block;font-size:2rem;color:var(--gold);font-family:'Amiri',serif;line-height:1.2;}
.hero-badge small{font-size:.85rem;opacity:.8;}

/* TABS BAR */
.tabs-bar{background:#fff;border-radius:22px;padding:14px;box-shadow:0 12px 40px rgba(0,0,0,.07);margin:45px 0 55px;position:sticky;top:76px;z-index:900;border:1px solid #e2e8f0;}
.tabs-bar .nav{gap:6px;justify-content:center;flex-wrap:wrap;overflow-x:auto;}
.tabs-bar .nav-link{border:1px solid #e2e8f0;border-radius:14px;color:#475569;font-weight:700;padding:12px 22px;font-size:1rem;white-space:nowrap;transition:.3s;display:flex;align-items:center;gap:7px;}
.tabs-bar .nav-link i{font-size:1.15rem;color:var(--gd);}
.tabs-bar .nav-link:hover{background:var(--light-red);border-color:var(--gd);}
.tabs-bar .nav-link.active{background:linear-gradient(135deg,var(--dk),var(--pr));color:#fff!important;border-color:transparent;box-shadow:0 8px 22px rgba(153,27,27,.35);}
.tabs-bar .nav-link.active i{color:var(--gold);}

/* SEC HEADER */
.sec-head{text-align:center;margin-bottom:55px;}
.badge-tag{display:inline-block;background:rgba(212,175,55,.12);color:var(--gd);border:1px solid rgba(212,175,55,.35);border-radius:30px;padding:8px 24px;font-size:.95rem;font-weight:700;margin-bottom:18px;}
.sec-head h2{font-size:clamp(2rem,4vw,3.2rem);color:var(--dk);font-weight:900;}
.sec-head h2 span{color:var(--pr);}
.sec-head p{color:#64748b;font-size:1.1rem;max-width:760px;margin:10px auto 0;line-height:1.9;}
.gold-divider{width:80px;height:5px;background:linear-gradient(90deg,var(--gold),var(--pr));border-radius:5px;margin:22px auto 0;}

/* TIMELINE */
.seerah-tl{position:relative;max-width:1100px;margin:0 auto;}
.seerah-tl::before{content:'';position:absolute;top:0;bottom:0;left:50%;width:3px;background:linear-gradient(to bottom,transparent,var(--gold) 8%,var(--pr) 92%,transparent);transform:translateX(-50%);}
.tl-row{display:flex;margin-bottom:60px;position:relative;align-items:flex-start;}
.tl-row:nth-child(odd) .tl-card-wrap{order:1;padding-right:55px;text-align:right;}
.tl-row:nth-child(even) .tl-card-wrap{order:3;padding-left:55px;}
.tl-center{order:2;flex:0 0 auto;display:flex;flex-direction:column;align-items:center;width:80px;position:relative;}
.tl-dot{width:24px;height:24px;background:var(--gold);border:4px solid var(--dk);border-radius:50%;box-shadow:0 0 0 6px rgba(212,175,55,.2);}
.tl-year{font-family:'Amiri',serif;font-weight:700;font-size:1rem;color:#fff;background:var(--dk);padding:5px 12px;border-radius:20px;margin-top:8px;white-space:nowrap;box-shadow:0 4px 12px rgba(0,0,0,.3);}
.tl-card-wrap{flex:1;}
.tl-card{background:#fff;border-radius:22px;padding:35px;box-shadow:0 12px 35px rgba(0,0,0,.05);border:1px solid #fee2e2;transition:.4s;position:relative;overflow:hidden;}
.tl-card::before{content:'';position:absolute;top:0;left:0;right:0;height:4px;background:linear-gradient(90deg,var(--pr),var(--gold));}
.tl-card:hover{transform:translateY(-8px);box-shadow:0 22px 50px rgba(153,27,27,.12);border-color:var(--gold);}
.tl-card h3{font-size:1.55rem;color:var(--dk);margin-bottom:12px;}
.tl-card p{color:#64748b;font-size:1.05rem;line-height:1.95;margin:0;}
.tl-tag{display:inline-block;background:var(--light-red);color:var(--pr);border-radius:20px;padding:3px 12px;font-size:.82rem;font-weight:700;margin-bottom:10px;}
@media(max-width:768px){
  .seerah-tl::before{left:24px;}
  .tl-row{flex-direction:column;padding-right:60px;}
  .tl-row:nth-child(odd) .tl-card-wrap,.tl-row:nth-child(even) .tl-card-wrap{order:1;padding:0;text-align:right;}
  .tl-center{position:absolute;left:0;flex-direction:row;width:auto;gap:8px;}
  .tl-year{font-size:.78rem;padding:3px 8px;}
}

/* MORALS */
.moral-card{background:#fff;border-radius:22px;padding:35px 28px;box-shadow:0 10px 30px rgba(0,0,0,.04);border:1px solid #fee2e2;transition:.4s;height:100%;text-align:center;position:relative;overflow:hidden;}
.moral-card::after{content:'';position:absolute;bottom:0;left:0;width:100%;height:4px;background:var(--gold);transform:scaleX(0);transition:.4s;transform-origin:left;}
.moral-card:hover{transform:translateY(-8px);box-shadow:0 20px 45px rgba(153,27,27,.1);}
.moral-card:hover::after{transform:scaleX(1);}
.moral-icon{width:85px;height:85px;border-radius:50%;background:linear-gradient(135deg,rgba(153,27,27,.1),rgba(212,175,55,.1));display:inline-flex;align-items:center;justify-content:center;font-size:2.5rem;color:var(--pr);margin-bottom:22px;transition:.4s;}
.moral-card:hover .moral-icon{background:linear-gradient(135deg,var(--pr),var(--dk));color:#fff;}

/* SAHABA */
.filter-bar{display:flex;justify-content:center;gap:10px;flex-wrap:wrap;margin-bottom:38px;}
.filter-bar button{background:#fff;color:var(--dk);border:1px solid #e2e8f0;padding:10px 24px;border-radius:30px;font-weight:700;transition:.3s;cursor:pointer;font-size:.95rem;}
.filter-bar button.active,.filter-bar button:hover{background:var(--pr);color:#fff;border-color:var(--pr);box-shadow:0 5px 15px rgba(153,27,27,.25);}
.comp-card{background:linear-gradient(145deg,#fff,var(--light-red));border-radius:22px;padding:30px 25px;text-align:center;box-shadow:0 8px 28px rgba(0,0,0,.05);border-bottom:5px solid var(--pr);transition:.4s;height:100%;}
.comp-card:hover{transform:translateY(-8px);border-color:var(--gold);box-shadow:0 18px 40px rgba(153,27,27,.1);}
.comp-rank{display:inline-block;background:var(--dk);color:var(--gold);padding:5px 16px;border-radius:20px;font-size:.82rem;font-weight:700;margin-bottom:10px;}
.comp-name{font-family:'Amiri',serif;font-size:1.75rem;color:var(--dk);font-weight:700;margin:8px 0 12px;}
.comp-card p{color:#64748b;font-size:.97rem;line-height:1.85;margin:0;}
.mom-card .comp-rank{background:#be123c;}
.mom-card{border-bottom-color:#be123c;}

/* BATTLES */
.battle-map{background:linear-gradient(135deg,#fdf6e3,#f0e5c0);border:3px solid var(--gold);border-radius:25px;position:relative;min-height:420px;overflow:hidden;background-image:url('https://www.transparenttextures.com/patterns/cartographer.png');padding:20px;}
.b-badge{position:absolute;top:18px;right:18px;background:var(--dk);color:var(--gold);font-family:'Amiri',serif;font-weight:700;font-size:1rem;padding:8px 20px;border-radius:12px;border:2px solid var(--gd);z-index:5;}
.b-team{position:absolute;padding:11px 20px;border-radius:12px;font-weight:700;font-family:'Amiri',serif;font-size:.95rem;color:#fff;box-shadow:0 8px 20px rgba(0,0,0,.3);z-index:4;}
.bt-m{background:linear-gradient(135deg,var(--pr),var(--dk));border:2px solid var(--gold);}
.bt-e{background:linear-gradient(135deg,#1e293b,#0f172a);border:2px solid #ef4444;}
.b-label{position:absolute;color:#78350f;font-weight:700;font-size:.88rem;z-index:3;}
.pulse-dot{position:absolute;width:80px;height:80px;background:radial-gradient(circle,rgba(239,68,68,.5) 0%,transparent 70%);border-radius:50%;animation:pls 2s infinite;z-index:2;}
@keyframes pls{0%{transform:scale(.5);opacity:1;}100%{transform:scale(2.5);opacity:0;}}
.battle-info-card{background:#fff;border-radius:22px;padding:35px;box-shadow:0 12px 35px rgba(0,0,0,.05);border:1px solid #fee2e2;height:100%;}

/* QURAN TABLE */
.quran-table th{background:var(--dk);color:var(--gold);font-family:'Amiri',serif;font-size:1.1rem;padding:15px;}
.quran-table td{padding:14px 18px;font-size:1rem;vertical-align:middle;}
.quran-table tr:hover td{background:var(--light-red);}

/* HADITH CARDS */
.hadith-card{background:#fff;border-radius:20px;padding:35px;border-right:6px solid var(--pr);box-shadow:0 10px 30px rgba(0,0,0,.04);transition:.3s;}
.hadith-card:hover{border-right-color:var(--gold);box-shadow:0 18px 40px rgba(153,27,27,.08);}
.hadith-text{font-family:'Amiri',serif;font-size:1.3rem;line-height:2.2;color:#1e293b;}
.hadith-source{font-size:.9rem;color:#94a3b8;font-weight:700;}

/* AHL AL BAYT */
.bayt-card{background:radial-gradient(circle at top right,#fff9f0,#fff);border-radius:22px;padding:35px;text-align:center;border:1px solid rgba(212,175,55,.3);box-shadow:0 10px 30px rgba(0,0,0,.04);transition:.4s;height:100%;}
.bayt-card:hover{transform:translateY(-8px);box-shadow:0 20px 45px rgba(212,175,55,.15);border-color:var(--gold);}
.bayt-icon{font-size:3rem;color:var(--gold);margin-bottom:18px;}

/* FOOTER */
.mega-footer{background:linear-gradient(135deg,var(--dk),#020617);color:#fff;padding:70px 0 30px;margin-top:80px;border-top:3px solid var(--gd);}
.mfl{color:rgba(255,255,255,.7);text-decoration:none;transition:.3s;display:block;margin-bottom:10px;}
.mfl:hover{color:var(--gold);padding-right:5px;}
</style>
</head>
<body>
""")
f.close()
print("Part 1 done")
