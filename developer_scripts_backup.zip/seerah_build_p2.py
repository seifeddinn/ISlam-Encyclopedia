import codecs

part2 = """
<!-- TAB 2: GHAZAWAT -->
<div class="tab-pane fade" id="t-ghazawat" role="tabpanel">
  <div class="sec-head">
    <span class="tag">الجهاد والدفاع عن الإسلام</span>
    <h3>الغزوات <span>الكبرى</span></h3>
    <p>المعارك التي خاضها النبي ﷺ دفاعاً عن الإسلام وتوطيداً لدولة المدينة</p>
    <div class="divider"></div>
  </div>
  <div class="row g-4">

    <div class="col-lg-4 col-md-6">
      <div class="ghaz-card">
        <div class="ghaz-top" data-year="بدر" style="background:linear-gradient(135deg,#0d3320,#1a5c3a);">
          <div class="d-flex align-items-center gap-2 mb-2"><i class="fas fa-star" style="color:#c9a66b;"></i><small>2 هـ | 624م</small></div>
          <h5>غزوة بدر الكبرى</h5>
          <small>أول معركة كبرى في الإسلام</small>
        </div>
        <div class="ghaz-body">
          <p>أول المعارك الكبرى. خرج النبي ﷺ في 313 مقاتلاً ليواجه جيش قريش البالغ 1000 رجل. كانت الملائكة قد نزلت بأمر الله لنصرة المسلمين. انتصر المسلمون وقُتل صناديد قريش وأُسر 70.</p>
          <div class="ghaz-stats">
            <span class="ghaz-stat"><i class="fas fa-user-friends me-1"></i>313 مسلم</span>
            <span class="ghaz-stat"><i class="fas fa-chess-rook me-1"></i>ضد 1000</span>
            <span class="ghaz-stat" style="background:#e8f8ef;color:#0d5c2a;border-color:rgba(13,92,42,.2);">نصر مؤزر ✓</span>
          </div>
        </div>
      </div>
    </div>

    <div class="col-lg-4 col-md-6">
      <div class="ghaz-card">
        <div class="ghaz-top" data-year="أحد" style="background:linear-gradient(135deg,#6b2b00,#a04000);">
          <div class="d-flex align-items-center gap-2 mb-2"><i class="fas fa-mountain" style="color:#e8d5a3;"></i><small>3 هـ | 625م</small></div>
          <h5>غزوة أحد</h5>
          <small>درس في الطاعة والثبات</small>
        </div>
        <div class="ghaz-body">
          <p>خرج المشركون بـ3000 مقاتل انتقاماً لبدر. انتصر المسلمون في البداية، ثم أخلّ الرماة بأوامر النبي ﷺ فانعكست الآية. استُشهد 70 صحابياً وجُرح النبي ﷺ في وجهه.</p>
          <div class="ghaz-stats">
            <span class="ghaz-stat"><i class="fas fa-users me-1"></i>700 مسلم</span>
            <span class="ghaz-stat"><i class="fas fa-chess-rook me-1"></i>ضد 3000</span>
            <span class="ghaz-stat" style="background:#fff5f0;color:#a04000;border-color:rgba(160,64,0,.2);">درس وابتلاء</span>
          </div>
        </div>
      </div>
    </div>

    <div class="col-lg-4 col-md-6">
      <div class="ghaz-card">
        <div class="ghaz-top" data-year="خندق" style="background:linear-gradient(135deg,#1c3a5e,#2c6b9e);">
          <div class="d-flex align-items-center gap-2 mb-2"><i class="fas fa-shield-alt" style="color:#e8d5a3;"></i><small>5 هـ | 627م</small></div>
          <h5>غزوة الخندق (الأحزاب)</h5>
          <small>الخندق الذي أنقذ المدينة</small>
        </div>
        <div class="ghaz-body">
          <p>تحالف الأعداء في جيش الأحزاب (10,000 مقاتل) لاجتياح المدينة. اقترح سلمان الفارسي حفر خندق حولها، مما أربك الخصوم. انتهى الحصار بانسحاب الأحزاب دون معركة.</p>
          <div class="ghaz-stats">
            <span class="ghaz-stat"><i class="fas fa-tools me-1"></i>حفر الخندق</span>
            <span class="ghaz-stat"><i class="fas fa-chess-rook me-1"></i>ضد 10,000</span>
            <span class="ghaz-stat" style="background:#e8f8ef;color:#0d5c2a;border-color:rgba(13,92,42,.2);">صمود ونصر ✓</span>
          </div>
        </div>
      </div>
    </div>

    <div class="col-lg-4 col-md-6">
      <div class="ghaz-card">
        <div class="ghaz-top" data-year="مكة" style="background:linear-gradient(135deg,#5c0d00,#9e2a00);">
          <div class="d-flex align-items-center gap-2 mb-2"><i class="fas fa-key" style="color:#e8d5a3;"></i><small>8 هـ | 630م</small></div>
          <h5>فتح مكة المكرمة</h5>
          <small>يوم النصر المبين</small>
        </div>
        <div class="ghaz-body">
          <p>أعظم انتصار في السيرة. دخل النبي ﷺ مكة فاتحاً في 10,000 مقاتل دون قتال تقريباً. طاف بالكعبة وكسر 360 صنماً وقال: "الحق جاء والباطل زهق". عفا عن قريش عفواً عاماً.</p>
          <div class="ghaz-stats">
            <span class="ghaz-stat"><i class="fas fa-horse me-1"></i>10,000 مقاتل</span>
            <span class="ghaz-stat" style="background:#e8f8ef;color:#0d5c2a;border-color:rgba(13,92,42,.2);">فتح كبير ✓</span>
          </div>
        </div>
      </div>
    </div>

    <div class="col-lg-4 col-md-6">
      <div class="ghaz-card">
        <div class="ghaz-top" data-year="حنين" style="background:linear-gradient(135deg,#2d1a00,#6b4000);">
          <div class="d-flex align-items-center gap-2 mb-2"><i class="fas fa-bolt" style="color:#e8d5a3;"></i><small>8 هـ | 630م</small></div>
          <h5>غزوة حنين</h5>
          <small>الثقة بالله لا بالكثرة</small>
        </div>
        <div class="ghaz-body">
          <p>بعد فتح مكة مباشرة. أُعجب بعض المسلمين بكثرتهم فأخلدوا للغفلة، فباغتهم بنو هوازن. ثبت النبي ﷺ وحده ثبات الجبال حتى انقلبت المعركة لصالح المسلمين.</p>
          <div class="ghaz-stats">
            <span class="ghaz-stat"><i class="fas fa-users me-1"></i>12,000 مقاتل</span>
            <span class="ghaz-stat" style="background:#e8f8ef;color:#0d5c2a;border-color:rgba(13,92,42,.2);">نصر بعد ابتلاء ✓</span>
          </div>
        </div>
      </div>
    </div>

    <div class="col-lg-4 col-md-6">
      <div class="ghaz-card">
        <div class="ghaz-top" data-year="تبوك" style="background:linear-gradient(135deg,#1a1a00,#4a4a00);">
          <div class="d-flex align-items-center gap-2 mb-2"><i class="fas fa-sun" style="color:#e8d5a3;"></i><small>9 هـ | 631م</small></div>
          <h5>غزوة تبوك</h5>
          <small>ساعة العسرة والتضحية</small>
        </div>
        <div class="ghaz-body">
          <p>آخر غزوات النبي ﷺ. خرج في أشد قيظ العرب وقلة الزاد لمواجهة الروم في تبوك. أظهر المسلمون عجائب من التضحية — تصدّق أبو بكر بكل ماله وجهز عثمان نصف الجيش.</p>
          <div class="ghaz-stats">
            <span class="ghaz-stat"><i class="fas fa-users me-1"></i>30,000 مقاتل</span>
            <span class="ghaz-stat" style="background:#e8f8ef;color:#0d5c2a;border-color:rgba(13,92,42,.2);">ردع الأعداء ✓</span>
          </div>
        </div>
      </div>
    </div>

  </div>
</div>

<!-- TAB 3: AKHLAQ -->
<div class="tab-pane fade" id="t-akhlaq" role="tabpanel">
  <div class="sec-head">
    <span class="tag">الأسوة الحسنة</span>
    <h3>أخلاقه الكريمة <span>وشمائله</span></h3>
    <p>«وَإِنَّكَ لَعَلَى خُلُقٍ عَظِيمٍ» — قال الله تعالى في القرآن الكريم</p>
    <div class="divider"></div>
  </div>
  <div class="row g-4">
    <div class="col-lg-3 col-md-6"><div class="akhlaq-card"><div class="akhlaq-icon"><i class="fas fa-heart"></i></div><h5 style="color:#3d1500;">الرحمة والشفقة</h5><p class="text-muted small">كان ﷺ أرحم الناس بالأطفال وبالفقراء وحتى بالحيوانات. قال: "الراحمون يرحمهم الرحمن، ارحموا من في الأرض يرحمكم من في السماء".</p></div></div>
    <div class="col-lg-3 col-md-6"><div class="akhlaq-card"><div class="akhlaq-icon"><i class="fas fa-handshake"></i></div><h5 style="color:#3d1500;">الكرم والجود</h5><p class="text-muted small">وصفه جابر بقوله: "ما سُئل رسول الله ﷺ شيئاً فقال لا". كان يعطي أحياناً عطاء من لا يخاف الفقر.</p></div></div>
    <div class="col-lg-3 col-md-6"><div class="akhlaq-card"><div class="akhlaq-icon"><i class="fas fa-smile"></i></div><h5 style="color:#3d1500;">بشاشة الوجه والتبسم</h5><p class="text-muted small">قال جرير: "ما حجبني ﷺ منذ أسلمت، وما رآني إلا تبسّم في وجهي". وقال: "تبسمك في وجه أخيك صدقة".</p></div></div>
    <div class="col-lg-3 col-md-6"><div class="akhlaq-card"><div class="akhlaq-icon"><i class="fas fa-balance-scale"></i></div><h5 style="color:#3d1500;">العدل والاستقامة</h5><p class="text-muted small">قال ﷺ: "لو أن فاطمة بنت محمد سرقت لقطعت يدها". لم يفرّق بين الشريف والوضيع في تطبيق الحق.</p></div></div>
    <div class="col-lg-3 col-md-6"><div class="akhlaq-card"><div class="akhlaq-icon"><i class="fas fa-shield-alt"></i></div><h5 style="color:#3d1500;">الشجاعة والثبات</h5><p class="text-muted small">قال علي: "كنا إذا احمر البأس ولقي القوم القوم اتقينا برسول الله ﷺ، وما كان منا أحد أقرب إلى العدو منه".</p></div></div>
    <div class="col-lg-3 col-md-6"><div class="akhlaq-card"><div class="akhlaq-icon"><i class="fas fa-user-friends"></i></div><h5 style="color:#3d1500;">التواضع</h5><p class="text-muted small">كان يجلس حيث انتهى به المجلس، ولا يفضّل نفسه في المجالس، وكان يُصلّح نعله ويرقع ثوبه ويخدم نفسه.</p></div></div>
    <div class="col-lg-3 col-md-6"><div class="akhlaq-card"><div class="akhlaq-icon"><i class="fas fa-comments"></i></div><h5 style="color:#3d1500;">صدق الحديث</h5><p class="text-muted small">لُقِّب قبل البعثة بـ"الصادق الأمين". لم يكذب ﷺ قط، حتى قال أعداؤه: "نعرف أنك لا تكذب في كلامك".</p></div></div>
    <div class="col-lg-3 col-md-6"><div class="akhlaq-card"><div class="akhlaq-icon"><i class="fas fa-pray"></i></div><h5 style="color:#3d1500;">الزهد والعبادة</h5><p class="text-muted small">قامت قدماه حتى تتورم في صلاة الليل. كان يقول: "أفلا أكون عبداً شكوراً؟". وكان فراشه مطوياً من جلد مملوء ليفاً.</p></div></div>
  </div>
</div>

<!-- TAB 4: SIFAT -->
<div class="tab-pane fade" id="t-sifat" role="tabpanel">
  <div class="sec-head">
    <span class="tag">كما وصفه الصحابة الكرام</span>
    <h3>الصفات الجسدية <span>الشريفة</span></h3>
    <p>وصف الصحابة الكرام شمائلهم النبوية بدقة لا تُضاهى، وكان لهم قلوب يرون بها ما لا يُرى</p>
    <div class="divider"></div>
  </div>
  <div class="sifat-grid">
    <div class="sifat-item"><div class="sifat-icon"><i class="fas fa-user"></i></div><div><strong style="color:#3d1500;">الطول والقامة</strong><p class="text-muted small mb-0">كان ﷺ مربوعاً لا بالطويل ولا بالقصير، وكان إذا مشى مع الطوال كان أطولهم.</p></div></div>
    <div class="sifat-item"><div class="sifat-icon"><i class="fas fa-sun"></i></div><div><strong style="color:#3d1500;">لون البشرة</strong><p class="text-muted small mb-0">كان أبيض مشرباً بحمرة، يتلألأ وجهه كالقمر ليلة البدر.</p></div></div>
    <div class="sifat-item"><div class="sifat-icon"><i class="fas fa-circle"></i></div><div><strong style="color:#3d1500;">الوجه الشريف</strong><p class="text-muted small mb-0">ضخم الرأس، أزج الحاجبين. كان أحسن الناس وجهاً وأحسنهم خُلقاً ولا أحسن منه.</p></div></div>
    <div class="sifat-item"><div class="sifat-icon"><i class="fas fa-eye"></i></div><div><strong style="color:#3d1500;">العينان</strong><p class="text-muted small mb-0">أدعج العينين (شديد سواد الحدقة) أهدب الأشفار (كثيف الرموش).</p></div></div>
    <div class="sifat-item"><div class="sifat-icon"><i class="fas fa-tshirt"></i></div><div><strong style="color:#3d1500;">الشعر الشريف</strong><p class="text-muted small mb-0">كان شعره بين الجعودة والسبوطة، يصل أحياناً إلى شحمة الأذنين وأحياناً إلى كتفيه.</p></div></div>
    <div class="sifat-item"><div class="sifat-icon"><i class="fas fa-star"></i></div><div><strong style="color:#3d1500;">خاتم النبوة</strong><p class="text-muted small mb-0">بين كتفيه ﷺ خاتم النبوة كبيضة الحمامة، تجمّع الشعر حوله.</p></div></div>
    <div class="sifat-item"><div class="sifat-icon"><i class="fas fa-walking"></i></div><div><strong style="color:#3d1500;">مشيته</strong><p class="text-muted small mb-0">كان ﷺ يمشي كأنما ينحطّ من صبَب (منحدر)، وكأن الأرض تُطوى له.</p></div></div>
    <div class="sifat-item"><div class="sifat-icon"><i class="fas fa-wind"></i></div><div><strong style="color:#3d1500;">رائحته الطيبة</strong><p class="text-muted small mb-0">كان ﷺ أطيب الناس رائحة. يعرف مكانه من رائحة عرقه الطيبة الجميلة.</p></div></div>
  </div>
</div>

<!-- TAB 5: FAMILY -->
<div class="tab-pane fade" id="t-family" role="tabpanel">
  <div class="sec-head">
    <span class="tag">ذوو وصحب النبي ﷺ</span>
    <h3>آل البيت <span>والصحابة</span></h3>
    <p>من أحاطوا بالنبي ﷺ وشاركوه رسالته ونقلوا هذا الدين إلى الأجيال</p>
    <div class="divider"></div>
  </div>
  <!-- Azwaj -->
  <h5 style="color:#3d1500;border-right:4px solid var(--gold);padding-right:15px;margin-bottom:25px;">أمهات المؤمنين</h5>
  <div class="row g-3 mb-5">
    <div class="col-md-4"><div class="p-4 rounded-4 bg-white shadow-sm h-100 border-top border-3" style="border-color:#c9a66b!important;"><strong style="color:#3d1500;">السيدة خديجة بنت خويلد</strong><p class="text-muted small mt-2 mb-0">أول زوجاته وأول من آمن به. دعمته في السنوات الأولى بنفسها ومالها. توفيت قبل الهجرة وحزن عليها حزناً شديداً.</p></div></div>
    <div class="col-md-4"><div class="p-4 rounded-4 bg-white shadow-sm h-100 border-top border-3" style="border-color:#c9a66b!important;"><strong style="color:#3d1500;">السيدة عائشة بنت أبي بكر</strong><p class="text-muted small mt-2 mb-0">أحب نسائه إليه. روت أكثر من 2000 حديث. أُوحي إليه ﷺ في فراشها، وتوفي في حجرها.</p></div></div>
    <div class="col-md-4"><div class="p-4 rounded-4 bg-white shadow-sm h-100 border-top border-3" style="border-color:#c9a66b!important;"><strong style="color:#3d1500;">السيدة حفصة بنت عمر</strong><p class="text-muted small mt-2 mb-0">ابنة عمر بن الخطاب. عُهد إليها بحفظ المصحف الأصلي في عهد أبي بكر الصديق.</p></div></div>
  </div>
  <!-- Asharat -->
  <h5 style="color:#3d1500;border-right:4px solid var(--gold);padding-right:15px;margin-bottom:25px;">العشرة المبشرون بالجنة</h5>
  <div class="row g-2 mb-2">
    <div class="col-6 col-md-3"><div class="p-3 rounded-3 text-center bg-white shadow-sm"><i class="fas fa-medal text-warning d-block mb-2 fs-4"></i><strong style="color:#3d1500;font-size:.9rem;">أبو بكر الصديق</strong></div></div>
    <div class="col-6 col-md-3"><div class="p-3 rounded-3 text-center bg-white shadow-sm"><i class="fas fa-medal text-warning d-block mb-2 fs-4"></i><strong style="color:#3d1500;font-size:.9rem;">عمر بن الخطاب</strong></div></div>
    <div class="col-6 col-md-3"><div class="p-3 rounded-3 text-center bg-white shadow-sm"><i class="fas fa-medal text-warning d-block mb-2 fs-4"></i><strong style="color:#3d1500;font-size:.9rem;">عثمان بن عفان</strong></div></div>
    <div class="col-6 col-md-3"><div class="p-3 rounded-3 text-center bg-white shadow-sm"><i class="fas fa-medal text-warning d-block mb-2 fs-4"></i><strong style="color:#3d1500;font-size:.9rem;">علي بن أبي طالب</strong></div></div>
    <div class="col-6 col-md-3"><div class="p-3 rounded-3 text-center bg-white shadow-sm"><i class="fas fa-medal text-warning d-block mb-2 fs-4"></i><strong style="color:#3d1500;font-size:.9rem;">طلحة بن عبيد الله</strong></div></div>
    <div class="col-6 col-md-3"><div class="p-3 rounded-3 text-center bg-white shadow-sm"><i class="fas fa-medal text-warning d-block mb-2 fs-4"></i><strong style="color:#3d1500;font-size:.9rem;">الزبير بن العوام</strong></div></div>
    <div class="col-6 col-md-3"><div class="p-3 rounded-3 text-center bg-white shadow-sm"><i class="fas fa-medal text-warning d-block mb-2 fs-4"></i><strong style="color:#3d1500;font-size:.9rem;">سعد بن أبي وقاص</strong></div></div>
    <div class="col-6 col-md-3"><div class="p-3 rounded-3 text-center bg-white shadow-sm"><i class="fas fa-medal text-warning d-block mb-2 fs-4"></i><strong style="color:#3d1500;font-size:.9rem;">سعيد بن زيد</strong></div></div>
    <div class="col-6 col-md-3"><div class="p-3 rounded-3 text-center bg-white shadow-sm"><i class="fas fa-medal text-warning d-block mb-2 fs-4"></i><strong style="color:#3d1500;font-size:.9rem;">عبد الرحمن بن عوف</strong></div></div>
    <div class="col-6 col-md-3"><div class="p-3 rounded-3 text-center bg-white shadow-sm"><i class="fas fa-medal text-warning d-block mb-2 fs-4"></i><strong style="color:#3d1500;font-size:.9rem;">أبو عبيدة الجراح</strong></div></div>
  </div>
</div>

</div><!-- end tab-content -->
</div><!-- end container -->

<!-- FOOTER -->
<footer class="mega-footer" style="background:linear-gradient(135deg,var(--dark),#020617);color:white;padding:80px 0 30px;margin-top:80px;border-top:3px solid var(--gold-dark);">
  <div class="container">
    <div class="row g-5 mb-5 border-bottom border-light border-opacity-10 pb-5">
      <div class="col-lg-4 text-md-end text-center">
        <i class="fas fa-mosque fa-4x text-warning mb-4 d-block"></i>
        <h4 class="fw-bold font-amiri fs-2 mb-3">الموسوعة الإسلامية الشاملة</h4>
        <p class="opacity-75 fs-6 line-height-2">أضخم صرح رقمي يجمع علوم القرآن العظيم، وأحاديث المصطفى، وفقهاء المذاهب، والتاريخ المجيد في منصة موثقة مصممة بأحدث التقنيات.</p>
      </div>
      <div class="col-lg-4 text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">تصفح الموسوعة</h5>
        <div class="d-flex flex-wrap justify-content-center gap-2">
          <a href="recitations.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">أكاديمية القرآن</a>
          <a href="hadith.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الحديث النبوي</a>
          <a href="seerah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">السيرة والصحابة</a>
          <a href="fiqh.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الفقه وأصوله</a>
          <a href="fatwa.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">فتاوى العلماء</a>
          <a href="aqeedah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">العقيدة الإسلامية</a>
          <a href="history.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">التاريخ المجيد</a>
          <a href="library.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">المكتبة الشاملة</a>
        </div>
      </div>
      <div class="col-lg-4 text-md-start text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">روابط سريعة</h5>
        <a href="contact.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> اتصل بالمطور</a>
        <a href="share.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> شارك الأجر</a>
        <a href="login.html" class="mega-footer-link text-warning mt-3" style="text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-user-circle me-2 ms-1"></i> تسجيل الدخول</a>
      </div>
    </div>
    <div class="text-center font-amiri fs-5 d-flex flex-column gap-2">
      <span class="opacity-75">الموسوعة الإسلامية الشاملة &copy; 2026 تم التصميم للإفادة | عمل مجاني لوجه الله</span>
      <span class="text-warning fw-bold fs-4 mt-2">تصميم وتطوير: لخذاري محمد سيف الدين</span>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Animate timeline items on scroll
const tlItems = document.querySelectorAll('.tl-card');
const obs = new IntersectionObserver(entries=>{
  entries.forEach(e=>{ if(e.isIntersecting){e.target.style.opacity='1';e.target.style.transform='translateY(0)';} });
},{threshold:0.15});
tlItems.forEach(el=>{el.style.opacity='0';el.style.transform='translateY(30px)';el.style.transition='all .6s ease';obs.observe(el);});
</script>
</body></html>
"""

with codecs.open(r"c:\Users\ST\Desktop\islamic.encyclopedia\seerah_p2.tmp", 'w', 'utf-8') as f:
    f.write(part2)

# Merge
parts = []
for fn in ['seerah_p1.tmp', 'seerah_p2.tmp']:
    with codecs.open(r"c:\Users\ST\Desktop\islamic.encyclopedia\\" + fn, 'r', 'utf-8') as f:
        parts.append(f.read())

with codecs.open(r"c:\Users\ST\Desktop\islamic.encyclopedia\seerah.html", 'w', 'utf-8') as f:
    f.write(''.join(parts))

import os
for fn in ['seerah_p1.tmp','seerah_p2.tmp']:
    try: os.remove(r"c:\Users\ST\Desktop\islamic.encyclopedia\\" + fn)
    except: pass

print("seerah.html rebuilt successfully!")
