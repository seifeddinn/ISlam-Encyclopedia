import codecs, re

# Read current seerah.html
txt = codecs.open("seerah.html","r","utf-8").read()

# 1. Remove TAB 3 (Sahaba) nav button
txt = re.sub(r'\s*<li class="nav-item"><button[^>]*data-bs-target="#t3"[^<]*</button></li>', '', txt)

# 2. Remove TAB 5 (Ahl al Bayt) nav button
txt = re.sub(r'\s*<li class="nav-item"><button[^>]*data-bs-target="#t5"[^<]*</button></li>', '', txt)

# 3. Remove TAB 3 content block
t3_start = txt.find("<!-- TAB 3: SAHABA")
t3_end_marker = "<!-- end t3 -->"
t3_end = txt.find(t3_end_marker) + len(t3_end_marker)
if t3_start > 0 and t3_end > len(t3_end_marker):
    txt = txt[:t3_start] + txt[t3_end:]
    print("TAB 3 removed OK")
else:
    print("TAB 3 NOT FOUND", t3_start, t3_end)

# 4. Remove TAB 5 content block (recalc after t3 removal)
t5_start = txt.find("<!-- TAB 5: AHL AL BAYT -->")
t5_end_marker = "<!-- end t5 -->"
t5_end = txt.find(t5_end_marker) + len(t5_end_marker)
if t5_start > 0 and t5_end > len(t5_end_marker):
    txt = txt[:t5_start] + txt[t5_end:]
    print("TAB 5 removed OK")
else:
    print("TAB 5 NOT FOUND", t5_start, t5_end)

# 5. Fix tab targets: renumber t4->t3, t6->t4, t7->t5
# (battles->t3, quran->t4, hadith->t5)
txt = txt.replace('data-bs-target="#t4"', 'data-bs-target="#t3_battle"')
txt = txt.replace('data-bs-target="#t6"', 'data-bs-target="#t4_quran"')
txt = txt.replace('data-bs-target="#t7"', 'data-bs-target="#t5_hadith"')
txt = txt.replace('id="t4"', 'id="t3_battle"')
txt = txt.replace('id="t6"', 'id="t4_quran"')
txt = txt.replace('id="t7"', 'id="t5_hadith"')

# 6. Remove sahaba-related CSS classes to clean up
txt = re.sub(r'/\* SAHABA \*/.*?/\* BATTLES \*/', '/* BATTLES */', txt, flags=re.DOTALL)

# 7. Fix footer: ensure developer credit is present, fix any about.html links
txt = txt.replace('href="about.html"', 'href="search.html"')

# Write result
codecs.open("seerah.html","w","utf-8").write(txt)
print("Done! Size:", len(txt), "chars")
