
    <!-- TAB 4: THE 10 QIRAAT MEGA -->
    <div class="tab-pane fade" id="tab-qiraat">
      <div class="sec-head">
        <span class="tag">تواتر القراءة والسند القطعي</span>
        <h3>القراءات العشر <span>المتواترة والأصول</span></h3>
        <p>رحلة في علوم القراءات، للتعرف على القراء السبعة والثلاثة المتممين، ورواتهم، وأصول قواعدهم التي بنوا عليها قراءتهم.</p>
        <div class="divider"></div>
      </div>
      
      <!-- Timeline of Imams -->
      <div class="mb-5">
         <h4 class="font-amiri fw-bold text-dark mb-4 border-bottom pb-2 border-emerald d-inline-block">التسلسل الزمني لأئمة القراءات (حاضرات العالم الإسلامي)</h4>
         <p class="text-muted mb-4 fs-5">توزع الأئمة العشرة على حواضر الإسلام الكبرى العريقة (المدينة، مكة، الكوفة، البصرة، الشام).</p>
         
         <div class="row g-3">
            <div class="col-lg-2 col-md-4 col-sm-6 text-center">
               <div class="mega-card bg-light border-0 py-4">
                  <div class="badge bg-gold text-dark mb-3 px-3 py-2 rounded-pill shadow-sm">المدينة المنورة</div>
                  <h5 class="fw-bold text-primary">أبو جعفر المدني</h5><p class="small text-muted mb-1">(ت 130 هـ)</p>
                  <hr class="w-50 mx-auto">
                  <h5 class="fw-bold text-primary">نافع المدني</h5><p class="small text-muted mb-0">(ت 169 هـ)</p>
               </div>
            </div>
            
            <div class="col-lg-2 col-md-4 col-sm-6 text-center">
               <div class="mega-card bg-light border-0 py-4">
                  <div class="badge bg-gold text-dark mb-3 px-3 py-2 rounded-pill shadow-sm">مكة المكرمة</div>
                  <h5 class="fw-bold text-success">ابن كثير المكي</h5><p class="small text-muted mb-0">(ت 120 هـ)</p>
               </div>
            </div>

            <div class="col-lg-2 col-md-4 col-sm-6 text-center">
               <div class="mega-card bg-light border-0 py-4">
                  <div class="badge bg-gold text-dark mb-3 px-3 py-2 rounded-pill shadow-sm">الشام (دمشق)</div>
                  <h5 class="fw-bold text-danger">ابن عامر الشامي</h5><p class="small text-muted mb-0">(ت 118 هـ)</p>
                  <p class="small mt-2 text-warning fw-bold">أعلى القراء سنداً</p>
               </div>
            </div>

            <div class="col-lg-4 col-md-6 text-center">
               <div class="mega-card bg-light border-0 py-4 p-x-2">
                  <div class="badge bg-gold text-dark mb-3 px-3 py-2 rounded-pill shadow-sm">الكوفة (العراق)</div>
                  <div class="d-flex justify-content-center gap-3 flex-wrap">
                     <div><h6 class="fw-bold text-info mb-0">عاصم بن أبي النجود</h6><small class="text-muted">(ت 127 هـ)</small></div>
                     <div class="border-start border-end px-3"><h6 class="fw-bold text-info mb-0">حمزة الزيات</h6><small class="text-muted">(ت 156 هـ)</small></div>
                     <div><h6 class="fw-bold text-info mb-0">الكسائي</h6><small class="text-muted">(ت 189 هـ)</small></div>
                     <div class="w-100 mt-2"><h6 class="fw-bold text-info mb-0">خلف العاشر</h6><small class="text-muted">(ت 229 هـ)</small></div>
                  </div>
               </div>
            </div>

            <div class="col-lg-2 col-md-6 text-center">
               <div class="mega-card bg-light border-0 py-4">
                  <div class="badge bg-gold text-dark mb-3 px-3 py-2 rounded-pill shadow-sm">البصرة (العراق)</div>
                  <h5 class="fw-bold text-secondary">أبو عمرو البصري</h5><p class="small text-muted mb-1">(ت 154 هـ)</p>
                  <hr class="w-50 mx-auto">
                  <h5 class="fw-bold text-secondary">يعقوب الحضرمي</h5><p class="small text-muted mb-0">(ت 205 هـ)</p>
               </div>
            </div>
         </div>
      </div>

      <!-- Origins of Qiraat -->
      <div class="mb-5 pt-4">
         <h4 class="font-amiri fw-bold text-dark mb-4 border-bottom pb-2 border-emerald d-inline-block">مبادئ وأصول القراءات الكبرى</h4>
         <div class="row g-4">
            <div class="col-md-4">
               <div class="mega-card border-top border-4 border-primary">
                  <h5 class="fw-bold text-primary mb-3">الإمالة والتقليل</h5>
                  <p class="text-muted small">أن تنحو بالفتحة نحو الكسرة، وبالألف نحو الياء (مثل كلمة <i>موسى، الضحى</i>). الإمالة الكبرى اشتهر بها حمزة والكسائي. والتقليل (بين الفتح والإمالة) اشتهر به ورش عن نافع.</p>
               </div>
            </div>
            <div class="col-md-4">
               <div class="mega-card border-top border-4 border-danger">
                  <h5 class="fw-bold text-danger mb-3">الهمزتين وتسهيلهما</h5>
                  <p class="text-muted small">إذا التقت همزتان (مثل <i>ءأنذرتهم</i>)، يميل القراء أهل الحجاز وأبو عمرو لعدم تحقيق الهمزة الثانية، بل يتم تسهيلها (بين الهمزة وحرف المد) لتخفيف النطق.</p>
               </div>
            </div>
            <div class="col-md-4">
               <div class="mega-card border-top border-4 border-success">
                  <h5 class="fw-bold text-success mb-3">الإدغام الكبير</h5>
                  <p class="text-muted small">إدغام حرف متحرك في حرف متحرك آخر بحيث يصيران حرفاً واحداً مشدداً (مثل <i>الرَّحِيمِ مَالِكِ</i>). وهذا الأصل تفرّد به السوسي عن أبي عمرو لسهولة ولين قراءته.</p>
               </div>
            </div>
            <div class="col-md-4">
               <div class="mega-card border-top border-4 border-warning">
                  <h5 class="fw-bold text-warning mb-3">صلة ميم الجمع</h5>
                  <p class="text-muted small">ضم ميم الجمع ووصلها بواو (مثل <i>عَلَيْهِمْ</i> تُقرأ <i>عَلَيْهِمُو</i>). اشتهر بها ابن كثير المكي مطلقاً، وقالون بخلف عنه، وورش إذا جاء بعدها همزة قطع.</p>
               </div>
            </div>
            <div class="col-md-4">
               <div class="mega-card border-top border-4 border-info">
                  <h5 class="fw-bold text-info mb-3">النقل والسكت</h5>
                  <p class="text-muted small">النقل: نقل حركة الهمزة للساكن قبلها (<i>الأَرض</i> تُقرأ <i>لَرض</i>) لورش. السكت: قطع الصوت زمناً يسيراً دون تنفس (السكت على الساكن قبل الهمز) لحمزة.</p>
               </div>
            </div>
         </div>
      </div>

      <!-- Mega Compare Table -->
      <div class="bg-white p-5 rounded-4 shadow-sm border text-center">
        <h4 class="font-amiri fw-bold mb-4 text-dark">نماذج مقارنة وتطبيق عملي من القرآن</h4>
        <div class="table-responsive">
          <table class="table table-bordered table-striped align-middle text-center dir-rtl">
            <thead class="table-dark">
              <tr>
                <th width="15%">الموضع</th>
                <th width="20%">حفص عن عاصم</th>
                <th width="20%">ورش عن نافع (المدينة)</th>
                <th width="20%">حمزة الكوفي</th>
                <th width="25%">السوسي المدغم (البصرة)</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td class="bg-light fw-bold text-danger">(مَالِكِ يَوْمِ)</td>
                <td>مَالِكِ (بإثبات الألف)</td>
                <td>مَلِكِ (بحذف الألف)</td>
                <td>مَلِكِ (بحذف الألف)</td>
                <td>مَلِكِ (بحذف الألف)</td>
              </tr>
              <tr>
                <td class="bg-light fw-bold text-danger">(الصِّرَاطَ)</td>
                <td>بالصاد الخالصة</td>
                <td>بالصاد الخالصة</td>
                <td>بإشمام الصاد زايا (تُنطق الزراط) لخلف</td>
                <td>بالصاد</td>
              </tr>
              <tr>
                <td class="bg-light fw-bold text-danger">(وَبِالآخِرَةِ)</td>
                <td>بالتحقيق للهمز ومد البدل حركتين</td>
                <td>نقل حركة الهمز ومد البدل 2/4/6 (<i>وبِلاخِرَة</i>)</td>
                <td>تحقيق وتسهيل في الوقف</td>
                <td>تحقيق الهمز كحفص</td>
              </tr>
              <tr>
                <td class="bg-light fw-bold text-danger">(فِيهِ هُدىً)</td>
                <td>إظهار الهاء، والوقف عليها</td>
                <td>إظهار الهاء</td>
                <td>إظهار الهاء</td>
                <td>إدغام الهاءين كبيراً (<i>فِيـهُّـدَى</i>)</td>
              </tr>
              <tr>
                <td class="bg-light fw-bold text-danger">(وَالضُّحَىٰ)</td>
                <td>بفتح الألف الخالصة</td>
                <td>بالتقليل وجهاً واحداً</td>
                <td>بالإمالة الكبرى (الكسر الشديد)</td>
                <td>طبيعي كحفص</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
