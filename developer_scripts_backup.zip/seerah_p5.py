import codecs
f = codecs.open("seerah.html","a","utf-8")
f.write("""
<!-- TAB 3: SAHABA & MOTHERS -->
<div class="tab-pane fade" id="t3">
  <div class="sec-head" data-aos="fade-up">
    <div class="badge-tag">نجوم الاهتداء ومصابيح الدجى</div>
    <h2 class="amiri">الصحابة الكرام <span>وأمهات المؤمنين</span></h2>
    <p>الرعيل الأول المبشرون بالجنة وزوجاته الطاهرات رضي الله عنهم أجمعين</p>
    <div class="gold-divider"></div>
  </div>
  <div class="filter-bar" data-aos="fade-up">
    <button class="active" onclick="filterC(event,'all')">الجميع</button>
    <button onclick="filterC(event,'ten')">العشرة المبشرون بالجنة</button>
    <button onclick="filterC(event,'mom')">أمهات المؤمنين الطاهرات (11)</button>
    <button onclick="filterC(event,'hero')">أبطال إضافيون</button>
  </div>
  <div class="row g-4" id="cgrid">
    <!-- الخلفاء + العشرة -->
    <div class="col-lg-4 col-md-6 ci ten" data-aos="zoom-in"><div class="comp-card"><div class="comp-rank">أول الخلفاء · الصديق</div><div class="comp-name">أبو بكر الصديق ؓ</div><p>أفضل الصحابة وأول من آمن من الرجال. ثبّت الأمة بعد وفاة النبي وحارب المرتدين وبدأ في عهده جمع القرآن الكريم.</p></div></div>
    <div class="col-lg-4 col-md-6 ci ten" data-aos="zoom-in" data-aos-delay="50"><div class="comp-card"><div class="comp-rank">ثاني الخلفاء · الفاروق</div><div class="comp-name">عمر بن الخطاب ؓ</div><p>أعزّ الله به الإسلام. بطل الفتوحات ومؤسس الدواوين والتقويم الهجري. "عبقري العبقريين" في العدل والرأي والسياسة.</p></div></div>
    <div class="col-lg-4 col-md-6 ci ten" data-aos="zoom-in" data-aos-delay="100"><div class="comp-card"><div class="comp-rank">ثالث الخلفاء · ذو النورين</div><div class="comp-name">عثمان بن عفان ؓ</div><p>جمع المصحف الكريم على حرف واحد. تزوج ابنتي النبي تباعاً، وجهّز جيش العسرة بجميل سخائه وأموال تجارته.</p></div></div>
    <div class="col-lg-4 col-md-6 ci ten" data-aos="zoom-in"><div class="comp-card"><div class="comp-rank">رابع الخلفاء · فدائي الهجرة</div><div class="comp-name">علي بن أبي طالب ؓ</div><p>ابن عم النبي وزوج فاطمة. نام في فراشه ليلة الهجرة فداءً له. باب مدينة العلم وبطل المشاهد وصاحب ذي الفقار.</p></div></div>
    <div class="col-lg-4 col-md-6 ci ten" data-aos="zoom-in" data-aos-delay="50"><div class="comp-card"><div class="comp-rank">أمين هذه الأمة</div><div class="comp-name">أبو عبيدة بن الجراح ؓ</div><p>نزع حلقتي المغفر من وجه النبي بثنيتيه يوم أحد. قائد جيوش الشام وفاتحها الزاهد الورع الأمين.</p></div></div>
    <div class="col-lg-4 col-md-6 ci ten" data-aos="zoom-in" data-aos-delay="100"><div class="comp-card"><div class="comp-rank">طلحة الخير والفياض</div><div class="comp-name">طلحة بن عبيد الله ؓ</div><p>الشهيد الحي الذي صوّب جسده درعاً للنبي يوم أُحُد حتى شُلّت يمينه الكريمة. عُرف بكثرة إنفاقه وجوده.</p></div></div>
    <div class="col-lg-4 col-md-6 ci ten" data-aos="zoom-in"><div class="comp-card"><div class="comp-rank">حواري رسول الله</div><div class="comp-name">الزبير بن العوام ؓ</div><p>أول من سلّ سيفاً في سبيل الله. ابن عمة النبي وصنديد الفرسان الذي يقتحم صفوف الأعداء بلا هوادة.</p></div></div>
    <div class="col-lg-4 col-md-6 ci ten" data-aos="zoom-in" data-aos-delay="50"><div class="comp-card"><div class="comp-rank">فاتح العراقَين · مستجاب الدعوة</div><div class="comp-name">سعد بن أبي وقاص ؓ</div><p>خال النبي وأول من رمى بسهم في سبيل الله. قائد القادسية قاهر الإمبراطورية الفارسية وباني الكوفة والبصرة.</p></div></div>
    <div class="col-lg-4 col-md-6 ci ten" data-aos="zoom-in" data-aos-delay="100"><div class="comp-card"><div class="comp-rank">من الأوائل · سبب إسلام عمر</div><div class="comp-name">سعيد بن زيد ؓ</div><p>من أسلم قبل دخول النبي دار الأرقم. شهد كل المشاهد إلا بدراً، وكان سبب إسلام عمر بن الخطاب مع أخته فاطمة.</p></div></div>
    <div class="col-lg-4 col-md-6 ci ten" data-aos="zoom-in"><div class="comp-card"><div class="comp-rank">التاجر الأمين الشكور</div><div class="comp-name">عبد الرحمن بن عوف ؓ</div><p>أغنى الصحابة وأزهدهم. تصدّق بقوافل كاملة في سبيل الله، وأحد الستة أصحاب الشورى وصاحب أمانة الإسلام.</p></div></div>
    <!-- Mothers of Believers -->
    <div class="col-lg-4 col-md-6 ci mom" data-aos="zoom-in"><div class="comp-card mom-card"><div class="comp-rank">أم المؤمنين الأولى · السيدة</div><div class="comp-name">خديجة بنت خويلد ؓ</div><p>أول من آمن به وناصرته بمالها ونفسها. أحبها النبي حباً لا مثيل له. أقرأها الله السلام من فوق سبع سماوات. أم أبنائه كلهم إلا إبراهيم.</p></div></div>
    <div class="col-lg-4 col-md-6 ci mom" data-aos="zoom-in" data-aos-delay="50"><div class="comp-card mom-card"><div class="comp-rank">أم المؤمنين العالمة المحدِّثة</div><div class="comp-name">عائشة بنت أبي بكر ؓ</div><p>أحب النساء إليه. المبرأة من السماء في حادثة الإفك. أكثر راوي الحديث النبوي وأعلم فقيهات الصحابة. توفي ووجهه الشريف على صدرها.</p></div></div>
    <div class="col-lg-4 col-md-6 ci mom" data-aos="zoom-in" data-aos-delay="100"><div class="comp-card mom-card"><div class="comp-rank">حارسة المصحف الأول</div><div class="comp-name">حفصة بنت عمر ؓ</div><p>الصوامة القوامة والعابدة الزاهدة. أُمِنت على أول مصحف شريف جمعه الصديق فحفظته عندها حتى نُسخ في عهد عثمان.</p></div></div>
    <div class="col-lg-4 col-md-6 ci mom" data-aos="zoom-in"><div class="comp-card mom-card"><div class="comp-rank">أم المؤمنين ذات الرأي</div><div class="comp-name">أم سلمة هند بنت أبي أمية ؓ</div><p>الحكيمة أصحاب الرأي السديد. هي التي أشارت يوم الحديبية بأن يحلق النبي رأسه أولاً ففعل الصحابة مثله.</p></div></div>
    <div class="col-lg-4 col-md-6 ci mom" data-aos="zoom-in" data-aos-delay="50"><div class="comp-card mom-card"><div class="comp-rank">أم المؤمنين الصوامة</div><div class="comp-name">زينب بنت جحش ؓ</div><p>تزوجها النبي بأمر من الله تعالى، وهي التي كانت تفخر قائلة: "زوّجكن آباؤكن وزوّجني الله من فوق سبع سماوات."</p></div></div>
    <div class="col-lg-4 col-md-6 ci mom" data-aos="zoom-in" data-aos-delay="100"><div class="comp-card mom-card"><div class="comp-rank">أم المؤمنين وأم المساكين</div><div class="comp-name">زينب بنت خزيمة ؓ</div><p>عُرفت بـ"أم المساكين" في جاهليتها وإسلامها لكثرة رعايتها للفقراء. توفيت بعد زواجها بأشهر قليلة.</p></div></div>
    <!-- Hero companions -->
    <div class="col-lg-4 col-md-6 ci hero" data-aos="zoom-in"><div class="comp-card" style="border-bottom-color:var(--gd);"><div class="comp-rank" style="background:var(--gd);">سيف الله المسلول</div><div class="comp-name">خالد بن الوليد ؓ</div><p>أعظم قائد عسكري في تاريخ الإسلام. لم يُهزم في معركة قط. بطل اليرموك والقادسية وعين جالوت والعراق والشام.</p></div></div>
    <div class="col-lg-4 col-md-6 ci hero" data-aos="zoom-in" data-aos-delay="50"><div class="comp-card" style="border-bottom-color:var(--gd);"><div class="comp-rank" style="background:var(--gd);">فاتح مصر · ذو الدهاء</div><div class="comp-name">عمرو بن العاص ؓ</div><p>أسلم بعد الحديبية. فاتح الإسكندرية ومصر بجيش أربعة آلاف فارس. صاحب الدهاء والحيلة في الحرب والسياسة.</p></div></div>
    <div class="col-lg-4 col-md-6 ci hero" data-aos="zoom-in" data-aos-delay="100"><div class="comp-card" style="border-bottom-color:var(--gd);"><div class="comp-rank" style="background:var(--gd);">أسد الله وأسد رسوله</div><div class="comp-name">حمزة بن عبد المطلب ؓ</div><p>عم النبي وبطل غزوة بدر وأُحُد. استُشهد في أحد وبكى النبي عليه طويلاً وسمّاه سيد الشهداء.</p></div></div>
  </div>
</div><!-- end t3 -->
""")
f.close()
print("Part 5 done")
