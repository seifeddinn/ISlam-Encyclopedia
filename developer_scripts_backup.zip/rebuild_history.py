import codecs

html = """<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>موسوعة التاريخ الإسلامي - الموسوعة الإسلامية الشاملة</title>
<link href="https://fonts.googleapis.com/css2?family=Amiri:ital,wght@0,400;0,700;1,400&family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root{--gold:#d4af37;--gold2:#f3e5ab;--dark:#0b1120;--indigo:#1e1b4b;--slate:#334155;}
body{font-family:'Cairo',sans-serif;background:#f8fafc;color:#0f172a;overflow-x:hidden;}
h1,h2,h3,h4,.ar{font-family:'Amiri',serif;}

/* NAVBAR */
.navbar {background:linear-gradient(135deg,#0b1120,#1e1b4b)!important;box-shadow:0 10px 30px rgba(0,0,0,.5);border-bottom:1px solid rgba(212,175,55,.15);}
.navbar-brand {font-family:'Amiri',serif;font-size:1.6rem;color:white!important;}
.nav-link {color:rgba(255,255,255,.8)!important;font-weight:700;transition:.3s;}
.nav-link:hover, .nav-link.active {color:var(--gold)!important;transform:translateY(-2px);}

/* HERO */
.history-hero{min-height:600px;background:linear-gradient(160deg,#0b1120 0%,#17193b 45%,#2c1b4d 100%);position:relative;overflow:hidden;display:flex;align-items:center;padding:100px 0;}
.orb{position:absolute;border-radius:50%;filter:blur(100px);opacity:.2;animation:orb 12s infinite alternate;}
.orb:nth-child(1){width:600px;height:600px;background:#d4af37;top:-200px;right:-100px;}
.orb:nth-child(2){width:400px;height:400px;background:#8b5cf6;bottom:-100px;left:0;animation-delay:4s;}
.orb:nth-child(3){width:250px;height:250px;background:#fff;top:30%;left:40%;animation-delay:7s;}
@keyframes orb{from{transform:scale(1) translate(0,0)}to{transform:scale(1.2) translate(30px,30px)}}
.hero-pattern{position:absolute;inset:0;background:url('https://www.transparenttextures.com/patterns/arabesque.png');opacity:.05;}
.hero-content{position:relative;z-index:5;color:white;}
.hero-eyebrow{display:inline-block;border:1px solid rgba(212,175,55,.3);background:rgba(212,175,55,.1);backdrop-filter:blur(10px);color:var(--gold2);border-radius:40px;padding:8px 24px;font-size:.85rem;font-weight:700;margin-bottom:20px;}
.history-hero h1{font-size:4rem;font-weight:bold;margin-bottom:15px;background:linear-gradient(135deg,#fff 30%,var(--gold2) 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;line-height:1.2;}
.tagline{color:rgba(255,255,255,.65);font-size:1.2rem;margin-bottom:40px;line-height:2;}
.hero-quote{background:rgba(255,255,255,.05);border:1px solid rgba(212,175,55,.2);border-right:4px solid var(--gold);border-radius:16px;padding:22px 26px;max-width:650px;backdrop-filter:blur(12px);}
.hero-quote p{font-family:'Amiri',serif;font-size:1.35rem;line-height:2;color:white;margin:0;}
.hero-quote small{color:rgba(255,255,255,.4);font-size:.85rem;}

/* MAP DECORATION */
.map-bg{position:absolute;top:50%;left:-5%;transform:translateY(-50%);width:50%;opacity:.1;pointer-events:none;}

/* TIMELINE V2 */
.timeline-v2{position:relative;padding:80px 0;margin-top:-30px;}
.timeline-v2::before{content:'';position:absolute;right:50%;top:0;bottom:0;width:2px;background:linear-gradient(180deg,transparent,var(--gold),transparent);}
.tv2-item{display:flex;justify-content:space-between;align-items:center;margin-bottom:60px;position:relative;}
.tv2-item:nth-child(even){flex-direction:row-reverse;}
.tv2-col{width:calc(50% - 40px);}
.tv2-dot{width:30px;height:30px;background:var(--gold);border-radius:50%;position:absolute;right:50%;transform:translateX(50%);box-shadow:0 0 0 8px rgba(212,175,55,.2), 0 0 20px rgba(212,175,55,.6);z-index:2;}
.tv2-card{background:white;padding:30px;border-radius:24px;box-shadow:0 15px 40px rgba(11,17,32,.08);position:relative;transition:.4s;border-right:5px solid var(--indigo);}
.tv2-item:nth-child(even) .tv2-card{border-right:none;border-left:5px solid var(--gold);}
.tv2-card:hover{transform:translateY(-10px);box-shadow:0 25px 50px rgba(11,17,32,.15);}
.tv2-year{position:absolute;top:-20px;background:var(--indigo);color:white;padding:5px 20px;border-radius:30px;font-weight:800;font-size:.9rem;box-shadow:0 5px 15px rgba(30,27,75,.3);}
.tv2-item:nth-child(even) .tv2-year{background:var(--gold);color:#0b1120;}
.tv2-card h4{color:#0b1120;font-weight:800;margin-top:10px;margin-bottom:12px;font-size:1.6rem;}
.tv2-card p{color:#475569;line-height:1.9;font-size:.95rem;margin:0;}

/* ERAS GRID */
.eras-section{padding:80px 0;background:#fff;}
.sec-head{text-align:center;margin-bottom:60px;}
.sec-head .tag{display:inline-block;background:rgba(212,175,55,.1);color:#b48600;border-radius:40px;padding:6px 20px;font-size:.85rem;font-weight:700;margin-bottom:15px;}
.sec-head h2{font-size:2.8rem;color:#0b1120;font-weight:800;margin-bottom:10px;}
.sec-head p{color:#64748b;max-width:600px;margin:0 auto;font-size:1.1rem;}
.sec-head .divider{width:70px;height:4px;background:linear-gradient(90deg,var(--gold),var(--gold2));border-radius:2px;margin:20px auto 0;}

.era-card{border-radius:20px;overflow:hidden;background:white;box-shadow:0 10px 30px rgba(11,17,32,.06);transition:.5s;height:100%;position:relative;border:1px solid rgba(0,0,0,.04);}
.era-card:hover{transform:translateY(-10px);box-shadow:0 20px 40px rgba(11,17,32,.12);}
.era-header{padding:40px 30px;position:relative;overflow:hidden;color:white;}
.era-header::after{content:'';position:absolute;inset:0;background:url('https://www.transparenttextures.com/patterns/arabesque.png');opacity:.1;}
.era-icon{position:absolute;left:-20px;bottom:-20px;font-size:8rem;opacity:.08;}
.era-header h3{font-size:1.8rem;font-weight:800;margin-bottom:5px;position:relative;z-index:2;}
.era-span{font-size:.9rem;opacity:.8;position:relative;z-index:2;}
.era-body{padding:30px;}
.era-body p{color:#475569;line-height:1.8;font-size:.9rem;}
.era-feature{display:flex;align-items:center;gap:12px;margin-top:15px;color:#0f172a;font-weight:600;font-size:.9rem;background:#f8fafc;padding:10px 15px;border-radius:12px;}
.era-feature i{color:var(--gold);font-size:1.2rem;}

/* FIGURES */
.figures-section{padding:80px 0;background:linear-gradient(135deg,#0b1120,#1e1b4b);color:white;position:relative;overflow:hidden;}
.figure-card{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:20px;padding:30px;text-align:center;transition:.4s;backdrop-filter:blur(10px);height:100%;}
.figure-card:hover{background:rgba(255,255,255,.1);transform:translateY(-10px);border-color:var(--gold);}
.fig-icon{width:80px;height:80px;border-radius:50%;background:linear-gradient(135deg,var(--gold),#b48600);display:flex;align-items:center;justify-content:center;font-size:2rem;color:#0b1120;margin:0 auto 20px;box-shadow:0 10px 20px rgba(212,175,55,.3);}
.figure-card h4{font-weight:800;margin-bottom:10px;font-size:1.4rem;}
.figure-card p{color:rgba(255,255,255,.7);font-size:.9rem;line-height:1.8;margin:0;}

/* ACHIEVEMENTS */
.achieve-card{background:white;border-radius:20px;padding:30px;box-shadow:0 10px 30px rgba(11,17,32,.05);transition:.4s;height:100%;text-align:center;}
.achieve-card:hover{box-shadow:0 20px 40px rgba(11,17,32,.1);transform:scale(1.03);}
.ach-icon{font-size:3.5rem;margin-bottom:20px;background:linear-gradient(135deg,#1e1b4b,#334155);-webkit-background-clip:text;-webkit-text-fill-color:transparent;}

/* FOOTER */
.site-footer{background:linear-gradient(135deg,#0b1120,#080c17);color:white;padding:70px 0 30px;margin-top:60px;}

@media(max-width:768px){
  .timeline-v2::before{right:30px;}
  .tv2-item, .tv2-item:nth-child(even){flex-direction:column;align-items:flex-end;}
  .tv2-col{width:calc(100% - 60px);}
  .tv2-dot{right:30px;transform:translateX(50%);}
  .history-hero h1{font-size:2.5rem;}
}
</style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold" href="index.html"><i class="fas fa-book-open me-2 text-warning"></i>الموسوعة الإسلامية الشاملة</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav1">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="nav1">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link " href="index.html">الرئيسية</a></li>
        <li class="nav-item"><a class="nav-link " href="recitations.html">القرآن والتلاوات</a></li>
        <li class="nav-item"><a class="nav-link " href="hadith.html">الحديث الشريف</a></li>
        <li class="nav-item"><a class="nav-link " href="fiqh.html">الفقه الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="fatwa.html">فتاوى العلماء <i class="fas fa-gavel"></i></a></li>
        <li class="nav-item"><a class="nav-link " href="seerah.html">السيرة والصحابة</a></li>
        <li class="nav-item"><a class="nav-link " href="aqeedah.html">العقيدة الإسلامية</a></li>
        <li class="nav-item"><a class="nav-link active" href="history.html">التاريخ الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="library.html">المكتبة الشاملة</a></li>
      </ul>
    </div>
  </div>
</nav>

<section class="history-hero">
  <div class="orb"></div><div class="orb"></div><div class="orb"></div>
  <div class="hero-pattern"></div>
  <div class="container hero-content">
    <div class="row align-items-center">
      <div class="col-lg-7">
        <div class="hero-eyebrow"><i class="fas fa-globe-africa me-2"></i>موسوعة التاريخ الإسلامي</div>
        <h1>حضارة أضاءت<br>ظلمات العالم</h1>
        <p class="tagline">من شِعاب مكة إلى الأندلس والصين.. استكشف تاريخ أعظم إمبراطوريات التاريخ التي نشرت العدل والعلم والنور في أرجاء الأرض لـ 1400 عام.</p>
        <div class="hero-quote">
          <p>«نحن أمة أعزنا الله بالإسلام، فمهما ابتغينا العزة في غيره أذلنا الله»</p>
          <small>— عمر بن الخطاب رضي الله عنه</small>
        </div>
      </div>
      <div class="col-lg-5 d-none d-lg-block text-center">
        <i class="fas fa-globe me-2" style="font-size:18rem;color:rgba(212,175,55,.15);animation:spin 40s linear infinite;"></i>
      </div>
    </div>
  </div>
</section>

<!-- ERAS GRID SEC -->
<section class="eras-section">
  <div class="container">
    <div class="sec-head">
      <span class="tag">العصور الذهبية</span>
      <h2>الدول الممتدة عبر التاريخ</h2>
      <p>محطات الخلافة الإسلامية الكبرى التي قادت العالم في شتى الميادين</p>
      <div class="divider"></div>
    </div>

    <div class="row g-4">
      <!-- 1 -->
      <div class="col-lg-4 col-md-6">
        <div class="era-card">
          <div class="era-header" style="background:linear-gradient(135deg,#064e3b,#047857);">
            <i class="fas fa-star era-icon"></i>
            <h3>الخلافة الراشدة</h3>
            <span class="era-span">11 - 41 هـ | 632 - 661 م</span>
          </div>
          <div class="era-body">
            <p>أعظم عصور الإسلام بعد العهد النبوي. اتسمت بالعدل التام والشورى. أسقطت إمبراطوريتي الفرس والروم وأسست الدولة الإسلامية المترامية.</p>
            <div class="era-feature"><i class="fas fa-book-quran"></i> جمع المصحف الشريف</div>
            <div class="era-feature"><i class="fas fa-landmark"></i> تأسيس الدواوين</div>
          </div>
        </div>
      </div>

      <!-- 2 -->
      <div class="col-lg-4 col-md-6">
        <div class="era-card">
          <div class="era-header" style="background:linear-gradient(135deg,#78350f,#b45309);">
            <i class="fas fa-crown era-icon"></i>
            <h3>الدولة الأموية</h3>
            <span class="era-span">41 - 132 هـ | 661 - 750 م</span>
          </div>
          <div class="era-body">
            <p>أكبر دولة إسلامية مساحةً في التاريخ، امتدت من الصين شرقاً حتى جنوب فرنسا غرباً. أسست العمارة الإسلامية والأساطيل البحرية.</p>
            <div class="era-feature"><i class="fas fa-coins"></i> تعريب الدواوين والنقود</div>
            <div class="era-feature"><i class="fas fa-mosque"></i> بناء المسجد الأموي والأقصى</div>
          </div>
        </div>
      </div>

      <!-- 3 -->
      <div class="col-lg-4 col-md-6">
        <div class="era-card">
          <div class="era-header" style="background:linear-gradient(135deg,#4c1d95,#7c3aed);">
            <i class="fas fa-university era-icon"></i>
            <h3>الدولة العباسية</h3>
            <span class="era-span">132 - 656 هـ | 750 - 1258 م</span>
          </div>
          <div class="era-body">
            <p>العصر الذهبي للعلوم والفنون. بغداد أصبحت قِبلة الدنيا وعاصمة الثراء والثقافة، وفيها ازدهرت الترجمة والرياضيات والطب والفلسفة.</p>
            <div class="era-feature"><i class="fas fa-book-reader"></i> تأسيس بيت الحكمة</div>
            <div class="era-feature"><i class="fas fa-microscope"></i> ريادة العلوم والطب</div>
          </div>
        </div>
      </div>

      <!-- 4 -->
      <div class="col-lg-4 col-md-6">
        <div class="era-card">
          <div class="era-header" style="background:linear-gradient(135deg,#1e3a8a,#2563eb);">
            <i class="fas fa-archway era-icon"></i>
            <h3>حضارة الأندلس</h3>
            <span class="era-span">138 - 897 هـ | 756 - 1492 م</span>
          </div>
          <div class="era-body">
            <p>بينما كانت أوروبا تعيش في عصور الظلام، كانت قرطبة تضاء مصابيحها ليلاً. تميزت بالتسامح والشِعر وقمة الإبداع المعماري والفلسفي.</p>
            <div class="era-feature"><i class="fas fa-palette"></i> روائع قصر الحمراء والزخرفة</div>
            <div class="era-feature"><i class="fas fa-book-medical"></i> ثورة في الطب والجراحة</div>
          </div>
        </div>
      </div>

      <!-- 5 -->
      <div class="col-lg-4 col-md-6">
        <div class="era-card">
          <div class="era-header" style="background:linear-gradient(135deg,#831843,#be185d);">
            <i class="fas fa-shield-halved era-icon"></i>
            <h3>دولة المماليك</h3>
            <span class="era-span">648 - 923 هـ | 1250 - 1517 م</span>
          </div>
          <div class="era-body">
            <p>حماة ديار الإسلام؛ أوقفوا زحف التتار المدمر في عين جالوت، وحرروا بلاد الشام من الصليبيين. تركوا إرثاً معمارياً ضخماً في القاهرة.</p>
            <div class="era-feature"><i class="fas fa-horse"></i> براعة عسكرية هائلة</div>
            <div class="era-feature"><i class="fas fa-chess-rook"></i> العمارة المملوكية البديعة</div>
          </div>
        </div>
      </div>

      <!-- 6 -->
      <div class="col-lg-4 col-md-6">
        <div class="era-card">
          <div class="era-header" style="background:linear-gradient(135deg,#020617,#1e293b);">
            <i class="fas fa-chess-knight era-icon"></i>
            <h3>الدولة العثمانية</h3>
            <span class="era-span">699 - 1342 هـ | 1299 - 1923 م</span>
          </div>
          <div class="era-body">
            <p>الإمبراطورية التي فتحت القسطنطينية (إسطنبول) وتوغلت في قلب أوروبا المشرقية، وحافظت على حياض الإسلام لأكثر من 600 عام.</p>
            <div class="era-feature"><i class="fas fa-fort-awesome"></i> فتح القسطنطينية الساحق</div>
            <div class="era-feature"><i class="fas fa-shield"></i> توحيد العالم الإسلامي</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- TIMELINE -->
<section style="background:#f1f5f9;padding:80px 0;">
  <div class="container">
    <div class="sec-head">
      <span class="tag">الذاكرة الحية</span>
      <h2>التسلسل الزمني</h2>
      <p>أبرز المنعطفات التاريخية التي غيرت مجرى العالم</p>
      <div class="divider"></div>
    </div>
    
    <div class="timeline-v2">
      <div class="tv2-item">
        <div class="tv2-col"></div><div class="tv2-dot"></div>
        <div class="tv2-col"><div class="tv2-card"><div class="tv2-year">15 هـ | 636 م</div><h4>معركة القادسية</h4><p>بقيادة سعد بن أبي وقاص، دُحر الفرس وسقطت إمبراطوريتهم إلى الأبد.</p></div></div>
      </div>
      <div class="tv2-item">
        <div class="tv2-col"><div class="tv2-card"><div class="tv2-year">92 هـ | 711 م</div><h4>فتح الأندلس</h4><p>بقيادة طارق بن زياد وموسى بن نصير، دخل المسلمون أيبيريا ليؤسسوا حضارة الأندلس.</p></div></div>
        <div class="tv2-col"></div><div class="tv2-dot"></div>
      </div>
      <div class="tv2-item">
        <div class="tv2-col"></div><div class="tv2-dot"></div>
        <div class="tv2-col"><div class="tv2-card"><div class="tv2-year">583 هـ | 1187 م</div><h4>معركة حطين</h4><p>انتصار صلاح الدين الأيوبي العظيم وتحرير بيت المقدس من الاحتلال الصليبي.</p></div></div>
      </div>
      <div class="tv2-item">
        <div class="tv2-col"><div class="tv2-card"><div class="tv2-year">656 هـ | 1258 م</div><h4>سقوط بغداد</h4><p>الميلاد القاسي، اجتاح المغول بغداد ودمروا مئات الآلاف والكتب، ليتعافى الإسلام بعدها في عين جالوت.</p></div></div>
        <div class="tv2-col"></div><div class="tv2-dot"></div>
      </div>
      <div class="tv2-item">
        <div class="tv2-col"></div><div class="tv2-dot"></div>
        <div class="tv2-col"><div class="tv2-card"><div class="tv2-year">857 هـ | 1453 م</div><h4>فتح القسطنطينية</h4><p>حقق محمد الفاتح بشارة النبي ﷺ وفتح أحصن مدن الأرض ليجعلها عاصمة الخلافة.</p></div></div>
      </div>
    </div>
  </div>
</section>

<!-- QUICK FIGURES -->
<section class="figures-section">
  <div class="orb"></div>
  <div class="container position-relative z-2">
    <div class="sec-head">
      <h2 style="color:white;">شخصيات خلدها الزمان</h2>
      <p style="color:rgba(255,255,255,.7);">عباقرة وقادة سطروا المجد</p>
      <div class="divider"></div>
    </div>
    <div class="row g-4 text-center">
      <div class="col-lg-3 col-md-6"><div class="figure-card"><div class="fig-icon"><i class="fas fa-horse-head"></i></div><h4>خالد بن الوليد</h4><p>سيف الله المسلول الذي لم يُهزم قط في أكثر من 100 معركة خاضها.</p></div></div>
      <div class="col-lg-3 col-md-6"><div class="figure-card"><div class="fig-icon"><i class="fas fa-shield"></i></div><h4>صلاح الدين</h4><p>القائد الفذ وحّد الشام ومصر واسترد أراضي المسلمين بأخلاق فرسانية.</p></div></div>
      <div class="col-lg-3 col-md-6"><div class="figure-card"><div class="fig-icon"><i class="fas fa-flask"></i></div><h4>ابن سينا</h4><p>الشيخ الرئيس، كتابه "القانون في الطب" ظل المرجع الأساسي بأوروبا لـ 6 قرون.</p></div></div>
      <div class="col-lg-3 col-md-6"><div class="figure-card"><div class="fig-icon"><i class="fas fa-microscope"></i></div><h4>ابن الهيثم</h4><p>مؤسس علم البصريات الحديث، صحح مفاهيم الرؤية وكان رائداً في المنهج العلمي.</p></div></div>
    </div>
  </div>
</section>

<footer class="mega-footer" style="background:linear-gradient(135deg,var(--dark),#020617);color:white;padding:80px 0 30px;margin-top:80px;border-top:3px solid var(--gold-dark);">
  <div class="container">
    <div class="row g-5 mb-5 border-bottom border-light border-opacity-10 pb-5">
      <div class="col-lg-4 text-md-end text-center">
        <i class="fas fa-mosque fa-4x text-warning mb-4 d-block"></i>
        <h4 class="fw-bold font-amiri fs-2 mb-3">الموسوعة الإسلامية الشاملة</h4>
        <p class="opacity-75 fs-6 line-height-2">أضخم صرح رقمي يجمع علوم القرآن العظيم، وأحاديث المصطفى، وفقهاء المذاهب، والتاريخ المجيد في منصة موثقة مصممة بأحدث التقنيات.</p>
      </div>
      <div class="col-lg-4 text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">تصفح الموسوعة</h5>
        <div class="d-flex flex-wrap justify-content-center gap-2">
          <a href="recitations.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">أكاديمية القرآن</a>
          <a href="hadith.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الحديث النبوي</a>
          <a href="seerah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">السيرة والصحابة</a>
          <a href="fiqh.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الفقه وأصوله</a>
          <a href="fatwa.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">فتاوى العلماء</a>
          <a href="aqeedah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">العقيدة الإسلامية</a>
          <a href="history.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">التاريخ المجيد</a>
          <a href="library.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">المكتبة الشاملة</a>
        </div>
      </div>
      <div class="col-lg-4 text-md-start text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">روابط سريعة</h5>
        <a href="contact.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> اتصل بالمطور</a>
        <a href="share.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> شارك الأجر</a>
        <a href="login.html" class="mega-footer-link text-warning mt-3" style="text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-user-circle me-2 ms-1"></i> تسجيل الدخول</a>
      </div>
    </div>
    <div class="text-center font-amiri fs-5 d-flex flex-column gap-2">
      <span class="opacity-75">الموسوعة الإسلامية الشاملة &copy; 2026 تم التصميم للإفادة | عمل مجاني لوجه الله</span>
      <span class="text-warning fw-bold fs-4 mt-2">تصميم وتطوير: لخذاري محمد سيف الدين</span>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<style>@keyframes spin{to{transform:rotate(360deg)}}</style>
</body>
</html>"""

with codecs.open(r"C:\Users\ST\Desktop\islamic.encyclopedia\history.html", 'w', 'utf-8') as f:
    f.write(html)
print("Rebuilt history.html successfully!")
