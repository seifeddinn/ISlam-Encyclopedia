<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>أكاديمية الموسوعة للقرآن والتلاوات - النسخة الكبرى</title>
<link href="https://fonts.googleapis.com/css2?family=Amiri:ital,wght@0,400;0,700;1,400&family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root{--gold:#d4af37;--gold-light:#f9f1d8;--gold-dark:#aa8a2a;--dark:#0b192c;--emerald:#064e3b;--cyan:#0f766e;--ruby:#7f1d1d;}
body{font-family:'Cairo',sans-serif;background:#f8fafc;color:#1e293b;overflow-x:hidden;padding-bottom:100px;}
h1,h2,h3,h4,h5,h6,.ar,.poetry{font-family:'Amiri',serif;}

/* NAVBAR */
.navbar {background:linear-gradient(135deg,#0b192c,#0f766e)!important;box-shadow:0 4px 30px rgba(0,0,0,.5);z-index:1000;border-bottom:2px solid rgba(212,175,55,0.2);}
.navbar-brand{font-family:'Amiri',serif;font-size:1.8rem;color:white!important;text-shadow:0 2px 10px rgba(212,175,55,0.5);}
.nav-link{color:rgba(255,255,255,.8)!important;font-weight:700;letter-spacing:0.5px;}
.nav-link:hover, .nav-link.active{color:var(--gold)!important;}

/* MEGA HERO */
.rec-hero{min-height:700px;background:radial-gradient(circle at 50% 50%, #0f766e 0%, #0b192c 80%);position:relative;overflow:hidden;display:flex;align-items:center;padding:120px 0;}
.hero-glass{background:rgba(11,25,44,0.4);backdrop-filter:blur(15px);border:1px solid rgba(212,175,55,0.3);border-radius:30px;padding:50px;box-shadow:0 20px 50px rgba(0,0,0,0.5);position:relative;z-index:5;}
.hero-pattern{position:absolute;inset:0;background:url('https://www.transparenttextures.com/patterns/arabesque.png');opacity:.1;mix-blend-mode:overlay;}
.hero-eyebrow{display:inline-block;background:linear-gradient(90deg,var(--gold-dark),var(--gold));color:#0b192c;padding:8px 30px;border-radius:50px;font-weight:bold;font-size:1rem;margin-bottom:25px;box-shadow:0 4px 15px rgba(212,175,55,0.4);}
.hero h1{font-size:5rem;font-weight:900;color:white;text-shadow:0 10px 30px rgba(0,0,0,0.8);line-height:1.2;margin-bottom:20px;}
.hero h1 span{background:linear-gradient(135deg,#fff,var(--gold));-webkit-background-clip:text;-webkit-text-fill-color:transparent;}
.tagline{color:#e2e8f0;font-size:1.3rem;line-height:2.2;text-shadow:0 2px 4px rgba(0,0,0,0.5);}

/* ANIMATED ORBS */
.orb{position:absolute;border-radius:50%;filter:blur(120px);opacity:.3;animation:floatOrb 15s ease-in-out infinite alternate;}
.orb-1{width:600px;height:600px;background:var(--gold);top:-150px;right:-100px;}
.orb-2{width:500px;height:500px;background:var(--cyan);bottom:-100px;left:-50px;animation-delay:5s;}
@keyframes floatOrb{0%{transform:translate(0,0) scale(1);}100%{transform:translate(50px,50px) scale(1.1);}}

/* STATS BAR MEGA */
.stats-mega{background:linear-gradient(90deg,var(--dark),#0f766e);border-top:2px solid var(--gold-dark);border-bottom:2px solid var(--gold-dark);padding:40px 0;position:relative;z-index:10;margin-top:-5px;}
.stat-box{text-align:center;color:white;padding:20px;border-left:1px solid rgba(212,175,55,0.2);}
.stat-box:last-child{border-left:none;}
.stat-num{font-family:'Amiri',serif;font-size:3.5rem;font-weight:bold;color:var(--gold);line-height:1;margin-bottom:10px;text-shadow:0 5px 15px rgba(212,175,55,0.3);}
.stat-label{font-size:1.1rem;font-weight:bold;letter-spacing:1px;color:#cbd5e1;}

/* TABS NAVIGATION */
.main-tabs-wrapper{background:white;padding:20px;border-radius:20px;box-shadow:0 10px 40px rgba(0,0,0,0.05);margin:40px auto 60px;position:sticky;top:80px;z-index:900;border:1px solid #e2e8f0;}
.main-tabs{display:flex;gap:10px;overflow-x:auto;padding-bottom:10px;border-bottom:none;}
.main-tabs::-webkit-scrollbar{height:6px;}
.main-tabs::-webkit-scrollbar-thumb{background:var(--gold);border-radius:10px;}
.main-tabs .nav-link{border:1px solid #e2e8f0;border-radius:12px;color:#475569;font-weight:bold;padding:15px 25px;font-size:1rem;white-space:nowrap;transition:all .3s;}
.main-tabs .nav-link:hover{background:#f8fafc;border-color:var(--gold-dark);color:var(--dark);transform:translateY(-2px);}
.main-tabs .nav-link.active{background:linear-gradient(135deg,var(--dark),var(--cyan));color:white;border-color:transparent;box-shadow:0 10px 20px rgba(15,118,110,0.3);}

/* SECTION HEADERS */
.sec-head{text-align:center;margin-bottom:60px;position:relative;}
.sec-head .tag{display:inline-block;background:rgba(212,175,55,0.1);color:var(--gold-dark);border:1px solid rgba(212,175,55,0.3);border-radius:30px;padding:8px 25px;font-size:1rem;font-weight:bold;margin-bottom:20px;}
.sec-head h3{font-size:3rem;font-family:'Amiri',serif;color:var(--dark);font-weight:900;margin-bottom:15px;}
.sec-head h3 span{color:var(--cyan);}
.sec-head p{color:#64748b;font-size:1.2rem;max-width:800px;margin:0 auto;line-height:1.8;}
.sec-head .divider{width:80px;height:5px;background:linear-gradient(90deg,var(--gold),var(--cyan));border-radius:5px;margin:25px auto 0;}

/* POETRY / MATN BOX */
.poetry-box{background:url('https://www.transparenttextures.com/patterns/cream-paper.png') #fdfbf7;border:2px solid var(--gold-dark);border-radius:15px;padding:40px;text-align:center;box-shadow:inset 0 0 50px rgba(212,175,55,0.1), 0 15px 30px rgba(0,0,0,0.05);position:relative;margin:30px 0;}
.poetry-box::before, .poetry-box::after{content:'❁';position:absolute;color:var(--gold);font-size:2rem;}
.poetry-box::before{top:10px;right:15px;} .poetry-box::after{bottom:10px;left:15px;}
.poetry-line{font-family:'Amiri',serif;font-size:1.8rem;color:var(--dark);line-height:2.5;margin-bottom:15px;}
.poetry-shatr{display:inline-block;width:45%;text-align:center;}
.poetry-gap{display:inline-block;width:8%;}
.poetry-title{background:var(--dark);color:var(--gold);display:inline-block;padding:5px 20px;border-radius:0 0 15px 15px;position:absolute;top:0;left:50%;transform:translateX(-50%);font-weight:bold;letter-spacing:2px;}

/* COMMON CARDS */
.mega-card{background:white;border-radius:20px;padding:35px;box-shadow:0 15px 35px rgba(0,0,0,0.04);border:1px solid #f1f5f9;transition:all .4s;height:100%;}
.mega-card:hover{transform:translateY(-8px);box-shadow:0 25px 50px rgba(15,118,110,0.1);border-color:var(--gold);}

/* RECITERS GRID */
.reciter-item { background:white; border:1px solid #e2e8f0; border-radius:15px; padding:20px; text-align:center; transition:0.3s; cursor:pointer; }
.reciter-item:hover { background:var(--emerald); color:white!important; transform:translateY(-5px); box-shadow:0 15px 30px rgba(6,78,59,0.2); border-color:var(--emerald); }
.reciter-item:hover h5, .reciter-item:hover i { color:white!important; }
</style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold" href="index.html"><i class="fas fa-book-open me-2 text-warning"></i>الموسوعة الإسلامية الشاملة</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav1">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="nav1">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link " href="index.html">الرئيسية</a></li>
        <li class="nav-item"><a class="nav-link " href="recitations.html">القرآن والتلاوات</a></li>
        <li class="nav-item"><a class="nav-link " href="hadith.html">الحديث الشريف</a></li>
        <li class="nav-item"><a class="nav-link " href="fiqh.html">الفقه الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="fatwa.html">فتاوى العلماء <i class="fas fa-gavel"></i></a></li>
        <li class="nav-item"><a class="nav-link " href="seerah.html">السيرة والصحابة</a></li>
        <li class="nav-item"><a class="nav-link " href="aqeedah.html">العقيدة الإسلامية</a></li>
        <li class="nav-item"><a class="nav-link " href="history.html">التاريخ الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="library.html">المكتبة الشاملة</a></li>
      </ul>
    </div>
  </div>
</nav>

<section class="rec-hero">
  <div class="orb orb-1"></div><div class="orb orb-2"></div>
  <div class="hero-pattern"></div>
  <div class="container relative z-10">
    <div class="row justify-content-center text-center">
      <div class="col-lg-10">
        <div class="hero-glass">
            <div class="hero-eyebrow"><i class="fas fa-crown me-2"></i>المرجع الذهبي والأكبر لعلوم القرآن</div>
            <h1>موسوعة <span>التلاوات</span> والقراءات</h1>
            <p class="tagline mt-4">الصرح العلمي الأضخم: تصفح المصحف المرتل، استكشف أعماق التجويد ومخارج الحروف، مكتبة صوتية شاملة لمئات القراء، وتبحر في أصول القراءات العشر المتواترة.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<div class="stats-mega">
  <div class="container">
    <div class="row g-0">
      <div class="col-6 col-md-2 stat-box"><div class="stat-num">114</div><div class="stat-label">سورة قرآنية</div></div>
      <div class="col-6 col-md-2 stat-box"><div class="stat-num">10</div><div class="stat-label">قراءات متواترة</div></div>
      <div class="col-6 col-md-2 stat-box"><div class="stat-num">10k+</div><div class="stat-label">تلاوة صوتية</div></div>
      <div class="col-6 col-md-2 stat-box"><div class="stat-num">5</div><div class="stat-label">مخارج رئيسية</div></div>
      <div class="col-6 col-md-2 stat-box"><div class="stat-num">8</div><div class="stat-label">مقامات صوتية</div></div>
      <div class="col-6 col-md-2 stat-box"><div class="stat-num">∞</div><div class="stat-label">أجر يتضاعف</div></div>
    </div>
  </div>
</div>

<div class="container">
  <div class="main-tabs-wrapper">
    <ul class="nav nav-pills main-tabs justify-content-between" id="megaTabs" role="tablist">
      <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#tab-quran"><i class="fas fa-quran fs-4 d-block mb-1"></i>المصحف الشريف</button></li>
      <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-tajweed"><i class="fas fa-microphone-alt fs-4 d-block mb-1"></i>موسوعة التجويد</button></li>
      <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-audio"><i class="fas fa-headphones fs-4 d-block mb-1"></i>المكتبة الصوتية</button></li>
      <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-maqam"><i class="fas fa-music fs-4 d-block mb-1"></i>المقامات الصوتية</button></li>
      <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-qiraat"><i class="fas fa-tree fs-4 d-block mb-1"></i>القراءات العشر والأصول</button></li>
      <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-legends"><i class="fas fa-crown fs-4 d-block mb-1"></i>مدارس وأساطير التلاوة</button></li>
      <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-ijazah"><i class="fas fa-scroll fs-4 d-block mb-1"></i>الإجازة والمتون</button></li>
    </ul>
  </div>

  <div class="tab-content pb-5" id="megaTabsContent">
