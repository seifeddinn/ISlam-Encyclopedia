import codecs

part3 = """
<!-- TAB 4: AIMMAH -->
<div class="tab-pane fade" id="t4" role="tabpanel">
  <div class="sec-head">
    <span class="tag">حفّاظ السنة على مرّ العصور</span>
    <h3>أئمة الحديث <span>ونقّاده</span></h3>
    <p>العلماء الذين بذلوا حياتهم في حفظ السنة النبوية وصونها من الدسيسة والوضع</p>
    <div class="divider"></div>
  </div>
  <div class="row g-4">
    <div class="col-lg-3 col-md-6">
      <div class="imam-card">
        <div class="imam-top" style="background:linear-gradient(135deg,#0d3320,#1a5c3a);">
          <div class="imam-avatar"><i class="fas fa-crown"></i></div>
        </div>
        <div class="imam-body">
          <div class="imam-name">الإمام البخاري</div>
          <div class="imam-date"><i class="fas fa-calendar-alt me-1"></i>194 – 256 هـ &nbsp;|&nbsp; بخارى</div>
          <p>أمير المؤمنين في الحديث. كان يحفظ 100,000 حديث بأسانيدها ومتونها ويُقدِّم الغسل والنافلة قبل كتابة كل حديث. قال عنه ابن خزيمة: لم أرَ تحت أديم السماء أعلم بالحديث منه.</p>
          <div class="d-flex flex-wrap gap-1 mt-2">
            <span class="badge" style="background:rgba(13,51,32,.1);color:#0d3320;">الجامع الصحيح</span>
            <span class="badge" style="background:rgba(13,51,32,.1);color:#0d3320;">التاريخ الكبير</span>
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-3 col-md-6">
      <div class="imam-card">
        <div class="imam-top" style="background:linear-gradient(135deg,#145a90,#1a81cc);">
          <div class="imam-avatar"><i class="fas fa-star"></i></div>
        </div>
        <div class="imam-body">
          <div class="imam-name">الإمام مسلم</div>
          <div class="imam-date"><i class="fas fa-calendar-alt me-1"></i>204 – 261 هـ &nbsp;|&nbsp; نيسابور</div>
          <p>انتخب صحيحه من 300,000 حديث. قال: "لو أن أهل الحديث يكتبون مائتي سنة فمدارهم على هذا المسند". عرض كتابه على أبي زرعة الرازي فأشاد به وأقرّه.</p>
          <div class="d-flex flex-wrap gap-1 mt-2">
            <span class="badge" style="background:rgba(20,90,144,.1);color:#145a90;">صحيح مسلم</span>
            <span class="badge" style="background:rgba(20,90,144,.1);color:#145a90;">الكنى والأسماء</span>
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-3 col-md-6">
      <div class="imam-card">
        <div class="imam-top" style="background:linear-gradient(135deg,#7b180e,#c0392b);">
          <div class="imam-avatar"><i class="fas fa-chess-king"></i></div>
        </div>
        <div class="imam-body">
          <div class="imam-name">الإمام أحمد بن حنبل</div>
          <div class="imam-date"><i class="fas fa-calendar-alt me-1"></i>164 – 241 هـ &nbsp;|&nbsp; بغداد</div>
          <p>إمام أهل السنة وصاحب أكبر مسند. صبر على فتنة خلق القرآن وضُرب وسُجن ولم يتزحزح. قال الشافعي: أحمد سيدنا وإمامنا وأعلمنا. حفظ مليون حديث.</p>
          <div class="d-flex flex-wrap gap-1 mt-2">
            <span class="badge" style="background:rgba(192,57,43,.1);color:#c0392b;">المسند</span>
            <span class="badge" style="background:rgba(192,57,43,.1);color:#c0392b;">الزهد</span>
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-3 col-md-6">
      <div class="imam-card">
        <div class="imam-top" style="background:linear-gradient(135deg,#6c2b9a,#9b59b6);">
          <div class="imam-avatar"><i class="fas fa-feather"></i></div>
        </div>
        <div class="imam-body">
          <div class="imam-name">الإمام النووي</div>
          <div class="imam-date"><i class="fas fa-calendar-alt me-1"></i>631 – 676 هـ &nbsp;|&nbsp; نوى (الشام)</div>
          <p>مات شاباً عن 45 عاماً وخلّف إرثاً علمياً هائلاً. شرح صحيح مسلم، وجمع الأربعين الحديثية وكتاب رياض الصالحين المملوء بالأحاديث المختارة.</p>
          <div class="d-flex flex-wrap gap-1 mt-2">
            <span class="badge" style="background:rgba(108,43,154,.1);color:#6c2b9a;">الأربعون</span>
            <span class="badge" style="background:rgba(108,43,154,.1);color:#6c2b9a;">رياض الصالحين</span>
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-3 col-md-6">
      <div class="imam-card">
        <div class="imam-top" style="background:linear-gradient(135deg,#9a5e10,#c9a66b);">
          <div class="imam-avatar"><i class="fas fa-microscope"></i></div>
        </div>
        <div class="imam-body">
          <div class="imam-name">الدارقطني</div>
          <div class="imam-date"><i class="fas fa-calendar-alt me-1"></i>306 – 385 هـ &nbsp;|&nbsp; بغداد</div>
          <p>أمير المؤمنين في الحديث في عصره. برع في كشف العلل الخفية والتفرد في الأسانيد. كتابه "السنن" من أثمن مصادر الأحاديث الفقهية التي لم ترد في غيرها.</p>
          <div class="d-flex flex-wrap gap-1 mt-2">
            <span class="badge" style="background:rgba(154,94,16,.1);color:#9a5e10;">السنن</span>
            <span class="badge" style="background:rgba(154,94,16,.1);color:#9a5e10;">العلل</span>
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-3 col-md-6">
      <div class="imam-card">
        <div class="imam-top" style="background:linear-gradient(135deg,#0d5c4a,#1abc9c);">
          <div class="imam-avatar"><i class="fas fa-pen-nib"></i></div>
        </div>
        <div class="imam-body">
          <div class="imam-name">ابن حجر العسقلاني</div>
          <div class="imam-date"><i class="fas fa-calendar-alt me-1"></i>773 – 852 هـ &nbsp;|&nbsp; القاهرة</div>
          <p>صاحب "فتح الباري" أعظم شروح البخاري الذي استغرق كتابته 25 عاماً. وضع "تقريب التهذيب" في أحوال الرجال الذي صار مرجعاً لكل طالب في علم الحديث.</p>
          <div class="d-flex flex-wrap gap-1 mt-2">
            <span class="badge" style="background:rgba(13,92,74,.1);color:#0d5c4a;">فتح الباري</span>
            <span class="badge" style="background:rgba(13,92,74,.1);color:#0d5c4a;">تقريب التهذيب</span>
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-3 col-md-6">
      <div class="imam-card">
        <div class="imam-top" style="background:linear-gradient(135deg,#1c3a5e,#2980b9);">
          <div class="imam-avatar"><i class="fas fa-book-reader"></i></div>
        </div>
        <div class="imam-body">
          <div class="imam-name">الإمام السيوطي</div>
          <div class="imam-date"><i class="fas fa-calendar-alt me-1"></i>849 – 911 هـ &nbsp;|&nbsp; مصر</div>
          <p>الحافظ المكثر، ألّف أكثر من 600 كتاب في شتى العلوم. في الحديث كتب "الجامع الصغير" و"الجامع الكبير" التي جمع فيها آلاف الأحاديث مع توثيقها وتصنيفها.</p>
          <div class="d-flex flex-wrap gap-1 mt-2">
            <span class="badge" style="background:rgba(28,58,94,.1);color:#1c3a5e;">الجامع الصغير</span>
            <span class="badge" style="background:rgba(28,58,94,.1);color:#1c3a5e;">تدريب الراوي</span>
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-3 col-md-6">
      <div class="imam-card">
        <div class="imam-top" style="background:linear-gradient(135deg,#2c3e50,#516375);">
          <div class="imam-avatar"><i class="fas fa-search"></i></div>
        </div>
        <div class="imam-body">
          <div class="imam-name">الشيخ الألباني</div>
          <div class="imam-date"><i class="fas fa-calendar-alt me-1"></i>1914 – 1999 م &nbsp;|&nbsp; الأردن</div>
          <p>محدّث العصر ومجدد علم الحديث في القرن العشرين. خصص سلسلتين "الصحيحة" و"الضعيفة" لتحقيق الأحاديث. خلّف مئات المجلدات التحقيقية في خدمة السنة.</p>
          <div class="d-flex flex-wrap gap-1 mt-2">
            <span class="badge" style="background:rgba(44,62,80,.1);color:#2c3e50;">السلسلة الصحيحة</span>
            <span class="badge" style="background:rgba(44,62,80,.1);color:#2c3e50;">إرواء الغليل</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- TAB 5: BAHETH -->
<div class="tab-pane fade" id="t5" role="tabpanel">
  <div class="sec-head">
    <span class="tag">بحث نصي في الأربعين النووية</span>
    <h3>الباحث <span>الحديثي</span></h3>
    <p>ابحث بأي كلمة من المتن أو اسم الراوي أو رقم الحديث</p>
    <div class="divider"></div>
  </div>
  <div class="baheth-wrapper">
    <div class="baheth-input-wrap">
      <i class="fas fa-search text-muted ms-2"></i>
      <input type="text" id="baheth-inp" placeholder="مثال: نية، الجار، المسلم، الله، 5...">
      <button class="baheth-btn" onclick="doBaheth()"><i class="fas fa-search me-2"></i>بحث</button>
    </div>
    <div id="baheth-hint" class="text-center text-muted small mt-3">اكتب كلمة لتبدأ البحث في 42 حديثاً نووياً</div>
  </div>
  <div id="baheth-results"></div>
</div>

</div><!-- end tab-content -->
</div><!-- end container -->

<!-- FOOTER -->
<footer class="mega-footer" style="background:linear-gradient(135deg,var(--dark),#020617);color:white;padding:80px 0 30px;margin-top:80px;border-top:3px solid var(--gold-dark);">
  <div class="container">
    <div class="row g-5 mb-5 border-bottom border-light border-opacity-10 pb-5">
      <div class="col-lg-4 text-md-end text-center">
        <i class="fas fa-mosque fa-4x text-warning mb-4 d-block"></i>
        <h4 class="fw-bold font-amiri fs-2 mb-3">الموسوعة الإسلامية الشاملة</h4>
        <p class="opacity-75 fs-6 line-height-2">أضخم صرح رقمي يجمع علوم القرآن العظيم، وأحاديث المصطفى، وفقهاء المذاهب، والتاريخ المجيد في منصة موثقة مصممة بأحدث التقنيات.</p>
      </div>
      <div class="col-lg-4 text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">تصفح الموسوعة</h5>
        <div class="d-flex flex-wrap justify-content-center gap-2">
          <a href="recitations.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">أكاديمية القرآن</a>
          <a href="hadith.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الحديث النبوي</a>
          <a href="seerah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">السيرة والصحابة</a>
          <a href="fiqh.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الفقه وأصوله</a>
          <a href="fatwa.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">فتاوى العلماء</a>
          <a href="aqeedah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">العقيدة الإسلامية</a>
          <a href="history.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">التاريخ المجيد</a>
          <a href="library.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">المكتبة الشاملة</a>
        </div>
      </div>
      <div class="col-lg-4 text-md-start text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">روابط سريعة</h5>
        <a href="contact.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> اتصل بالمطور</a>
        <a href="share.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> شارك الأجر</a>
        <a href="login.html" class="mega-footer-link text-warning mt-3" style="text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-user-circle me-2 ms-1"></i> تسجيل الدخول</a>
      </div>
    </div>
    <div class="text-center font-amiri fs-5 d-flex flex-column gap-2">
      <span class="opacity-75">الموسوعة الإسلامية الشاملة &copy; 2026 تم التصميم للإفادة | عمل مجاني لوجه الله</span>
      <span class="text-warning fw-bold fs-4 mt-2">تصميم وتطوير: لخذاري محمد سيف الدين</span>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="nawawi.js"></script>
<script>
// === Hadith of the Day ===
const picks = [1,6,12,15,18,19,23,27,34,36];
const h = nawawiHadiths[picks[new Date().getDate() % picks.length] - 1];
if(h){ document.getElementById('hotd-text').textContent = '«' + h.text.substring(0,180) + '...»'; document.getElementById('hotd-source').textContent = '— ' + h.source; }

// === Render Nawawi ===
function renderNawawi(list){
  const c = document.getElementById('nawawi-list');
  document.getElementById('nawawi-count').textContent = list.length + ' حديث';
  c.innerHTML = '';
  if(!list.length){ c.innerHTML='<div class="text-center py-5 text-muted"><i class="fas fa-search fa-3x mb-3 opacity-25 d-block"></i>لا نتائج مطابقة.</div>'; return; }
  list.forEach(h=>{
    const d=document.createElement('div'); d.className='hadith-card';
    d.innerHTML=`<div class="hadith-num-bg">${h.number}</div>
      <div class="hadith-header">
        <div class="hadith-num-badge">${h.number}</div>
        <div><div class="hadith-title">${h.title}</div><div class="hadith-narrator"><i class="fas fa-user-circle me-1"></i>${h.narrator}</div></div>
      </div>
      <p class="hadith-text">${h.text}</p>
      <span class="hadith-source-tag"><i class="fas fa-book me-1"></i>${h.source}</span>`;
    c.appendChild(d);
  });
}
renderNawawi(nawawiHadiths);

// === Nawawi filter ===
function filterNawawi(){
  const q=document.getElementById('nSearch').value.trim().toLowerCase();
  renderNawawi(q ? nawawiHadiths.filter(h=>h.title.includes(q)||h.text.includes(q)||h.narrator.includes(q)||String(h.number).includes(q)) : nawawiHadiths);
}
document.getElementById('nSearch').addEventListener('keydown',e=>e.key==='Enter'&&filterNawawi());

// === Baheth ===
function doBaheth(){
  const q=document.getElementById('baheth-inp').value.trim().toLowerCase();
  const rc=document.getElementById('baheth-results');
  const hint=document.getElementById('baheth-hint');
  rc.innerHTML='';
  if(!q){ hint.textContent='يرجى كتابة كلمة للبحث.'; return; }
  const m=nawawiHadiths.filter(h=>h.title.includes(q)||h.text.includes(q)||h.narrator.includes(q));
  hint.textContent = m.length ? `وُجد ${m.length} نتيجة للبحث عن: "${q}"` : `لا توجد نتائج لـ "${q}"`;
  m.forEach((h,i)=>{
    const d=document.createElement('div'); d.className='result-card'; d.style.animationDelay=(i*0.08)+'s';
    d.innerHTML=`<div class="d-flex align-items-center gap-3 mb-2">
      <span style="width:38px;height:38px;background:linear-gradient(135deg,#0d3320,#1a5c3a);border-radius:50%;display:flex;align-items:center;justify-content:center;color:white;font-family:'Amiri',serif;font-weight:bold;flex-shrink:0;">${h.number}</span>
      <strong style="color:#0d3320;">${h.title}</strong></div>
      <p style="font-family:'Amiri',serif;font-size:1.1rem;line-height:2;color:#333;margin-bottom:10px;">${h.text.substring(0,250)}...</p>
      <span class="hadith-source-tag"><i class="fas fa-book me-1"></i>${h.source}</span>`;
    rc.appendChild(d);
  });
}
document.getElementById('baheth-inp').addEventListener('keydown',e=>e.key==='Enter'&&doBaheth());
</script>
</body></html>
"""

with codecs.open(r"c:\Users\ST\Desktop\islamic.encyclopedia\hadith_p3.tmp", 'w', 'utf-8') as f:
    f.write(part3)

# ===== Merge all parts =====
parts = []
for fn in ['hadith_p1.tmp','hadith_p2.tmp','hadith_p3.tmp']:
    with codecs.open(r"c:\Users\ST\Desktop\islamic.encyclopedia\\" + fn, 'r', 'utf-8') as f:
        parts.append(f.read())

final = ''.join(parts)
with codecs.open(r"c:\Users\ST\Desktop\islamic.encyclopedia\hadith.html", 'w', 'utf-8') as f:
    f.write(final)

import os
for fn in ['hadith_p1.tmp','hadith_p2.tmp','hadith_p3.tmp']:
    try: os.remove(r"c:\Users\ST\Desktop\islamic.encyclopedia\\" + fn)
    except: pass

print("hadith.html rebuilt successfully!")
