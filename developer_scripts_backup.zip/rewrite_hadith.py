import codecs

file_path = r"c:\Users\ST\Desktop\islamic.encyclopedia\hadith.html"

html = """<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>أكاديمية الحديث النبوي - الموسوعة الإسلامية الشاملة</title>
    <link href="https://fonts.googleapis.com/css2?family=Amiri:wght@400;700&family=Cairo:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="styles.css">
    <style>
        :root {
            --primary: #1a4f3a;
            --secondary: #c9a66b;
            --accent: #f0f7f4;
            --glass-shadow: 0 8px 32px 0 rgba(31,38,135,0.1);
            --grad-primary: linear-gradient(135deg,#1a4f3a 0%,#2d7a5c 100%);
            --grad-gold: linear-gradient(135deg,#c9a66b 0%,#e0c28f 100%);
        }
        body { font-family:'Cairo',sans-serif; background:#f6faf8; color:#2c3e50; overflow-x:hidden; }
        h1,h2,h3,h4,.arabic { font-family:'Amiri',serif; }

        /* HERO */
        .hadith-hero {
            background: var(--grad-primary);
            padding: 90px 0 70px;
            position: relative;
            overflow: hidden;
            color: white;
            margin-bottom: 50px;
        }
        .hadith-hero::before {
            content:''; position:absolute; inset:0;
            background:url('https://www.transparenttextures.com/patterns/arabesque.png');
            opacity:.15; animation:bgMove 80s linear infinite;
        }
        @keyframes bgMove { from{background-position:0 0} to{background-position:1000px 1000px} }
        .hero-icon {
            width:100px; height:100px; border-radius:50%;
            background:rgba(255,255,255,.12); border:2px solid rgba(255,255,255,.25);
            display:flex; align-items:center; justify-content:center;
            margin:0 auto 20px; font-size:3rem; color:var(--secondary);
            animation:pulseGold 2.5s infinite;
        }
        @keyframes pulseGold {
            0%{box-shadow:0 0 0 0 rgba(201,166,107,.5)}
            70%{box-shadow:0 0 0 22px rgba(201,166,107,0)}
            100%{box-shadow:0 0 0 0 rgba(201,166,107,0)}
        }
        .hadith-of-day {
            background:rgba(255,255,255,.12); border:1px solid rgba(255,255,255,.2);
            border-radius:15px; padding:20px 30px; max-width:750px; margin:30px auto 0;
            font-family:'Amiri',serif; font-size:1.25rem; line-height:2.2;
            backdrop-filter:blur(6px);
        }

        /* TABS */
        .academy-tabs {
            background:white; padding:10px; border-radius:50px;
            box-shadow:var(--glass-shadow); margin-bottom:40px;
            display:flex; overflow-x:auto; white-space:nowrap; flex-wrap:nowrap;
            border:1px solid rgba(0,0,0,.05);
        }
        .academy-tabs .nav-item { flex:1; text-align:center; min-width:160px; }
        .academy-tabs .nav-link {
            border:none; border-radius:40px; font-weight:700; color:#2c3e50;
            padding:14px 18px; transition:all .4s;
        }
        .academy-tabs .nav-link.active {
            background:var(--grad-gold); color:white;
            box-shadow:0 4px 15px rgba(201,166,107,.4); transform:translateY(-2px);
        }
        .academy-tabs .nav-link i { margin-left:8px; }

        /* SECTION TITLE */
        .sec-title { text-align:center; margin-bottom:40px; }
        .sec-title h3 {
            display:inline-block; color:var(--primary); font-size:2rem; font-weight:700;
            padding-bottom:12px; position:relative;
        }
        .sec-title h3::after {
            content:''; position:absolute; bottom:0; left:50%; transform:translateX(-50%);
            width:70px; height:4px; background:var(--grad-gold); border-radius:2px;
        }

        /* KUTUB 6 CARDS */
        .kitab-card {
            border:none; border-radius:20px; overflow:hidden;
            box-shadow:0 10px 30px rgba(0,0,0,.06); transition:all .4s; height:100%;
        }
        .kitab-card:hover { transform:translateY(-8px); box-shadow:0 18px 40px rgba(26,79,58,.15); }
        .kitab-card .kitab-top {
            height:9px; width:100%; display:block;
        }
        .kitab-body { padding:25px; }
        .kitab-icon {
            width:65px; height:65px; border-radius:50%;
            display:flex; align-items:center; justify-content:center;
            font-size:1.8rem; margin:0 auto 18px;
        }
        .kitab-stat {
            background:#f6faf8; border-radius:10px; padding:8px 14px;
            font-size:.82rem; color:#888; margin-top:12px; display:flex;
            justify-content:space-between; align-items:center;
        }

        /* IMAM CARDS */
        .imam-card {
            background:white; border-radius:18px; overflow:hidden;
            box-shadow:0 8px 25px rgba(0,0,0,.06); transition:all .3s; height:100%;
            border-top:4px solid var(--secondary);
        }
        .imam-card:hover { transform:translateY(-6px); }
        .imam-avatar {
            width:80px; height:80px; border-radius:50%;
            display:flex; align-items:center; justify-content:center;
            background:var(--grad-primary); color:white; font-size:2rem;
            margin:0 auto 15px;
        }

        /* NAWAWI CARDS */
        .nawawi-card {
            background:white; border-radius:18px; padding:25px;
            box-shadow:0 8px 25px rgba(0,0,0,.05); margin-bottom:20px;
            border-right:5px solid var(--secondary); transition:all .3s;
            position:relative; overflow:hidden;
        }
        .nawawi-card:hover { box-shadow:0 12px 35px rgba(26,79,58,.12); transform:translateX(-4px); }
        .nawawi-num {
            position:absolute; left:20px; top:15px;
            font-size:3.5rem; font-family:'Amiri',serif;
            color:rgba(26,79,58,.06); font-weight:bold; line-height:1;
        }
        .nawawi-text {
            font-family:'Amiri',serif; font-size:1.2rem;
            line-height:2; color:#2c3e50; margin-bottom:15px;
        }
        .nawawi-source {
            display:inline-flex; align-items:center; gap:8px;
            background:rgba(201,166,107,.1); border:1px solid rgba(201,166,107,.3);
            color:#9a7940; border-radius:20px; padding:5px 14px; font-size:.83rem; font-weight:700;
        }
        #nawawi-search {
            border-radius:40px; border:2px solid transparent; padding:12px 22px;
            background:#f0f7f4; transition:border .3s;
        }
        #nawawi-search:focus { border-color:var(--secondary); outline:none; background:white; }

        /* MUSTALAH GRID */
        .mustalah-card {
            border:none; border-radius:18px; padding:28px; text-align:center;
            box-shadow:0 8px 25px rgba(0,0,0,.06); transition:all .4s; height:100%;
            position:relative; overflow:hidden;
        }
        .mustalah-card:hover { transform:translateY(-6px); }
        .mustalah-icon {
            width:72px; height:72px; border-radius:50%;
            display:flex; align-items:center; justify-content:center;
            font-size:2rem; margin:0 auto 18px; box-shadow:0 8px 18px rgba(0,0,0,.15);
        }

        /* SEARCH */
        .baheth-box {
            background:white; border-radius:20px; padding:30px;
            box-shadow:var(--glass-shadow); margin-bottom:30px;
        }
        .result-card {
            background:white; border-radius:15px; padding:22px;
            border-right:4px solid var(--primary); margin-bottom:18px;
            box-shadow:0 4px 15px rgba(0,0,0,.05); display:none;
        }
        .result-card.visible { display:block; animation:fadeIn .5s ease; }
        @keyframes fadeIn { from{opacity:0;transform:translateY(10px)} to{opacity:1;transform:translateY(0)} }
    </style>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-dark sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold" href="index.html"><i class="fas fa-book-open me-2 text-warning"></i>الموسوعة الإسلامية الشاملة</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav1">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="nav1">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link " href="index.html">الرئيسية</a></li>
        <li class="nav-item"><a class="nav-link " href="recitations.html">القرآن والتلاوات</a></li>
        <li class="nav-item"><a class="nav-link active" href="hadith.html">الحديث الشريف</a></li>
        <li class="nav-item"><a class="nav-link " href="fiqh.html">الفقه الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="fatwa.html">فتاوى العلماء <i class="fas fa-gavel"></i></a></li>
        <li class="nav-item"><a class="nav-link " href="seerah.html">السيرة والصحابة</a></li>
        <li class="nav-item"><a class="nav-link " href="aqeedah.html">العقيدة الإسلامية</a></li>
        <li class="nav-item"><a class="nav-link " href="history.html">التاريخ الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="library.html">المكتبة الشاملة</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- HERO -->
<section class="hadith-hero text-center">
    <div class="container" style="position:relative;z-index:2;">
        <div class="hero-icon"><i class="fas fa-scroll"></i></div>
        <h1 class="display-4 fw-bold mb-2">أكاديمية الحديث النبوي</h1>
        <p class="fs-5 opacity-75">الصحاح الستة | الأربعون النووية | علوم الحديث | الباحث الحديثي</p>
        <div class="hadith-of-day" id="hotd">
            <p class="mb-1 small opacity-75 fw-bold"><i class="fas fa-star text-warning me-1"></i>حديث اليوم</p>
            <p id="hotd-text" class="mb-0">"إنما الأعمال بالنيات، وإنما لكل امرئ ما نوى..."</p>
            <p id="hotd-source" class="mt-1 small opacity-75">― البخاري ومسلم</p>
        </div>
    </div>
</section>

<div class="container mb-5">

    <!-- MAIN TABS -->
    <ul class="nav academy-tabs" id="hadithTabs" role="tablist">
        <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#tab-kutub"><i class="fas fa-books"></i> الصحاح والسنن</button></li>
        <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-nawawi"><i class="fas fa-feather-alt"></i> الأربعون النووية</button></li>
        <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-mustalah"><i class="fas fa-graduation-cap"></i> علوم الحديث</button></li>
        <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-aimmah"><i class="fas fa-users"></i> أئمة الحديث</button></li>
        <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-baheth"><i class="fas fa-search"></i> الباحث الحديثي</button></li>
    </ul>

    <div class="tab-content" id="hadithTabsContent">

        <!-- ===== 1. KUTUB ===== -->
        <div class="tab-pane fade show active" id="tab-kutub" role="tabpanel">
            <div class="sec-title"><h3>الصحاح والسنن الكبرى</h3><p class="text-muted mt-2">الكتب التسعة المعتمدة في الحديث النبوي الشريف</p></div>
            <div class="row g-4">
                <!-- Bukhari -->
                <div class="col-lg-4 col-md-6">
                    <div class="kitab-card">
                        <span class="kitab-top" style="background:linear-gradient(90deg,#1a4f3a,#2d7a5c)"></span>
                        <div class="kitab-body text-center">
                            <div class="kitab-icon" style="background:rgba(26,79,58,.1);color:#1a4f3a;"><i class="fas fa-book"></i></div>
                            <h5 class="fw-bold text-dark">صحيح البخاري</h5>
                            <p class="text-muted small mb-2">الإمام محمد بن إسماعيل البخاري (ت 256 هـ)</p>
                            <p class="text-muted small">أصح كتاب بعد القرآن الكريم. جمعه الإمام البخاري بعد انتقاء من 600,000 حديث على مدى 16 سنة، واشترط في قبوله الشروط الأكثر صرامة.</p>
                            <div class="kitab-stat"><span><i class="fas fa-list-ol me-1"></i> عدد الأحاديث</span><strong>7,563</strong></div>
                        </div>
                    </div>
                </div>
                <!-- Muslim -->
                <div class="col-lg-4 col-md-6">
                    <div class="kitab-card">
                        <span class="kitab-top" style="background:linear-gradient(90deg,#145a90,#1a7cc4)"></span>
                        <div class="kitab-body text-center">
                            <div class="kitab-icon" style="background:rgba(20,90,144,.1);color:#145a90;"><i class="fas fa-book-open"></i></div>
                            <h5 class="fw-bold text-dark">صحيح مسلم</h5>
                            <p class="text-muted small mb-2">الإمام مسلم بن الحجاج النيسابوري (ت 261 هـ)</p>
                            <p class="text-muted small">ثاني أصح كتب الحديث. امتاز بحسن تبويبه وتجميع طرق الحديث الواحد في موضع واحد، مما يجعله أسهل في الدراسة.</p>
                            <div class="kitab-stat"><span><i class="fas fa-list-ol me-1"></i> عدد الأحاديث</span><strong>5,362</strong></div>
                        </div>
                    </div>
                </div>
                <!-- Abu Dawud -->
                <div class="col-lg-4 col-md-6">
                    <div class="kitab-card">
                        <span class="kitab-top" style="background:linear-gradient(90deg,#c9a66b,#e0c28f)"></span>
                        <div class="kitab-body text-center">
                            <div class="kitab-icon" style="background:rgba(201,166,107,.15);color:#9a7940;"><i class="fas fa-scroll"></i></div>
                            <h5 class="fw-bold text-dark">سنن أبي داود</h5>
                            <p class="text-muted small mb-2">الإمام أبو داود السجستاني (ت 275 هـ)</p>
                            <p class="text-muted small">أهم كتاب في الفقه الحديثي. انتخبها من أكثر من 500,000 حديث. قال الإمام أحمد: كفى بسنن أبي داود في الدين.</p>
                            <div class="kitab-stat"><span><i class="fas fa-list-ol me-1"></i> عدد الأحاديث</span><strong>5,274</strong></div>
                        </div>
                    </div>
                </div>
                <!-- Tirmidhi -->
                <div class="col-lg-4 col-md-6">
                    <div class="kitab-card">
                        <span class="kitab-top" style="background:linear-gradient(90deg,#8e44ad,#a569bd)"></span>
                        <div class="kitab-body text-center">
                            <div class="kitab-icon" style="background:rgba(142,68,173,.1);color:#8e44ad;"><i class="fas fa-star-half-alt"></i></div>
                            <h5 class="fw-bold text-dark">جامع الترمذي</h5>
                            <p class="text-muted small mb-2">الإمام أبو عيسى الترمذي (ت 279 هـ)</p>
                            <p class="text-muted small">يُعدّ جامعاً لأنه يشمل مسائل الأحكام وبيان درجة الحديث (صحيح ، حسن، ضعيف) وذكر مذاهب الفقهاء فيه.</p>
                            <div class="kitab-stat"><span><i class="fas fa-list-ol me-1"></i> عدد الأحاديث</span><strong>3,956</strong></div>
                        </div>
                    </div>
                </div>
                <!-- Nasai -->
                <div class="col-lg-4 col-md-6">
                    <div class="kitab-card">
                        <span class="kitab-top" style="background:linear-gradient(90deg,#c0392b,#e74c3c)"></span>
                        <div class="kitab-body text-center">
                            <div class="kitab-icon" style="background:rgba(192,57,43,.1);color:#c0392b;"><i class="fas fa-feather"></i></div>
                            <h5 class="fw-bold text-dark">سنن النسائي</h5>
                            <p class="text-muted small mb-2">الإمام أحمد بن شعيب النسائي (ت 303 هـ)</p>
                            <p class="text-muted small">يُعدّ من أقل الكتب الستة رواية للضعيف والمنكر. امتاز بدقة انتقاده للأسانيد وتنبيهه على العلل الخفية.</p>
                            <div class="kitab-stat"><span><i class="fas fa-list-ol me-1"></i> عدد الأحاديث</span><strong>5,758</strong></div>
                        </div>
                    </div>
                </div>
                <!-- Ibn Majah -->
                <div class="col-lg-4 col-md-6">
                    <div class="kitab-card">
                        <span class="kitab-top" style="background:linear-gradient(90deg,#d35400,#e67e22)"></span>
                        <div class="kitab-body text-center">
                            <div class="kitab-icon" style="background:rgba(211,84,0,.1);color:#d35400;"><i class="fas fa-landmark"></i></div>
                            <h5 class="fw-bold text-dark">سنن ابن ماجه</h5>
                            <p class="text-muted small mb-2">الإمام محمد بن يزيد ابن ماجه (ت 273 هـ)</p>
                            <p class="text-muted small">يشتمل على أحاديث لا توجد في الكتب الخمسة الأخرى. وقد تنافس مع موطأ مالك ومسند أحمد في احتلال مكانة السادس.</p>
                            <div class="kitab-stat"><span><i class="fas fa-list-ol me-1"></i> عدد الأحاديث</span><strong>4,341</strong></div>
                        </div>
                    </div>
                </div>
                <!-- Muwatta -->
                <div class="col-lg-4 col-md-6">
                    <div class="kitab-card">
                        <span class="kitab-top" style="background:linear-gradient(90deg,#27ae60,#2ecc71)"></span>
                        <div class="kitab-body text-center">
                            <div class="kitab-icon" style="background:rgba(39,174,96,.1);color:#27ae60;"><i class="fas fa-leaf"></i></div>
                            <h5 class="fw-bold text-dark">موطأ الإمام مالك</h5>
                            <p class="text-muted small mb-2">الإمام مالك بن أنس (ت 179 هـ)</p>
                            <p class="text-muted small">أقدم كتب الحديث الموثّقة. قال عنه الشافعي: ما على ظهر الأرض كتاب بعد كتاب الله أصح من كتاب مالك.</p>
                            <div class="kitab-stat"><span><i class="fas fa-list-ol me-1"></i> عدد الأحاديث</span><strong>1,720</strong></div>
                        </div>
                    </div>
                </div>
                <!-- Musnad Ahmad -->
                <div class="col-lg-4 col-md-6">
                    <div class="kitab-card">
                        <span class="kitab-top" style="background:linear-gradient(90deg,#2c3e50,#34495e)"></span>
                        <div class="kitab-body text-center">
                            <div class="kitab-icon" style="background:rgba(44,62,80,.1);color:#2c3e50;"><i class="fas fa-archive"></i></div>
                            <h5 class="fw-bold text-dark">مسند الإمام أحمد</h5>
                            <p class="text-muted small mb-2">الإمام أحمد بن حنبل (ت 241 هـ)</p>
                            <p class="text-muted small">أكبر مسانيد الحديث. رتّبه على مسانيد الصحابة. يحتوي على أحاديث نادرة لا توجد في غيره وقد تعهّد ابنه بإكماله.</p>
                            <div class="kitab-stat"><span><i class="fas fa-list-ol me-1"></i> عدد الأحاديث</span><strong>40,000+</strong></div>
                        </div>
                    </div>
                </div>
                <!-- Darimi -->
                <div class="col-lg-4 col-md-6">
                    <div class="kitab-card">
                        <span class="kitab-top" style="background:linear-gradient(90deg,#1abc9c,#16a085)"></span>
                        <div class="kitab-body text-center">
                            <div class="kitab-icon" style="background:rgba(26,188,156,.1);color:#16a085;"><i class="fas fa-book-reader"></i></div>
                            <h5 class="fw-bold text-dark">سنن الدارمي</h5>
                            <p class="text-muted small mb-2">الإمام عبد الله بن عبد الرحمن الدارمي (ت 255 هـ)</p>
                            <p class="text-muted small">يشتمل على أحاديث مرفوعة وموقوفة ومقطوعة، ويُعدّ من أصح الكتب وأنقاها شيوخاً.</p>
                            <div class="kitab-stat"><span><i class="fas fa-list-ol me-1"></i> عدد الأحاديث</span><strong>3,540</strong></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ===== 2. NAWAWI ===== -->
        <div class="tab-pane fade" id="tab-nawawi" role="tabpanel">
            <div class="sec-title"><h3>الأربعون النووية</h3><p class="text-muted mt-2">أربعون حديثاً وحديثان جمعها الإمام النووي تشمل أصول الإسلام والإيمان والإحسان</p></div>
            <div class="mb-4">
                <input type="text" id="nawawi-search" class="form-control" placeholder="ابحث في الأربعين النووية بالكلمة أو الرقم...">
            </div>
            <div id="nawawi-container"><!-- Rendered by JS --></div>
        </div>

        <!-- ===== 3. MUSTALAH ===== -->
        <div class="tab-pane fade" id="tab-mustalah" role="tabpanel">
            <div class="sec-title"><h3>علوم الحديث ومصطلحاته</h3><p class="text-muted mt-2">الأدوات الأساسية لنقد الحديث وتمييز الصحيح من الضعيف</p></div>
            <div class="row g-4">
                <div class="col-lg-3 col-md-6">
                    <div class="mustalah-card" style="background:linear-gradient(145deg,#e8f8f0,#d4edda);">
                        <div class="mustalah-icon" style="background:linear-gradient(135deg,#27ae60,#2ecc71);color:white;"><i class="fas fa-check-double"></i></div>
                        <h5 class="fw-bold" style="color:#1a5c36;">الحديث الصحيح</h5>
                        <p class="text-muted small mb-0">ما اتصل سنده بنقل العدل الضابط عن مثله من غير شذوذ ولا علة قادحة. وهو أعلى درجات الحديث قبولاً.</p>
                        <div class="mt-3 p-2 rounded text-center" style="background:rgba(39,174,96,.1);"><span class="fw-bold" style="color:#27ae60;">مثال: البخاري ومسلم</span></div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="mustalah-card" style="background:linear-gradient(145deg,#fef9e7,#fdebd0);">
                        <div class="mustalah-icon" style="background:linear-gradient(135deg,#f39c12,#e67e22);color:white;"><i class="fas fa-check"></i></div>
                        <h5 class="fw-bold" style="color:#9a5e10;">الحديث الحسن</h5>
                        <p class="text-muted small mb-0">ما اتصل سنده بنقل عدل خفيف الضبط من غير شذوذ ولا علة. يُحتج به كالصحيح لكنه أدنى منه درجة.</p>
                        <div class="mt-3 p-2 rounded text-center" style="background:rgba(243,156,18,.1);"><span class="fw-bold" style="color:#f39c12;">مثال: معظم أحاديث الترمذي</span></div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="mustalah-card" style="background:linear-gradient(145deg,#f0f0f0,#e0e0e0);">
                        <div class="mustalah-icon" style="background:linear-gradient(135deg,#95a5a6,#7f8c8d);color:white;"><i class="fas fa-times"></i></div>
                        <h5 class="fw-bold" style="color:#5d6d7e;">الحديث الضعيف</h5>
                        <p class="text-muted small mb-0">ما لم تتوفر فيه شروط الصحة أو الحسن لانقطاع في السند أو ضعف في الراوي، ولا يُحتج به في الأحكام.</p>
                        <div class="mt-3 p-2 rounded text-center" style="background:rgba(149,165,166,.1);"><span class="fw-bold text-secondary">لا يُحتج به في الأحكام</span></div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="mustalah-card" style="background:linear-gradient(145deg,#fdecea,#f7c6c3);">
                        <div class="mustalah-icon" style="background:linear-gradient(135deg,#e74c3c,#c0392b);color:white;"><i class="fas fa-ban"></i></div>
                        <h5 class="fw-bold" style="color:#922b21;">الحديث الموضوع</h5>
                        <p class="text-muted small mb-0">ما اختُلق ونُسب كذباً وزوراً إلى النبي ﷺ. وهو أشد أنواع الحديث الضعيف وحرام روايته مع العلم بوضعه.</p>
                        <div class="mt-3 p-2 rounded text-center" style="background:rgba(231,76,60,.1);"><span class="fw-bold" style="color:#e74c3c;">حرام روايته!</span></div>
                    </div>
                </div>
                <!-- Row 2 -->
                <div class="col-lg-4 col-md-6">
                    <div class="mustalah-card" style="background:#fff;">
                        <div class="mustalah-icon" style="background:var(--grad-primary);color:white;"><i class="fas fa-link"></i></div>
                        <h5 class="fw-bold" style="color:var(--primary);">السند والمتن</h5>
                        <p class="text-muted small">السند: سلسلة الرواة الموصلة إلى النبي ﷺ. المتن: نص الحديث نفسه وألفاظه.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="mustalah-card" style="background:#fff;">
                        <div class="mustalah-icon" style="background:var(--grad-gold);color:white;"><i class="fas fa-user-check"></i></div>
                        <h5 class="fw-bold text-warning" style="color:#9a7940 !important;">العدالة والضبط</h5>
                        <p class="text-muted small">العدالة: الاستقامة الدينية في الراوي. الضبط: دقته في الحفظ والأداء سواء أكان صدرياً أم كتابياً.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="mustalah-card" style="background:#fff;">
                        <div class="mustalah-icon" style="background:linear-gradient(135deg,#2980b9,#3498db);color:white;"><i class="fas fa-project-diagram"></i></div>
                        <h5 class="fw-bold" style="color:#2980b9;">الاتصال والانقطاع</h5>
                        <p class="text-muted small">الاتصال: سماع كل راوٍ مباشرةً ممن فوقه. الانقطاع: سقوط راوٍ أو أكثر من السند (المرسل، المعضل، المنقطع).</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- ===== 4. AIMMAH ===== -->
        <div class="tab-pane fade" id="tab-aimmah" role="tabpanel">
            <div class="sec-title"><h3>أئمة الحديث ونقاده</h3><p class="text-muted mt-2">العلماء الذين حفظوا السنة النبوية وصانوها من الدسائس والوضع</p></div>
            <div class="row g-4">
                <!-- Bukhari -->
                <div class="col-lg-3 col-md-6">
                    <div class="imam-card p-4 text-center">
                        <div class="imam-avatar"><i class="fas fa-user-graduate"></i></div>
                        <h5 class="fw-bold mb-1" style="color:var(--primary);">الإمام البخاري</h5>
                        <p class="text-muted small mb-2">194 هـ – 256 هـ</p>
                        <p class="text-muted small">أمير المؤمنين في الحديث. يُقال إنه كان يحفظ 100,000 حديث صحيح و200,000 حديث غير صحيح. كان يُقدِّم الاغتسال قبل كتابة الحديث.</p>
                        <span class="badge mt-2" style="background:rgba(26,79,58,.1);color:var(--primary);">البصرة ← خراسان</span>
                    </div>
                </div>
                <!-- Muslim -->
                <div class="col-lg-3 col-md-6">
                    <div class="imam-card p-4 text-center">
                        <div class="imam-avatar"><i class="fas fa-user-shield"></i></div>
                        <h5 class="fw-bold mb-1" style="color:var(--primary);">الإمام مسلم</h5>
                        <p class="text-muted small mb-2">204 هـ – 261 هـ</p>
                        <p class="text-muted small">ثاني عمالقة المحدثين. قال: "لو أن أهل الحديث يكتبون مائتي سنة حديثهم فمدارهم على هذا المسند". انتخب صحيحه من 300,000 حديث.</p>
                        <span class="badge mt-2" style="background:rgba(26,79,58,.1);color:var(--primary);">نيسابور</span>
                    </div>
                </div>
                <!-- Ahmad -->
                <div class="col-lg-3 col-md-6">
                    <div class="imam-card p-4 text-center">
                        <div class="imam-avatar"><i class="fas fa-chess-king"></i></div>
                        <h5 class="fw-bold mb-1" style="color:var(--primary);">الإمام أحمد</h5>
                        <p class="text-muted small mb-2">164 هـ – 241 هـ</p>
                        <p class="text-muted small">إمام أهل السنة وصاحب أكبر مسند في التاريخ. صبر على الفتنة وسجن ولم يُقرّ بخلق القرآن. قال الشافعي: أحمد إمام في ثمانية أشياء.</p>
                        <span class="badge mt-2" style="background:rgba(26,79,58,.1);color:var(--primary);">بغداد</span>
                    </div>
                </div>
                <!-- Nawawi -->
                <div class="col-lg-3 col-md-6">
                    <div class="imam-card p-4 text-center">
                        <div class="imam-avatar"><i class="fas fa-feather"></i></div>
                        <h5 class="fw-bold mb-1" style="color:var(--primary);">الإمام النووي</h5>
                        <p class="text-muted small mb-2">631 هـ – 676 هـ</p>
                        <p class="text-muted small">شرح الإمام مسلم وجمع الأربعين الحديثية المشهورة. مات شاباً (45 عاماً) وترك إرثاً علمياً هائلاً في الحديث والفقه.</p>
                        <span class="badge mt-2" style="background:rgba(26,79,58,.1);color:var(--primary);">نوى – الشام</span>
                    </div>
                </div>
                <!-- Daraqutni -->
                <div class="col-lg-3 col-md-6">
                    <div class="imam-card p-4 text-center">
                        <div class="imam-avatar"><i class="fas fa-microscope"></i></div>
                        <h5 class="fw-bold mb-1" style="color:var(--primary);">الدارقطني</h5>
                        <p class="text-muted small mb-2">306 هـ – 385 هـ</p>
                        <p class="text-muted small">أمير المؤمنين في الحديث في عصره. برع في نقد الأسانيد وبيان العلل الخفية. كتابه "العلل" من أمهات الكتب في الجرح والتعديل.</p>
                        <span class="badge mt-2" style="background:rgba(26,79,58,.1);color:var(--primary);">بغداد</span>
                    </div>
                </div>
                <!-- Ibn Hajr -->
                <div class="col-lg-3 col-md-6">
                    <div class="imam-card p-4 text-center">
                        <div class="imam-avatar"><i class="fas fa-pen-nib"></i></div>
                        <h5 class="fw-bold mb-1" style="color:var(--primary);">ابن حجر العسقلاني</h5>
                        <p class="text-muted small mb-2">773 هـ – 852 هـ</p>
                        <p class="text-muted small">صاحب "فتح الباري" أعظم شروح البخاري. وكتاب "تقريب التهذيب" في مصطلح الرجال. استغرق شرحه للبخاري أكثر من 25 سنة.</p>
                        <span class="badge mt-2" style="background:rgba(26,79,58,.1);color:var(--primary);">القاهرة</span>
                    </div>
                </div>
                <!-- Suyuti -->
                <div class="col-lg-3 col-md-6">
                    <div class="imam-card p-4 text-center">
                        <div class="imam-avatar"><i class="fas fa-book-reader"></i></div>
                        <h5 class="fw-bold mb-1" style="color:var(--primary);">الإمام السيوطي</h5>
                        <p class="text-muted small mb-2">849 هـ – 911 هـ</p>
                        <p class="text-muted small">الحافظ المكثر، ألّف أكثر من 600 كتاب. ادّعى أنه بلغ درجة الاجتهاد المطلق وأنه يرى النبيﷺ في اليقظة أكثر من سبعين مرة.</p>
                        <span class="badge mt-2" style="background:rgba(26,79,58,.1);color:var(--primary);">مصر</span>
                    </div>
                </div>
                <!-- Albani -->
                <div class="col-lg-3 col-md-6">
                    <div class="imam-card p-4 text-center">
                        <div class="imam-avatar"><i class="fas fa-search"></i></div>
                        <h5 class="fw-bold mb-1" style="color:var(--primary);">الشيخ الألباني</h5>
                        <p class="text-muted small mb-2">1914 م – 1999 م</p>
                        <p class="text-muted small">محدث العصر ومجدد علم الحديث في القرن العشرين. صنّف الأحاديث في "الصحيحة والضعيفة" وخلّف آلاف المجلدات التحقيقية.</p>
                        <span class="badge mt-2" style="background:rgba(26,79,58,.1);color:var(--primary);">ألبانيا → الأردن</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- ===== 5. BAHETH ===== -->
        <div class="tab-pane fade" id="tab-baheth" role="tabpanel">
            <div class="sec-title"><h3>الباحث في الأربعين النووية</h3><p class="text-muted mt-2">ابحث عن أي حديث من الأربعين النووية بالكلمة أو الموضوع</p></div>
            <div class="baheth-box">
                <div class="input-group mb-3">
                    <input type="text" id="baheth-input" class="form-control" placeholder="اكتب كلمة للبحث مثل: نية، الله، الإسلام...">
                    <button class="btn" style="background:var(--grad-primary);color:white;" id="baheth-btn"><i class="fas fa-search me-2"></i>بحث</button>
                </div>
                <div id="baheth-status" class="text-muted text-center small"></div>
            </div>
            <div id="baheth-results"></div>
        </div>

    </div>
</div>

<!-- FOOTER -->
<footer class="mega-footer" style="background:linear-gradient(135deg,var(--dark),#020617);color:white;padding:80px 0 30px;margin-top:80px;border-top:3px solid var(--gold-dark);">
  <div class="container">
    <div class="row g-5 mb-5 border-bottom border-light border-opacity-10 pb-5">
      <div class="col-lg-4 text-md-end text-center">
        <i class="fas fa-mosque fa-4x text-warning mb-4 d-block"></i>
        <h4 class="fw-bold font-amiri fs-2 mb-3">الموسوعة الإسلامية الشاملة</h4>
        <p class="opacity-75 fs-6 line-height-2">أضخم صرح رقمي يجمع علوم القرآن العظيم، وأحاديث المصطفى، وفقهاء المذاهب، والتاريخ المجيد في منصة موثقة مصممة بأحدث التقنيات.</p>
      </div>
      <div class="col-lg-4 text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">تصفح الموسوعة</h5>
        <div class="d-flex flex-wrap justify-content-center gap-2">
          <a href="recitations.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">أكاديمية القرآن</a>
          <a href="hadith.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الحديث النبوي</a>
          <a href="seerah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">السيرة والصحابة</a>
          <a href="fiqh.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الفقه وأصوله</a>
          <a href="fatwa.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">فتاوى العلماء</a>
          <a href="aqeedah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">العقيدة الإسلامية</a>
          <a href="history.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">التاريخ المجيد</a>
          <a href="library.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">المكتبة الشاملة</a>
        </div>
      </div>
      <div class="col-lg-4 text-md-start text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">روابط سريعة</h5>
        <a href="contact.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> اتصل بالمطور</a>
        <a href="share.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> شارك الأجر</a>
        <a href="login.html" class="mega-footer-link text-warning mt-3" style="text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-user-circle me-2 ms-1"></i> تسجيل الدخول</a>
      </div>
    </div>
    <div class="text-center font-amiri fs-5 d-flex flex-column gap-2">
      <span class="opacity-75">الموسوعة الإسلامية الشاملة &copy; 2026 تم التصميم للإفادة | عمل مجاني لوجه الله</span>
      <span class="text-warning fw-bold fs-4 mt-2">تصميم وتطوير: لخذاري محمد سيف الدين</span>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="nawawi.js"></script>
<script>
// ===== Hadith of the Day =====
const hotdPicks = [1, 6, 12, 15, 18, 19, 23, 27, 34, 36];
const dayIdx = new Date().getDate() % hotdPicks.length;
const hotd = nawawiHadiths[hotdPicks[dayIdx] - 1];
if (hotd) {
    document.getElementById('hotd-text').textContent = hotd.text.substring(0, 200) + '...';
    document.getElementById('hotd-source').textContent = '— ' + hotd.source;
}

// ===== Render Nawawi =====
function renderNawawi(hadiths) {
    const container = document.getElementById('nawawi-container');
    container.innerHTML = '';
    if (!hadiths.length) {
        container.innerHTML = '<div class="text-center py-5 text-muted"><i class="fas fa-search fa-3x mb-3 d-block"></i>لا توجد نتائج مطابقة للبحث.</div>';
        return;
    }
    hadiths.forEach(h => {
        const div = document.createElement('div');
        div.className = 'nawawi-card';
        div.innerHTML = `
            <div class="nawawi-num">${h.number}</div>
            <div class="d-flex align-items-center mb-3 ps-4">
                <div style="width:45px;height:45px;background:var(--grad-primary);border-radius:50%;display:flex;align-items:center;justify-content:center;color:white;font-family:'Amiri',serif;font-size:1.3rem;font-weight:bold;flex-shrink:0;">${h.number}</div>
                <div class="me-3">
                    <h6 class="fw-bold mb-0" style="color:var(--primary);">${h.title}</h6>
                    <small class="text-muted"><i class="fas fa-user me-1"></i>${h.narrator}</small>
                </div>
            </div>
            <p class="nawawi-text">${h.text}</p>
            <span class="nawawi-source"><i class="fas fa-book me-1"></i>${h.source}</span>`;
        container.appendChild(div);
    });
}
renderNawawi(nawawiHadiths);

// ===== Nawawi Search =====
document.getElementById('nawawi-search').addEventListener('input', function() {
    const q = this.value.trim().toLowerCase();
    const filtered = q ? nawawiHadiths.filter(h =>
        h.title.toLowerCase().includes(q) ||
        h.text.toLowerCase().includes(q) ||
        String(h.number).includes(q)
    ) : nawawiHadiths;
    renderNawawi(filtered);
});

// ===== Baheth Search =====
function doBaheth() {
    const q = document.getElementById('baheth-input').value.trim().toLowerCase();
    const container = document.getElementById('baheth-results');
    const status = document.getElementById('baheth-status');
    container.innerHTML = '';
    if (!q) { status.textContent = 'يرجى إدخال كلمة للبحث.'; return; }
    const matches = nawawiHadiths.filter(h =>
        h.title.toLowerCase().includes(q) ||
        h.text.toLowerCase().includes(q)
    );
    status.textContent = matches.length ? `وُجد ${matches.length} نتيجة للبحث عن: "${q}"` : `لم يوجد شيء عن: "${q}"`;
    matches.forEach(h => {
        const d = document.createElement('div');
        d.className = 'result-card visible';
        d.innerHTML = `
            <div class="d-flex align-items-center mb-2">
                <span class="badge me-2 px-3 py-2" style="background:var(--grad-primary);font-size:1rem;">${h.number}</span>
                <strong style="color:var(--primary);">${h.title}</strong>
            </div>
            <p class="mb-2" style="font-family:'Amiri',serif;font-size:1.1rem;line-height:2;">${h.text.substring(0, 300)}...</p>
            <small class="text-muted"><i class="fas fa-book me-1"></i>${h.source}</small>`;
        container.appendChild(d);
    });
}
document.getElementById('baheth-btn').addEventListener('click', doBaheth);
document.getElementById('baheth-input').addEventListener('keydown', e => { if (e.key === 'Enter') doBaheth(); });
</script>
</body>
</html>"""

with codecs.open(file_path, 'w', 'utf-8') as f:
    f.write(html)
print("hadith.html rewritten successfully!")
