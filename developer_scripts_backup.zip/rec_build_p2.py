import codecs

part2 = """
<!-- TAB 2: QIRAAT -->
<div class="tab-pane fade" id="t-10">
  <div class="sec-head">
    <span class="tag">تنوع رباني معجز</span>
    <h3>القراءات العشر <span>المتواترة</span></h3>
    <p>سبع قراءات ثم ثلاث مكملات، تواترت عن النبي ﷺ بأحرف العرب، حفظت المعاني وأثرت الدلالات</p>
    <div class="divider"></div>
  </div>

  <div class="row g-4 mb-5">
    <!-- Qira'at Nafe' -->
    <div class="col-lg-4 col-md-6">
      <div class="qiraat-card">
        <div class="qiraat-icon"><i class="fas fa-book-reader"></i></div>
        <h5 style="color:#064b63;font-weight:700;">قراءة نافع المدني</h5>
        <div class="d-flex gap-2 mb-3">
          <span class="badge bg-light text-dark border">قالون</span>
          <span class="badge bg-light text-dark border">ورش</span>
        </div>
        <p class="text-muted small" style="line-height:1.9;">من أشهر القراءات في العالم الإسلامي، وتنتشر رواية ورش في المغرب العربي، ورواية قالون في ليبيا وتونس وأجزاء من إفريقيا. تمتاز بأحكام المدود والنقل.</p>
      </div>
    </div>
    
    <!-- Qira'at Ibn Kathir -->
    <div class="col-lg-4 col-md-6">
      <div class="qiraat-card">
        <div class="qiraat-icon"><i class="fas fa-kaaba"></i></div>
        <h5 style="color:#064b63;font-weight:700;">قراءة ابن كثير المكي</h5>
        <div class="d-flex gap-2 mb-3">
          <span class="badge bg-light text-dark border">البزي</span>
          <span class="badge bg-light text-dark border">قنبل</span>
        </div>
        <p class="text-muted small" style="line-height:1.9;">إمام أهل مكة في القراءة. تمتاز قراءته بصلة ميم الجمع وصلة هاء الضمير دائماً. وهي قراءة سهلة يسيرة ذات وقع محبب للنفوس.</p>
      </div>
    </div>
    
    <!-- Qira'at Abu Amr -->
    <div class="col-lg-4 col-md-6">
      <div class="qiraat-card">
        <div class="qiraat-icon"><i class="fas fa-water"></i></div>
        <h5 style="color:#064b63;font-weight:700;">قراءة أبي عمرو البصري</h5>
        <div class="d-flex gap-2 mb-3">
          <span class="badge bg-light text-dark border">الدوري</span>
          <span class="badge bg-light text-dark border">السوسي</span>
        </div>
        <p class="text-muted small" style="line-height:1.9;">قراءة أهل البصرة وأجزاء من السودان والصومال في رواية الدوري. تمتاز بالإدغام الكبير في رواية السوسي، والتقليل والإمالة.</p>
      </div>
    </div>
    
    <!-- Qira'at Ibn Amir -->
    <div class="col-lg-4 col-md-6">
      <div class="qiraat-card">
        <div class="qiraat-icon"><i class="fas fa-mosque"></i></div>
        <h5 style="color:#064b63;font-weight:700;">قراءة ابن عامر الشامي</h5>
        <div class="d-flex gap-2 mb-3">
          <span class="badge bg-light text-dark border">هشام</span>
          <span class="badge bg-light text-dark border">ابن ذكوان</span>
        </div>
        <p class="text-muted small" style="line-height:1.9;">إمام الشام بدمشق في عهد التابعين. أخذ القراءة عرضاً عن الصحابة. تمتاز بالهمزات وتحقيقها، وهي قراءة قديمة وعريقة.</p>
      </div>
    </div>
    
    <!-- Qira'at Asim -->
    <div class="col-lg-4 col-md-6">
      <div class="qiraat-card border-top border-warning" style="border-width:4px;">
        <div class="qiraat-icon" style="background:var(--gold);color:#064b63;"><i class="fas fa-globe"></i></div>
        <h5 style="color:#064b63;font-weight:700;">قراءة عاصم الكوفي</h5>
        <div class="d-flex gap-2 mb-3">
          <span class="badge bg-warning text-dark border border-warning">شعبة</span>
          <span class="badge bg-warning text-dark border border-warning">حفص</span>
        </div>
        <p class="text-muted small" style="line-height:1.9;">رواية حفص عن عاصم هي الأكثر انتشاراً الآن في العالم الإسلامي بنسبة 95٪. قراءة متقنة وواضحة جداً، سلسلة في النطق، وعليها معظم طباعة المصاحف.</p>
      </div>
    </div>
    
    <!-- Qira'at Hamzah -->
    <div class="col-lg-4 col-md-6">
      <div class="qiraat-card">
        <div class="qiraat-icon"><i class="fas fa-link"></i></div>
        <h5 style="color:#064b63;font-weight:700;">قراءة حمزة الزيات</h5>
        <div class="d-flex gap-2 mb-3">
          <span class="badge bg-light text-dark border">خلف</span>
          <span class="badge bg-light text-dark border">خلاد</span>
        </div>
        <p class="text-muted small" style="line-height:1.9;">إمام الكوفة. اشتهرت قراءته بقوة أحكامها، وطول المد المتصل والمنفصل (6 حركات)، والإمالات الكثيرة والسكت على الساكن قبل الهمز.</p>
      </div>
    </div>
  </div>
</div>

<!-- TAB 3: QURA -->
<div class="tab-pane fade" id="t-qura">
  <div class="sec-head">
    <span class="tag">أصوات من نور</span>
    <h3>أشهر <span>القراء</span></h3>
    <p>باقة مختارة من أعلام التلاوة في العالم الإسلامي أصحاب الحناجر الذهبية والأداء الخاشع</p>
    <div class="divider"></div>
  </div>

  <div class="row g-4">
    <!-- Abdul Basit -->
    <div class="col-lg-3 col-md-4 col-sm-6">
      <div class="reciter-card">
        <div class="r-img"><i class="fas fa-user-tie"></i></div>
        <div class="r-body">
          <strong style="color:#064b63;font-size:1.1rem;display:block;">عبد الباسط عبد الصمد</strong>
          <span class="text-muted d-block small mb-2">الصوت الذهبي، مصري</span>
          <button class="btn btn-sm btn-outline-info rounded-pill w-100"><i class="fas fa-play me-1"></i>استمع لتلاوته</button>
        </div>
      </div>
    </div>
    <!-- Al Minshawi -->
    <div class="col-lg-3 col-md-4 col-sm-6">
      <div class="reciter-card">
        <div class="r-img"><i class="fas fa-user-tie"></i></div>
        <div class="r-body">
          <strong style="color:#064b63;font-size:1.1rem;display:block;">محمد صديق المنشاوي</strong>
          <span class="text-muted d-block small mb-2">الصوت الباكي الخاشع</span>
          <button class="btn btn-sm btn-outline-info rounded-pill w-100"><i class="fas fa-play me-1"></i>استمع لتلاوته</button>
        </div>
      </div>
    </div>
    <!-- Al Husary -->
    <div class="col-lg-3 col-md-4 col-sm-6">
      <div class="reciter-card">
        <div class="r-img"><i class="fas fa-user-tie"></i></div>
        <div class="r-body">
          <strong style="color:#064b63;font-size:1.1rem;display:block;">محمود خليل الحصري</strong>
          <span class="text-muted d-block small mb-2">شيخ عموم المقارئ، التجويد المتقن</span>
          <button class="btn btn-sm btn-outline-info rounded-pill w-100"><i class="fas fa-play me-1"></i>استمع لتلاوته</button>
        </div>
      </div>
    </div>
    <!-- Mishari -->
    <div class="col-lg-3 col-md-4 col-sm-6">
      <div class="reciter-card">
        <div class="r-img"><i class="fas fa-user-tie"></i></div>
        <div class="r-body">
          <strong style="color:#064b63;font-size:1.1rem;display:block;">مشاري راشد العفاسي</strong>
          <span class="text-muted d-block small mb-2">كويتي، صوت شجي وإصدارات متعددة</span>
          <button class="btn btn-sm btn-outline-info rounded-pill w-100"><i class="fas fa-play me-1"></i>استمع لتلاوته</button>
        </div>
      </div>
    </div>
    <!-- Al Sudais -->
    <div class="col-lg-3 col-md-4 col-sm-6">
      <div class="reciter-card">
        <div class="r-img"><i class="fas fa-user-tie"></i></div>
        <div class="r-body">
          <strong style="color:#064b63;font-size:1.1rem;display:block;">عبد الرحمن السديس</strong>
          <span class="text-muted d-block small mb-2">إمام الحرم المكي، سعودي</span>
          <button class="btn btn-sm btn-outline-info rounded-pill w-100"><i class="fas fa-play me-1"></i>استمع لتلاوته</button>
        </div>
      </div>
    </div>
    <!-- Al Shuraim -->
    <div class="col-lg-3 col-md-4 col-sm-6">
      <div class="reciter-card">
        <div class="r-img"><i class="fas fa-user-tie"></i></div>
        <div class="r-body">
          <strong style="color:#064b63;font-size:1.1rem;display:block;">سعود الشريم</strong>
          <span class="text-muted d-block small mb-2">إمام الحرم المكي، صوت جهوري</span>
          <button class="btn btn-sm btn-outline-info rounded-pill w-100"><i class="fas fa-play me-1"></i>استمع لتلاوته</button>
        </div>
      </div>
    </div>
    <!-- Al Ghamdi -->
    <div class="col-lg-3 col-md-4 col-sm-6">
      <div class="reciter-card">
        <div class="r-img"><i class="fas fa-user-tie"></i></div>
        <div class="r-body">
          <strong style="color:#064b63;font-size:1.1rem;display:block;">سعد الغامدي</strong>
          <span class="text-muted d-block small mb-2">تلاوات هادئة مريحة، سعودي</span>
          <button class="btn btn-sm btn-outline-info rounded-pill w-100"><i class="fas fa-play me-1"></i>استمع لتلاوته</button>
        </div>
      </div>
    </div>
    <!-- Maher -->
    <div class="col-lg-3 col-md-4 col-sm-6">
      <div class="reciter-card">
        <div class="r-img"><i class="fas fa-user-tie"></i></div>
        <div class="r-body">
          <strong style="color:#064b63;font-size:1.1rem;display:block;">ماهر المعيقلي</strong>
          <span class="text-muted d-block small mb-2">إمام الحرم المكي، أداء مميز جداً</span>
          <button class="btn btn-sm btn-outline-info rounded-pill w-100"><i class="fas fa-play me-1"></i>استمع لتلاوته</button>
        </div>
      </div>
    </div>
  </div>
</div>
"""

with codecs.open(r"C:\Users\ST\Desktop\islamic.encyclopedia\rec_p2.tmp", 'w', 'utf-8') as f:
    f.write(part2)
print("recitations part 2 ready")
