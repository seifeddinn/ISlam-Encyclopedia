
    <!-- TAB 1: QURAN -->
    <div class="tab-pane fade show active" id="t-quran">
      <div class="sec-head">
        <span class="tag">كتاب الله المكنون</span>
        <h3>المصحف <span>الشريف</span></h3>
        <p>تصفح سور القرآن الكريم، اقرأها بالتشكيل الكامل، واستمع للتلاوة</p>
        <div class="divider"></div>
      </div>
      
      <div class="search-container col-lg-8 mx-auto">
        <i class="fas fa-search text-muted ms-2 fs-5"></i>
        <input type="text" id="quickSurahSearch" placeholder="ابحث عن سورة (مثال: الكهف، مريم...)">
        <div class="btn-group border-end pe-3 me-3" id="surahFilters" role="group">
          <button type="button" class="btn btn-outline-secondary active" data-filter="all">الكل</button>
          <button type="button" class="btn btn-outline-secondary" data-filter="meccan">مكية</button>
          <button type="button" class="btn btn-outline-secondary" data-filter="medinan">مدنية</button>
        </div>
      </div>

      <div class="row g-4" id="surah-list">
        <!-- Injected by JS -->
      </div>
    </div>

    <!-- TAB 2: 10 QIRAAT TREE -->
    <div class="tab-pane fade" id="t-10">
      <div class="sec-head">
        <span class="tag">تواتر القراءة والسند</span>
        <h3>القراءات العشر <span>المتواترة</span></h3>
        <p>القراءات القرآنية الثابتة بالتواتر القطعي عن النبي ﷺ، لكل قراءة من الأئمة العشرة راويان ضحيا بحياتهما لضبطها ونقلها.</p>
        <div class="divider"></div>
      </div>
      
      <div class="qiraat-tree-box mb-5">
        <div class="row g-5 text-center justify-content-center">
          
          <!-- Imam 1 -->
          <div class="col-lg-2 col-md-4 col-sm-6">
            <div class="imam-box"><i class="fas fa-kaaba fs-2 mb-2"></i><h4>نافع المدني</h4></div>
            <div class="d-flex justify-content-between mt-3 position-relative">
               <div class="connector-line" style="height:20px;top:-20px;left:50%;"></div>
               <div class="connector-line" style="width:70%;height:2px;top:-10px;left:15%;"></div>
               <div class="rawi-box w-100 me-2" onclick="alert('قالون: عيسى بن مينا، قارئ المدينة')">قالون</div>
               <div class="rawi-box w-100 ms-2" onclick="alert('ورش: عثمان بن سعيد، رحل من مصر ليقرأ على نافع')">ورش</div>
            </div>
          </div>
          
          <!-- Imam 2 -->
          <div class="col-lg-2 col-md-4 col-sm-6">
            <div class="imam-box"><i class="fas fa-mosque fs-2 mb-2 text-warning"></i><h4>ابن كثير المكي</h4></div>
            <div class="d-flex justify-content-between mt-3 position-relative">
               <div class="connector-line" style="height:20px;top:-20px;left:50%;"></div>
               <div class="connector-line" style="width:70%;height:2px;top:-10px;left:15%;"></div>
               <div class="rawi-box w-100 me-2">البزي</div>
               <div class="rawi-box w-100 ms-2">قنبل</div>
            </div>
          </div>

          <!-- Imam 3 -->
          <div class="col-lg-2 col-md-4 col-sm-6">
            <div class="imam-box"><i class="fas fa-water fs-2 mb-2 text-info"></i><h4>أبو عمرو البصري</h4></div>
            <div class="d-flex justify-content-between mt-3 position-relative">
               <div class="connector-line" style="height:20px;top:-20px;left:50%;"></div>
               <div class="connector-line" style="width:70%;height:2px;top:-10px;left:15%;"></div>
               <div class="rawi-box w-100 me-2">الدوري</div>
               <div class="rawi-box w-100 ms-2">السوسي</div>
            </div>
          </div>

          <!-- Imam 4 -->
          <div class="col-lg-2 col-md-4 col-sm-6">
            <div class="imam-box"><i class="fas fa-map-marker-alt fs-2 mb-2 text-success"></i><h4>ابن عامر الشامي</h4></div>
            <div class="d-flex justify-content-between mt-3 position-relative">
               <div class="connector-line" style="height:20px;top:-20px;left:50%;"></div>
               <div class="connector-line" style="width:70%;height:2px;top:-10px;left:15%;"></div>
               <div class="rawi-box w-100 me-2">هشام</div>
               <div class="rawi-box w-100 ms-2">ابن ذكوان</div>
            </div>
          </div>

          <!-- Imam 5 -->
          <div class="col-lg-2 col-md-4 col-sm-6">
            <div class="imam-box" style="border:2px solid var(--gold);"><i class="fas fa-star fs-2 mb-2 text-warning"></i><h4>عاصم الكوفي</h4></div>
            <div class="d-flex justify-content-between mt-3 position-relative">
               <div class="connector-line" style="height:20px;top:-20px;left:50%;"></div>
               <div class="connector-line" style="width:70%;height:2px;top:-10px;left:15%;"></div>
               <div class="rawi-box w-100 me-2" style="background:#fef3c7;border-color:var(--gold);">شعبة</div>
               <div class="rawi-box w-100 ms-2" style="background:#fef3c7;border-color:var(--gold);">حفص</div>
            </div>
          </div>

          <!-- Imam 6 -->
          <div class="col-lg-2 col-md-4 col-sm-6">
            <div class="imam-box"><i class="fas fa-leaf fs-2 mb-2"></i><h4>حمزة الكوفي</h4></div>
            <div class="d-flex justify-content-between mt-3 position-relative">
               <div class="connector-line" style="height:20px;top:-20px;left:50%;"></div>
               <div class="connector-line" style="width:70%;height:2px;top:-10px;left:15%;"></div>
               <div class="rawi-box w-100 me-2">خلف</div>
               <div class="rawi-box w-100 ms-2">خلاد</div>
            </div>
          </div>

        </div> <!-- /row -->

        <div class="row g-5 text-center mt-2 justify-content-center">
          <!-- Imam 7 -->
          <div class="col-lg-2 col-md-4 col-sm-6">
            <div class="imam-box"><i class="fas fa-book fs-2 mb-2 text-muted"></i><h4>الكسائي الكوفي</h4></div>
            <div class="d-flex justify-content-between mt-3 position-relative">
               <div class="connector-line" style="height:20px;top:-20px;left:50%;"></div>
               <div class="connector-line" style="width:70%;height:2px;top:-10px;left:15%;"></div>
               <div class="rawi-box w-100 me-2">أبو الحارث</div>
               <div class="rawi-box w-100 ms-2">الدوري</div>
            </div>
          </div>
          <!-- Imam 8 -->
          <div class="col-lg-2 col-md-4 col-sm-6">
            <div class="imam-box"><i class="fas fa-sun fs-2 mb-2 text-warning"></i><h4>أبو جعفر المدني</h4></div>
            <div class="d-flex justify-content-between mt-3 position-relative">
               <div class="connector-line" style="height:20px;top:-20px;left:50%;"></div>
               <div class="connector-line" style="width:70%;height:2px;top:-10px;left:15%;"></div>
               <div class="rawi-box w-100 me-2">ابن وردان</div>
               <div class="rawi-box w-100 ms-2">ابن جماز</div>
            </div>
          </div>
          <!-- Imam 9 -->
          <div class="col-lg-2 col-md-4 col-sm-6">
            <div class="imam-box"><i class="fas fa-compass fs-2 mb-2 text-info"></i><h4>يعقوب الحضرمي</h4></div>
            <div class="d-flex justify-content-between mt-3 position-relative">
               <div class="connector-line" style="height:20px;top:-20px;left:50%;"></div>
               <div class="connector-line" style="width:70%;height:2px;top:-10px;left:15%;"></div>
               <div class="rawi-box w-100 me-2">رويس</div>
               <div class="rawi-box w-100 ms-2">رَوح</div>
            </div>
          </div>
          <!-- Imam 10 -->
          <div class="col-lg-2 col-md-4 col-sm-6">
            <div class="imam-box"><i class="fas fa-moon fs-2 mb-2 text-success"></i><h4>خلف العاشر</h4></div>
            <div class="d-flex justify-content-between mt-3 position-relative">
               <div class="connector-line" style="height:20px;top:-20px;left:50%;"></div>
               <div class="connector-line" style="width:70%;height:2px;top:-10px;left:15%;"></div>
               <div class="rawi-box w-100 me-2">إسحاق</div>
               <div class="rawi-box w-100 ms-2">إدريس</div>
            </div>
          </div>
        </div><!-- /row -->

      </div>

      <!-- Compare Section -->
      <div class="bg-white p-5 rounded-4 shadow-sm border mt-4 text-center">
        <h4 class="font-amiri fw-bold mb-4 text-primary">المقارنة التطبيقية (أمثلة من الفاتحة)</h4>
        <div class="table-responsive">
          <table class="table table-bordered table-hover align-middle">
            <thead class="table-light">
              <tr>
                <th>الكلمة / الآية</th>
                <th>رواية حفص عن عاصم (الشائعة)</th>
                <th>رواية ورش عن نافع</th>
                <th>رواية الدوري عن أبي عمرو</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>(مَالِكِ يَوْمِ الدِّينِ)</td>
                <td>مَالِكِ (بإثبات الألف)</td>
                <td>مَلِكِ (بحذف الألف)</td>
                <td>مَلِكِ (بحذف الألف)</td>
              </tr>
              <tr>
                <td>(الصِّرَاطَ)</td>
                <td>بالصاد الخالصة (الصِّرَاطَ)</td>
                <td>بالصاد الخالصة (الصِّرَاطَ)</td>
                <td>بالسين (السِّرَاطَ) في قراءة قنبل ورويس، أما الدوري فبالصاد</td>
              </tr>
              <tr>
                <td>(عَلَيْهِمْ)</td>
                <td>بكسر الهاء وسكون الميم (عَلَيْهِمْ)</td>
                <td>بكسر الهاء وضم الميم بصلة (عَلَيْهِمُو) إذا تلاها متحرك</td>
                <td>بكسر الهاء وضم الميم لأبي عمرو</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
