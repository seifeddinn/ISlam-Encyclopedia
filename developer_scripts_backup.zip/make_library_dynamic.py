import re

file_path = r"c:\Users\ST\Desktop\islamic.encyclopedia\library.html"

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Clear the contents inside #bookGrid
# The grid starts with <div class="row g-4" id="bookGrid"> and ends with </div> just before </section>
grid_pattern = re.compile(r'(<div class="row g-4" id="bookGrid">)(.*?)(    </section>)', re.DOTALL)
new_grid = r'\1\n        </div>\n\3'
content = grid_pattern.sub(new_grid, content)

# 2. Inject <script src="books.js"></script>
content = content.replace(
    '<script src="https://unpkg.com/isotope-layout@3/dist/isotope.pkgd.min.js"></script>',
    '<script src="https://unpkg.com/isotope-layout@3/dist/isotope.pkgd.min.js"></script>\n    <script src="books.js"></script>'
)

# 3. Replace the old initialization script with the new dynamic one
script_pattern = re.compile(r'<script>\s*document\.addEventListener\(\'DOMContentLoaded\', function \(\) \{.*?</script>', re.DOTALL)

new_script = """<script>
        document.addEventListener('DOMContentLoaded', function () {
            const grid = document.querySelector('#bookGrid');
            
            // 1. Render all books dynamically from booksData array
            if (typeof booksData !== 'undefined') {
                let htmlContent = '';
                booksData.forEach(book => {
                    let badgeClass = "badge-seerah";
                    if(book.id === 'quran') badgeClass = "badge-quran";
                    else if(book.id === 'hadith') badgeClass = "badge-hadith";
                    else if(book.id === 'fiqh') badgeClass = "badge-fiqh";
                    else if(book.id === 'aqeedah') badgeClass = "badge-aqeedah";
                    else if(book.id === 'tazkiyah') badgeClass = "badge-tazkiyah";
                    
                    htmlContent += `
                    <div class="col-md-4 col-lg-3 book-item" data-category="${book.id}">
                        <div class="card h-100 book-card">
                            <div class="card-body text-center p-4">
                                <div class="icon-wrapper"><i class="fas fa-${book.icon} mb-0"></i></div>
                                <h5 class="card-title">${book.title}</h5>
                                <p class="card-text text-muted small">${book.author}</p>
                                <span class="badge custom-badge ${badgeClass} mb-3">${book.categoryName}</span>
                            </div>
                            <div class="card-footer bg-white border-0 text-center pb-4 pt-0">
                                <button type="button" class="btn w-100 quick-view-btn" data-bs-toggle="modal" data-bs-target="#quickViewModal">
                                    <i class="fas fa-eye me-2"></i>معاينة الكتاب
                                </button>
                            </div>
                        </div>
                    </div>`;
                });
                grid.innerHTML = htmlContent;
            }

            // 2. Initialize Isotope after rendering items
            let iso;
            // Wait for elements to be fully rendered
            setTimeout(() => {
                iso = new Isotope(grid, {
                    itemSelector: '.book-item',
                    layoutMode: 'masonry',
                    isOriginLeft: false
                });

                // Category Filtering
                const filterButtons = document.querySelectorAll('[data-filter]');
                filterButtons.forEach(btn => {
                    btn.addEventListener('click', () => {
                        filterButtons.forEach(b => b.classList.remove('active'));
                        btn.classList.add('active');
                        const filterValue = btn.getAttribute('data-filter');
                        iso.arrange({
                            filter: filterValue === 'all' ? '*' : `[data-category="${filterValue}"]`
                        });
                    });
                });

                // Search text filtering
                const searchInput = document.getElementById('bookSearch');
                if (searchInput) {
                    searchInput.addEventListener('keyup', function () {
                        const query = this.value.trim().toLowerCase();
                        const activeBtn = document.querySelector('[data-filter].active');
                        const categoryFilter = activeBtn ? activeBtn.getAttribute('data-filter') : 'all';

                        iso.arrange({
                            filter: function(itemElem) {
                                const title = itemElem.querySelector('.card-title').textContent.toLowerCase();
                                const author = itemElem.querySelector('.card-text').textContent.toLowerCase();
                                const category = itemElem.getAttribute('data-category');
                                
                                const matchesSearch = title.includes(query) || author.includes(query);
                                const matchesCategory = categoryFilter === 'all' || category === categoryFilter;

                                return matchesSearch && matchesCategory;
                            }
                        });
                    });
                }
            }, 100);

            // 3. Quick View Dynamic Population (Event Delegation since cards are dynamic)
            grid.addEventListener('click', function(e) {
                const btn = e.target.closest('.quick-view-btn');
                if (!btn) return;
                
                const card = btn.closest('.card');
                const title = card.querySelector('.card-title').textContent.trim();
                const author = card.querySelector('.card-text').textContent.trim();
                const badge = card.querySelector('.badge').textContent.trim();
                const iconClass = card.querySelector('.card-body i').className;

                document.getElementById('qvTitle').textContent = title;
                document.getElementById('qvAuthor').textContent = "المؤلف: " + author;
                document.getElementById('qvCategory').textContent = badge;
                document.getElementById('qvIcon').className = iconClass + " fa-5x text-secondary mb-4";
                
                document.getElementById('qvDesc').textContent = `هذا الكتاب (${title}) للإمام والمؤلف ${author}، يُعَدُّ من أبرز وأهم المراجع في قسم ${badge}. الكتاب مزود بفهارس علمية لتسهيل الوصول للمعلومات، ويمكنك تحميله بصيغة PDF المرفقة بالقراءة المباشرة.`;
                document.getElementById('qvDownloadBtn').setAttribute('href', '#download_' + encodeURIComponent(title));
            });
        });
    </script>"""

content = script_pattern.sub(new_script, content)

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("library.html made dynamic successfully!")
