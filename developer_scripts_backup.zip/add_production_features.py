import os
import re

ga_snippet = """
<!-- Google Analytics Tag -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-XXXXXXXXXX'); // استبدل XXXXXXXXXX بمعرف التتبع الخاص بك
</script>
</head>
"""

sweetalert_script = """
<!-- SweetAlert2 Plugin -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            Swal.fire({
                title: 'قيد التطوير!',
                text: 'تم تصميم واجهة المستخدم بنجاح. لتفعيل هذه الخاصية، يرجى ربط قاعدة البيانات (مثل Firebase) واستبدال هذا النوافذ المنبثقة بكود الاتصال.',
                icon: 'info',
                confirmButtonText: 'حسناً',
                confirmButtonColor: '#d4af37'
            });
        });
    });
});
</script>
</body>
"""

for f in os.listdir('.'):
    if f.endswith('.html'):
        with open(f, 'r', encoding='utf-8') as file:
            content = file.read()
        
        changed = False

        # Add Google Analytics placeholder
        if "G-XXXXXXXXXX" not in content and "</head>" in content:
            content = content.replace("</head>", ga_snippet)
            changed = True

        # Convert simple contact form to Formspree
        if f == 'contact.html':
            if 'formspree.io' not in content:
                # Replace the first form tag it finds if it doesn't already have an action
                content = re.sub(r'<form\b([^>]*)>', r'<form action="https://formspree.io/f/YOUR_FORM_ID" method="POST" \1>', content)
                changed = True

        # Catch form submissions in Auth pages
        if f in ['login.html', 'register.html']:
            if "sweetalert2" not in content and "</body>" in content:
                content = content.replace("</body>", sweetalert_script)
                changed = True

        if changed:
            with open(f, 'w', encoding='utf-8') as file:
                file.write(content)
            print(f"[{f}] Production features applied.")

print("All features added successfully.")
