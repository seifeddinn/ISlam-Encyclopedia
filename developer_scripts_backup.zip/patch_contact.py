import codecs

try:
    with codecs.open(r"c:\Users\ST\Desktop\islamic.encyclopedia\contact.html", "r", "utf-8") as f:
        content = f.read()

    old_socials = """                <div class="d-flex justify-content-center mb-4">
                    <a href="mailto:contact@example.com" class="contact-btn" title="البريد الإلكتروني"><i class="fas fa-envelope"></i></a>
                    <a href="#" class="contact-btn" title="لينكد إن"><i class="fab fa-linkedin-in"></i></a>
                    <a href="#" class="contact-btn" title="جيت هاب"><i class="fab fa-github"></i></a>
                    <a href="#" class="contact-btn" title="تويتر"><i class="fab fa-twitter"></i></a>
                </div>"""

    new_socials = """                <div class="d-flex justify-content-center mb-4 flex-wrap gap-2">
                    <a href="mailto:contact@example.com" class="contact-btn" title="البريد الإلكتروني"><i class="fas fa-envelope"></i></a>
                    <a href="#" class="contact-btn" title="لينكد إن"><i class="fab fa-linkedin-in"></i></a>
                    <a href="#" class="contact-btn" title="جيت هاب"><i class="fab fa-github"></i></a>
                    <a href="#" class="contact-btn" style="color: #0088cc;" title="تيليجرام"><i class="fab fa-telegram-plane"></i></a>
                    <a href="#" class="contact-btn" style="color: var(--gold);" title="الموقع الشخصي للمطور"><i class="fas fa-globe"></i></a>
                </div>"""

    if old_socials in content:
        content = content.replace(old_socials, new_socials)
    else:
        print("Warning: old_socials block not found.")

    content = content.replace('<input type="text" class="form-control rounded-4 p-3 border-light bg-light" required>', '<input type="text" name="name" class="form-control rounded-4 p-3 border-light bg-light" required>')
    content = content.replace('<textarea class="form-control rounded-4 p-3 border-light bg-light" rows="4" required></textarea>', '<textarea name="message" class="form-control rounded-4 p-3 border-light bg-light" rows="4" required></textarea>')

    content = content.replace('onsubmit="event.preventDefault(); alert(\'تم إرسال رسالتك بنجاح! شكراً لتواصلك.\'); this.reset();"', '')

    with codecs.open(r"c:\Users\ST\Desktop\islamic.encyclopedia\contact.html", "w", "utf-8") as f:
        f.write(content)

    print("Contact page successfully patched!")

except Exception as e:
    print(f"Error: {e}")
