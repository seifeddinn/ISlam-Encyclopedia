import codecs

shb_navs = """
  <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t-fadail"><i class="fas fa-star me-1"></i>فضائل الصحابة</button></li>
  <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t-khulafa"><i class="fas fa-chess-king me-1"></i>الخلفاء الراشدون</button></li>
  <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t-ashara"><i class="fas fa-medal me-1"></i>العشرة المبشرون</button></li>
  <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t-ummahat"><i class="fas fa-female me-1"></i>أمهات المؤمنين</button></li>
  <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t-sahabiyat"><i class="fas fa-gem me-1"></i>أعلام الصحابيات</button></li>
"""

shb_tabs = """
<!-- TAB: FADAIL -->
<div class="tab-pane fade" id="t-fadail">
  <div class="sec-head">
    <span class="tag">خير القرون</span>
    <h3>فضائل <span>الصحابة واعتقادنا فيهم</span></h3>
    <p>عقيدة أهل السنة والجماعة في الصحابة هي الحب والترضي عليهم والإمساك عما شجر بينهم</p>
    <div class="divider"></div>
  </div>
  
  <div class="row g-4 mb-5">
    <div class="col-lg-4 col-md-6"><div class="p-4 bg-white rounded-4 shadow-sm h-100 border-bottom border-4 border-warning"><h5 style="color:#2c1810;font-weight:700;"><i class="fas fa-heart me-2 text-warning"></i>محبتهم دين وإيمان</h5><p class="text-muted small mt-3 mb-0" style="line-height:2;">حب الصحابة دين وإيمان وإحسان، وبغضهم كفر ونفاق وطغيان. فهم الذين نقلوا لنا الدين وصدّقوا الرسول.</p></div></div>
    <div class="col-lg-4 col-md-6"><div class="p-4 bg-white rounded-4 shadow-sm h-100 border-bottom border-4 border-warning"><h5 style="color:#2c1810;font-weight:700;"><i class="fas fa-shield-alt me-2 text-warning"></i>عدالتهم جميعاً</h5><p class="text-muted small mt-3 mb-0" style="line-height:2;">أجمع أهل السنة على عدالة جميع الصحابة بلا استثناء، فقد عدّلهم الله تعالى في آيات كثيرة من القرآن.</p></div></div>
    <div class="col-lg-4 col-md-6"><div class="p-4 bg-white rounded-4 shadow-sm h-100 border-bottom border-4 border-warning"><h5 style="color:#2c1810;font-weight:700;"><i class="fas fa-comment-slash me-2 text-warning"></i>الكف عما شجر بينهم</h5><p class="text-muted small mt-3 mb-0" style="line-height:2;">نعتقد أنهم مجتهدون، للمصيب أجران وللمخطئ أجر، وتاريخهم يطهر ولا ينبش بحثاً عن الزلات.</p></div></div>
    <div class="col-lg-4 col-md-6"><div class="p-4 bg-white rounded-4 shadow-sm h-100 border-bottom border-4 border-warning"><h5 style="color:#2c1810;font-weight:700;"><i class="fas fa-quran me-2 text-warning"></i>تزكية القرآن لهم</h5><p class="text-muted small mt-3 mb-0" style="line-height:2;">﴿وَالسَّابِقُونَ الْأَوَّلُونَ مِنَ الْمُهَاجِرِينَ وَالْأَنصَارِ وَالَّذِينَ اتَّبَعُوهُم بِإِحْسَانٍ رَّضِيَ اللَّهُ عَنْهُمْ وَرَضُوا عَنْهُ﴾.</p></div></div>
    <div class="col-lg-4 col-md-6"><div class="p-4 bg-white rounded-4 shadow-sm h-100 border-bottom border-4 border-warning"><h5 style="color:#2c1810;font-weight:700;"><i class="fas fa-layer-group me-2 text-warning"></i>تفاضل مراتبهم</h5><p class="text-muted small mt-3 mb-0" style="line-height:2;">أفضلهم الخلفاء الأربعة، ثم بقية العشرة، ثم أهل بدر، ثم أهل أحد، ثم بيعة الرضوان.</p></div></div>
    <div class="col-lg-4 col-md-6"><div class="p-4 bg-white rounded-4 shadow-sm h-100 border-bottom border-4 border-warning"><h5 style="color:#2c1810;font-weight:700;"><i class="fas fa-users me-2 text-warning"></i>المهاجرون والأنصار</h5><p class="text-muted small mt-3 mb-0" style="line-height:2;">آية الإيمان حب الأنصار المأويين، والمهاجرون الذين تركوا ديارهم نصرة لله مفضلون على غيرهم.</p></div></div>
  </div>
</div>

<!-- TAB: KHULAFA -->
<div class="tab-pane fade" id="t-khulafa">
  <div class="sec-head">
    <span class="tag">المهديون المتبعون</span>
    <h3>الخلفاء الراشدون <span>الأربعة</span></h3>
    <p>أفضل هذه الأمة بعد نبيها، أمرنا النبي ﷺ بسنتهم والعض عليها بالنواجذ</p>
    <div class="divider"></div>
  </div>

  <div class="row g-4 mb-5">
    <div class="col-lg-6">
      <div class="p-4 bg-white rounded-4 shadow-sm h-100" style="border-right:5px solid #000;">
        <h4 class="mb-1" style="font-weight:800;color:#2c1810;">1. أبو بكر الصديق</h4>
        <span class="opacity-75 small text-muted d-block mb-3">عبد الله بن عثمان الخزومي رضي الله عنه (مدة الخلافة: سنتان و3 أشهر)</span>
        <p class="text-muted small" style="line-height:1.9;">أول من آمن من الرجال، وصاحب النبي في الهجرة. تصدق بجميع ماله. من أعماله: قتال المرتدين وجمع القرآن.</p>
      </div>
    </div>
    
    <div class="col-lg-6">
      <div class="p-4 bg-white rounded-4 shadow-sm h-100" style="border-right:5px solid #000;">
        <h4 class="mb-1" style="font-weight:800;color:#2c1810;">2. عمر بن الخطاب</h4>
        <span class="opacity-75 small text-muted d-block mb-3">الفاروق أبو حفص رضي الله عنه (مدة الخلافة: 10 سنوات و6 أشهر)</span>
        <p class="text-muted small" style="line-height:1.9;">أعز الله الإسلام بإسلامه. فرّق الله به بين الحق والباطل. في عهده فتحت الشام والعراق ومصر. أنشأ الدواوين.</p>
      </div>
    </div>
    
    <div class="col-lg-6">
      <div class="p-4 bg-white rounded-4 shadow-sm h-100" style="border-right:5px solid #000;">
        <h4 class="mb-1" style="font-weight:800;color:#2c1810;">3. عثمان بن عفان</h4>
        <span class="opacity-75 small text-muted d-block mb-3">ذو النورين وأمير المؤمنين رضي الله عنه (مدة الخلافة: 12 سنة)</span>
        <p class="text-muted small" style="line-height:1.9;">تزوج ابنتي الرسول. عُرف بالحياء الشديد وتجهيز جيش العسرة. جمع الناس على مصحف واحد ووسع المسجدين.</p>
      </div>
    </div>
    
    <div class="col-lg-6">
      <div class="p-4 bg-white rounded-4 shadow-sm h-100" style="border-right:5px solid #000;">
        <h4 class="mb-1" style="font-weight:800;color:#2c1810;">4. علي بن أبي طالب</h4>
        <span class="opacity-75 small text-muted d-block mb-3">أبو الحسن وأبو تراب رضي الله عنه (مدة الخلافة: 4 سنوات و9 أشهر)</span>
        <p class="text-muted small" style="line-height:1.9;">أول من آمن من الصبيان ونام في فراش النبي ليلة الهجرة. زوج السيدة فاطمة. واشتهر بالبلاغة والشجاعة الفذة.</p>
      </div>
    </div>
  </div>
</div>

<!-- TAB: ASHARA -->
<div class="tab-pane fade" id="t-ashara">
  <div class="sec-head">
    <span class="tag">المشهد المهيب</span>
    <h3>العشرة المبشرون <span>بالجنة</span></h3>
    <p>بشرهم النبي ﷺ بالجنة وهم يمشون على الأرض في حديث واحد</p>
    <div class="divider"></div>
  </div>

  <div class="row g-3 mb-5 text-center">
    <div class="col-md-3 col-sm-6"><div class="p-3 bg-white rounded shadow-sm"><strong class="d-block" style="color:#2c1810;">أبو بكر الصديق</strong></div></div>
    <div class="col-md-3 col-sm-6"><div class="p-3 bg-white rounded shadow-sm"><strong class="d-block" style="color:#2c1810;">عمر بن الخطاب</strong></div></div>
    <div class="col-md-3 col-sm-6"><div class="p-3 bg-white rounded shadow-sm"><strong class="d-block" style="color:#2c1810;">عثمان بن عفان</strong></div></div>
    <div class="col-md-3 col-sm-6"><div class="p-3 bg-white rounded shadow-sm"><strong class="d-block" style="color:#2c1810;">علي بن أبي طالب</strong></div></div>
    <div class="col-md-3 col-sm-6"><div class="p-3 bg-white rounded shadow-sm"><strong class="d-block" style="color:#2c1810;">طلحة بن عبيد الله</strong></div></div>
    <div class="col-md-3 col-sm-6"><div class="p-3 bg-white rounded shadow-sm"><strong class="d-block" style="color:#2c1810;">الزبير بن العوام</strong></div></div>
    <div class="col-md-3 col-sm-6"><div class="p-3 bg-white rounded shadow-sm"><strong class="d-block" style="color:#2c1810;">عبد الرحمن بن عوف</strong></div></div>
    <div class="col-md-3 col-sm-6"><div class="p-3 bg-white rounded shadow-sm"><strong class="d-block" style="color:#2c1810;">سعد بن أبي وقاص</strong></div></div>
    <div class="col-md-3 col-sm-6 offset-md-3"><div class="p-3 bg-white rounded shadow-sm"><strong class="d-block" style="color:#2c1810;">سعيد بن زيد</strong></div></div>
    <div class="col-md-3 col-sm-6"><div class="p-3 bg-white rounded shadow-sm"><strong class="d-block" style="color:#2c1810;">أبو عبيدة بن الجراح</strong></div></div>
  </div>
</div>

<!-- TAB: UMMAHAT -->
<div class="tab-pane fade" id="t-ummahat">
  <div class="sec-head">
    <span class="tag">البيت النبوي</span>
    <h3>أمهات <span>المؤمنين</span></h3>
    <p>زوجات النبي ﷺ في الدنيا والآخرة، واللاتي نقلن لنا تفاصيل حياته في بيته</p>
    <div class="divider"></div>
  </div>
  <div class="row g-3">
    <div class="col-12"><div class="p-4 bg-white rounded shadow-sm text-center"><strong>خديجة بنت خويلد، سودة بنت زمعة، عائشة بنت أبي بكر، حفصة بنت عمر، زينب بنت خزيمة، أم سلمة، زينب بنت جحش، جويرية بنت الحارث، أم حبيبة، صفية بنت حيي، ميمونة بنت الحارث (رضي الله عنهن جميعاً).</strong></div></div>
  </div>
</div>

<!-- TAB: SAHABIYAT -->
<div class="tab-pane fade" id="t-sahabiyat">
  <div class="sec-head">
    <span class="tag">القدوات</span>
    <h3>أعلام <span>الصحابيات</span></h3>
    <p>نساء خلدن أسماءهن بأحرف من نور في نصرة الإسلام وبناء الأمة</p>
    <div class="divider"></div>
  </div>
  <div class="row g-4">
    <div class="col-md-6"><div class="p-3 bg-white rounded shadow-sm"><strong>فاطمة الزهراء:</strong> سيدة نساء العالمين وبنت رسول الله.</div></div>
    <div class="col-md-6"><div class="p-3 bg-white rounded shadow-sm"><strong>أسماء بنت أبي بكر:</strong> ذات النطاقين التي ساعدت في الهجرة.</div></div>
    <div class="col-md-6"><div class="p-3 bg-white rounded shadow-sm"><strong>نسيبة بنت كعب (أم عمارة):</strong> الفدائية في غزوة أحد التي قاتلت دفاعاً عن الرسول.</div></div>
    <div class="col-md-6"><div class="p-3 bg-white rounded shadow-sm"><strong>أم سليم:</strong> المربية الفاضلة ومهرها الإسلام.</div></div>
  </div>
</div>
"""

try:
    with codecs.open(r"C:\Users\ST\Desktop\islamic.encyclopedia\seerah.html", 'r', 'utf-8') as f:
        srh = f.read()
    
    # Inject Navs
    # seerah.html has </ul> right before <div class="tab-content">
    srh = srh.replace('</ul>\n\n<div class="tab-content">', shb_navs + '\n</ul>\n\n<div class="tab-content">')
    
    # Inject Tabs
    srh = srh.replace('</div><!-- /tab-content -->', shb_tabs + '\n</div><!-- /tab-content -->')
    
    # Save merged
    with codecs.open(r"C:\Users\ST\Desktop\islamic.encyclopedia\seerah.html", 'w', 'utf-8') as f:
        f.write(srh)
        
    print("Sahaba successfully injected into seerah.html!")
except Exception as e:
    print("Error:", e)
