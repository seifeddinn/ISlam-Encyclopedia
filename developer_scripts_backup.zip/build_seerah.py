import codecs

html = """<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>اكاديمية السيرة النبوية - الموسوعة الاسلامية الشاملة</title>
<meta name="description" content="السيرة النبوية الشريفة، الصحابة الكرام، الغزوات والمعارك، الشمائل المحمدية.">
<link href="https://fonts.googleapis.com/css2?family=Amiri:ital,wght@0,400;0,700;1,400&family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root{--gold:#d4af37;--gd:#aa8a2a;--dk:#450a0a;--pr:#b91c1c;}
body{font-family:'Cairo',sans-serif;background:#f8fafc;color:#1e293b;overflow-x:hidden;}
.amiri,h1,h2,h3,h4{font-family:'Amiri',serif;}
/* NAV */
.navbar{background:linear-gradient(135deg,var(--dk),var(--pr))!important;box-shadow:0 4px 30px rgba(0,0,0,.5);border-bottom:2px solid rgba(212,175,55,.2);}
.navbar-brand{font-family:'Amiri',serif;font-size:1.8rem;color:#fff!important;}
.nav-link{color:rgba(255,255,255,.8)!important;font-weight:700;transition:.3s;}
.nav-link:hover,.nav-link.active{color:var(--gold)!important;}
/* HERO */
.seerah-hero{min-height:92vh;background:radial-gradient(ellipse at 60% 40%,#7f1d1d 0%,var(--dk) 70%);display:flex;align-items:center;position:relative;overflow:hidden;}
.hero-arabesque{position:absolute;inset:0;background:url('https://www.transparenttextures.com/patterns/arabesque.png');opacity:.08;}
.orb{position:absolute;border-radius:50%;filter:blur(100px);opacity:.25;animation:float 12s ease-in-out infinite alternate;}
.orb1{width:500px;height:500px;background:var(--gold);top:-100px;right:-80px;}
.orb2{width:400px;height:400px;background:#dc2626;bottom:-80px;left:-60px;animation-delay:4s;}
@keyframes float{to{transform:translate(40px,40px) scale(1.1);}}
.hero-content{position:relative;z-index:2;text-align:center;}
.hero-pill{display:inline-block;background:linear-gradient(90deg,var(--gd),var(--gold));color:#1a0000;padding:8px 28px;border-radius:50px;font-weight:700;font-size:.95rem;margin-bottom:25px;box-shadow:0 4px 15px rgba(212,175,55,.4);}
.hero-h1{font-size:clamp(2.5rem,7vw,5.5rem);color:#fff;font-weight:900;text-shadow:0 8px 25px rgba(0,0,0,.8);line-height:1.15;}
.hero-h1 em{font-style:normal;background:linear-gradient(135deg,#fff,var(--gold));-webkit-background-clip:text;-webkit-text-fill-color:transparent;}
.hero-sub{color:#fecaca;font-size:1.2rem;line-height:2;max-width:750px;margin:0 auto;}
.hero-badges{display:flex;justify-content:center;gap:15px;flex-wrap:wrap;margin-top:30px;}
.hero-badge{background:rgba(255,255,255,.1);border:1px solid rgba(212,175,55,.3);border-radius:15px;padding:15px 25px;color:#fff;backdrop-filter:blur(5px);}
.hero-badge strong{display:block;font-size:1.8rem;color:var(--gold);font-family:'Amiri',serif;}
/* TABS */
.tabs-bar{background:#fff;border-radius:20px;padding:12px;box-shadow:0 10px 40px rgba(0,0,0,.06);margin:40px 0 50px;position:sticky;top:76px;z-index:900;border:1px solid #e2e8f0;}
.tabs-bar .nav{gap:8px;justify-content:center;flex-wrap:nowrap;overflow-x:auto;padding-bottom:5px;}
.tabs-bar .nav-link{border:1px solid #e2e8f0;border-radius:14px;color:#475569;font-weight:700;padding:14px 28px;font-size:1.05rem;white-space:nowrap;transition:.3s;display:flex;align-items:center;gap:8px;}
.tabs-bar .nav-link i{font-size:1.2rem;color:var(--gd);}
.tabs-bar .nav-link:hover{background:#fef2f2;border-color:var(--gd);}
.tabs-bar .nav-link.active{background:linear-gradient(135deg,var(--dk),var(--pr));color:#fff;border-color:transparent;box-shadow:0 8px 20px rgba(153,27,27,.3);}
.tabs-bar .nav-link.active i{color:var(--gold);}
/* SEC HEAD */
.sec-head{text-align:center;margin-bottom:55px;}
.sec-head .badge-tag{display:inline-block;background:rgba(212,175,55,.12);color:var(--gd);border:1px solid rgba(212,175,55,.3);border-radius:30px;padding:8px 24px;font-size:.95rem;font-weight:700;margin-bottom:18px;}
.sec-head h2{font-size:clamp(2rem,4vw,3rem);color:var(--dk);font-weight:900;}
.sec-head h2 span{color:var(--pr);}
.sec-head p{color:#64748b;font-size:1.1rem;max-width:750px;margin:10px auto 0;line-height:1.8;}
.sec-divider{width:70px;height:5px;background:linear-gradient(90deg,var(--gold),var(--pr));border-radius:5px;margin:20px auto 0;}
/* TIMELINE */
.seerah-tl{position:relative;padding:20px 0;}
.seerah-tl::before{content:'';position:absolute;top:0;bottom:0;left:50%;width:3px;background:linear-gradient(to bottom,transparent,var(--gold) 10%,var(--pr) 90%,transparent);transform:translateX(-50%);}
.tl-item{display:flex;gap:0;margin-bottom:55px;align-items:flex-start;}
.tl-item:nth-child(odd){flex-direction:row-reverse;}
.tl-side{width:50%;padding:0 50px;}
.tl-item:nth-child(odd) .tl-side{text-align:left;}
.tl-dot-wrap{position:absolute;left:50%;transform:translateX(-50%);z-index:2;margin-top:15px;}
.tl-dot{width:22px;height:22px;background:var(--gold);border:3px solid var(--dk);border-radius:50%;display:block;}
.tl-year-label{position:absolute;left:50%;transform:translateX(-50%);margin-top:40px;background:var(--dk);color:var(--gold);font-family:'Amiri',serif;font-weight:700;font-size:1rem;padding:4px 14px;border-radius:20px;white-space:nowrap;}
.tl-card{background:#fff;border-radius:22px;padding:35px;box-shadow:0 12px 35px rgba(0,0,0,.05);border:1px solid #fee2e2;transition:.4s;position:relative;overflow:hidden;}
.tl-card::before{content:'';position:absolute;top:0;left:0;right:0;height:4px;background:linear-gradient(90deg,var(--pr),var(--gold));}
.tl-card:hover{transform:translateY(-8px);box-shadow:0 20px 45px rgba(153,27,27,.12);border-color:var(--gold);}
.tl-card h3{font-size:1.5rem;color:var(--dk);font-weight:700;margin-bottom:12px;}
.tl-card p{color:#64748b;font-size:1.05rem;line-height:1.9;margin:0;}
@media(max-width:768px){
  .seerah-tl::before{left:25px;}
  .tl-item,.tl-item:nth-child(odd){flex-direction:column;padding-right:60px;}
  .tl-item:nth-child(odd) .tl-side{text-align:right;}
  .tl-dot-wrap{left:25px;}
  .tl-year-label{display:none;}
  .tl-side{width:100%;padding:0;}
}
/* MORALS */
.moral-card{background:#fff;border-radius:22px;padding:35px 28px;box-shadow:0 10px 30px rgba(0,0,0,.04);border:1px solid #fee2e2;transition:.4s;height:100%;text-align:center;position:relative;overflow:hidden;}
.moral-card::after{content:'';position:absolute;bottom:0;left:0;width:100%;height:4px;background:var(--gold);transform:scaleX(0);transition:.4s;transform-origin:left;}
.moral-card:hover{transform:translateY(-8px);box-shadow:0 20px 45px rgba(153,27,27,.1);}
.moral-card:hover::after{transform:scaleX(1);}
.moral-icon-wrap{width:85px;height:85px;border-radius:50%;background:linear-gradient(135deg,rgba(153,27,27,.1),rgba(212,175,55,.1));display:inline-flex;align-items:center;justify-content:center;font-size:2.5rem;color:var(--pr);margin-bottom:22px;transition:.4s;}
.moral-card:hover .moral-icon-wrap{background:linear-gradient(135deg,var(--pr),var(--dk));color:#fff;}
/* SAHABA */
.filter-bar{display:flex;justify-content:center;gap:10px;flex-wrap:wrap;margin-bottom:35px;}
.filter-bar button{background:#fff;color:var(--dk);border:1px solid #e2e8f0;padding:9px 24px;border-radius:30px;font-weight:700;transition:.3s;cursor:pointer;}
.filter-bar button.active,.filter-bar button:hover{background:var(--pr);color:#fff;border-color:var(--pr);box-shadow:0 5px 15px rgba(153,27,27,.25);}
.comp-card{background:linear-gradient(145deg,#fff,#fef2f2);border-radius:20px;padding:28px 25px;text-align:center;box-shadow:0 8px 25px rgba(0,0,0,.05);border-bottom:5px solid var(--pr);transition:.4s;height:100%;}
.comp-card:hover{transform:translateY(-8px);border-color:var(--gold);}
.comp-rank{display:inline-block;background:var(--dk);color:var(--gold);padding:5px 16px;border-radius:20px;font-size:.82rem;font-weight:700;margin-bottom:10px;}
.comp-name{font-family:'Amiri',serif;font-size:1.7rem;color:var(--dk);font-weight:700;margin:8px 0 12px;}
/* BATTLES */
.battle-nav .btn{border-radius:30px;padding:10px 25px;font-weight:700;font-size:1rem;}
.battle-map{background:linear-gradient(135deg,#fdf6e3,#f5e6c8);border:3px solid var(--gold);border-radius:25px;position:relative;height:420px;overflow:hidden;box-shadow:0 20px 50px rgba(0,0,0,.1);background-image:url('https://www.transparenttextures.com/patterns/cartographer.png');}
.b-badge{position:absolute;top:20px;right:20px;background:var(--dk);color:var(--gold);font-family:'Amiri',serif;font-weight:700;font-size:1.1rem;padding:10px 22px;border-radius:12px;border:2px solid var(--gd);}
.b-team{position:absolute;padding:12px 22px;border-radius:12px;font-weight:700;font-family:'Amiri',serif;font-size:1rem;color:#fff;box-shadow:0 8px 20px rgba(0,0,0,.3);}
.bt-m{background:linear-gradient(135deg,var(--pr),var(--dk));border:2px solid var(--gold);}
.bt-e{background:linear-gradient(135deg,#1e293b,#0f172a);border:2px solid #ef4444;}
.b-label{position:absolute;color:#78350f;font-weight:700;font-size:.9rem;}
.pulse-dot{position:absolute;width:80px;height:80px;background:radial-gradient(circle,rgba(239,68,68,.5) 0%,transparent 70%);border-radius:50%;animation:pulse 2s infinite;}
@keyframes pulse{0%{transform:scale(.5);opacity:1;}100%{transform:scale(2.5);opacity:0;}}
/* FOOTER */
.mega-footer{background:linear-gradient(135deg,var(--dk),#020617);color:#fff;padding:70px 0 30px;margin-top:80px;border-top:3px solid var(--gd);}
.mfl{color:rgba(255,255,255,.7);text-decoration:none;transition:.3s;display:block;margin-bottom:10px;}
.mfl:hover{color:var(--gold);padding-right:5px;}
</style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold" href="index.html"><i class="fas fa-book-open me-2 text-warning"></i>الموسوعة الإسلامية الشاملة</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav1">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="nav1">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link " href="index.html">الرئيسية</a></li>
        <li class="nav-item"><a class="nav-link " href="recitations.html">القرآن والتلاوات</a></li>
        <li class="nav-item"><a class="nav-link " href="hadith.html">الحديث الشريف</a></li>
        <li class="nav-item"><a class="nav-link " href="fiqh.html">الفقه الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="fatwa.html">فتاوى العلماء <i class="fas fa-gavel"></i></a></li>
        <li class="nav-item"><a class="nav-link active" href="seerah.html">السيرة والصحابة</a></li>
        <li class="nav-item"><a class="nav-link " href="aqeedah.html">العقيدة الإسلامية</a></li>
        <li class="nav-item"><a class="nav-link " href="history.html">التاريخ الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="library.html">المكتبة الشاملة</a></li>
      </ul>
    </div>
  </div>
</nav>

<section class="seerah-hero">
  <div class="hero-arabesque"></div>
  <div class="orb orb1"></div><div class="orb orb2"></div>
  <div class="container hero-content">
    <div class="hero-pill"><i class="fas fa-star me-2"></i>سيرة خير الانام والجيل الفريد</div>
    <h1 class="hero-h1 amiri mb-4">موسوعة <em>السيرة</em> والصحابة</h1>
    <p class="hero-sub">رحلة النبوة الطاهرة من المولد الى الرفيق الاعلى، واخلاق المصطفى صلوات ربي عليه، ومقامات الرعيل الاول من اصحابه الكرام.</p>
    <div class="hero-badges">
      <div class="hero-badge"><strong>23</strong> سنة النبوة</div>
      <div class="hero-badge"><strong>10</strong> المبشرون</div>
      <div class="hero-badge"><strong>11</strong> ام المؤمنين</div>
      <div class="hero-badge"><strong>3</strong> غزوات كبرى</div>
    </div>
  </div>
</section>

<div class="container">
  <div class="tabs-bar">
    <ul class="nav nav-pills" id="sTabs" role="tablist">
      <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#t1"><i class="fas fa-route"></i> التسلسل الزمني</button></li>
      <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t2"><i class="fas fa-seedling"></i> الشمائل المحمدية</button></li>
      <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t3"><i class="fas fa-users"></i> الصحابة والازواج</button></li>
      <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t4"><i class="fas fa-map-marked-alt"></i> المعارك الفاصلة</button></li>
    </ul>
  </div>

  <div class="tab-content pb-5">

    <!-- T1: TIMELINE -->
    <div class="tab-pane fade show active" id="t1">
      <div class="sec-head">
        <div class="badge-tag">من المولد الى الرفيق الاعلى</div>
        <h2 class="amiri">التسلسل <span>الزمني</span> للسيرة الطاهرة</h2>
        <p>محطات تبليغ الرسالة بتصميم تفاعلي يستعرض المراحل الكبرى</p>
        <div class="sec-divider"></div>
      </div>
      <div class="seerah-tl position-relative">

        <div class="tl-item position-relative">
          <div class="tl-dot-wrap"><span class="tl-dot"></span><span class="tl-year-label">571م</span></div>
          <div class="tl-side">
            <div class="tl-card">
              <h3><i class="fas fa-star text-warning me-2"></i>المولد والنشاة</h3>
              <p>ولد يتيما بمكة المكرمة يوم الاثنين من عام الفيل. كفله جده عبد المطلب ثم عمه ابو طالب. عرف بالصادق الامين وتزوج السيدة خديجة رضي الله عنها وهو ابن خمس وعشرين سنة.</p>
            </div>
          </div>
        </div>

        <div class="tl-item position-relative">
          <div class="tl-dot-wrap"><span class="tl-dot"></span><span class="tl-year-label">610م</span></div>
          <div class="tl-side">
            <div class="tl-card">
              <h3><i class="fas fa-book-reader text-warning me-2"></i>البعثة ونزول الوحي</h3>
              <p>نزل جبريل عليه السلام في غار حراء بـ"اقرا" وبدا عهد الوحي. بدات الدعوة سرا ثلاث سنوات ثم جهرا فعانى المسلمون الاوائل اشد صنوف الاذى والتعذيب.</p>
            </div>
          </div>
        </div>

        <div class="tl-item position-relative">
          <div class="tl-dot-wrap"><span class="tl-dot"></span><span class="tl-year-label">620م</span></div>
          <div class="tl-side">
            <div class="tl-card">
              <h3><i class="fas fa-moon text-warning me-2"></i>الاسراء والمعراج</h3>
              <p>بعد عام الحزن ووفاة خديجة وابي طالب، اسري بالنبي من مكة الى المسجد الاقصى وعرج به الى السماوات العلى وفرضت الصلوات الخمس تشريفا ومواساة له.</p>
            </div>
          </div>
        </div>

        <div class="tl-item position-relative">
          <div class="tl-dot-wrap"><span class="tl-dot"></span><span class="tl-year-label">1 هـ</span></div>
          <div class="tl-side">
            <div class="tl-card">
              <h3><i class="fas fa-walking text-warning me-2"></i>الهجرة المباركة</h3>
              <p>خرج مع الصديق ابي بكر الى يثرب التي اضاءت بقدومه فصارت المدينة المنورة. بنى المسجد النبوي، وآخى بين المهاجرين والانصار، فكانت الدولة الاسلامية الاولى.</p>
            </div>
          </div>
        </div>

        <div class="tl-item position-relative">
          <div class="tl-dot-wrap"><span class="tl-dot"></span><span class="tl-year-label">8 هـ</span></div>
          <div class="tl-side">
            <div class="tl-card">
              <h3><i class="fas fa-kaaba text-warning me-2"></i>الفتح الاعظم لمكة</h3>
              <p>دخل النبي مكة فاتحا متواضعا مطاطئا راسه، حطم الاصنام حول الكعبة، وعفا عن اهلها الذين ظلموه قائلا: "اذهبوا فانتم الطلقاء".</p>
            </div>
          </div>
        </div>

        <div class="tl-item position-relative">
          <div class="tl-dot-wrap"><span class="tl-dot"></span><span class="tl-year-label">11 هـ</span></div>
          <div class="tl-side">
            <div class="tl-card">
              <h3><i class="fas fa-dove text-warning me-2"></i>الرحيل الى الرفيق الاعلى</h3>
              <p>بعد حجة الوداع واكتمال الوحي، صعدت الروح الطاهرة الى الله في ضحى يوم الاثنين، ودفن في حجرته الشريفة ملاصقة للمسجد النبوي الشريف.</p>
            </div>
          </div>
        </div>

      </div>
    </div>

    <!-- T2: MORALS -->
    <div class="tab-pane fade" id="t2">
      <div class="sec-head">
        <div class="badge-tag">وانك لعلى خلق عظيم</div>
        <h2 class="amiri">الشمائل <span>المحمدية</span></h2>
        <p>اخلاقه وصفاته الخلقية والخلقية التي جعلت منه الاسوة الحسنة لكل البشرية</p>
        <div class="sec-divider"></div>
      </div>

      <div class="bg-white rounded-4 shadow p-5 mb-5 border-start border-5 border-danger">
        <div class="row align-items-center">
          <div class="col-lg-9">
            <h3 class="amiri fw-bold text-dark mb-3"><i class="fas fa-quote-right text-danger me-2"></i>كان خلقه القرآن</h3>
            <p class="fs-4 text-muted mb-0 lh-lg">سئلت السيدة عائشة رضي الله عنها عن خلق النبي فقالت: كان خلقه القرآن. ما من فضيلة امر بها القرآن الكريم الا وكان عليه الصلاة والسلام مثلها الاعلى وتجسيدها الحي في حياته عليه السلام.</p>
          </div>
          <div class="col-lg-3 text-center mt-4 mt-lg-0">
            <i class="fas fa-sun fa-6x text-warning" style="filter:drop-shadow(0 0 20px rgba(212,175,55,.5))"></i>
          </div>
        </div>
      </div>

      <div class="row g-4">
        <div class="col-lg-6">
          <div class="moral-card">
            <div class="moral-icon-wrap"><i class="fas fa-hand-holding-heart"></i></div>
            <h3 class="amiri fw-bold mb-3">الرحمة الشاملة</h3>
            <p class="text-muted fs-5">وما ارسلناك الا رحمة للعالمين، شملت رحمته الاعداء والاطفال والمساكين وحتى الحيوانات والجماد كحنين الجذع.</p>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="moral-card">
            <div class="moral-icon-wrap"><i class="fas fa-balance-scale"></i></div>
            <h3 class="amiri fw-bold mb-3">العدل المطلق</h3>
            <p class="text-muted fs-5">لو ان فاطمة بنت محمد سرقت لقطعت يدها، صاحب اعدل قضاء في التاريخ البشري.</p>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="moral-card">
            <div class="moral-icon-wrap"><i class="fas fa-heart"></i></div>
            <h3 class="amiri fw-bold mb-3">التواضع والبشاشة</h3>
            <p class="text-muted fs-5">كان يخيط ثوبه ويحلب شاته ويجالس الفقراء ولا يرضى ان يتميز عنهم. يدخل الغريب المسجد فلا يعرفه من بينهم.</p>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="moral-card">
            <div class="moral-icon-wrap"><i class="fas fa-shield-alt"></i></div>
            <h3 class="amiri fw-bold mb-3">الشجاعة الثابتة</h3>
            <p class="text-muted fs-5">في غزوة حنين حين ولى الناس ثبت على بغلته يقول: انا النبي لا كذب، وكانت الصحابة تحتمي به اشد ما يكون الكفاح.</p>
          </div>
        </div>
      </div>

      <div class="bg-dark text-white rounded-4 p-5 mt-5 text-center">
        <h3 class="amiri fw-bold text-warning mb-4">وصف ام معبد للنبي صلى الله عليه وسلم</h3>
        <p class="fs-4 fst-italic amiri lh-lg opacity-90">ظاهر الوضاءة، ابلج الوجه، جليّ مشرب، في عينيه دعج، وفي اشفاره وطف... ابهى الناس وانورهم وجها من بعيد، واحلاهم واجملهم عند الدنو والمقاربة.</p>
      </div>
    </div>

    <!-- T3: SAHABA + MOTHERS -->
    <div class="tab-pane fade" id="t3">
      <div class="sec-head">
        <div class="badge-tag">نجوم الاهتداء ومصابيح الدجى</div>
        <h2 class="amiri">الصحابة الكرام <span>وامهات المؤمنين</span></h2>
        <p>الرعيل الاول المبشرون بالجنة وزوجاته الطاهرات رضي الله عنهم اجمعين</p>
        <div class="sec-divider"></div>
      </div>
      <div class="filter-bar">
        <button class="active" onclick="filterC(event,'all')">الجميع</button>
        <button onclick="filterC(event,'ten')">العشرة المبشرون</button>
        <button onclick="filterC(event,'mom')">امهات المؤمنين</button>
      </div>
      <div class="row g-4" id="cgrid">
        <div class="col-lg-4 col-md-6 ci ten">
          <div class="comp-card"><div class="comp-rank">اول الخلفاء ~ الصديق</div><div class="comp-name">ابو بكر الصديق</div><p class="text-muted">اول من آمن من الرجال ورفيق الغار. ثبّت الامة بعد وفاة النبي وحارب المرتدين وبدا في عهده جمع القرآن.</p></div>
        </div>
        <div class="col-lg-4 col-md-6 ci ten">
          <div class="comp-card"><div class="comp-rank">ثاني الخلفاء ~ الفاروق</div><div class="comp-name">عمر بن الخطاب</div><p class="text-muted">اعز الله به الاسلام. بطل الفتوح ومؤسس الدواوين وباني الدولة الاسلامية المدنية.</p></div>
        </div>
        <div class="col-lg-4 col-md-6 ci ten">
          <div class="comp-card"><div class="comp-rank">ثالث الخلفاء ~ ذو النورين</div><div class="comp-name">عثمان بن عفان</div><p class="text-muted">الحيي الغني السخي، جهز جيش العسرة، وجمع المصحف الكريم في عهده على حرف واحد.</p></div>
        </div>
        <div class="col-lg-4 col-md-6 ci ten">
          <div class="comp-card"><div class="comp-rank">رابع الخلفاء ~ فدائي الهجرة</div><div class="comp-name">علي بن ابي طالب</div><p class="text-muted">ابن عم النبي وزوج فاطمة، فدائي ليلة الهجرة وبطل المشاهد وامير بيان الاسلام.</p></div>
        </div>
        <div class="col-lg-4 col-md-6 ci ten">
          <div class="comp-card"><div class="comp-rank">امين الامة</div><div class="comp-name">ابو عبيدة بن الجراح</div><p class="text-muted">نزع حلقتي المغفر من وجه النبي بثنيتيه يوم احد، وقائد الشام الزاهد الفاتح.</p></div>
        </div>
        <div class="col-lg-4 col-md-6 ci ten">
          <div class="comp-card"><div class="comp-rank">طلحة الخير والفياض</div><div class="comp-name">طلحة بن عبيد الله</div><p class="text-muted">الشهيد الحي الذي صوّب جسده يحمي النبي يوم احد حتى شلّت يمينه.</p></div>
        </div>
        <div class="col-lg-4 col-md-6 ci ten">
          <div class="comp-card"><div class="comp-rank">حواري رسول الله</div><div class="comp-name">الزبير بن العوام</div><p class="text-muted">اول من سل سيفا في سبيل الله، ابن عمة النبي وصنديد الفرسان في كل المشاهد.</p></div>
        </div>
        <div class="col-lg-4 col-md-6 ci ten">
          <div class="comp-card"><div class="comp-rank">فاتح العراق وقاهر الفرس</div><div class="comp-name">سعد بن ابي وقاص</div><p class="text-muted">خال النبي ومستجاب الدعوة، اول من رمى بسهم في سبيل الله، بطل القادسية الخالدة.</p></div>
        </div>
        <div class="col-lg-4 col-md-6 ci mom" style="border-bottom:5px solid #be123c;">
          <div class="comp-card" style="border-bottom-color:#be123c;"><div class="comp-rank" style="background:#be123c;">ام المؤمنين الاولى</div><div class="comp-name">خديجة بنت خويلد</div><p class="text-muted">صدّقته واعانته اول مرة بمالها ونفسها. احبها النبي حبا لم يكن لغيرها، وارسل الله سلامه عليها من فوق سبع سماوات.</p></div>
        </div>
        <div class="col-lg-4 col-md-6 ci mom">
          <div class="comp-card" style="border-bottom-color:#be123c;"><div class="comp-rank" style="background:#be123c;">ام المؤمنين والعالمة</div><div class="comp-name">عائشة بنت ابي بكر</div><p class="text-muted">اقرب نسائه اليه، المبرأة من السماء، ومن اكثر راويي الحديث النبوي الشريف.</p></div>
        </div>
        <div class="col-lg-4 col-md-6 ci mom">
          <div class="comp-card" style="border-bottom-color:#be123c;"><div class="comp-rank" style="background:#be123c;">حارسة المصحف الاول</div><div class="comp-name">حفصة بنت عمر</div><p class="text-muted">الصوامة القوامة العابدة، أمينة على اول نسخة من المصحف الشريف الذي جمعه الصديق.</p></div>
        </div>
        <div class="col-lg-4 col-md-6 ci mom">
          <div class="comp-card" style="border-bottom-color:#be123c;"><div class="comp-rank" style="background:#be123c;">ام المساكين</div><div class="comp-name">زينب بنت خزيمة</div><p class="text-muted">عرفت بامّ المساكين لكثرة عطائها وحنانها على الفقراء والمحتاجين رضي الله عنها.</p></div>
        </div>
      </div>
    </div>

    <!-- T4: BATTLES -->
    <div class="tab-pane fade" id="t4">
      <div class="sec-head">
        <div class="badge-tag">ايام الله الخالدة</div>
        <h2 class="amiri">المعارك <span>الفاصلة</span></h2>
        <p>التصوير التكتيكي التفاعلي لاهم الغزوات النبوية الكريمة</p>
        <div class="sec-divider"></div>
      </div>

      <ul class="nav battle-nav justify-content-center gap-3 mb-5" id="bNav" role="tablist">
        <li class="nav-item"><button class="btn btn-outline-danger active" data-bs-toggle="tab" data-bs-target="#badr">بدر (2 هـ)</button></li>
        <li class="nav-item"><button class="btn btn-outline-danger" data-bs-toggle="tab" data-bs-target="#uhud">احد (3 هـ)</button></li>
        <li class="nav-item"><button class="btn btn-outline-danger" data-bs-toggle="tab" data-bs-target="#khndq">الخندق (5 هـ)</button></li>
      </ul>

      <div class="tab-content">
        <div class="tab-pane fade show active" id="badr">
          <div class="row g-5 align-items-center">
            <div class="col-lg-6">
              <div class="battle-map">
                <div class="b-badge">بدر الكبرى ~ يوم الفرقان</div>
                <div class="b-label" style="top:18px;left:20px;"><i class="fas fa-mountain me-1"></i>العدوة القصوى</div>
                <div class="b-label" style="bottom:18px;right:20px;"><i class="fas fa-mountain me-1"></i>العدوة الدنيا</div>
                <div class="b-label" style="top:45%;left:35%;color:#0284c7;font-size:1.1rem;"><i class="fas fa-tint fa-2x d-block mb-1"></i>آبار بدر</div>
                <div class="b-team bt-m" style="bottom:28%;right:12%;">المسلمون (313)<br><small>بقيادة: النبي صلى الله عليه وسلم</small></div>
                <div class="b-team bt-e" style="top:25%;left:12%;">قريش (1000)<br><small>بقيادة: ابو جهل</small></div>
                <div class="pulse-dot" style="top:40%;left:40%;"></div>
              </div>
            </div>
            <div class="col-lg-6">
              <h3 class="amiri fw-bold text-dark mb-3">النصر المؤزر الاول</h3>
              <p class="fs-5 text-muted lh-lg mb-4">اول معركة فاصلة، قصد المسلمون قافلة تجارية فتفاجأوا بجيش مكة. نصر الله الحق بالملائكة وقتل رؤوس الكفر وعلى رأسهم ابو جهل.</p>
              <div class="d-flex gap-3 flex-wrap">
                <span class="badge bg-success fs-6 rounded-pill px-3 py-2"><i class="fas fa-heart me-1"></i>الشهداء: 14</span>
                <span class="badge bg-danger fs-6 rounded-pill px-3 py-2"><i class="fas fa-skull me-1"></i>العدو: 70 قتيلا + 70 اسيرا</span>
              </div>
            </div>
          </div>
        </div>

        <div class="tab-pane fade" id="uhud">
          <div class="row g-5 align-items-center">
            <div class="col-lg-6">
              <div class="battle-map">
                <div class="b-badge">احد ~ الابتلاء والتمحيص</div>
                <div class="b-label" style="top:15px;left:20px;font-size:1.1rem;color:#78350f;"><i class="fas fa-mountain fa-2x me-1"></i>جبل احد</div>
                <div class="b-label" style="top:38%;left:38%;background:#fbbf24;padding:4px 10px;border-radius:8px;color:#1a0000;">جبل الرماة (عينين)</div>
                <div class="b-team bt-m" style="top:25%;left:25%;">المسلمون (700)</div>
                <div class="b-team bt-e" style="bottom:20%;right:15%;">قريش (3000)<br><small>خالد في الميسرة</small></div>
                <div class="pulse-dot" style="top:50%;left:50%;"></div>
              </div>
            </div>
            <div class="col-lg-6">
              <h3 class="amiri fw-bold text-dark mb-3">الابتلاء العظيم</h3>
              <p class="fs-5 text-muted lh-lg mb-4">اراد الله ان يمحص المؤمنين. لما كان النصر يلوح نزل الرماة مخالفين الامر النبوي طمعا في الغنيمة فالتف خالد بفرسانه وانقلبت الموازين.</p>
              <div class="d-flex gap-3 flex-wrap">
                <span class="badge bg-success fs-6 rounded-pill px-3 py-2">الشهداء: 70 منهم حمزة الاسد</span>
                <span class="badge bg-primary fs-6 rounded-pill px-3 py-2">الدرس: لا تخالفوا امر القائد</span>
              </div>
            </div>
          </div>
        </div>

        <div class="tab-pane fade" id="khndq">
          <div class="row g-5 align-items-center">
            <div class="col-lg-6">
              <div class="battle-map">
                <div class="b-badge">الاحزاب ~ حفر الخندق</div>
                <div class="b-label" style="top:10px;left:25%;background:#fcd34d;padding:4px 12px;border-radius:8px;color:#450a0a;border-bottom:4px dashed #450a0a;">الخنـدق المانـع</div>
                <div class="b-team bt-m" style="top:45%;left:50%;transform:translateX(-50%);">المدينة المنورة (3000)</div>
                <div class="b-team bt-e" style="top:10%;left:50%;transform:translateX(-50%);">الاحزاب (10,000)<br><small>قريش وغطفان واليهود</small></div>
                <div class="b-label" style="bottom:25px;right:20px;color:#dc2626;"><i class="fas fa-exclamation-triangle me-1"></i>غدر بني قريظة</div>
                <div style="position:absolute;top:35%;left:10%;font-size:2.5rem;color:#94a3b8;opacity:.5;"><i class="fas fa-wind"></i></div>
              </div>
            </div>
            <div class="col-lg-6">
              <h3 class="amiri fw-bold text-dark mb-3">النصر الرباني بالريح</h3>
              <p class="fs-5 text-muted lh-lg mb-4">تحالف كل اعداء الاسلام لاجتثاثه. بفكرة سلمان الفارسي حُفر الخندق المانع. دام الحصار شهرا مع جوع وبرد وغدر من الداخل حتى ارسل الله الريح فاقتلعت خيام المشركين.</p>
              <div class="d-flex gap-3 flex-wrap">
                <span class="badge bg-info fs-6 rounded-pill px-3 py-2"><i class="fas fa-wind me-1"></i>جنود الله: الريح العاتية</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>
</div>

<footer class="mega-footer" style="background:linear-gradient(135deg,var(--dark),#020617);color:white;padding:80px 0 30px;margin-top:80px;border-top:3px solid var(--gold-dark);">
  <div class="container">
    <div class="row g-5 mb-5 border-bottom border-light border-opacity-10 pb-5">
      <div class="col-lg-4 text-md-end text-center">
        <i class="fas fa-mosque fa-4x text-warning mb-4 d-block"></i>
        <h4 class="fw-bold font-amiri fs-2 mb-3">الموسوعة الإسلامية الشاملة</h4>
        <p class="opacity-75 fs-6 line-height-2">أضخم صرح رقمي يجمع علوم القرآن العظيم، وأحاديث المصطفى، وفقهاء المذاهب، والتاريخ المجيد في منصة موثقة مصممة بأحدث التقنيات.</p>
      </div>
      <div class="col-lg-4 text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">تصفح الموسوعة</h5>
        <div class="d-flex flex-wrap justify-content-center gap-2">
          <a href="recitations.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">أكاديمية القرآن</a>
          <a href="hadith.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الحديث النبوي</a>
          <a href="seerah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">السيرة والصحابة</a>
          <a href="fiqh.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الفقه وأصوله</a>
          <a href="fatwa.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">فتاوى العلماء</a>
          <a href="aqeedah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">العقيدة الإسلامية</a>
          <a href="history.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">التاريخ المجيد</a>
          <a href="library.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">المكتبة الشاملة</a>
        </div>
      </div>
      <div class="col-lg-4 text-md-start text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">روابط سريعة</h5>
        <a href="contact.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> اتصل بالمطور</a>
        <a href="share.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> شارك الأجر</a>
        <a href="login.html" class="mega-footer-link text-warning mt-3" style="text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-user-circle me-2 ms-1"></i> تسجيل الدخول</a>
      </div>
    </div>
    <div class="text-center font-amiri fs-5 d-flex flex-column gap-2">
      <span class="opacity-75">الموسوعة الإسلامية الشاملة &copy; 2026 تم التصميم للإفادة | عمل مجاني لوجه الله</span>
      <span class="text-warning fw-bold fs-4 mt-2">تصميم وتطوير: لخذاري محمد سيف الدين</span>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
function filterC(e, cat) {
  document.querySelectorAll('.ci').forEach(item => {
    item.style.display = (cat === 'all' || item.classList.contains(cat)) ? '' : 'none';
  });
  document.querySelectorAll('.filter-bar button').forEach(b => b.classList.remove('active'));
  e.target.classList.add('active');
}
</script>
</body>
</html>"""

with codecs.open(r"seerah.html", "w", "utf-8") as f:
    f.write(html)
print("seerah.html written OK - lines:", html.count("\\n"))
