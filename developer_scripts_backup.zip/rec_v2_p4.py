
    <!-- TAB 5: LEGENDS OF RECITED QURAN -->
    <div class="tab-pane fade" id="t-qura">
      <div class="sec-head">
        <span class="tag">حناجر من ذهب</span>
        <h3>أساطير التلاوة <span>والمقرئين</span></h3>
        <p>استمع لأعذب الأصوات التي سجلت المصحف المرتل والمجود عبر التاريخ في العالم الإسلامي</p>
        <div class="divider"></div>
      </div>
      
      <div class="row g-4">
        <!-- R1 -->
        <div class="col-lg-3 col-md-4 col-sm-6">
          <div class="legend-card">
            <div class="l-img"><i class="fas fa-user-circle"></i><span class="l-badge">الصوت الباكي</span></div>
            <div class="legend-body">
              <h4>محمد صديق المنشاوي</h4>
              <p class="text-muted small">صاحب التلاوة الخاشعة التي تلامس شغاف القلوب من الآية الأولى.</p>
              <button class="btn btn-sm btn-outline-primary rounded-pill w-100 mt-2" onclick="alert('سيتوفر قريباً المصحف المرتل والمجود للشيخ')">مكتبة الشيخ</button>
            </div>
          </div>
        </div>
        <!-- R2 -->
        <div class="col-lg-3 col-md-4 col-sm-6">
          <div class="legend-card">
            <div class="l-img"><i class="fas fa-user-circle"></i><span class="l-badge">الحنجرة الذهبية</span></div>
            <div class="legend-body">
              <h4>عبد الباسط عبد الصمد</h4>
              <p class="text-muted small">أسطورة التلاوة المجودة وصاحب أطول نفس وأعذب أداء فني في قراءة القرآن.</p>
              <button class="btn btn-sm btn-outline-primary rounded-pill w-100 mt-2" onclick="alert('سيتوفر قريباً المصحف المرتل والمجود للشيخ')">مكتبة الشيخ</button>
            </div>
          </div>
        </div>
        <!-- R3 -->
        <div class="col-lg-3 col-md-4 col-sm-6">
          <div class="legend-card">
            <div class="l-img"><i class="fas fa-user-circle"></i><span class="l-badge">المعلم الأول</span></div>
            <div class="legend-body">
              <h4>محمود خليل الحصري</h4>
              <p class="text-muted small">شيخ عموم المقارئ، والمدرسة الأولى للضبط والإتقان الدقيق للمخارج والصفات.</p>
              <button class="btn btn-sm btn-outline-primary rounded-pill w-100 mt-2" onclick="alert('سيتوفر قريباً المصحف المرتل والمجود للشيخ')">مكتبة الشيخ</button>
            </div>
          </div>
        </div>
        <!-- R4 -->
        <div class="col-lg-3 col-md-4 col-sm-6">
          <div class="legend-card">
            <div class="l-img"><i class="fas fa-user-circle"></i><span class="l-badge">مقرئ الملوك</span></div>
            <div class="legend-body">
              <h4>مصطفى إسماعيل</h4>
              <p class="text-muted small">عبقري التلاوة والمقامات الصوتية، يصور المعاني تصويراً بديعاً لا مثيل له.</p>
              <button class="btn btn-sm btn-outline-primary rounded-pill w-100 mt-2" onclick="alert('سيتوفر قريباً المصحف المرتل والمجود للشيخ')">مكتبة الشيخ</button>
            </div>
          </div>
        </div>
      </div>
      
      <div class="text-center mt-5">
         <button class="btn btn-outline-secondary px-5 py-2 rounded-pill font-amiri fs-5" onclick="alert('قريباً: إضافة الحذيفي، السديس، الشريم، العفاسي، الطبلاوي')">تحميل المزيد من القراء <i class="fas fa-angle-down ms-2"></i></button>
      </div>
    </div>

    <!-- TAB 6: IJAZAH CHAIN -->
    <div class="tab-pane fade" id="t-ijazah">
      <div class="sec-head">
        <span class="tag">إنا نحن نزلنا الذكر وإنا له لحافظون</span>
        <h3>الإجازة <span>والسند المتصل</span></h3>
        <p>الشهادة القرآنية التي تفيد بأن القارئ قد قرأ القرآن غيباً كاملاً على شيخ مجاز، فاتصل سنده إلى النبي ﷺ</p>
        <div class="divider"></div>
      </div>
      
      <div class="row mb-5">
        <div class="col-lg-6 mb-4">
           <h4 class="font-amiri fw-bold" style="color:#033547;">ما هي الإجازة القرآنية؟</h4>
           <p class="text-muted" style="line-height:2;">الإجازة في اللغة: إعطاء الجواز. وفي علم القراءات: هي شهادة من الشيخ المجاز لطالبه بأنه قد قرأ عليه القرآن الكريم كاملاً غيباً مع تطبيق أحكام التجويد، وأنه أصبح مؤهلاً لتعليم القرآن ونقله للآخرين.</p>
           <p class="text-muted" style="line-height:2;">وأهمية الإجازة أنها تحفظ كلام الله سبحانه وتعالى من التحريف، ليكون السند متصلاً يداً بيد، وفماً لفم، إلى أمين الوحي جبريل عليه السلام، إلى رب العزة جل جلاله.</p>
        </div>
        <div class="col-lg-6">
           <div class="bg-white p-4 rounded-4 shadow-sm border text-center">
             <i class="fas fa-award fa-4x text-warning mb-3"></i>
             <h5 class="fw-bold">شروط الحصول على الإجازة</h5>
             <ul class="text-start mt-3 mb-0" style="line-height:2;">
                <li>حفظ القرآن الكريم غيباً حفظاً متقناً.</li>
                <li>إتقان أحكام التجويد ومخارج الحروف.</li>
                <li>حفظ وفهم منظومات التجويد (كالتحفة والجزرية).</li>
                <li>قراءة ختمة كاملة لاختبار الضبط على الشيخ.</li>
                <li>الإخلاص وتقوى الله تعالى.</li>
             </ul>
           </div>
        </div>
      </div>

      <div class="ijazah-box">
         <div style="position:absolute;top:-50px;right:-50px;opacity:0.1;"><i class="fas fa-link fa-10x"></i></div>
         <h3 class="font-amiri text-warning mb-4">مثال للسند القرآني الذهبي</h3>
         
         <div class="d-flex flex-column align-items-center">
            <div class="chain-step">الله جل جلاله</div>
            <i class="fas fa-arrow-down text-warning"></i>
            <div class="chain-step">جبريل عليه السلام</div>
            <i class="fas fa-arrow-down text-warning"></i>
            <div class="chain-step">محمد ﷺ</div>
            <i class="fas fa-arrow-down text-warning"></i>
            <div class="chain-step px-5">الصحابة الكرام<br><small class="fs-6">(علي، عثمان، أبي، زيد، ابن مسعود)</small></div>
            <i class="fas fa-arrow-down text-warning"></i>
            <div class="chain-step px-5">التابعون والقراء العشرة<br><small class="fs-6">(نافع، عاصم، ابن كثير، حمزة...)</small></div>
            <i class="fas fa-arrow-down text-warning"></i>
            <div class="chain-step px-5">أئمة الضبط والتأصيل<br><small class="fs-6">(الشاطبي، ابن الجزري..)</small></div>
            <i class="fas fa-arrow-down text-warning"></i>
            <div class="chain-step text-white" style="border-color:white;">شيوخ الإقراء في زماننا</div>
         </div>
      </div>
    </div>

  </div> <!-- End tabs content -->
</div>

<!-- Reader Modal -->
<div class="modal fade" id="quranModal" tabindex="-1">
  <div class="modal-dialog modal-xl modal-dialog-scrollable">
    <div class="modal-content border-0 shadow-lg">
      <div class="modal-header text-white" style="background:linear-gradient(135deg,#033547,#05708a);">
        <h5 class="modal-title font-amiri fs-3" id="quranModalTitle"></h5>
        <button type="button" class="btn-close btn-close-white ms-0 me-auto" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body quran-reader" id="quranModalBody" style="background:#fffcf4;">
        <!-- text -->
      </div>
    </div>
  </div>
</div>

<!-- Global Player -->
<div class="global-player" id="globalPlayer">
  <div class="container d-flex align-items-center justify-content-between position-relative">
    <button class="btn btn-sm btn-outline-secondary position-absolute top-0 end-0 mt-2 border-0 text-white" onclick="document.getElementById('globalPlayer').classList.remove('active')"><i class="fas fa-times"></i></button>
    <div class="d-flex align-items-center gap-3">
      <div style="width:50px;height:50px;background:var(--gold);border-radius:50%;display:flex;align-items:center;justify-content:center;color:#021a24;font-size:1.5rem;"><i class="fas fa-play"></i></div>
      <div class="text-white">
        <h6 class="mb-0 font-amiri fs-5 text-warning" id="playerTitle"></h6>
        <small class="opacity-75" id="playerReciter">مشارى العفاسي</small>
      </div>
    </div>
    <audio id="quranAudio" controls class="w-50" style="filter:invert(1) hue-rotate(180deg);"></audio>
  </div>
</div>

<!-- FOOTER -->
<footer class="mega-footer" style="background:linear-gradient(135deg,var(--dark),#020617);color:white;padding:80px 0 30px;margin-top:80px;border-top:3px solid var(--gold-dark);">
  <div class="container">
    <div class="row g-5 mb-5 border-bottom border-light border-opacity-10 pb-5">
      <div class="col-lg-4 text-md-end text-center">
        <i class="fas fa-mosque fa-4x text-warning mb-4 d-block"></i>
        <h4 class="fw-bold font-amiri fs-2 mb-3">الموسوعة الإسلامية الشاملة</h4>
        <p class="opacity-75 fs-6 line-height-2">أضخم صرح رقمي يجمع علوم القرآن العظيم، وأحاديث المصطفى، وفقهاء المذاهب، والتاريخ المجيد في منصة موثقة مصممة بأحدث التقنيات.</p>
      </div>
      <div class="col-lg-4 text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">تصفح الموسوعة</h5>
        <div class="d-flex flex-wrap justify-content-center gap-2">
          <a href="recitations.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">أكاديمية القرآن</a>
          <a href="hadith.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الحديث النبوي</a>
          <a href="seerah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">السيرة والصحابة</a>
          <a href="fiqh.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الفقه وأصوله</a>
          <a href="fatwa.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">فتاوى العلماء</a>
          <a href="aqeedah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">العقيدة الإسلامية</a>
          <a href="history.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">التاريخ المجيد</a>
          <a href="library.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">المكتبة الشاملة</a>
        </div>
      </div>
      <div class="col-lg-4 text-md-start text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">روابط سريعة</h5>
        <a href="contact.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> اتصل بالمطور</a>
        <a href="share.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> شارك الأجر</a>
        <a href="login.html" class="mega-footer-link text-warning mt-3" style="text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-user-circle me-2 ms-1"></i> تسجيل الدخول</a>
      </div>
    </div>
    <div class="text-center font-amiri fs-5 d-flex flex-column gap-2">
      <span class="opacity-75">الموسوعة الإسلامية الشاملة &copy; 2026 تم التصميم للإفادة | عمل مجاني لوجه الله</span>
      <span class="text-warning fw-bold fs-4 mt-2">تصميم وتطوير: لخذاري محمد سيف الدين</span>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- Included quran-script.js for Quran Tab interactions -->
<script src="quran-script.js"></script>
</body>
</html>
