import codecs

html = """<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>القراءات والتلاوات - الموسوعة الإسلامية الشاملة</title>
<link href="https://fonts.googleapis.com/css2?family=Amiri:ital,wght@0,400;0,700;1,400&family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root{--gold:#c9a66b;--gold2:#e8d5a3;--dark:#01121a;--cyan:#05708a;}
body{font-family:'Cairo',sans-serif;background:#f0f6f8;color:#1c2528;overflow-x:hidden;}
h1,h2,h3,h4,.ar{font-family:'Amiri',serif;}

/* NAVBAR - Will be replaced globally but providing default here */
.navbar {background:linear-gradient(135deg,#01121a,#064b63)!important;box-shadow:0 4px 20px rgba(0,0,0,.4);}
.navbar-brand{font-family:'Amiri',serif;font-size:1.6rem;color:white!important;}
.nav-link{color:rgba(255,255,255,.8)!important;font-weight:700;}

/* HERO */
.rec-hero{min-height:480px;background:linear-gradient(160deg,#01121a 0%,#064b63 45%,#05708a 100%);position:relative;overflow:hidden;display:flex;align-items:center;padding:80px 0;}
.orb{position:absolute;border-radius:50%;filter:blur(90px);opacity:.25;animation:orb 12s infinite alternate;}
.orb:nth-child(1){width:450px;height:450px;background:#c9a66b;top:-100px;right:-100px;}
.orb:nth-child(2){width:300px;height:300px;background:#1abc9c;bottom:-80px;left:5%;animation-delay:4s;}
@keyframes orb{from{transform:scale(1) translate(0,0)}to{transform:scale(1.2) translate(25px,25px)}}
.hero-pattern{position:absolute;inset:0;background:url('https://www.transparenttextures.com/patterns/arabesque.png');opacity:.1;}
.hero-content{position:relative;z-index:5;color:white;}
.hero-eyebrow{display:inline-block;border:1px solid rgba(201,166,107,.4);background:rgba(201,166,107,.1);backdrop-filter:blur(10px);color:var(--gold2);border-radius:40px;padding:8px 24px;font-size:.85rem;font-weight:700;margin-bottom:20px;}
.hero h1{font-size:3.8rem;font-weight:bold;margin-bottom:12px;background:linear-gradient(135deg,#fff 30%,var(--gold2) 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;line-height:1.3;}
.tagline{color:rgba(255,255,255,.7);font-size:1.15rem;margin-bottom:35px;line-height:2;}

/* TABS */
.sec-tabs{background:white;border-radius:60px;padding:8px;box-shadow:0 10px 40px rgba(6,75,99,.08);margin:-30px auto 50px;max-width:800px;display:flex;position:relative;z-index:10;border:1px solid rgba(6,75,99,.05);}
.sec-tabs .nav-item{flex:1;}
.sec-tabs .nav-link{border:none;border-radius:50px;color:#555;font-weight:700;padding:14px 12px;width:100%;text-align:center;transition:all .35s;font-size:1.05rem;}
.sec-tabs .nav-link.active{background:linear-gradient(135deg,#064b63,#05708a);color:white;box-shadow:0 8px 20px rgba(6,75,99,.3);}

/* SEC HEAD */
.sec-head{text-align:center;margin-bottom:50px;}
.sec-head .tag{display:inline-block;background:rgba(6,75,99,.08);color:var(--cyan);border-radius:40px;padding:6px 20px;font-size:.85rem;font-weight:700;margin-bottom:15px;}
.sec-head h3{font-size:2.4rem;color:#064b63;font-weight:800;margin-bottom:10px;}
.sec-head h3 span{color:var(--gold);}
.sec-head p{color:#666;max-width:650px;margin:0 auto;font-size:1.05rem;line-height:1.8;}
.sec-head .divider{width:60px;height:4px;background:linear-gradient(90deg,var(--gold),var(--gold2));border-radius:2px;margin:15px auto 0;}

/* QIRAAT CARDS */
.qiraat-card{background:white;border-radius:20px;padding:30px;box-shadow:0 10px 30px rgba(6,75,99,.06);transition:.4s;height:100%;border-top:4px solid var(--gold);position:relative;overflow:hidden;}
.qiraat-card:hover{transform:translateY(-8px);box-shadow:0 20px 40px rgba(6,75,99,.12);}
.qiraat-icon{width:65px;height:65px;border-radius:16px;background:linear-gradient(135deg,#064b63,#05708a);display:flex;align-items:center;justify-content:center;font-size:1.8rem;color:var(--gold2);margin-bottom:20px;box-shadow:0 10px 20px rgba(6,75,99,.2);}
.qiraat-card h4{font-weight:800;color:#01121a;margin-bottom:10px;font-size:1.4rem;}
.qiraat-card p{color:#555;font-size:.95rem;line-height:1.8;margin-bottom:20px;}
.qiraat-tags span{display:inline-block;background:#f0f6f8;color:var(--cyan);padding:5px 12px;border-radius:6px;font-size:.8rem;font-weight:700;margin-left:5px;margin-bottom:5px;}

/* RECITER CARDS */
.reciter-card{background:white;border-radius:20px;overflow:hidden;box-shadow:0 10px 30px rgba(0,0,0,.06);transition:.4s;text-align:center;border:1px solid rgba(0,0,0,.04);}
.reciter-card:hover{transform:translateY(-10px);box-shadow:0 20px 40px rgba(6,75,99,.12);border-color:var(--gold);}
.r-img{width:100%;height:160px;background:linear-gradient(135deg,rgba(6,75,99,.08),rgba(6,75,99,.02));display:flex;align-items:center;justify-content:center;font-size:4rem;color:var(--cyan);position:relative;}
.r-body{padding:25px;}
.r-body h5{font-weight:800;color:#01121a;margin-bottom:5px;font-size:1.25rem;}
.r-body p{color:#777;font-size:.85rem;margin-bottom:15px;}
.r-btn{background:var(--cyan);color:white;border:none;border-radius:30px;padding:8px 25px;font-weight:700;font-size:.9rem;transition:.3s;}
.r-btn:hover{background:var(--dark);transform:scale(1.05);}

/* TAJWEED TAB */
.taj-card{background:white;border-radius:16px;padding:25px;box-shadow:0 8px 25px rgba(6,75,99,.05);display:flex;align-items:flex-start;gap:20px;margin-bottom:20px;transition:.3s;border-right:4px solid var(--cyan);}
.taj-card:hover{transform:translateX(-5px);border-right-color:var(--gold);}
.taj-icon{width:50px;height:50px;border-radius:12px;background:var(--cyan);color:white;display:flex;align-items:center;justify-content:center;font-size:1.4rem;flex-shrink:0;}
.taj-body h5{font-weight:800;color:#01121a;margin-bottom:8px;}
.taj-body p{color:#555;font-size:.9rem;line-height:1.7;margin:0;}

/* AUDIO MODAL */
.audio-modal-content{border-radius:20px;overflow:hidden;border:none;}
.audio-modal-header{background:linear-gradient(135deg,#01121a,#064b63);color:white;border:none;padding:25px;}
</style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold" href="index.html"><i class="fas fa-book-open me-2 text-warning"></i>الموسوعة الإسلامية الشاملة</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav1">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="nav1">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link " href="index.html">الرئيسية</a></li>
        <li class="nav-item"><a class="nav-link active" href="recitations.html">القرآن والتلاوات</a></li>
        <li class="nav-item"><a class="nav-link " href="hadith.html">الحديث الشريف</a></li>
        <li class="nav-item"><a class="nav-link " href="fiqh.html">الفقه الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="fatwa.html">فتاوى العلماء <i class="fas fa-gavel"></i></a></li>
        <li class="nav-item"><a class="nav-link " href="seerah.html">السيرة والصحابة</a></li>
        <li class="nav-item"><a class="nav-link " href="aqeedah.html">العقيدة الإسلامية</a></li>
        <li class="nav-item"><a class="nav-link " href="history.html">التاريخ الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="library.html">المكتبة الشاملة</a></li>
      </ul>
    </div>
  </div>
</nav>

<section class="rec-hero">
  <div class="orb"></div><div class="orb"></div>
  <div class="hero-pattern"></div>
  <div class="container hero-content">
    <div class="row align-items-center g-5">
      <div class="col-lg-7">
        <div class="hero-eyebrow"><i class="fas fa-headphones me-2"></i>أكاديمية القراءات</div>
        <h1>القراءات والتلاوات</h1>
        <p class="tagline">تعرف على القراءات العشر المتواترة، واستمع لأعذب التلاوات لأشهر المقرئين، وتعرف على أحكام التجويد الأساسية لإتقان قراءة كتاب الله الدقيقة.</p>
      </div>
      <div class="col-lg-5 d-none d-lg-block text-center">
        <i class="fas fa-microphone-alt" style="font-size:14rem;color:rgba(201,166,107,.15);animation:spin 30s linear infinite;"></i>
      </div>
    </div>
  </div>
</section>

<div class="container mb-5">
  <ul class="nav sec-tabs" id="rTabs" role="tablist">
    <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#t-10"><i class="fas fa-book-open me-1"></i>القراءات العشر</button></li>
    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t-qura"><i class="fas fa-headphones me-1"></i>أشهر القراء</button></li>
    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t-tajweed"><i class="fas fa-star me-1"></i>علوم التجويد</button></li>
  </ul>

  <div class="tab-content mt-5">

    <!-- TAB 1: 10 QIRAAT -->
    <div class="tab-pane fade show active" id="t-10">
      <div class="sec-head">
        <span class="tag">تواتر السند والقرآن</span>
        <h3>القراءات العشر <span>المتواترة</span></h3>
        <p>القراءات القرآنية الثابتة بالتواتر القطعي عن النبي ﷺ، لكل قراءة راويان</p>
        <div class="divider"></div>
      </div>
      
      <div class="row g-4 justify-content-center">
        <div class="col-lg-4 col-md-6">
          <div class="qiraat-card">
            <div class="qiraat-icon"><i class="fas fa-kaaba"></i></div>
            <h4>قراءة نافع المدني</h4>
            <p>هي قراءة أهل المدينة المنورة، وتمتاز بالفخامة وإعطاء الحروف حقها من المد والتحقيق.</p>
            <div class="qiraat-tags"><span>رواية قالون</span><span>رواية ورش</span></div>
          </div>
        </div>
        
        <div class="col-lg-4 col-md-6">
          <div class="qiraat-card">
            <div class="qiraat-icon"><i class="fas fa-mosque"></i></div>
            <h4>قراءة ابن كثير المكي</h4>
            <p>قراءة أهل مكة المكرمة، وتشتهر بالصلة الخفيفة وتمكين الغنن وإعطاء الحروف حقها.</p>
            <div class="qiraat-tags"><span>رواية البزي</span><span>رواية قنبل</span></div>
          </div>
        </div>
        
        <div class="col-lg-4 col-md-6">
          <div class="qiraat-card">
            <div class="qiraat-icon"><i class="fas fa-moon"></i></div>
            <h4>قراءة أبي عمرو البصري</h4>
            <p>قراءة أهل البصرة، تمتاز بكثرة الإدغام الكبير المتقن وتسهيل الهمزات.</p>
            <div class="qiraat-tags"><span>رواية الدوري</span><span>رواية السوسي</span></div>
          </div>
        </div>
        
        <div class="col-lg-4 col-md-6">
          <div class="qiraat-card">
            <div class="qiraat-icon"><i class="fas fa-star text-warning"></i></div>
            <h4>قراءة عاصم الكوفي</h4>
            <p>من أشهر القراءات وأكثرها انتشاراً في العالم الإسلامي، وتتميز بالتحقيق الشديد وإيضاح الحروف.</p>
            <div class="qiraat-tags"><span>رواية شعبة</span><span>رواية حفص</span></div>
          </div>
        </div>

        <div class="col-lg-4 col-md-6">
          <div class="qiraat-card">
            <div class="qiraat-icon"><i class="fas fa-compass"></i></div>
            <h4>قراءة حمزة الزيات الكوفي</h4>
            <p>تتميز بطول المد وتسهيل الهمزات في الوقف وكثرة الإمالة وشدة التحقيق عند البدء والميل للترقيق.</p>
            <div class="qiraat-tags"><span>رواية خلف</span><span>رواية خلاد</span></div>
          </div>
        </div>
      </div>
    </div>

    <!-- TAB 2: RECITER -->
    <div class="tab-pane fade" id="t-qura">
      <div class="sec-head">
        <span class="tag">أصوات من الجنة</span>
        <h3>أشهر القراء <span>والمجودين</span></h3>
        <p>استمع لأعذب الأصوات التي سجلت المصحف المرتل والمجود عبر التاريخ</p>
        <div class="divider"></div>
      </div>
      
      <div class="row g-4">
        <!-- R1 -->
        <div class="col-lg-3 col-md-4 col-sm-6">
          <div class="reciter-card">
            <div class="r-img"><i class="fas fa-user-circle"></i></div>
            <div class="r-body">
              <h5>عبد الباسط عبد الصمد</h5>
              <p>صاحب الحنجرة الذهبية، أسطورة التلاوة المجودة.</p>
              <button class="r-btn" data-bs-toggle="modal" data-bs-target="#audioModal">استماع لتلاواته</button>
            </div>
          </div>
        </div>
        <!-- R2 -->
        <div class="col-lg-3 col-md-4 col-sm-6">
          <div class="reciter-card">
            <div class="r-img"><i class="fas fa-user-circle"></i></div>
            <div class="r-body">
              <h5>محمود خليل الحصري</h5>
              <p>شيخ عموم المقارئ، مدرسة الإتقان الدقيق بأحكام التجويد.</p>
              <button class="r-btn" data-bs-toggle="modal" data-bs-target="#audioModal">استماع لتلاواته</button>
            </div>
          </div>
        </div>
        <!-- R3 -->
        <div class="col-lg-3 col-md-4 col-sm-6">
          <div class="reciter-card">
            <div class="r-img"><i class="fas fa-user-circle"></i></div>
            <div class="r-body">
              <h5>محمد صديق المنشاوي</h5>
              <p>الصوت الخاشع الباكي، يلمس القلوب من أول آية.</p>
              <button class="r-btn" data-bs-toggle="modal" data-bs-target="#audioModal">استماع لتلاواته</button>
            </div>
          </div>
        </div>
        <!-- R4 -->
        <div class="col-lg-3 col-md-4 col-sm-6">
          <div class="reciter-card">
            <div class="r-img"><i class="fas fa-user-circle"></i></div>
            <div class="r-body">
              <h5>مشاري بن راشد العفاسي</h5>
              <p>صوت الرقة والعذوبة والتلاوة المرتلة الآسرة.</p>
              <button class="r-btn" data-bs-toggle="modal" data-bs-target="#audioModal">استماع لتلاواته</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- TAB 3: TAJWEED -->
    <div class="tab-pane fade" id="t-tajweed">
       <div class="sec-head">
        <span class="tag">ترتيل وتجويد</span>
        <h3>أحكام <span>التجويد</span> الأساسية</h3>
        <p>قواعد قراءة القرآن الكريم كما أُنزِل لإعطاء الحروف حقها ومستحقها</p>
        <div class="divider"></div>
      </div>
      <div class="row">
        <div class="col-lg-6">
          <div class="taj-card"><div class="taj-icon">ن</div><div class="taj-body"><h5>أحكام النون الساكنة والتنوين</h5><p>تشمل أربعة أحكام رئيسية: <strong>الإظهار</strong> (عند حروف الحلق)، <strong>الإدغام</strong> (حروف يرملون)، <strong>القلب</strong> (عند الباء)، و<strong>الإخفاء</strong> الحقيقي (بقية الحروف ومع الغنة).</p></div></div>
          <div class="taj-card"><div class="taj-icon">م</div><div class="taj-body"><h5>أحكام الميم الساكنة</h5><p>تشمل ثلاثة أحكام: <strong>الإخفاء الشفوي</strong> (عند الباء)، <strong>الإدغام المتماثل</strong> (عند ميم أخرى)، و<strong>الإظهار الشفوي</strong> (تظهر عند بقية الحروف خاصة الواو والفاء).</p></div></div>
        </div>
        <div class="col-lg-6">
          <div class="taj-card"><div class="taj-icon">~</div><div class="taj-body"><h5>أحكام المدود</h5><p>إطالة الصوت بحرف المد. المد الطبيعي حركتان، والفرعي يتفرع بسبب الهمز (متصل ومنفصل وبدل) أو السكون (العارض للسكون واللازم) ويُمد 4 و 5 أو 6 حركات.</p></div></div>
          <div class="taj-card"><div class="taj-icon">ّ</div><div class="taj-body"><h5>أحكام الميم والنون المشددتين</h5><p>يجب غنّهما بمقدار حركتين ويُسمى كل منهما حرف غنة مُشدّد نحو: (قُلْ أَعُوذُ بِرَبِّ <strong>النَّاسِ</strong>).</p></div></div>
        </div>
      </div>
    </div>

  </div> <!-- End tabs pt2 -->
</div>

<!-- audio mock -->
<div class="modal fade" id="audioModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content audio-modal-content">
      <div class="modal-header audio-modal-header text-center d-block">
        <h5 class="modal-title font-amiri fs-3 text-warning">المكتبة الصوتية</h5>
      </div>
      <div class="modal-body text-center py-5">
        <i class="fas fa-music fa-3x text-muted opacity-25 mb-3"></i>
        <h5 class="fw-bold">قريباً</h5>
        <p class="text-muted">نعمل على ربط المكتبة الصوتية الكاملة لهذا القارئ</p>
        <button class="btn btn-secondary px-4 rounded-pill mt-3" data-bs-dismiss="modal">إغلاق</button>
      </div>
    </div>
  </div>
</div>

<!-- FOOTER -->
<footer class="mega-footer" style="background:linear-gradient(135deg,var(--dark),#020617);color:white;padding:80px 0 30px;margin-top:80px;border-top:3px solid var(--gold-dark);">
  <div class="container">
    <div class="row g-5 mb-5 border-bottom border-light border-opacity-10 pb-5">
      <div class="col-lg-4 text-md-end text-center">
        <i class="fas fa-mosque fa-4x text-warning mb-4 d-block"></i>
        <h4 class="fw-bold font-amiri fs-2 mb-3">الموسوعة الإسلامية الشاملة</h4>
        <p class="opacity-75 fs-6 line-height-2">أضخم صرح رقمي يجمع علوم القرآن العظيم، وأحاديث المصطفى، وفقهاء المذاهب، والتاريخ المجيد في منصة موثقة مصممة بأحدث التقنيات.</p>
      </div>
      <div class="col-lg-4 text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">تصفح الموسوعة</h5>
        <div class="d-flex flex-wrap justify-content-center gap-2">
          <a href="recitations.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">أكاديمية القرآن</a>
          <a href="hadith.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الحديث النبوي</a>
          <a href="seerah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">السيرة والصحابة</a>
          <a href="fiqh.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الفقه وأصوله</a>
          <a href="fatwa.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">فتاوى العلماء</a>
          <a href="aqeedah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">العقيدة الإسلامية</a>
          <a href="history.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">التاريخ المجيد</a>
          <a href="library.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">المكتبة الشاملة</a>
        </div>
      </div>
      <div class="col-lg-4 text-md-start text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">روابط سريعة</h5>
        <a href="contact.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> اتصل بالمطور</a>
        <a href="share.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> شارك الأجر</a>
        <a href="login.html" class="mega-footer-link text-warning mt-3" style="text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-user-circle me-2 ms-1"></i> تسجيل الدخول</a>
      </div>
    </div>
    <div class="text-center font-amiri fs-5 d-flex flex-column gap-2">
      <span class="opacity-75">الموسوعة الإسلامية الشاملة &copy; 2026 تم التصميم للإفادة | عمل مجاني لوجه الله</span>
      <span class="text-warning fw-bold fs-4 mt-2">تصميم وتطوير: لخذاري محمد سيف الدين</span>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<style>@keyframes spin{to{transform:rotate(360deg)}}</style>
</body>
</html>"""

with codecs.open(r"C:\Users\ST\Desktop\islamic.encyclopedia\recitations.html", 'w', 'utf-8') as f:
    f.write(html)
print("recitations.html built successfully.")
