import os
import re

master_navbar = """<nav class="navbar navbar-expand-lg navbar-dark sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold" href="index.html"><i class="fas fa-book-open me-2 text-warning"></i>الموسوعة الإسلامية الشاملة</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav1">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="nav1">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link {INDEX_ACTIVE}" href="index.html">الرئيسية</a></li>
        <li class="nav-item"><a class="nav-link {RECITATIONS_ACTIVE}" href="recitations.html">القرآن والتلاوات</a></li>
        <li class="nav-item"><a class="nav-link {HADITH_ACTIVE}" href="hadith.html">الحديث الشريف</a></li>
        <li class="nav-item"><a class="nav-link {FIQH_ACTIVE}" href="fiqh.html">الفقه الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link {FATWA_ACTIVE}" href="fatwa.html">فتاوى العلماء <i class="fas fa-gavel"></i></a></li>
        <li class="nav-item"><a class="nav-link {SEERAH_ACTIVE}" href="seerah.html">السيرة والصحابة</a></li>
        <li class="nav-item"><a class="nav-link {AQEEDAH_ACTIVE}" href="aqeedah.html">العقيدة الإسلامية</a></li>
        <li class="nav-item"><a class="nav-link {HISTORY_ACTIVE}" href="history.html">التاريخ الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link {LIBRARY_ACTIVE}" href="library.html">المكتبة الشاملة</a></li>
      </ul>
    </div>
  </div>
</nav>"""

master_footer = """<footer class="mega-footer" style="background:linear-gradient(135deg,var(--dark),#020617);color:white;padding:80px 0 30px;margin-top:80px;border-top:3px solid var(--gold-dark);">
  <div class="container">
    <div class="row g-5 mb-5 border-bottom border-light border-opacity-10 pb-5">
      <div class="col-lg-4 text-md-end text-center">
        <i class="fas fa-mosque fa-4x text-warning mb-4 d-block"></i>
        <h4 class="fw-bold font-amiri fs-2 mb-3">الموسوعة الإسلامية الشاملة</h4>
        <p class="opacity-75 fs-6 line-height-2">أضخم صرح رقمي يجمع علوم القرآن العظيم، وأحاديث المصطفى، وفقهاء المذاهب، والتاريخ المجيد في منصة موثقة مصممة بأحدث التقنيات.</p>
      </div>
      <div class="col-lg-4 text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">تصفح الموسوعة</h5>
        <div class="d-flex flex-wrap justify-content-center gap-2">
          <a href="recitations.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">أكاديمية القرآن</a>
          <a href="hadith.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الحديث النبوي</a>
          <a href="seerah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">السيرة والصحابة</a>
          <a href="fiqh.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الفقه وأصوله</a>
          <a href="fatwa.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">فتاوى العلماء</a>
          <a href="aqeedah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">العقيدة الإسلامية</a>
          <a href="history.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">التاريخ المجيد</a>
          <a href="library.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">المكتبة الشاملة</a>
        </div>
      </div>
      <div class="col-lg-4 text-md-start text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">روابط سريعة</h5>
        <a href="contact.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> اتصل بالمطور</a>
        <a href="share.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> شارك الأجر</a>
        <a href="login.html" class="mega-footer-link text-warning mt-3" style="text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-user-circle me-2 ms-1"></i> تسجيل الدخول</a>
      </div>
    </div>
    <div class="text-center font-amiri fs-5 d-flex flex-column gap-2">
      <span class="opacity-75">الموسوعة الإسلامية الشاملة &copy; 2026 تم التصميم للإفادة | عمل مجاني لوجه الله</span>
      <span class="text-warning fw-bold fs-4 mt-2">تصميم وتطوير: لخذاري محمد سيف الدين</span>
    </div>
  </div>
</footer>"""

for f in os.listdir('.'):
    if f.endswith('.html') or f.endswith('.py'):
        if f == 'unify_all.py': continue
        with open(f, 'r', encoding='utf-8') as file:
            content = file.read()
            
        original_content = content
        
        # Build file specific navbar
        nav = master_navbar
        keys = ['INDEX', 'RECITATIONS', 'HADITH', 'FIQH', 'FATWA', 'SEERAH', 'AQEEDAH', 'HISTORY', 'LIBRARY']
        active_key = None
        for k in keys:
            if k.lower() in f.lower():
                active_key = k
                break
        
        for k in keys:
            if k == active_key:
                if k == 'INDEX':
                    nav = nav.replace('{' + k + '_ACTIVE}', 'active" style="color:var(--gold)!important;')
                elif k == 'LIBRARY':
                    nav = nav.replace('{' + k + '_ACTIVE}', 'active" style="color:var(--gold)!important;')
                else:
                    nav = nav.replace('{' + k + '_ACTIVE}', 'active')
            else:
                nav = nav.replace('{' + k + '_ACTIVE}', '')
        
        # Clean any stray curly braces mapping issue just in case
        for k in keys:
            nav = nav.replace('{' + k + '_ACTIVE}', '')
            
        content = re.sub(r'<nav\b[^>]*>.*?</nav>', nav, content, flags=re.DOTALL)
        content = re.sub(r'<footer\b[^>]*>.*?</footer>', master_footer, content, flags=re.DOTALL)
        
        if content != original_content:
            print(f"Updated {f}")
            with open(f, 'w', encoding='utf-8') as file:
                file.write(content)

print('Done unifying.')
