import codecs
import os

part3 = """
<!-- TAB 4: NAWAQID -->
<div class="tab-pane fade" id="t-nawaqid">
  <div class="sec-head">
    <span class="tag" style="background:rgba(231,76,60,.1);color:#c0392b;">احذر المهلكات</span>
    <h3 style="color:#c0392b;">نواقض <span>الإسلام</span></h3>
    <p>أمور إذا فعلها المسلم بطل إسلامه (والعياذ بالله)، وهي أهم ما يجب على العبد تجنبه</p>
    <div class="divider" style="background:linear-gradient(90deg,#c0392b,#e74c3c);"></div>
  </div>

  <div class="row">
    <div class="col-lg-10 mx-auto">
      <div style="background:#fff5f5;border:1px solid rgba(231,76,60,.3);border-radius:15px;padding:25px;margin-bottom:30px;">
        <h5 class="mb-3" style="color:#c0392b;font-weight:bold;"><i class="fas fa-info-circle me-2"></i>تنبيه هام حول التكفير:</h5>
        <p class="mb-0 text-muted small" style="line-height:2;">الحكم على شخص معين بالكفر له شروط وموانع يتولاها القضاة والعلماء الراسخون. والهدف من دراسة النواقض هو الحذر منها وعدم الوقوع فيها، وليس إطلاق الأحكام على الناس. قال حذيفة رضي الله عنه: "كان الناس يسألون رسول الله عن الخير، وكنت أسأله عن الشر مخافة أن يدركني".</p>
      </div>

      <ul class="nawaqid-list">
        <li class="nawaqid-item"><i class="fas fa-om"></i><div><strong style="color:#0a2540;">1. الشرك في عبادة الله تعالى:</strong><br><span class="small text-muted">دعاء الأموات، وذبح القرابين والنذور لغير الله (للجن أو الأضرحة). قال تعالى: ﴿إِنَّ اللَّهَ لَا يَغْفِرُ أَن يُشْرَكَ بِهِ﴾.</span></div></li>
        <li class="nawaqid-item"><i class="fas fa-users-slash"></i><div><strong style="color:#0a2540;">2. من جعل بينه وبين الله وسائط:</strong><br><span class="small text-muted">يدعوهم ويسألهم الشفاعة ويتوكل عليهم. وقد أجمع العلماء على كفر من فعل ذلك.</span></div></li>
        <li class="nawaqid-item"><i class="fas fa-question-circle"></i><div><strong style="color:#0a2540;">3. من لم يُكفر المشركين أو شك في كفرهم:</strong><br><span class="small text-muted">من اعتقد صحة دين غير الإسلام، أو صحح مذهب المشركين بعد قيام الحجة.</span></div></li>
        <li class="nawaqid-item"><i class="fas fa-balance-scale-right"></i><div><strong style="color:#0a2540;">4. اعتقاد أن هدي غير النبي ﷺ أكمل من هديه:</strong><br><span class="small text-muted">أو أن حكم غيره أفضل من حكمه، كالذين يفضلون القوانين الوضعية الشاملة المخالفة لحكم الله على شرع الله.</span></div></li>
        <li class="nawaqid-item"><i class="fas fa-heart-broken"></i><div><strong style="color:#0a2540;">5. من أبغض شيئاً مما جاء به الرسول ﷺ:</strong><br><span class="small text-muted">ولو عمل به، كمن يكره الصلاة أو الحجاب الشرعي كرهاً ذاتياً لما فرضه الله. قال تعالى: ﴿ذَلِكَ بِأَنَّهُمْ كَرِهُوا مَا أَنزَلَ اللَّهُ فَأَحْبَطَ أَعْمَالَهُمْ﴾.</span></div></li>
        <li class="nawaqid-item"><i class="fas fa-laugh-squint"></i><div><strong style="color:#0a2540;">6. الاستهزاء بشيء من دين الله:</strong><br><span class="small text-muted">أو ثوابه أو عقابه. قال تعالى: ﴿قُلْ أَبِاللَّهِ وَآيَاتِهِ وَرَسُولِهِ كُنتُمْ تَسْتَهْزِئُونَ * لَا تَعْتَذِرُوا قَدْ كَفَرْتُم بَعْدَ إِيمَانِكُمْ﴾.</span></div></li>
        <li class="nawaqid-item"><i class="fas fa-magic"></i><div><strong style="color:#0a2540;">7. السحر بنوعيه (الصرف والعطف):</strong><br><span class="small text-muted">من فعله أو رضي به كفر. قال تعالى: ﴿وَمَا يُعَلِّمَانِ مِنْ أَحَدٍ حَتَّى يَقُولَا إِنَّمَا نَحْنُ فِتْنَةٌ فَلَا تَكْفُرْ﴾.</span></div></li>
        <li class="nawaqid-item"><i class="fas fa-handshake"></i><div><strong style="color:#0a2540;">8. مظاهرة المشركين ومعاونتهم على المسلمين:</strong><br><span class="small text-muted">تولي الكفار بمعاونتهم ونصرتهم ضد المسلمين. قال تعالى: ﴿وَمَن يَتَوَلَّهُم مِّنكُمْ فَإِنَّهُ مِنْهُمْ﴾.</span></div></li>
        <li class="nawaqid-item"><i class="fas fa-door-open"></i><div><strong style="color:#0a2540;">9. اعتقاد أن بعض الناس يسعه الخروج عن شريعة محمد ﷺ:</strong><br><span class="small text-muted">كما وسع الخضر الخروج عن شريعة موسى. وهو كفر مخرج من الملة.</span></div></li>
        <li class="nawaqid-item"><i class="fas fa-blind"></i><div><strong style="color:#0a2540;">10. الإعراض عن دين الله إعراضاً كلياً:</strong><br><span class="small text-muted">لا يتعلمه ولا يعمل به أبداً. قال تعالى: ﴿وَمَنْ أَظْلَمُ مِمَّن ذُكِّرَ بِآيَاتِ رَبِّهِ ثُمَّ أَعْرَضَ عَنْهَا﴾.</span></div></li>
      </ul>
    </div>
  </div>
</div>

<!-- TAB 5: KUTUB -->
<div class="tab-pane fade" id="t-kutub">
  <div class="sec-head">
    <span class="tag">مصادر ومراجع</span>
    <h3>متون <span>العقيدة البارزة</span></h3>
    <p>أهم الكتب والمتون التي عُنيت بشرح العقيدة الإسلامية عبر العصور</p>
    <div class="divider"></div>
  </div>

  <div class="row g-4">
    <div class="col-lg-4 col-md-6">
      <div class="kitab-card border-top border-4 border-warning">
        <div class="kitab-icon"><i class="fas fa-scroll"></i></div>
        <h5 style="color:#0a2540;font-weight:700;">العقيدة الطحاوية</h5>
        <h6 class="text-warning small mb-3">للإمام أبي جعفر الطحاوي (ت 321 هـ)</h6>
        <p class="text-muted small" style="line-height:1.8;">متن جامع لعقيدة أهل السنة والجماعة على مذهب فقهاء الملة (أبو حنيفة وأصحابه). من أشهر شروحها شرح ابن أبي العز الحنفي. تُعد مرجعاً معتمداً في كافة المعاهد الدينية الإسلامية.</p>
        <button class="btn btn-sm btn-outline-primary mt-2 rounded-pill px-4">تصفح المتن</button>
      </div>
    </div>
    <div class="col-lg-4 col-md-6">
      <div class="kitab-card border-top border-4 border-warning">
        <div class="kitab-icon"><i class="fas fa-book"></i></div>
        <h5 style="color:#0a2540;font-weight:700;">العقيدة الواسطية</h5>
        <h6 class="text-warning small mb-3">لشيخ الإسلام ابن تيمية (ت 728 هـ)</h6>
        <p class="text-muted small" style="line-height:1.8;">رسالة عظيمة كتبها استجابة لطلب قاضي "واسط". ركّز فيها على أسماء الله وصفاته وإثباتها بلا تكييف ولا تعطيل، وموقف أهل السنة من الصحابة، وحقيقة الإيمان.</p>
        <button class="btn btn-sm btn-outline-primary mt-2 rounded-pill px-4">تصفح المتن</button>
      </div>
    </div>
    <div class="col-lg-4 col-md-6">
      <div class="kitab-card border-top border-4 border-warning">
        <div class="kitab-icon"><i class="fas fa-bookmark"></i></div>
        <h5 style="color:#0a2540;font-weight:700;">كتاب التوحيد</h5>
        <h6 class="text-warning small mb-3">للمجدد محمد بن عبد الوهاب (ت 1206 هـ)</h6>
        <p class="text-muted small" style="line-height:1.8;">من أبرز الكتب التي عالجت توحيد الألوهية والعبادة، وحذرت من الشركيات الصغرى والكبرى المنتشرة. رتبه المصنف على أبواب، يورد الآيات ثم الأحاديث ثم المسائل المستنبطة.</p>
        <button class="btn btn-sm btn-outline-primary mt-2 rounded-pill px-4">تصفح المتن</button>
      </div>
    </div>
    <div class="col-lg-4 col-md-6">
      <div class="kitab-card border-top border-4 border-primary">
        <div class="kitab-icon"><i class="fas fa-book-open"></i></div>
        <h5 style="color:#0a2540;font-weight:700;">لمعة الاعتقاد</h5>
        <h6 class="text-primary small mb-3">لابن قدامة المقدسي (ت 620 هـ)</h6>
        <p class="text-muted small" style="line-height:1.8;">متن مختصر بيّن فيه عقيدة السلف الصالح، وركز على إمرار آيات الصفات وأحاديثها كما جاءت بلا كيف.</p>
      </div>
    </div>
    <div class="col-lg-4 col-md-6">
      <div class="kitab-card border-top border-4 border-primary">
        <div class="kitab-icon"><i class="fas fa-quran"></i></div>
        <h5 style="color:#0a2540;font-weight:700;">النونية (الكافية الشافية)</h5>
        <h6 class="text-primary small mb-3">للإمام ابن القيم (ت 751 هـ)</h6>
        <p class="text-muted small" style="line-height:1.8;">منظومة شعرية ضخمة (نحو 6 آلاف بيت) شملت أبواب العقيدة والردود على الفرق المخالفة بأسلوب علمي وشاعري فريد.</p>
      </div>
    </div>
    <div class="col-lg-4 col-md-6">
      <div class="kitab-card border-top border-4 border-primary">
        <div class="kitab-icon"><i class="fas fa-file-alt"></i></div>
        <h5 style="color:#0a2540;font-weight:700;">الأصول الثلاثة</h5>
        <h6 class="text-primary small mb-3">رسالة في أسئلة القبر</h6>
        <p class="text-muted small" style="line-height:1.8;">ملخص مهم ومفيد للأسئلة الثلاثة التي يُسأل عنها العبد في قبره: من ربك؟ وما دينك؟ ومن نبيك؟</p>
      </div>
    </div>
  </div>
</div>

</div><!-- /tab-content -->
</div><!-- /container -->

<footer class="mega-footer" style="background:linear-gradient(135deg,var(--dark),#020617);color:white;padding:80px 0 30px;margin-top:80px;border-top:3px solid var(--gold-dark);">
  <div class="container">
    <div class="row g-5 mb-5 border-bottom border-light border-opacity-10 pb-5">
      <div class="col-lg-4 text-md-end text-center">
        <i class="fas fa-mosque fa-4x text-warning mb-4 d-block"></i>
        <h4 class="fw-bold font-amiri fs-2 mb-3">الموسوعة الإسلامية الشاملة</h4>
        <p class="opacity-75 fs-6 line-height-2">أضخم صرح رقمي يجمع علوم القرآن العظيم، وأحاديث المصطفى، وفقهاء المذاهب، والتاريخ المجيد في منصة موثقة مصممة بأحدث التقنيات.</p>
      </div>
      <div class="col-lg-4 text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">تصفح الموسوعة</h5>
        <div class="d-flex flex-wrap justify-content-center gap-2">
          <a href="recitations.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">أكاديمية القرآن</a>
          <a href="hadith.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الحديث النبوي</a>
          <a href="seerah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">السيرة والصحابة</a>
          <a href="fiqh.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الفقه وأصوله</a>
          <a href="fatwa.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">فتاوى العلماء</a>
          <a href="aqeedah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">العقيدة الإسلامية</a>
          <a href="history.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">التاريخ المجيد</a>
          <a href="library.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">المكتبة الشاملة</a>
        </div>
      </div>
      <div class="col-lg-4 text-md-start text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">روابط سريعة</h5>
        <a href="contact.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> اتصل بالمطور</a>
        <a href="share.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> شارك الأجر</a>
        <a href="login.html" class="mega-footer-link text-warning mt-3" style="text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-user-circle me-2 ms-1"></i> تسجيل الدخول</a>
      </div>
    </div>
    <div class="text-center font-amiri fs-5 d-flex flex-column gap-2">
      <span class="opacity-75">الموسوعة الإسلامية الشاملة &copy; 2026 تم التصميم للإفادة | عمل مجاني لوجه الله</span>
      <span class="text-warning fw-bold fs-4 mt-2">تصميم وتطوير: لخذاري محمد سيف الدين</span>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
@keyframes spin{from{transform:rotate(0)}to{transform:rotate(360deg)}}
</script>
</body></html>
"""

with codecs.open(r"C:\Users\ST\Desktop\islamic.encyclopedia\aq_p3.tmp", 'w', 'utf-8') as f:
    f.write(part3)
print("Aqeedah part 3 ready")

# MERGE
parts=[]
for fn in ['aq_p1.tmp','aq_p2.tmp','aq_p3.tmp']:
    with codecs.open(r"C:\Users\ST\Desktop\islamic.encyclopedia\\"+fn,'r','utf-8') as f:
        parts.append(f.read())

with codecs.open(r"C:\Users\ST\Desktop\islamic.encyclopedia\aqeedah.html",'w','utf-8') as f:
    f.write(''.join(parts))

for fn in ['aq_p1.tmp','aq_p2.tmp','aq_p3.tmp']:
    try: os.remove(r"C:\Users\ST\Desktop\islamic.encyclopedia\\"+fn)
    except: pass

print("aqeedah.html rebuilt — RICH VERSION OK!")
