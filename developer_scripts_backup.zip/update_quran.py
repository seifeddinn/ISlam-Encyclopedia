import codecs
import re

html = codecs.open('recitations.html', 'r', 'utf-8').read()

# 1. Add NavBar Tab
nav_item = '<li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-quran-search"><i class="fas fa-search fs-4 d-block mb-1"></i>الباحث القرآني</button></li>'
if 'tab-quran-search' not in html:
    html = html.replace('<li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-ijazah">',
                        nav_item + '\n      <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-ijazah">')

# 2. Add Tab Content for الباحث القرآني
tab_content = """
    <!-- TAB 8: QURAN SEARCHER -->
    <div class="tab-pane fade" id="tab-quran-search">
      <div class="sec-head">
        <span class="tag">البحث الذكي والدقيق</span>
        <h3>الباحث <span>القرآني</span></h3>
        <p>محرك بحث فوري لكلمات وآيات القرآن الكريم للتحقق من مواضعها وتفسيرها المعتمد.</p>
        <div class="divider"></div>
      </div>
      <div class="row justify-content-center">
         <div class="col-lg-10">
            <div class="mega-card text-center" style="background:var(--dark);color:white;border:1px solid var(--gold);">
               <i class="fas fa-search fa-4x text-warning mb-4"></i>
               <h3 class="font-amiri fw-bold mb-3">البحث في آيات القرآن الكريم</h3>
               
               <div class="input-group input-group-lg mb-4 shadow-lg mx-auto" dir="ltr" style="max-width:800px;">
                  <button class="btn btn-warning fw-bold px-4" type="button" onclick="performQuranSearch()">ابحث <i class="fas fa-search ms-1"></i></button>
                  <input type="text" id="quranSearchInput" class="form-control text-end font-amiri fs-4" placeholder="اكتب الكلمة أو الآية للبحث (مثال: فسيكفيكهم)..." dir="rtl" onkeypress="if(event.key === 'Enter') performQuranSearch()">
               </div>
               
               <div id="quranSearchResults" class="text-end bg-white text-dark rounded-4 p-4 mt-4 text-start shadow-sm d-none" style="max-height:600px; overflow-y:auto;">
                  <h5 class="fw-bold mb-3 text-cyan border-bottom pb-2">نتائج البحث: <span id="quranResultCount" class="text-danger">0</span> آيات</h5>
                  <div id="quranResultsList"></div>
               </div>
            </div>
         </div>
      </div>
    </div>
"""

if 'tab-quran-search' not in html: # Already checked above, but wait 'tab-quran-search' was just added, so re-check won't work that way.
    pass # Wait, if it wasn't in original html, we add it.

# Actually, let's just use string replace before the first <div class="tab-pane fade" id="tab-legends">
if 'id="tab-quran-search"' not in html:
    html = html.replace('<!-- TAB 5: LEGENDS & SCHOOLS OF RECITED QURAN -->', tab_content + '\n    <!-- TAB 5: LEGENDS & SCHOOLS OF RECITED QURAN -->')

# 3. Add JS Function
js_code = """
async function performQuranSearch() {
    const q = document.getElementById('quranSearchInput').value.trim();
    if(!q) return;
    const resBox = document.getElementById('quranSearchResults');
    const resList = document.getElementById('quranResultsList');
    const countBadge = document.getElementById('quranResultCount');
    
    resBox.classList.remove('d-none');
    resList.innerHTML = '<div class="text-center py-4"><div class="spinner-border text-cyan"></div><p class="mt-2 text-muted">جاري البحث في الآيات...</p></div>';
    
    try {
        const response = await fetch('https://api.alquran.cloud/v1/search/' + encodeURIComponent(q) + '/all/quran-uthmani');
        const data = await response.json();
        
        if(data.code === 200 && data.data && data.data.matches.length > 0) {
            countBadge.innerText = data.data.count;
            let out = '';
            data.data.matches.forEach(m => {
                const highlighted = m.text.replace(new RegExp(q, 'g'), match => `<mark class="bg-warning text-dark px-1 rounded">${match}</mark>`);
                out += `
                    <div class="mb-4 p-4 bg-light rounded-4 border border-light shadow-sm">
                        <p class="font-amiri fs-3 fw-bold mb-3 text-dark text-center lh-lg">﴾ ${highlighted} ﴿</p>
                        <div class="d-flex gap-2 justify-content-center">
                            <span class="badge bg-cyan px-3 py-2 fs-6"><i class="fas fa-book-open me-1"></i> سورة ${m.surah.name}</span>
                            <span class="badge bg-secondary px-3 py-2 fs-6"><i class="fas fa-list-ol me-1"></i> آية رقم ${m.numberInSurah}</span>
                        </div>
                    </div>
                `;
            });
            resList.innerHTML = out;
        } else {
            countBadge.innerText = '0';
            resList.innerHTML = '<div class="alert alert-warning text-center fw-bold"><i class="fas fa-exclamation-circle me-2"></i>عذراً، لم نجد نتائج مطابقة لبحثك في المصحف.</div>';
        }
    } catch (err) {
        resList.innerHTML = '<div class="alert alert-danger text-center fw-bold">حدث خطأ في الاتصال بقاعدة البيانات. تأكد من اتصالك بالإنترنت.</div>';
    }
}
</script>
"""

if 'performQuranSearch' not in html:
    html = html.replace('</script>\n</body>', js_code + '\n</body>')

codecs.open('recitations.html', 'w', 'utf-8').write(html)
print("Updated recitations.html successfully.")
