import codecs

css = """<style>
:root{--gold:#c9a66b;--gold2:#e8d5a3;--dark:#0b1116;--green:#043826;--green2:#116850;}
body{font-family:'Cairo',sans-serif;background:#0d151c;color:#e2ecf3;overflow-x:hidden;}
h1,h2,h3,h4,.ar{font-family:'Amiri',serif;}
/* HERO */
.main-hero{min-height:90vh;background:linear-gradient(160deg,#0b1116 0%,#15232d 45%,#0b161e 100%);position:relative;overflow:hidden;display:flex;align-items:center;}
.orb{position:absolute;border-radius:50%;filter:blur(100px);opacity:.15;animation:orb 15s infinite alternate;}
.orb:nth-child(1){width:550px;height:550px;background:#c9a66b;top:-150px;right:-100px;}
.orb:nth-child(2){width:400px;height:400px;background:#3498db;bottom:-100px;left:0;animation-delay:5s;}
@keyframes orb{from{transform:translate(0,0)}to{transform:translate(40px,40px)}}
.hero-pattern{position:absolute;inset:0;background:url('https://www.transparenttextures.com/patterns/stardust.png');opacity:.1;}
.hero-content{position:relative;z-index:5;text-align:center;}
.hero-content h1{font-size:4.5rem;font-weight:bold;margin-bottom:20px;background:linear-gradient(135deg,#fff 30%,var(--gold2) 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;}
.hero-content p{font-size:1.3rem;color:rgba(255,255,255,.7);max-width:800px;margin:0 auto 40px;}
/* CAT CARDS */
.cat-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:25px;position:relative;z-index:6;margin-top:-80px;}
.cat-card{background:linear-gradient(145deg,rgba(30,45,60,0.9),rgba(15,25,35,0.95));backdrop-filter:blur(20px);border:1px solid rgba(201,166,107,.15);border-radius:24px;padding:35px 25px;text-align:center;transition:all .4s;box-shadow:0 15px 35px rgba(0,0,0,.3);text-decoration:none;display:block;}
.cat-card:hover{transform:translateY(-10px);border-color:var(--gold);box-shadow:0 20px 50px rgba(201,166,107,.2);}
.cat-icon{width:80px;height:80px;border-radius:50%;background:rgba(201,166,107,.1);color:var(--gold);display:flex;align-items:center;justify-content:center;font-size:2.5rem;margin:0 auto 20px;transition:.4s;}
.cat-card:hover .cat-icon{background:var(--gold);color:#0b1116;transform:scale(1.1);}
.cat-card h4{color:#fff;font-weight:700;margin-bottom:10px;}
.cat-card p{color:rgba(255,255,255,.5);font-size:.9rem;line-height:1.7;margin:0;}
/* SCHOLARS BAR */
.scholars-bar{background:linear-gradient(135deg,#0e151b,#1c2b36);padding:80px 0;border-top:1px solid rgba(201,166,107,.1);border-bottom:1px solid rgba(201,166,107,.1);position:relative;overflow:hidden;}
.scholars-bar::before{content:'';position:absolute;left:0;top:-2px;height:4px;width:100px;background:var(--gold);box-shadow:0 0 20px var(--gold);}
.scholar-quote{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.05);border-radius:20px;padding:40px;height:100%;transition:.3s;}
.scholar-quote:hover{background:rgba(255,255,255,.05);border-color:rgba(201,166,107,.3);}
.s-icon{font-size:2.5rem;color:var(--gold);opacity:.3;margin-bottom:15px;}
.s-text{font-family:'Amiri',serif;font-size:1.3rem;line-height:2.2;color:#e2ecf3;margin-bottom:20px;}
.s-author{color:var(--gold2);font-weight:700;font-size:.95rem;text-align:left;}
/* NAV */
.navbar{background:rgba(11,17,22,0.9)!important;backdrop-filter:blur(15px);border-bottom:1px solid rgba(255,255,255,.05);}
.navbar-brand{color:var(--gold)!important;}
.nav-link{color:rgba(255,255,255,.7)!important;font-weight:600;}
.nav-link:hover,.nav-link.active{color:var(--gold2)!important;}
</style>"""

html = """<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>الموسوعة الإسلامية الشاملة</title>
<link href="https://fonts.googleapis.com/css2?family=Amiri:ital,wght@0,400;0,700;1,400&family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
""" + css + """
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold" href="index.html"><i class="fas fa-book-open me-2 text-warning"></i>الموسوعة الإسلامية الشاملة</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav1">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="nav1">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link active" style="color:var(--gold)!important;" href="index.html">الرئيسية</a></li>
        <li class="nav-item"><a class="nav-link " href="recitations.html">القرآن والتلاوات</a></li>
        <li class="nav-item"><a class="nav-link " href="hadith.html">الحديث الشريف</a></li>
        <li class="nav-item"><a class="nav-link " href="fiqh.html">الفقه الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="fatwa.html">فتاوى العلماء <i class="fas fa-gavel"></i></a></li>
        <li class="nav-item"><a class="nav-link " href="seerah.html">السيرة والصحابة</a></li>
        <li class="nav-item"><a class="nav-link " href="aqeedah.html">العقيدة الإسلامية</a></li>
        <li class="nav-item"><a class="nav-link " href="history.html">التاريخ الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="library.html">المكتبة الشاملة</a></li>
      </ul>
    </div>
  </div>
</nav>

<section class="main-hero">
  <div class="orb"></div><div class="orb"></div>
  <div class="hero-pattern"></div>
  <div class="container">
    <div class="hero-content">
      <i class="fas fa-star-and-crescent" style="font-size:3rem;color:var(--gold);margin-bottom:25px;filter:drop-shadow(0 0 15px rgba(201,166,107,.5));"></i>
      <h1>الموسوعة الإسلامية الشاملة</h1>
      <p>منصة معرفية كبرى تجمع بين أصالة المنهج وجمال العرض؛ لتضع بين يديك علوم القرآن، السنة النبوية، الفقه، العقيدة، والسيرة العطرة في واجهة واحدة.</p>
    </div>
  </div>
</section>

<div class="container mb-5">
  <div class="cat-grid">
    <a href="recitations.html" class="cat-card">
      <div class="cat-icon"><i class="fas fa-quran"></i></div>
      <h4>القرآن الكريم والأكاديمية</h4>
      <p>المصحف الشريف، القراءات العشر المتواترة، أحكام التجويد الميسر، وأشهر القراء.</p>
    </a>
    <a href="hadith.html" class="cat-card">
      <div class="cat-icon"><i class="fas fa-book-open"></i></div>
      <h4>أكاديمية الحديث الشريف</h4>
      <p>الصحاح والسنن، الأربعون النووية، مصطلح الحديث، والبحث الذكي في الأحاديث.</p>
    </a>
    <a href="seerah.html" class="cat-card">
      <div class="cat-icon"><i class="fas fa-route"></i></div>
      <h4>السيرة النبوية والصحابة</h4>
      <p>التسلسل الزمني، الغزوات والمعجزات، فضائل الصحابة الكرام والخلفاء الراشدين.</p>
    </a>
    <a href="fiqh.html" class="cat-card">
      <div class="cat-icon"><i class="fas fa-balance-scale"></i></div>
      <h4>الفقه الإسلامي والمذاهب</h4>
      <p>أحكام العبادات والمعاملات على أصول المذاهب الفقهية الأربعة المعتبرة.</p>
    </a>
    <a href="aqeedah.html" class="cat-card">
      <div class="cat-icon"><i class="fas fa-pray"></i></div>
      <h4>العقيدة الإسلامية</h4>
      <p>أصول الإيمان، أقسام التوحيد الثلاثة، ونواقض الإسلام، ومتون العقيدة.</p>
    </a>
    <a href="history.html" class="cat-card">
      <div class="cat-icon"><i class="fas fa-globe-asia"></i></div>
      <h4>التاريخ الإسلامي</h4>
      <p>تاريخ الحضارة الإسلامية، الدول، الفتوحات، والمراحل المفصلية للأمة.</p>
    </a>
  </div>
</div>

<section class="scholars-bar">
  <div class="container">
    <div class="text-center mb-5">
      <h6 class="text-warning mb-2" style="font-weight:700;letter-spacing:1px;">حِكم ودرر</h6>
      <h2 style="color:white;font-weight:bold;font-size:2.5rem;">أقوال العلماء الأعلام</h2>
      <div style="width:60px;height:3px;background:var(--gold);margin:15px auto 0;"></div>
    </div>
    
    <div class="row g-4">
      <div class="col-lg-4 col-md-6">
        <div class="scholar-quote">
          <i class="fas fa-quote-right s-icon"></i>
          <p class="s-text">«إذا رأيت الرجل يمشي على الماء أو يطير في الهواء، فلا تغتر به حتى تعرض أمره على الكتاب والسنة»</p>
          <div class="s-author">— الإمام الشافعي رحمه الله</div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6">
        <div class="scholar-quote">
          <i class="fas fa-quote-right s-icon"></i>
          <p class="s-text">«ما أنعم الله على عبد نعمة فانتزعها منه، فعاضه مكانها الصبر، إلا كان ما عوّضه خيراً مما انتزعه»</p>
          <div class="s-author">— أمير المؤمنين عمر بن عبد العزيز</div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6">
        <div class="scholar-quote">
          <i class="fas fa-quote-right s-icon"></i>
          <p class="s-text">«القلب إنما خُلق لأجل حب الله تعالى، فلا تشتت قلبك في غير محبوه، فإنك لن تجد راحة إلا في الله»</p>
          <div class="s-author">— شيخ الإسلام ابن تيمية</div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6">
        <div class="scholar-quote">
          <i class="fas fa-quote-right s-icon"></i>
          <p class="s-text">«ابن آدم، إنما أنت أيام، فإذا ذهب يومك ذهب بعضك، ويوشك إذا ذهب البعض أن يذهب الكل»</p>
          <div class="s-author">— الحسن البصري رحمـه الله</div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6">
        <div class="scholar-quote">
          <i class="fas fa-quote-right s-icon"></i>
          <p class="s-text">«العلم صيدٌ والكتابة قيده، قيّد صيودك بالحبال الواثقة، فمن الحماقة أن تصيد غزالة، وتتركها بين الخلائق طالقة»</p>
          <div class="s-author">— الإمام الشافعي رحمه الله</div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6">
        <div class="scholar-quote">
          <i class="fas fa-quote-right s-icon"></i>
          <p class="s-text">«لا يزال العبد بخير ما إذا قال، قال لله، وإذا عمل، عمل لله»</p>
          <div class="s-author">— الإمام أحمد بن حنبل</div>
        </div>
      </div>
    </div>
  </div>
</section>

<footer class="mega-footer" style="background:linear-gradient(135deg,var(--dark),#020617);color:white;padding:80px 0 30px;margin-top:80px;border-top:3px solid var(--gold-dark);">
  <div class="container">
    <div class="row g-5 mb-5 border-bottom border-light border-opacity-10 pb-5">
      <div class="col-lg-4 text-md-end text-center">
        <i class="fas fa-mosque fa-4x text-warning mb-4 d-block"></i>
        <h4 class="fw-bold font-amiri fs-2 mb-3">الموسوعة الإسلامية الشاملة</h4>
        <p class="opacity-75 fs-6 line-height-2">أضخم صرح رقمي يجمع علوم القرآن العظيم، وأحاديث المصطفى، وفقهاء المذاهب، والتاريخ المجيد في منصة موثقة مصممة بأحدث التقنيات.</p>
      </div>
      <div class="col-lg-4 text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">تصفح الموسوعة</h5>
        <div class="d-flex flex-wrap justify-content-center gap-2">
          <a href="recitations.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">أكاديمية القرآن</a>
          <a href="hadith.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الحديث النبوي</a>
          <a href="seerah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">السيرة والصحابة</a>
          <a href="fiqh.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الفقه وأصوله</a>
          <a href="fatwa.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">فتاوى العلماء</a>
          <a href="aqeedah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">العقيدة الإسلامية</a>
          <a href="history.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">التاريخ المجيد</a>
          <a href="library.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">المكتبة الشاملة</a>
        </div>
      </div>
      <div class="col-lg-4 text-md-start text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">روابط سريعة</h5>
        <a href="contact.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> اتصل بالمطور</a>
        <a href="share.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> شارك الأجر</a>
        <a href="login.html" class="mega-footer-link text-warning mt-3" style="text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-user-circle me-2 ms-1"></i> تسجيل الدخول</a>
      </div>
    </div>
    <div class="text-center font-amiri fs-5 d-flex flex-column gap-2">
      <span class="opacity-75">الموسوعة الإسلامية الشاملة &copy; 2026 تم التصميم للإفادة | عمل مجاني لوجه الله</span>
      <span class="text-warning fw-bold fs-4 mt-2">تصميم وتطوير: لخذاري محمد سيف الدين</span>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
"""

with codecs.open(r"C:\Users\ST\Desktop\islamic.encyclopedia\index.html", 'w', 'utf-8') as f:
    f.write(html)
print("index.html rewritten successfully!")
