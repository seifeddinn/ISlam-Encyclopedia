import codecs

part3 = """
<!-- AKHLAQ TAB -->
<div class="tab-pane fade" id="t-akh">
  <div class="sec-head"><span class="tag">الأسوة الحسنة</span><h3>أخلاقه الكريمة <span>وشمائله</span></h3><p>﴿وَإِنَّكَ لَعَلَى خُلُقٍ عَظِيمٍ﴾ — قال الله تعالى في القرآن الكريم</p><div class="divider"></div></div>

  <div class="quote-strip mb-5">
    <p>«بُعِثْتُ لأُتَمِّمَ مَكَارِمَ الأَخْلَاقِ»</p>
    <small class="d-block mt-2" style="opacity:.5;">— رواه البيهقي وأحمد، حديث صحيح</small>
  </div>

  <div class="row g-4">
    <div class="col-lg-3 col-md-6"><div class="akhlaq-card"><div class="akhlaq-icon"><i class="fas fa-heart"></i></div><h5 style="color:#2e0e00;">الرحمة والشفقة</h5><p class="text-muted small">كان ﷺ أرحم الناس بالأطفال والمرضى والحيوانات. نهى عن حبس الطير وعن إيقاد النار على النمل. كان يحمل الحسن والحسين ويلاعبهما. وقال: "الراحمون يرحمهم الرحمن".</p></div></div>
    <div class="col-lg-3 col-md-6"><div class="akhlaq-card"><div class="akhlaq-icon"><i class="fas fa-coins"></i></div><h5 style="color:#2e0e00;">الكرم والجود</h5><p class="text-muted small">قال جابر: "ما سُئل ﷺ شيئاً فقال لا". كان يعطي عطاء من لا يخاف الفقر. أعطى رجلاً قطيعاً من الغنم ملأ وادياً فرجع الرجل لقومه يقول: أسلموا فإن محمداً يعطي عطاء لا يخشى الفاقة.</p></div></div>
    <div class="col-lg-3 col-md-6"><div class="akhlaq-card"><div class="akhlaq-icon"><i class="fas fa-smile-beam"></i></div><h5 style="color:#2e0e00;">البشاشة والابتسام</h5><p class="text-muted small">قال جرير البجلي: "ما رآني ﷺ منذ أسلمت إلا تبسّم في وجهي". وقال: "تبسمك في وجه أخيك صدقة". وكان يمزح ولا يقول إلا حقاً. وقال: "أثقل ما يوضع في الميزان الخلق الحسن".</p></div></div>
    <div class="col-lg-3 col-md-6"><div class="akhlaq-card"><div class="akhlaq-icon"><i class="fas fa-balance-scale"></i></div><h5 style="color:#2e0e00;">العدل والاستقامة</h5><p class="text-muted small">قال ﷺ: "والذي نفسي بيده لو أن فاطمة بنت محمد سرقت لقطعت يدها". لم يكن يتسامح في الحق لأحد كائناً من كان، وطبّق المساواة في الحقوق على الشريف والوضيع سواء.</p></div></div>
    <div class="col-lg-3 col-md-6"><div class="akhlaq-card"><div class="akhlaq-icon"><i class="fas fa-shield-alt"></i></div><h5 style="color:#2e0e00;">الشجاعة والثبات</h5><p class="text-muted small">قال علي: "كنا إذا احمر البأس اتقينا برسول الله ﷺ — ما كان منا أحد أقرب إلى العدو منه". يوم حنين حين انهزم الناس بقي وحده يصيح: "أنا النبي لا كذب".</p></div></div>
    <div class="col-lg-3 col-md-6"><div class="akhlaq-card"><div class="akhlaq-icon"><i class="fas fa-user-circle"></i></div><h5 style="color:#2e0e00;">التواضع العظيم</h5><p class="text-muted small">كان يجلس حيث انتهى المجلس دون تشريف. يُصلح نعله ويرقع ثوبه. كان يُجيب دعوة العبد والمسكين. يمشي في أسواق المدينة ويشتري بنفسه. وكان يقول: "لا تطروني كما أطرت النصارى المسيح".</p></div></div>
    <div class="col-lg-3 col-md-6"><div class="akhlaq-card"><div class="akhlaq-icon"><i class="fas fa-comments"></i></div><h5 style="color:#2e0e00;">الصدق والأمانة</h5><p class="text-muted small">لُقِّب قبل البعثة بـ"الصادق الأمين" من كافة قبائل قريش. لم يصدر عنه ﷺ كذب قط. حين خيّره الله بين البقاء والرحيل اختار الرحيل تواضعاً، وقال: "الصدق يهدي إلى البر والبر يهدي إلى الجنة".</p></div></div>
    <div class="col-lg-3 col-md-6"><div class="akhlaq-card"><div class="akhlaq-icon"><i class="fas fa-pray"></i></div><h5 style="color:#2e0e00;">الزهد والعبادة</h5><p class="text-muted small">كانت تُوقد النار في بيته أشهراً دون طبخ. فراشه مطوي من جلد مملوء ليفاً. وكان يقوم الليل حتى تورّم قدماه. قالت عائشة: "بيتنا ثلاث أيام لا يوقد فيه نار إلا الماء والتمر".</p></div></div>
    <div class="col-lg-3 col-md-6"><div class="akhlaq-card"><div class="akhlaq-icon"><i class="fas fa-hands-helping"></i></div><h5 style="color:#2e0e00;">خدمة أهل البيت</h5><p class="text-muted small">سُئلت عائشة بماذا يشتغل ﷺ في بيته؟ قالت: "كان يخيط ثوبه ويخصف نعله ويعمل ما يعمل الرجال في بيوتهم". لم يكن يكسر وصفعة الخادم ولم يُرَ رافعاً يده على أحد.</p></div></div>
    <div class="col-lg-3 col-md-6"><div class="akhlaq-card"><div class="akhlaq-icon"><i class="fas fa-globe"></i></div><h5 style="color:#2e0e00;">الرحمة بالكافرين</h5><p class="text-muted small">حين أُوذي في الطائف وطلب جبريل أن يُهلك أهلها قال: "اللهم اهدِ قومي فإنهم لا يعلمون". ولم يلعن قوماً قط. يوم فتح مكة عفا عمن قتل أصحابه وعذّب المسلمين.</p></div></div>
    <div class="col-lg-3 col-md-6"><div class="akhlaq-card"><div class="akhlaq-icon"><i class="fas fa-child"></i></div><h5 style="color:#2e0e00;">حبه للأطفال</h5><p class="text-muted small">كان يُطيل السجود إذا ركب الحسن أو الحسين على ظهره. وكان يُقبّل الأطفال حتى قال رجل: إن له عشرة أولاد ما قبّل منهم أحداً. فقال ﷺ: "من لا يرحم لا يُرحَم".</p></div></div>
    <div class="col-lg-3 col-md-6"><div class="akhlaq-card"><div class="akhlaq-icon"><i class="fas fa-leaf"></i></div><h5 style="color:#2e0e00;">البساطة والزهد</h5><p class="text-muted small">كان يجلس على الأرض ويأكل على الأرض ويقول: "إنما أنا عبد آكل كما يأكل العبد". توفي ودرعه مرهونة عند يهودي في المدينة في مقابل طعام لأهل بيته.</p></div></div>
  </div>
</div>

<!-- SIFAT TAB -->
<div class="tab-pane fade" id="t-sf">
  <div class="sec-head"><span class="tag">وصف الصحابة الكرام</span><h3>الصفات الجسدية <span>الشريفة</span></h3><p>نقل الصحابة الكرام صفاته ﷺ بدقة فائقة لأجيال لم تره، وأودعوا ذلك في كتب الشمائل</p><div class="divider"></div></div>
  <div class="quote-strip mb-5">
    <p>«كَانَ رَسُولُ اللَّهِ ﷺ أَحْسَنَ النَّاسِ وَجْهًا وَأَحْسَنَهُمْ خَلْقًا»</p>
    <small class="d-block mt-2" style="opacity:.5;">— البخاري ومسلم</small>
  </div>
  <div class="sifat-grid">
    <div class="sifat-item"><div class="sifat-icon"><i class="fas fa-user"></i></div><div><strong style="color:#2e0e00;">القامة والبنية</strong><p class="text-muted small mb-0">كان مربوعاً لا بالطويل ولا بالقصير. إذا مشى مع الطوال يتجاوزهم. عريض المنكبين ضخم الرأس.</p></div></div>
    <div class="sifat-item"><div class="sifat-icon"><i class="fas fa-sun"></i></div><div><strong style="color:#2e0e00;">لون البشرة</strong><p class="text-muted small mb-0">أبيض مُشرب بالحمرة يتلألأ كأنما أُفرغ فيه النور. قال أنس: كان ﷺ أبيض وكان عرقه كاللؤلؤ.</p></div></div>
    <div class="sifat-item"><div class="sifat-icon"><i class="fas fa-circle"></i></div><div><strong style="color:#2e0e00;">وجهه الشريف</strong><p class="text-muted small mb-0">مُستدير الوجه أحياناً يُوصف بالاستدارة. واسع الجبين، أزج الحاجبين متوسط الأنف، كث اللحية.</p></div></div>
    <div class="sifat-item"><div class="sifat-icon"><i class="fas fa-eye"></i></div><div><strong style="color:#2e0e00;">عيناه الشريفتان</strong><p class="text-muted small mb-0">أدعج العينين: شديد سواد الحدقة. أهدب الأشفار: كثيف الرموش. فيهما حمرة خفية تُشبه حمرة الزعفران.</p></div></div>
    <div class="sifat-item"><div class="sifat-icon"><i class="fas fa-wind"></i></div><div><strong style="color:#2e0e00;">الشعر الشريف</strong><p class="text-muted small mb-0">بين الجعودة والسبوطة — لا جعداً ولا سبطاً. يصل لشحمة الأذن وأحياناً لكتفيه. أسوده بعض الشيب.</p></div></div>
    <div class="sifat-item"><div class="sifat-icon"><i class="fas fa-star"></i></div><div><strong style="color:#2e0e00;">خاتم النبوة</strong><p class="text-muted small mb-0">بين كتفيه بضعة ناتئة كبيضة الحمامة أو بعر البعير، عليها شعر يلتوي حولها.</p></div></div>
    <div class="sifat-item"><div class="sifat-icon"><i class="fas fa-walking"></i></div><div><strong style="color:#2e0e00;">مشيته المباركة</strong><p class="text-muted small mb-0">يتكفّأ في مشيته ويمشي مسرعاً كأنما ينحطّ من صببٍ — أي منحدرٍ — ويرفع قدميه بقوة وثقة.</p></div></div>
    <div class="sifat-item"><div class="sifat-icon"><i class="fas fa-spray-can"></i></div><div><strong style="color:#2e0e00;">رائحته الطيبة</strong><p class="text-muted small mb-0">كان أطيب رائحةً من كل طيب. يعرف من كان معه بشمّ رائحة عرقه. التقط أنس منديله فاحتفظ به يتبرك.</p></div></div>
    <div class="sifat-item"><div class="sifat-icon"><i class="fas fa-hand-paper"></i></div><div><strong style="color:#2e0e00;">يداه المباركتان</strong><p class="text-muted small mb-0">راحتاه واسعتان، بارزتا عظم الرُّسْغ. كان يصافح ولا يبدأ بسحب يده حتى يسحبها من صافحه.</p></div></div>
    <div class="sifat-item"><div class="sifat-icon"><i class="fas fa-moon"></i></div><div><strong style="color:#2e0e00;">وجهه كالبدر</strong><p class="text-muted small mb-0">قال البراء: "لم أرَ شيئاً أجمل من رسول الله ﷺ في حلة حمراء". ومن رآه استيقن أنه لا يكذب.</p></div></div>
    <div class="sifat-item"><div class="sifat-icon"><i class="fas fa-tshirt"></i></div><div><strong style="color:#2e0e00;">لباسه الشريف</strong><p class="text-muted small mb-0">كان يلبس البياض وأحياناً الحمرة والخضرة. أحبّ الثياب إليه القميص. وكره التشبه بالمشركين.</p></div></div>
    <div class="sifat-item"><div class="sifat-icon"><i class="fas fa-volume-up"></i></div><div><strong style="color:#2e0e00;">صوته وكلامه</strong><p class="text-muted small mb-0">كان ﷺ يتكلم بجوامع الكلم — يختصر الكلام وفيه المعاني الكثيرة. وكان صوته إذا خطب يُسمع من بعيد.</p></div></div>
  </div>
</div>

<!-- FAMILY TAB -->
<div class="tab-pane fade" id="t-fam">
  <div class="sec-head"><span class="tag">ذوو وصحب النبي ﷺ</span><h3>الآل والصحابة <span>الكرام</span></h3><p>من آمنوا به وشاركوه رسالته ونقلوا نور الإسلام إلى الأجيال اللاحقة</p><div class="divider"></div></div>

  <h5 class="mb-4" style="color:#2e0e00;border-right:4px solid var(--gold);padding-right:15px;">أمهات المؤمنين رضي الله عنهن</h5>
  <div class="row g-3 mb-5">
    <div class="col-md-4"><div class="comp-card"><div class="comp-avatar"><i class="fas fa-star"></i></div><strong style="color:#2e0e00;">خديجة بنت خويلد</strong><p class="text-muted small mt-1 mb-0">أول المؤمنين به ﷺ. ساندته بمالها وعقلها. توفيت قبل الهجرة. بشّرها النبي ﷺ ببيت في الجنة من قصب لا صخب فيه ولا نصب.</p></div></div>
    <div class="col-md-4"><div class="comp-card"><div class="comp-avatar"><i class="fas fa-star"></i></div><strong style="color:#2e0e00;">عائشة بنت أبي بكر</strong><p class="text-muted small mt-1 mb-0">أحب نسائه إليه. رات الوحي ينزل في برودتها. روت أكثر من 2210 حديث. ماتت ﷺ في حجرها ودُفن تحت أرض غرفتها.</p></div></div>
    <div class="col-md-4"><div class="comp-card"><div class="comp-avatar"><i class="fas fa-star"></i></div><strong style="color:#2e0e00;">حفصة بنت عمر</strong><p class="text-muted small mt-1 mb-0">حافظة المصحف الأصلي في عهد أبي بكر. كانت تصوم وتقوم. وصفها ﷺ بأنها "صوامة قوامة".</p></div></div>
    <div class="col-md-4"><div class="comp-card"><div class="comp-avatar"><i class="fas fa-star"></i></div><strong style="color:#2e0e00;">أم سلمة هند</strong><p class="text-muted small mt-1 mb-0">من أعقل نساء العرب. هجرت إلى الحبشة ثم إلى المدينة. كانت تُستشار في المهمات وأشارت يوم الحديبية برأي أنقذ الموقف.</p></div></div>
    <div class="col-md-4"><div class="comp-card"><div class="comp-avatar"><i class="fas fa-star"></i></div><strong style="color:#2e0e00;">زينب بنت جحش</strong><p class="text-muted small mt-1 mb-0">زوّجها الله من نبيه بآية من القرآن دون ولي وكانت تفتخر بذلك. عُرفت بكثرة صدقتها وكان يُقال لها "أم المساكين".</p></div></div>
    <div class="col-md-4"><div class="comp-card"><div class="comp-avatar"><i class="fas fa-star"></i></div><strong style="color:#2e0e00;">صفية بنت حيي</strong><p class="text-muted small mt-1 mb-0">من ذرية هارون ﷺ. تزوجها النبي ﷺ بعد خيبر وأعتقها وجعل عتقها صداقها. كانت شجاعة وقوية الشخصية.</p></div></div>
  </div>

  <h5 class="mb-4" style="color:#2e0e00;border-right:4px solid var(--gold);padding-right:15px;">أبناؤه وبناته الكرام</h5>
  <div class="row g-3 mb-5">
    <div class="col-6 col-md-3"><div class="p-3 text-center bg-white rounded-4 shadow-sm"><i class="fas fa-child text-warning d-block mb-2 fs-3"></i><strong style="font-size:.9rem;color:#2e0e00;">القاسم</strong><p class="text-muted small mb-0">ابنه البكر — توفي طفلاً</p></div></div>
    <div class="col-6 col-md-3"><div class="p-3 text-center bg-white rounded-4 shadow-sm"><i class="fas fa-child text-warning d-block mb-2 fs-3"></i><strong style="font-size:.9rem;color:#2e0e00;">عبد الله الطيب</strong><p class="text-muted small mb-0">توفي طفلاً أيضاً</p></div></div>
    <div class="col-6 col-md-3"><div class="p-3 text-center bg-white rounded-4 shadow-sm"><i class="fas fa-child text-warning d-block mb-2 fs-3"></i><strong style="font-size:.9rem;color:#2e0e00;">إبراهيم</strong><p class="text-muted small mb-0">من مارية القبطية — توفي رضيعاً</p></div></div>
    <div class="col-6 col-md-3"><div class="p-3 text-center bg-white rounded-4 shadow-sm"><i class="fas fa-female text-warning d-block mb-2 fs-3"></i><strong style="font-size:.9rem;color:#2e0e00;">زينب</strong><p class="text-muted small mb-0">الكبرى — توفيت في المدينة</p></div></div>
    <div class="col-6 col-md-3"><div class="p-3 text-center bg-white rounded-4 shadow-sm"><i class="fas fa-female text-warning d-block mb-2 fs-3"></i><strong style="font-size:.9rem;color:#2e0e00;">رقية</strong><p class="text-muted small mb-0">زوجة عثمان — استُشهدت</p></div></div>
    <div class="col-6 col-md-3"><div class="p-3 text-center bg-white rounded-4 shadow-sm"><i class="fas fa-female text-warning d-block mb-2 fs-3"></i><strong style="font-size:.9rem;color:#2e0e00;">أم كلثوم</strong><p class="text-muted small mb-0">زوجة عثمان بعد رقية</p></div></div>
    <div class="col-6 col-md-3"><div class="p-3 text-center bg-white rounded-4 shadow-sm"><i class="fas fa-female text-warning d-block mb-2 fs-3"></i><strong style="font-size:.9rem;color:#2e0e00;">فاطمة الزهراء</strong><p class="text-muted small mb-0">سيدة نساء الجنة — أمّ الحسنين</p></div></div>
  </div>

  <h5 class="mb-4" style="color:#2e0e00;border-right:4px solid var(--gold);padding-right:15px;">العشرة المبشرون بالجنة</h5>
  <div class="row g-3">
    <div class="col-6 col-md-4 col-lg-3"><div class="p-3 bg-white rounded-4 shadow-sm h-100"><div class="d-flex align-items-center gap-2 mb-2"><i class="fas fa-medal text-warning"></i><strong style="color:#2e0e00;font-size:.88rem;">أبو بكر الصديق</strong></div><p class="text-muted small mb-0">تصدّق بكل ماله يوم تبوك. قال النبي له: "ما نفعني مال قط كمال أبي بكر".</p></div></div>
    <div class="col-6 col-md-4 col-lg-3"><div class="p-3 bg-white rounded-4 shadow-sm h-100"><div class="d-flex align-items-center gap-2 mb-2"><i class="fas fa-medal text-warning"></i><strong style="color:#2e0e00;font-size:.88rem;">عمر بن الخطاب</strong></div><p class="text-muted small mb-0">قال فيه ﷺ: "لو كان بعدي نبي لكان عمر". وافق رأيه إنزال آيات قرآنية.</p></div></div>
    <div class="col-6 col-md-4 col-lg-3"><div class="p-3 bg-white rounded-4 shadow-sm h-100"><div class="d-flex align-items-center gap-2 mb-2"><i class="fas fa-medal text-warning"></i><strong style="color:#2e0e00;font-size:.88rem;">عثمان بن عفان</strong></div><p class="text-muted small mb-0">جهّز جيش العسرة وحفر بئر رومة. قال النبي ﷺ: "ما ضرّ عثمان ما عمل بعد اليوم".</p></div></div>
    <div class="col-6 col-md-4 col-lg-3"><div class="p-3 bg-white rounded-4 shadow-sm h-100"><div class="d-flex align-items-center gap-2 mb-2"><i class="fas fa-medal text-warning"></i><strong style="color:#2e0e00;font-size:.88rem;">علي بن أبي طالب</strong></div><p class="text-muted small mb-0">بات في فراش النبي ليلة الهجرة. قال النبي للحسن والحسين: "أُحبّكما وأُحبّ من يحبّكما".</p></div></div>
    <div class="col-6 col-md-4 col-lg-3"><div class="p-3 bg-white rounded-4 shadow-sm h-100"><div class="d-flex align-items-center gap-2 mb-2"><i class="fas fa-medal text-warning"></i><strong style="color:#2e0e00;font-size:.88rem;">طلحة بن عبيد الله</strong></div><p class="text-muted small mb-0">حمى النبي ﷺ يوم أحد بجسده حتى شُلّت يده. قيل: من أراد أن يرى شهيداً يمشي فلينظر إلى طلحة.</p></div></div>
    <div class="col-6 col-md-4 col-lg-3"><div class="p-3 bg-white rounded-4 shadow-sm h-100"><div class="d-flex align-items-center gap-2 mb-2"><i class="fas fa-medal text-warning"></i><strong style="color:#2e0e00;font-size:.88rem;">الزبير بن العوام</strong></div><p class="text-muted small mb-0">حواري رسول الله وابن عمته. قال فيه ﷺ: "إن لكل نبي حوارياً وحواريّ الزبير".</p></div></div>
    <div class="col-6 col-md-4 col-lg-3"><div class="p-3 bg-white rounded-4 shadow-sm h-100"><div class="d-flex align-items-center gap-2 mb-2"><i class="fas fa-medal text-warning"></i><strong style="color:#2e0e00;font-size:.88rem;">سعد بن أبي وقاص</strong></div><p class="text-muted small mb-0">قال له النبي ﷺ: "ارمِ فداك أبي وأمي" — وهو أول من رمى بسهم في الإسلام. قائد فتح القادسية.</p></div></div>
    <div class="col-6 col-md-4 col-lg-3"><div class="p-3 bg-white rounded-4 shadow-sm h-100"><div class="d-flex align-items-center gap-2 mb-2"><i class="fas fa-medal text-warning"></i><strong style="color:#2e0e00;font-size:.88rem;">عبد الرحمن بن عوف</strong></div><p class="text-muted small mb-0">جاء المدينة مهاجراً لا يملك شيئاً فبنى ثروة هائلة وكان ينفق منها في سبيل الله بغير حدود.</p></div></div>
    <div class="col-6 col-md-4 col-lg-3"><div class="p-3 bg-white rounded-4 shadow-sm h-100"><div class="d-flex align-items-center gap-2 mb-2"><i class="fas fa-medal text-warning"></i><strong style="color:#2e0e00;font-size:.88rem;">سعيد بن زيد</strong></div><p class="text-muted small mb-0">أحد السابقين إلى الإسلام. أسلم هو وزوجته قبل دخول عمر في الإسلام. شهد كثيراً من الغزوات.</p></div></div>
    <div class="col-6 col-md-4 col-lg-3"><div class="p-3 bg-white rounded-4 shadow-sm h-100"><div class="d-flex align-items-center gap-2 mb-2"><i class="fas fa-medal text-warning"></i><strong style="color:#2e0e00;font-size:.88rem;">أبو عبيدة الجراح</strong></div><p class="text-muted small mb-0">أمين هذه الأمة. كان مقدّم المسلمين في الشام وفاتح إيليا. مات شهيداً بالطاعون في الأردن.</p></div></div>
  </div>
</div>

</div><!-- /tab-content -->
</div><!-- /container -->

<footer class="mega-footer" style="background:linear-gradient(135deg,var(--dark),#020617);color:white;padding:80px 0 30px;margin-top:80px;border-top:3px solid var(--gold-dark);">
  <div class="container">
    <div class="row g-5 mb-5 border-bottom border-light border-opacity-10 pb-5">
      <div class="col-lg-4 text-md-end text-center">
        <i class="fas fa-mosque fa-4x text-warning mb-4 d-block"></i>
        <h4 class="fw-bold font-amiri fs-2 mb-3">الموسوعة الإسلامية الشاملة</h4>
        <p class="opacity-75 fs-6 line-height-2">أضخم صرح رقمي يجمع علوم القرآن العظيم، وأحاديث المصطفى، وفقهاء المذاهب، والتاريخ المجيد في منصة موثقة مصممة بأحدث التقنيات.</p>
      </div>
      <div class="col-lg-4 text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">تصفح الموسوعة</h5>
        <div class="d-flex flex-wrap justify-content-center gap-2">
          <a href="recitations.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">أكاديمية القرآن</a>
          <a href="hadith.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الحديث النبوي</a>
          <a href="seerah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">السيرة والصحابة</a>
          <a href="fiqh.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الفقه وأصوله</a>
          <a href="fatwa.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">فتاوى العلماء</a>
          <a href="aqeedah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">العقيدة الإسلامية</a>
          <a href="history.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">التاريخ المجيد</a>
          <a href="library.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">المكتبة الشاملة</a>
        </div>
      </div>
      <div class="col-lg-4 text-md-start text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">روابط سريعة</h5>
        <a href="contact.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> اتصل بالمطور</a>
        <a href="share.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> شارك الأجر</a>
        <a href="login.html" class="mega-footer-link text-warning mt-3" style="text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-user-circle me-2 ms-1"></i> تسجيل الدخول</a>
      </div>
    </div>
    <div class="text-center font-amiri fs-5 d-flex flex-column gap-2">
      <span class="opacity-75">الموسوعة الإسلامية الشاملة &copy; 2026 تم التصميم للإفادة | عمل مجاني لوجه الله</span>
      <span class="text-warning fw-bold fs-4 mt-2">تصميم وتطوير: لخذاري محمد سيف الدين</span>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
@keyframes spin{from{transform:rotate(0)}to{transform:rotate(360deg)}}
// Timeline scroll animation
const obs = new IntersectionObserver(entries=>{
  entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible');}});
},{threshold:0.12});
document.querySelectorAll('.tl-card').forEach(el=>obs.observe(el));
</script>
</body></html>
"""

with codecs.open(r"c:\Users\ST\Desktop\islamic.encyclopedia\s_part3.tmp",'w','utf-8') as f:
    f.write(part3)

# MERGE
parts=[]
for fn in ['s_part1.tmp','s_part2.tmp','s_part3.tmp']:
    with codecs.open(r"c:\Users\ST\Desktop\islamic.encyclopedia\\"+fn,'r','utf-8') as f:
        parts.append(f.read())

with codecs.open(r"c:\Users\ST\Desktop\islamic.encyclopedia\seerah.html",'w','utf-8') as f:
    f.write(''.join(parts))

import os
for fn in ['s_part1.tmp','s_part2.tmp','s_part3.tmp']:
    try: os.remove(r"c:\Users\ST\Desktop\islamic.encyclopedia\\"+fn)
    except: pass

print("seerah.html rebuilt — RICH VERSION OK!")
