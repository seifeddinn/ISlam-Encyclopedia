import codecs
import os

part3 = """
<!-- TAB 4: TAJWEED -->
<div class="tab-pane fade" id="t-tajweed">
  <div class="sec-head">
    <span class="tag">ورتل القرآن ترتيلاً</span>
    <h3>علوم <span>التجويد</span></h3>
    <p>إعطاء الحروف حقها ومستحقها كما أنزلت على النبي ﷺ</p>
    <div class="divider"></div>
  </div>

  <div class="row g-4 justify-content-center">
    <!-- Noun Sakinah -->
    <div class="col-lg-5">
      <div class="card border-0 shadow-sm h-100 rounded-4" style="border-right:4px solid #064b63!important;">
        <div class="card-body p-4">
          <div class="d-flex align-items-center mb-3">
            <div style="width:50px;height:50px;border-radius:12px;background:rgba(6,75,99,.1);color:#064b63;display:flex;align-items:center;justify-content:center;font-size:1.5rem;font-family:'Amiri',serif;margin-left:15px;font-weight:bold;">نْ</div>
            <h5 class="mb-0 fw-bold" style="color:#064b63;">أحكام النون الساكنة والتنوين</h5>
          </div>
          <ul class="list-unstyled mb-0 small text-muted">
            <li class="mb-2"><strong class="text-dark">الإظهار:</strong> عند حروف الحلق (ء، هـ، ع، ح، غ، خ). ينطق الحرف بوضوح بدون غنة زائدة.</li>
            <li class="mb-2"><strong class="text-dark">الإدغام:</strong> عند (يرملون). وهو قسمان: بغنة (ينمو) وبغير غنة (ر، ل).</li>
            <li class="mb-2"><strong class="text-dark">الإقلاب:</strong> قلب النون ميماً مخفاة بغنة عند حرف (الباء).</li>
            <li><strong class="text-dark">الإخفاء:</strong> إخفاء النون بغنة عند باقي الحروف الـ 15 المتبقية.</li>
          </ul>
        </div>
      </div>
    </div>
    
    <!-- Meem Sakinah -->
    <div class="col-lg-5">
      <div class="card border-0 shadow-sm h-100 rounded-4" style="border-right:4px solid #c9a66b!important;">
        <div class="card-body p-4">
          <div class="d-flex align-items-center mb-3">
            <div style="width:50px;height:50px;border-radius:12px;background:rgba(201,166,107,.1);color:#c9a66b;display:flex;align-items:center;justify-content:center;font-size:1.5rem;font-family:'Amiri',serif;margin-left:15px;font-weight:bold;">مْ</div>
            <h5 class="mb-0 fw-bold" style="color:#064b63;">أحكام الميم الساكنة</h5>
          </div>
          <ul class="list-unstyled mb-0 small text-muted">
            <li class="mb-2"><strong class="text-dark">الإخفاء الشفوي:</strong> إذا جاء بعدها حرف (الباء) مثل "ترميهم بحجارة".</li>
            <li class="mb-2"><strong class="text-dark">الإدغام الشفوي:</strong> إذا جاء بعدها (ميم) أخرى، تدغم لتصبح ميماً واحدة مشددة بغنة.</li>
            <li><strong class="text-dark">الإظهار الشفوي:</strong> عند بقية أحرف الهجاء (26 حرفاً). وأشد الإظهار عند الواو والفاء.</li>
          </ul>
        </div>
      </div>
    </div>

    <!-- Al Madood -->
    <div class="col-lg-5">
      <div class="card border-0 shadow-sm h-100 rounded-4" style="border-right:4px solid #e74c3c!important;">
        <div class="card-body p-4">
          <div class="d-flex align-items-center mb-3">
            <div style="width:50px;height:50px;border-radius:12px;background:rgba(231,76,60,.1);color:#e74c3c;display:flex;align-items:center;justify-content:center;font-size:1.5rem;font-family:'Amiri',serif;margin-left:15px;font-weight:bold;">ـا</div>
            <h5 class="mb-0 fw-bold" style="color:#064b63;">أحكام المدود</h5>
          </div>
          <p class="small text-muted mb-2">المد هو إطالة الصوت بحرف من حروف المد (ا، و، ي). ينقسم إلى:</p>
          <ul class="list-unstyled mb-0 small text-muted">
            <li class="mb-1"><strong class="text-dark">المد الطبيعي:</strong> يمد حركتين، مثل (قال، يقول، قيل).</li>
            <li class="mb-1"><strong class="text-dark">المد المتصل:</strong> حرف المد يليه همزة في نفس الكلمة (سماء). يمد 4-5 حركات وجوباً.</li>
            <li class="mb-1"><strong class="text-dark">المد المنفصل:</strong> حرف المد في كلمة والهمزة في أخرى (بما أنزل). يمد 4-5 جوازاً.</li>
            <li><strong class="text-dark">المد اللازم:</strong> حرف المد يليه سكون أصلي (الضآلّين). يمد 6 حركات لزوماً.</li>
          </ul>
        </div>
      </div>
    </div>

    <!-- Al Qalqalah -->
    <div class="col-lg-5">
      <div class="card border-0 shadow-sm h-100 rounded-4" style="border-right:4px solid #3498db!important;">
        <div class="card-body p-4">
          <div class="d-flex align-items-center mb-3">
            <div style="width:50px;height:50px;border-radius:12px;background:rgba(52,152,219,.1);color:#3498db;display:flex;align-items:center;justify-content:center;font-size:1.5rem;font-family:'Amiri',serif;margin-left:15px;font-weight:bold;">قْ</div>
            <h5 class="mb-0 fw-bold" style="color:#064b63;">القلقلة وصفات الحروف</h5>
          </div>
          <p class="small text-muted mb-2">القلقلة: هي اضطراب مخرج الحرف عند النطق به ساكناً حتى يُسمع له نبرة قوية.</p>
          <ul class="list-unstyled mb-0 small text-muted">
            <li class="mb-2"><strong class="text-dark">حروفها:</strong> مجتمعة في كلمة (قطب جد).</li>
            <li class="mb-2"><strong class="text-dark">قلقلة صغرى:</strong> إذا كان حرف القلقلة ساكناً في وسط الكلمة (يَقْطَعون).</li>
            <li><strong class="text-dark">قلقلة كبرى:</strong> إذا كان الحرف في آخر الكلمة ووقفنا عليه بالسكون (الْفَلَقْ).</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>

</div><!-- /tab-content -->
</div><!-- /container -->

<!-- Global Audio Player -->
<div class="global-player" id="globalAudioPlayer">
  <div class="container position-relative">
    <button id="closePlayerBtn" class="position-absolute" style="top:-15px;right:0;background:none;border:none;color:white;font-size:24px;z-index:100;opacity:0.6;"><i class="fas fa-times-circle"></i></button>
    <div class="row align-items-center">
      <div class="col-md-3 text-center text-md-end mb-3 mb-md-0 d-flex justify-content-center justify-content-md-end align-items-center">
        <div id="playerSpinIcon" class="me-3" style="width:40px;height:40px;border-radius:50%;background:rgba(6,75,99,.3);display:flex;align-items:center;justify-content:center;color:var(--gold);"><i class="fas fa-compact-disc fa-spin"></i></div>
        <div>
          <h5 id="playerSurahName" class="mb-0 text-white ar" style="font-size:1.1rem;">سورة..</h5>
          <small class="text-white-50"><i class="fas fa-microphone-alt ms-1"></i>مشاري العفاسي</small>
        </div>
      </div>
      <div class="col-md-9">
        <audio id="mainAudio" controls class="w-100" style="height:40px;filter:invert(1) hue-rotate(180deg);border-radius:20px;"></audio>
      </div>
    </div>
  </div>
</div>

<!-- Quran Reader Modal -->
<div class="modal fade" id="quranReaderModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-fullscreen">
    <div class="modal-content" style="background:#fdfdfd;">
      <div class="modal-header border-0" style="background:linear-gradient(135deg,#021a24,#064b63);">
        <h5 class="modal-title w-100 text-center text-white ar" style="font-size:1.5rem;" id="readerSurahName">سورة..</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body p-0 position-relative">
        <div class="container h-100">
          <div class="row h-100 justify-content-center pt-4 pb-5">
            <div class="col-lg-8 text-center" style="max-height:80vh;overflow-y:auto;padding:20px 15px;">
              <h3 class="ar mb-4 text-success" id="bismillahHeader" style="font-size:1.8rem;display:none;">بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ</h3>
              <div id="readerVerses" class="quran-reader text-dark"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<footer class="mega-footer" style="background:linear-gradient(135deg,var(--dark),#020617);color:white;padding:80px 0 30px;margin-top:80px;border-top:3px solid var(--gold-dark);">
  <div class="container">
    <div class="row g-5 mb-5 border-bottom border-light border-opacity-10 pb-5">
      <div class="col-lg-4 text-md-end text-center">
        <i class="fas fa-mosque fa-4x text-warning mb-4 d-block"></i>
        <h4 class="fw-bold font-amiri fs-2 mb-3">الموسوعة الإسلامية الشاملة</h4>
        <p class="opacity-75 fs-6 line-height-2">أضخم صرح رقمي يجمع علوم القرآن العظيم، وأحاديث المصطفى، وفقهاء المذاهب، والتاريخ المجيد في منصة موثقة مصممة بأحدث التقنيات.</p>
      </div>
      <div class="col-lg-4 text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">تصفح الموسوعة</h5>
        <div class="d-flex flex-wrap justify-content-center gap-2">
          <a href="recitations.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">أكاديمية القرآن</a>
          <a href="hadith.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الحديث النبوي</a>
          <a href="seerah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">السيرة والصحابة</a>
          <a href="fiqh.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الفقه وأصوله</a>
          <a href="fatwa.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">فتاوى العلماء</a>
          <a href="aqeedah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">العقيدة الإسلامية</a>
          <a href="history.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">التاريخ المجيد</a>
          <a href="library.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">المكتبة الشاملة</a>
        </div>
      </div>
      <div class="col-lg-4 text-md-start text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">روابط سريعة</h5>
        <a href="contact.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> اتصل بالمطور</a>
        <a href="share.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> شارك الأجر</a>
        <a href="login.html" class="mega-footer-link text-warning mt-3" style="text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-user-circle me-2 ms-1"></i> تسجيل الدخول</a>
      </div>
    </div>
    <div class="text-center font-amiri fs-5 d-flex flex-column gap-2">
      <span class="opacity-75">الموسوعة الإسلامية الشاملة &copy; 2026 تم التصميم للإفادة | عمل مجاني لوجه الله</span>
      <span class="text-warning fw-bold fs-4 mt-2">تصميم وتطوير: لخذاري محمد سيف الدين</span>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- Import Surahs Data before script -->
<script src="surahs.js"></script>
<script src="quran-script.js"></script>
<script>
@keyframes spin{from{transform:rotate(0)}to{transform:rotate(360deg)}}
</script>
</body></html>
"""

with codecs.open(r"C:\Users\ST\Desktop\islamic.encyclopedia\rec_p3.tmp", 'w', 'utf-8') as f:
    f.write(part3)

# MERGE
parts=[]
for fn in ['rec_p1.tmp','rec_p2.tmp','rec_p3.tmp']:
    with codecs.open(r"C:\Users\ST\Desktop\islamic.encyclopedia\\"+fn,'r','utf-8') as f:
        parts.append(f.read())

with codecs.open(r"C:\Users\ST\Desktop\islamic.encyclopedia\recitations.html",'w','utf-8') as f:
    f.write(''.join(parts))

for fn in ['rec_p1.tmp','rec_p2.tmp','rec_p3.tmp']:
    try: os.remove(r"C:\Users\ST\Desktop\islamic.encyclopedia\\"+fn)
    except: pass

print("recitations.html rebuilt — MERGED QURAN WITH RICH DESIGN OK!")
