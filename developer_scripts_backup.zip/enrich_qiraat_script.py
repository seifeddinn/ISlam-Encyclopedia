import codecs
import re

html_file = r"c:\Users\ST\Desktop\islamic.encyclopedia\recitations.html"

with codecs.open(html_file, 'r', 'utf-8') as f:
    html = f.read()

qiraat_data = {
    "الإمام نافع المدني": {
        "id": "1",
        "usul": "<li><strong>قالون:</strong> إثبات البسملة بين السورتين، صلة ميم الجمع بخلف، قصر المنفصل وتوسطه.</li><li><strong>ورش:</strong> ترك البسملة (أوجه)، إشباع المدود (6 حركات)، النقل، تغليظ اللامات وترقيق الراءات.</li>",
        "readers": "محمود خليل الحصري (قالون وورش)، عبد الباسط عبد الصمد (ورش)، الدوكالي محمد العالم (قالون)، عمر القزابري (ورش)."
    },
    "الإمام ابن كثير المكي": {
        "id": "2",
        "usul": "<li>البسملة بين السورتين وجوباً.</li><li>صلة ميم الجمع بواو لفظية (عليهمُو، همُو).</li><li>صلة هاء الكناية دائماً (فيهِي هدى).</li><li>قصر المنفصل وتوسط المتصل.</li>",
        "readers": "عبد الله الجهني (في مسجده)، أبو العينين شعيشع (في بعض محافله)، أحمد خضر الطرابلسي، حسن مشاري العفاسي."
    },
    "الإمام أبو عمرو البصري": {
        "id": "3",
        "usul": "<li><strong>الدوري:</strong> الاختلاس في بعض الحركات، والإمالة في الألفات.</li><li><strong>السوسي:</strong> الإدغام الكبير للحرفين المتماثلين والمتقاربين من كلمتين (الرحيمْ مَلك)، وإبدال الهمز الساكن.</li>",
        "readers": "محمود خليل الحصري، محمد صديق المنشاوي (الدوري)، عبد الرشيد صوفي (السوسي والدوري)."
    },
    "الإمام ابن عامر الشامي": {
        "id": "4",
        "usul": "<li>الإبدال والتسهيل في الهمز عند الوقف (لهشام).</li><li>له في البسملة الخلاف.</li><li>تتميز قراءته ببعض الاستعارات اللغوية الشامية القديمة كالهمزة في بعض الكلمات (يأجوج ومأجوج).</li>",
        "readers": "أيمن سويد (تعليمياً)، عبد الرشيد صوفي، مشاري العفاسي (في بعض إصداراته)."
    },
    "الإمام عاصم الكوفي": {
        "id": "5",
        "usul": "<li><strong>حفص:</strong> قراءة الترتيل وتحقيق الهمزات، المد المتصل والمنفصل 4-5 حركات، لا إمالة فيها إلا في كلمة (مَجْرَاهَا).</li><li><strong>شعبة:</strong> إمالة بعض الألفات، وترك الغنة في الياء والواو أحياناً.</li>",
        "readers": "الغالبية العظمى من قراء العالم الإسلامي (العفاسي، السديس، الشريم، المنشاوي، عبد الباسط، المعيقلي)."
    },
    "الإمام حمزة الكوفي": {
        "id": "6",
        "usul": "<li>إشباع المد المتصل والمنفصل (6 حركات).</li><li>السكت على (أل) وعلى الساكن المفصول (منْ ءامن).</li><li>تغيير الهمز المتطرف والمتوسط عند الوقف عليه.</li><li>الكثرة في الإمالة الكبرى المحضة للألفات.</li>",
        "readers": "عبد الباسط عبد الصمد (في حفلاته المباشرة مثل سورة التكوير)، محمد أيوب، محمود خليل الحصري."
    },
    "الإمام الكسائي الكوفي": {
        "id": "7",
        "usul": "<li>كثرة الإمالة في الألفات وهاء التأنيث عند الوقف (الرحمـةْ تُمَال إلى الرحمـي).</li><li>إدغام الحروف المتقاربة.</li><li>توسط المدود المتصلة والمنفصلة.</li>",
        "readers": "عبد الرشيد صوفي، محمد أيوب (في بعض تلاواته الخاصة)، عبد الولي الأركاني."
    },
    "الإمام أبو جعفر المدني": {
        "id": "8",
        "usul": "<li>قراءة تتميز بالسهولة واليُسر.</li><li>السكت الخفيف جداً على الحروف المقطعة في أوائل السور.</li><li>إبدال الهمز الساكن والمتحرك في كثير من الكلمات وتخفيف النطق.</li>",
        "readers": "محمود خليل الحصري (أول من سجلها)، عبد الرشيد صوفي، حسن صالح."
    },
    "الإمام يعقوب الحضرمي": {
        "id": "9",
        "usul": "<li>الوقف بهاء السكت على بعض الكلمات (هُوَه، هِيَه، المفلحونه).</li><li>الجمع بين الساكنين في بعض المواضع.</li><li>ضم هاء الضمير في جمع المذكر إذا سبقت بياء ساكنة (عليهُم).</li>",
        "readers": "مشاري العفاسي (سجل بها عدة ختمات)، محمد أيوب، عبد الرشيد صوفي."
    },
    "الإمام خلف العاشر": {
        "id": "10",
        "usul": "<li>قراءة تجمع بين اختياراته من قراءة حمزة والكسائي.</li><li>يميل للأحكام القوية كالسكت وعدم الغنة مع اللام والراء.</li><li>السكت على المفصول وعدم الغنة مع الياء والواو بخلف.</li>",
        "readers": "عبد الرشيد صوفي، ياسر سلامة، مشاري العفاسي (في ألبومات متفرقة)."
    }
}

def create_accordion(im_id, im_usul, im_readers):
    return f"""
                                <div class="accordion qiraat-accordion mt-3" id="acc-{im_id}">
                                    <div class="accordion-item border-0">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button collapsed rounded py-2 px-3" type="button" data-bs-toggle="collapse" data-bs-target="#col-{im_id}-1" style="font-size: 0.95rem;">
                                                <i class="fas fa-book-open me-2 text-warning"></i> أبرز أصول قراءته
                                            </button>
                                        </h2>
                                        <div id="col-{im_id}-1" class="accordion-collapse collapse" data-bs-parent="#acc-{im_id}">
                                            <div class="accordion-body bg-light rounded mt-2 border-start border-3 border-warning small">
                                                <ul class="mb-0 text-secondary ps-3" style="list-style-type: arabic-indic;">
                                                    {im_usul}
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="accordion-item border-0 mt-2">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button collapsed rounded py-2 px-3" type="button" data-bs-toggle="collapse" data-bs-target="#col-{im_id}-2" style="background: rgba(26, 95, 122, 0.05); color: var(--primary-color); font-size: 0.95rem;">
                                                <i class="fas fa-microphone-alt me-2 text-primary"></i> أشهر من يتلو بها
                                            </button>
                                        </h2>
                                        <div id="col-{im_id}-2" class="accordion-collapse collapse" data-bs-parent="#acc-{im_id}">
                                            <div class="accordion-body bg-light rounded mt-2 border-start border-3 border-primary small text-muted">
                                                {im_readers}
                                            </div>
                                        </div>
                                    </div>
                                </div>"""

for name, data in qiraat_data.items():
    pattern = r'(<h4 class="reader-name">' + re.escape(name) + r'</h4>.*?<div class="mb-3">.*?</div>)'
    match = re.search(pattern, html, flags=re.DOTALL)
    if match:
        original = match.group(1)
        insertion = create_accordion(data['id'], data['usul'], data['readers'])
        html = html.replace(original, original + insertion)

with codecs.open(html_file, 'w', 'utf-8') as f:
    f.write(html)

print("Qiraat enriched successfully!")
