import codecs
f = codecs.open("seerah.html","a","utf-8")
f.write("""
<!-- TAB 4: BATTLES -->
<div class="tab-pane fade" id="t4">
  <div class="sec-head" data-aos="fade-up">
    <div class="badge-tag">أيام الله الخالدة</div>
    <h2 class="amiri">المعارك <span>الفاصلة</span></h2>
    <p>التصوير التكتيكي لأهم الغزوات النبوية الكريمة مع تفاصيل ودروس كل معركة</p>
    <div class="gold-divider"></div>
  </div>
  <ul class="nav justify-content-center gap-3 mb-5 flex-wrap" id="bNav" data-aos="fade-up">
    <li class="nav-item"><button class="btn btn-outline-danger active rounded-pill px-4 fw-bold" data-bs-toggle="tab" data-bs-target="#badr">بدر الكبرى</button></li>
    <li class="nav-item"><button class="btn btn-outline-danger rounded-pill px-4 fw-bold" data-bs-toggle="tab" data-bs-target="#uhud">أُحُد</button></li>
    <li class="nav-item"><button class="btn btn-outline-danger rounded-pill px-4 fw-bold" data-bs-toggle="tab" data-bs-target="#khnq">الخندق</button></li>
    <li class="nav-item"><button class="btn btn-outline-danger rounded-pill px-4 fw-bold" data-bs-toggle="tab" data-bs-target="#makkah">فتح مكة</button></li>
    <li class="nav-item"><button class="btn btn-outline-danger rounded-pill px-4 fw-bold" data-bs-toggle="tab" data-bs-target="#hunain">حنين</button></li>
  </ul>
  <div class="tab-content">

    <div class="tab-pane fade show active" id="badr">
      <div class="row g-5 align-items-stretch">
        <div class="col-lg-6">
          <div class="battle-map">
            <div class="b-badge">بدر الكبرى — 2 هـ</div>
            <div class="b-label" style="top:15px;left:15px;"><i class="fas fa-mountain me-1"></i>العدوة القصوى (قريش)</div>
            <div class="b-label" style="bottom:15px;right:15px;"><i class="fas fa-mountain me-1"></i>العدوة الدنيا (المسلمون)</div>
            <div class="b-label" style="top:46%;left:38%;color:#0284c7;font-size:1rem;"><i class="fas fa-tint fa-2x d-block mb-1"></i>آبار بدر</div>
            <div class="b-team bt-m" style="bottom:30%;right:10%;">المسلمون (313)<br><small>بقيادة: النبي ﷺ</small></div>
            <div class="b-team bt-e" style="top:22%;left:10%;">قريش (1000)<br><small>بقيادة: أبو جهل</small></div>
            <div class="pulse-dot" style="top:40%;left:42%;"></div>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="battle-info-card">
            <h3 class="amiri fw-bold text-dark mb-3">يوم الفرقان — النصر الأول</h3>
            <p class="fs-5 text-muted lh-xl">أولى المعارك الفاصلة وأعظمها أثراً. قصد المسلمون قافلة أبي سفيان فخرج لنصرتها جيش قريش بألف مقاتل. بفضل الثبات والملائكة المنزّلة انتصر الحق انتصاراً مدوياً. قُتل أبو جهل وسبعون من أشراف قريش.</p>
            <div class="d-flex gap-3 flex-wrap mt-4">
              <span class="badge bg-success fs-6 rounded-pill px-3 py-2">الشهداء: 14</span>
              <span class="badge bg-danger fs-6 rounded-pill px-3 py-2">قتلى العدو: 70 + 70 أسير</span>
            </div>
            <div class="alert alert-warning mt-4 rounded-4"><strong>الدرس:</strong> نصر الله لا يشترط الكثرة، والتوكل مع الأخذ بالأسباب سبيل النصر.</div>
          </div>
        </div>
      </div>
    </div>

    <div class="tab-pane fade" id="uhud">
      <div class="row g-5 align-items-stretch">
        <div class="col-lg-6">
          <div class="battle-map">
            <div class="b-badge">أُحُد — 3 هـ</div>
            <div class="b-label" style="top:15px;left:15px;font-size:1rem;"><i class="fas fa-mountain fa-2x d-block mb-1"></i>جبل أُحُد</div>
            <div class="b-label" style="top:42%;left:38%;background:#fbbf24;padding:4px 12px;border-radius:8px;color:#1a0000;">جبل الرماة (عينين)</div>
            <div class="b-team bt-m" style="top:25%;left:20%;">المسلمون (700)</div>
            <div class="b-team bt-e" style="bottom:22%;right:15%;">قريش (3000)<br><small>خالد بالميسرة</small></div>
            <div class="pulse-dot" style="top:52%;left:50%;"></div>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="battle-info-card">
            <h3 class="amiri fw-bold text-dark mb-3">الابتلاء الإلهي والتمحيص</h3>
            <p class="fs-5 text-muted lh-xl">أرادت قريش الثأر لبدر. وضع النبي الجبل خلفه وأقام 50 رامياً. لمّا لاحت بوادر النصر نزل بعضهم للغنيمة مخالفين أمره صلى الله عليه وسلم، فالتفّ خالد بن الوليد من الخلف وانقلبت الموازين.</p>
            <div class="d-flex gap-3 flex-wrap mt-4">
              <span class="badge bg-success fs-6 rounded-pill px-3 py-2">الشهداء: 70 (منهم عمّه حمزة)</span>
            </div>
            <div class="alert alert-danger mt-4 rounded-4"><strong>الدرس العظيم:</strong> خطورة عصيان أمر القائد ولو ظنّ المرء أن النصر قد تحقق. الطاعة شرط النجاح.</div>
          </div>
        </div>
      </div>
    </div>

    <div class="tab-pane fade" id="khnq">
      <div class="row g-5 align-items-stretch">
        <div class="col-lg-6">
          <div class="battle-map">
            <div class="b-badge">الأحزاب/الخندق — 5 هـ</div>
            <div class="b-label" style="top:12px;left:20%;background:#fcd34d;padding:4px 14px;border-radius:8px;color:#450a0a;border-bottom:4px dashed #450a0a;">الخنـدق الحصين</div>
            <div class="b-team bt-m" style="top:48%;left:50%;transform:translateX(-50%);">المدينة المنورة (3000)</div>
            <div class="b-team bt-e" style="top:8%;left:50%;transform:translateX(-50%);">الأحزاب (10,000+)</div>
            <div class="b-label" style="bottom:20px;right:18px;color:#dc2626;"><i class="fas fa-exclamation-triangle me-1"></i>غدر بني قريظة</div>
            <div class="pulse-dot" style="top:38%;left:10%;"></div>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="battle-info-card">
            <h3 class="amiri fw-bold text-dark mb-3">النصر الرباني بجنود السماء</h3>
            <p class="fs-5 text-muted lh-xl">تجمع عشرة آلاف من الأحزاب. بفكرة سلمان الفارسي حُفر الخندق في أيام. دام الحصار شهراً مع برد وجوع، حتى أرسل الله ريحاً عاتية وجنوداً من السماء فاقتلعت خيام الأحزاب.</p>
            <div class="alert alert-info mt-4 rounded-4"><strong>الدرس:</strong> الأخذ بالأسباب والشورى ولو جاءت الفكرة من أصغر الأصحاب منزلة.</div>
          </div>
        </div>
      </div>
    </div>

    <div class="tab-pane fade" id="makkah">
      <div class="row g-5 align-items-stretch">
        <div class="col-lg-6">
          <div class="battle-map">
            <div class="b-badge">فتح مكة — 8 هـ</div>
            <div class="b-label" style="top:50%;left:45%;transform:translate(-50%,-50%);text-align:center;"><i class="fas fa-kaaba fa-3x d-block mb-2" style="color:var(--dk);"></i><strong>الكعبة المشرفة</strong></div>
            <div class="b-team bt-m" style="top:15%;right:10%;">جيش المسلمين (10,000)<br><small>بقيادة: النبي ﷺ</small></div>
            <div class="b-label" style="bottom:20px;left:15px;">4 فيالق من 4 اتجاهات</div>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="battle-info-card">
            <h3 class="amiri fw-bold text-dark mb-3">فتح بلا دماء — العفو الأسطوري</h3>
            <p class="fs-5 text-muted lh-xl">دخل ﷺ مكة بعشرة آلاف فاتحاً مطأطئَ الرأس. كسر 360 صنماً، طاف بالبيت، ثم جمع أهل مكة وقال: "يا معشر قريش، ما تظنون أني فاعل بكم؟والله لا يؤاخذكم الله اليوم. اذهبوا فأنتم الطلقاء."</p>
            <div class="alert alert-success mt-4 rounded-4"><strong>الدرس:</strong> العفو عند المقدرة أعلى مراتب القوة والعظمة. فتح مكة غيّر وجه التاريخ دون سفك دماء.</div>
          </div>
        </div>
      </div>
    </div>

    <div class="tab-pane fade" id="hunain">
      <div class="row g-5 align-items-stretch">
        <div class="col-lg-6">
          <div class="battle-map">
            <div class="b-badge">حنين — 8 هـ</div>
            <div class="b-label" style="top:15px;left:20px;"><i class="fas fa-mountain me-1"></i>وادي حنين الضيق</div>
            <div class="b-team bt-e" style="top:20%;left:8%;">هوازن وثقيف (كامنون بالوادي)</div>
            <div class="b-team bt-m" style="bottom:25%;right:10%;">12,000 مسلم<br><small>النبي ﷺ يثبت وحده</small></div>
            <div class="pulse-dot" style="top:45%;left:35%;"></div>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="battle-info-card">
            <h3 class="amiri fw-bold text-dark mb-3">الثبات حين الدنيا تداعت</h3>
            <p class="fs-5 text-muted lh-xl">بعد فتح مكة مباشرة خرج المسلمون بثقة لقتال هوازن. كمن العدو في الوادي فانهزم الناس. وقف النبي ﷺ وحده على بغلته ينادي: "أنا النبي لا كذب، أنا ابن عبد المطلب" حتى تراجع المؤمنون.</p>
            <div class="alert alert-warning mt-4 rounded-4"><strong>الدرس:</strong> الإعجاب بالكثرة آفة تورث الهزيمة. النصر من الله لا من العدد والعدة.</div>
          </div>
        </div>
      </div>
    </div>

  </div>
</div><!-- end t4 -->

<!-- TAB 5: AHL AL BAYT -->
<div class="tab-pane fade" id="t5">
  <div class="sec-head" data-aos="fade-up">
    <div class="badge-tag">وَأْمُرْ أَهْلَكَ بِالصَّلَاةِ</div>
    <h2 class="amiri">أهل البيت <span>النبوي الشريف</span></h2>
    <p>بناته الكريمات وسبطاه الحسنان سيدا شباب أهل الجنة رضي الله عنهم أجمعين</p>
    <div class="gold-divider"></div>
  </div>
  <div class="row g-4">
    <div class="col-lg-4 col-md-6" data-aos="fade-up"><div class="bayt-card"><div class="bayt-icon"><i class="fas fa-gem"></i></div><h3 class="amiri fw-bold text-dark mb-3">السيدة فاطمة الزهراء ؓ</h3><p class="text-muted lh-xl">سيدة نساء أهل الجنة وبضعة النبي. كان إذا دخلت عليه قام لها وقبّل يدها. بكت يوم وفاته بكاءً شديداً ولحقت به بعد ستة أشهر. زوجة علي وأم الحسنين.</p></div></div>
    <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="50"><div class="bayt-card"><div class="bayt-icon"><i class="fas fa-crown"></i></div><h3 class="amiri fw-bold text-dark mb-3">الحسن بن علي ؓ</h3><p class="text-muted lh-xl">سيد شباب أهل الجنة وريحانة النبي. كان يشبهه في الخلق والخُلق. تنازل عن الخلافة حقناً لدماء المسلمين. يُعدّ تنازله من أعظم مواقف الإيثار في الإسلام.</p></div></div>
    <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="100"><div class="bayt-card"><div class="bayt-icon"><i class="fas fa-star"></i></div><h3 class="amiri fw-bold text-dark mb-3">الحسين بن علي ؓ</h3><p class="text-muted lh-xl">سيد شباب أهل الجنة ثانياً مع أخيه، ريحانة النبي. كان النبي يحمله ويقبله ويقول: "اللهم إني أحبه فأحبه." استُشهد في كربلاء ونشر الله له علماً لن يُغلّ.</p></div></div>
    <div class="col-lg-4 col-md-6" data-aos="fade-up"><div class="bayt-card"><div class="bayt-icon"><i class="fas fa-heart"></i></div><h3 class="amiri fw-bold text-dark mb-3">زينب بنت محمد ؓ</h3><p class="text-muted lh-xl">أكبر بنات النبي وأوسعهن قلباً. كانت تعيش محنة زوجها أبي العاص وإسلامها صبوراً على الفراق حتى هاجر زوجها مسلماً وأعادها النبي إليه.</p></div></div>
    <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="50"><div class="bayt-card"><div class="bayt-icon"><i class="fas fa-feather-alt"></i></div><h3 class="amiri fw-bold text-dark mb-3">رقية بنت محمد ؓ</h3><p class="text-muted lh-xl">تزوجت عثمان بن عفان رضي الله عنه. هاجرت معه إلى الحبشة هجرتين. توفيت أثناء غزوة بدر فلم يشهدها عثمان ولا أبوها ﷺ.</p></div></div>
    <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="100"><div class="bayt-card"><div class="bayt-icon"><i class="fas fa-moon"></i></div><h3 class="amiri fw-bold text-dark mb-3">أم كلثوم بنت محمد ؓ</h3><p class="text-muted lh-xl">تزوجها عثمان بعد وفاة أختها رقية فسُمّي "ذا النورين". قال فيه النبي: "لو كانت عندي ثالثة لأنكحتها عثمان." توفيت في حياة النبي.</p></div></div>
  </div>
</div><!-- end t5 -->

<!-- TAB 6: QURAN -->
<div class="tab-pane fade" id="t6">
  <div class="sec-head" data-aos="fade-up">
    <div class="badge-tag">القرآن ومرايا السيرة</div>
    <h2 class="amiri">السيرة النبوية <span>في القرآن الكريم</span></h2>
    <p>ارتبطت أحداث السيرة ارتباطاً عضوياً بنزول القرآن الكريم، حتى صار القرآن المرجع الأول لفهم السيرة</p>
    <div class="gold-divider"></div>
  </div>
  <div class="table-responsive shadow rounded-4 overflow-hidden" data-aos="fade-up">
    <table class="table table-hover quran-table mb-0 text-center">
      <thead><tr><th>الحدث</th><th>السورة/الآيات</th><th>الرسالة الرئيسية</th></tr></thead>
      <tbody>
        <tr><td class="fw-bold amiri fs-5">البعثة ونزول الوحي</td><td class="text-primary fw-bold">العلق: 1-5</td><td class="text-muted">اقرأ باسم ربك الذي خلق — أول ما نزل</td></tr>
        <tr><td class="fw-bold amiri fs-5">الإسراء والمعراج</td><td class="text-primary fw-bold">الإسراء: 1 — النجم: 13-18</td><td class="text-muted">سبحان الذي أسرى بعبده ليلاً</td></tr>
        <tr><td class="fw-bold amiri fs-5">الهجرة إلى المدينة</td><td class="text-primary fw-bold">التوبة: 40</td><td class="text-muted">إذ أخرجه الذين كفروا ثاني اثنين</td></tr>
        <tr><td class="fw-bold amiri fs-5">غزوة بدر الكبرى</td><td class="text-primary fw-bold">الأنفال: 5-19</td><td class="text-muted">وما النصر إلا من عند الله</td></tr>
        <tr><td class="fw-bold amiri fs-5">غزوة أُحُد</td><td class="text-primary fw-bold">آل عمران: 121-175</td><td class="text-muted">إن يمسسكم قرح فقد مس القوم قرح مثله</td></tr>
        <tr><td class="fw-bold amiri fs-5">غزوة الخندق/الأحزاب</td><td class="text-primary fw-bold">الأحزاب: 9-25</td><td class="text-muted">وكفى الله المؤمنين القتال وكان الله قوياً عزيزاً</td></tr>
        <tr><td class="fw-bold amiri fs-5">صلح الحديبية</td><td class="text-primary fw-bold">الفتح: 1-29</td><td class="text-muted">إنا فتحنا لك فتحاً مبيناً</td></tr>
        <tr><td class="fw-bold amiri fs-5">فتح مكة المكرمة</td><td class="text-primary fw-bold">النصر: 1-3</td><td class="text-muted">إذا جاء نصر الله والفتح</td></tr>
        <tr><td class="fw-bold amiri fs-5">حجة الوداع وإكمال الدين</td><td class="text-primary fw-bold">المائدة: 3</td><td class="text-muted">اليوم أكملت لكم دينكم وأتممت عليكم نعمتي</td></tr>
      </tbody>
    </table>
  </div>
</div><!-- end t6 -->

<!-- TAB 7: HADITH LANDMARKS -->
<div class="tab-pane fade" id="t7">
  <div class="sec-head" data-aos="fade-up">
    <div class="badge-tag">من الوحي المشرق</div>
    <h2 class="amiri">منارات <span>الوحي</span></h2>
    <p>أبرز الأحاديث النبوية المتعلقة بالسيرة الشريفة وأحداثها الكبرى</p>
    <div class="gold-divider"></div>
  </div>
  <div class="row g-4">
    <div class="col-12" data-aos="fade-up"><div class="hadith-card"><p class="hadith-text">"كان أول ما بُدئ به رسول الله ﷺ من الوحي الرؤيا الصادقة في النوم، فكان لا يرى رؤيا إلا جاءت مثل فَلَق الصبح"</p><div class="hadith-source mt-3">رواه البخاري ومسلم — حديث بدء الوحي الشريف</div></div></div>
    <div class="col-12" data-aos="fade-up"><div class="hadith-card"><p class="hadith-text">"اللهم إن قريشاً أخذتني وأذلتني وكذّبتني، اللهم فأسألك نصرك الذي وعدتني، اللهم إن شئت لم تُعبد في الأرض" — دعاء النبي ﷺ يوم بدر وهو يناشد ربه</p><div class="hadith-source mt-3">رواه مسلم</div></div></div>
    <div class="col-12" data-aos="fade-up"><div class="hadith-card"><p class="hadith-text">"أيها الناس، إن دماءكم وأموالكم وأعراضكم عليكم حرام كحرمة يومكم هذا في شهركم هذا في بلدكم هذا. ألا هل بلغت؟ اللهم فاشهد"</p><div class="hadith-source mt-3">خطبة حجة الوداع — رواه البخاري ومسلم</div></div></div>
    <div class="col-12" data-aos="fade-up"><div class="hadith-card"><p class="hadith-text">"إن الله وملائكته يصلون على النبي، يا أيها الذين آمنوا صلوا عليه وسلموا تسليماً." — وقال ﷺ: "من صلى عليّ واحدة صلى الله عليه بها عشراً"</p><div class="hadith-source mt-3">رواه مسلم</div></div></div>
  </div>
</div><!-- end t7 -->

</div><!-- end tab-content -->
</div><!-- end container -->
""")
f.close()
print("Part 6 done — battles, ahl al bayt, quran, hadith tabs")
