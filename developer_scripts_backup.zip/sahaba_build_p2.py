import codecs

part2 = """
<!-- TAB 2: KHULAFA -->
<div class="tab-pane fade" id="t-khulafa">
  <div class="sec-head">
    <span class="tag">المهديون المتبعون</span>
    <h3>الخلفاء الراشدون <span>الأربعة</span></h3>
    <p>أفضل هذه الأمة بعد نبيها، أمرنا النبي ﷺ بسنتهم والعض عليها بالنواجذ</p>
    <div class="divider"></div>
  </div>

  <div class="row g-4 mb-5">
    <div class="col-lg-6">
      <div class="comp-card h-100">
        <div class="comp-head" data-bg="١">
          <h4 class="mb-1" style="font-weight:800;">أبو بكر الصديق</h4>
          <span class="opacity-75 small">عبد الله بن عثمان الخزومي رضي الله عنه</span>
        </div>
        <div class="comp-body">
          <div class="comp-badge">مدة الخلافة: سنتان و3 أشهر</div>
          <p class="text-muted small" style="line-height:1.9;">أول من آمن من الرجال، وصاحب النبي في الهجرة والغار. تصدق بجميع ماله في سبيل الله. قال النبي ﷺ: "إن أمنّ الناس علي في صحبته وماله أبو بكر، ولو كنت متخذاً خليلاً لاتخذت أبا بكر خليلاً". من أعظم أعماله كخليفة: قتال المرتدين وحفظ بيضة الإسلام، والبدء في جمع القرآن الكريم.</p>
        </div>
      </div>
    </div>
    
    <div class="col-lg-6">
      <div class="comp-card h-100">
        <div class="comp-head" data-bg="٢" style="background:linear-gradient(135deg,#0a2540,#15457a);">
          <h4 class="mb-1" style="font-weight:800;">عمر بن الخطاب</h4>
          <span class="opacity-75 small">الفاروق أبو حفص رضي الله عنه</span>
        </div>
        <div class="comp-body">
          <div class="comp-badge" style="background:rgba(10,37,64,.1);color:#0a2540;border-color:rgba(10,37,64,.2);">مدة الخلافة: 10 سنوات و6 أشهر</div>
          <p class="text-muted small" style="line-height:1.9;">أعز الله الإسلام بإسلامه. قال نبينا ﷺ: "إن الله جعل الحق على لسان عمر وقلبه". فرّق الله به بين الحق والباطل فلُقب بالفاروق. في عهده فتحت الشام والعراق ومصر والقدس. أنشأ الدواوين، وأسس التقويم الهجري، وكان يطوف بالليل يتفقد أحوال الرعية بنفسه.</p>
        </div>
      </div>
    </div>
    
    <div class="col-lg-6">
      <div class="comp-card h-100">
        <div class="comp-head" data-bg="٣" style="background:linear-gradient(135deg,#c0392b,#e74c3c);">
          <h4 class="mb-1" style="font-weight:800;">عثمان بن عفان</h4>
          <span class="opacity-75 small">ذو النورين وأمير المؤمنين رضي الله عنه</span>
        </div>
        <div class="comp-body">
          <div class="comp-badge" style="background:rgba(231,76,60,.1);color:#c0392b;border-color:rgba(231,76,60,.2);">مدة الخلافة: 12 سنة</div>
          <p class="text-muted small" style="line-height:1.9;">تزوج ابنتي الرسول رقية ثم أم كلثوم بعد وفاتها ولا يعرف أحد تزوج بنتي نبي غيره. عُرف بالحياء الشديد الذي تستحي منه الملائكة، وتجهيز جيش العسرة. أعظم منجزاته كخليفة: جمع الناس على مصحف واحد (مصحف عثمان) لمنع الاختلاف الماحق في القراءة، وتوسعة المسجدين.</p>
        </div>
      </div>
    </div>
    
    <div class="col-lg-6">
      <div class="comp-card h-100">
        <div class="comp-head" data-bg="٤" style="background:linear-gradient(135deg,#27ae60,#2ecc71);">
          <h4 class="mb-1" style="font-weight:800;">علي بن أبي طالب</h4>
          <span class="opacity-75 small">أبو الحسن وأبو تراب رضي الله عنه</span>
        </div>
        <div class="comp-body">
          <div class="comp-badge" style="background:rgba(46,204,113,.1);color:#27ae60;border-color:rgba(46,204,113,.2);">مدة الخلافة: 4 سنوات و9 أشهر</div>
          <p class="text-muted small" style="line-height:1.9;">أول من آمن من الصبيان. نام في فراش النبي ﷺ ليلة الهجرة فداءً له. زوج السيدة فاطمة الزهراء، وأبو السبطين الحسن والحسين. قال النبي ﷺ له يوم خيبر: "لأعطين الراية غداً رجلاً يحب الله ورسوله ويحبه الله ورسوله". اشتهر بالبلاغة والفصاحة والقضاء العادل والشجاعة الفذة.</p>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- TAB 3: ASHARA -->
<div class="tab-pane fade" id="t-ashara">
  <div class="sec-head">
    <span class="tag">المشهد المهيب</span>
    <h3>العشرة المبشرون <span>بالجنة</span></h3>
    <p>ذكرهم النبي ﷺ في حديث واحد وبشرهم بالجنة وهم يمشون على الأرض</p>
    <div class="divider"></div>
  </div>

  <div class="quote-strip mb-5 text-center" style="padding:25px;">
    <p style="font-size:1.1rem;line-height:1.9;">«أَبُو بَكْرٍ فِي الْجَنَّةِ، وَعُمَرُ فِي الْجَنَّةِ، وَعُثْمَانُ فِي الْجَنَّةِ، وَعَلِيٌّ فِي الْجَنَّةِ، وَطَلْحَةُ فِي الْجَنَّةِ، وَالزُّبَيْرُ فِي الْجَنَّةِ، وَعَبْدُ الرَّحْمَنِ بْنُ عَوْفٍ فِي الْجَنَّةِ، وَسَعْدٌ فِي الْجَنَّةِ، وَسَعِيدٌ فِي الْجَنَّةِ، وَأَبُو عُبَيْدَةَ بْنُ الْجَرَّاحِ فِي الْجَنَّةِ»</p>
    <small class="d-block mt-2" style="opacity:.6;">— رواه الترمذي</small>
  </div>

  <div class="row g-3">
    <div class="col-md-4 col-sm-6"><div class="p-4 bg-white rounded-4 shadow-sm h-100 border-top border-3 border-success text-center"><i class="fas fa-medal text-warning fa-2x mb-3"></i><strong class="d-block" style="color:#043826;font-size:1.1rem;">أبو بكر الصديق</strong><span class="text-muted small">صاحب النبي في هجرته</span></div></div>
    <div class="col-md-4 col-sm-6"><div class="p-4 bg-white rounded-4 shadow-sm h-100 border-top border-3 border-success text-center"><i class="fas fa-medal text-warning fa-2x mb-3"></i><strong class="d-block" style="color:#043826;font-size:1.1rem;">عمر بن الخطاب</strong><span class="text-muted small">الفاروق شهيد المحراب</span></div></div>
    <div class="col-md-4 col-sm-6"><div class="p-4 bg-white rounded-4 shadow-sm h-100 border-top border-3 border-success text-center"><i class="fas fa-medal text-warning fa-2x mb-3"></i><strong class="d-block" style="color:#043826;font-size:1.1rem;">عثمان بن عفان</strong><span class="text-muted small">ذو النورين وشهيد الدار</span></div></div>
    <div class="col-md-4 col-sm-6"><div class="p-4 bg-white rounded-4 shadow-sm h-100 border-top border-3 border-success text-center"><i class="fas fa-medal text-warning fa-2x mb-3"></i><strong class="d-block" style="color:#043826;font-size:1.1rem;">علي بن أبي طالب</strong><span class="text-muted small">أبو تراب بطل المعارك</span></div></div>
    <div class="col-md-4 col-sm-6"><div class="p-4 bg-white rounded-4 shadow-sm h-100 border-top border-3 border-warning text-center"><i class="fas fa-medal text-warning fa-2x mb-3"></i><strong class="d-block" style="color:#043826;font-size:1.1rem;">طلحة بن عبيد الله</strong><span class="text-muted small">طلحة الخير، شهيد يمشي</span></div></div>
    <div class="col-md-4 col-sm-6"><div class="p-4 bg-white rounded-4 shadow-sm h-100 border-top border-3 border-warning text-center"><i class="fas fa-medal text-warning fa-2x mb-3"></i><strong class="d-block" style="color:#043826;font-size:1.1rem;">الزبير بن العوام</strong><span class="text-muted small">حواري رسول الله وابن عمته</span></div></div>
    <div class="col-md-4 col-sm-6"><div class="p-4 bg-white rounded-4 shadow-sm h-100 border-top border-3 border-info text-center"><i class="fas fa-medal text-warning fa-2x mb-3"></i><strong class="d-block" style="color:#043826;font-size:1.1rem;">عبد الرحمن بن عوف</strong><span class="text-muted small">التاجر المنفق ماله مرات عديدة</span></div></div>
    <div class="col-md-4 col-sm-6"><div class="p-4 bg-white rounded-4 shadow-sm h-100 border-top border-3 border-info text-center"><i class="fas fa-medal text-warning fa-2x mb-3"></i><strong class="d-block" style="color:#043826;font-size:1.1rem;">سعد بن أبي وقاص</strong><span class="text-muted small">أول من رمى بسهم في سبيل الله</span></div></div>
    <div class="col-md-4 col-sm-6"><div class="p-4 bg-white rounded-4 shadow-sm h-100 border-top border-3 border-info text-center"><i class="fas fa-medal text-warning fa-2x mb-3"></i><strong class="d-block" style="color:#043826;font-size:1.1rem;">سعيد بن زيد</strong><span class="text-muted small">من السابقين الأولين مجاب الدعوة</span></div></div>
    <div class="col-md-4 col-sm-6 mx-auto"><div class="p-4 bg-white rounded-4 shadow-sm h-100 border-top border-3 border-primary text-center"><i class="fas fa-medal text-warning fa-2x mb-3"></i><strong class="d-block" style="color:#043826;font-size:1.1rem;">أبو عبيدة بن الجراح</strong><span class="text-muted small">أمين هذه الأمة وقائد فتوح الشام</span></div></div>
  </div>
</div>
"""

with codecs.open(r"C:\Users\ST\Desktop\islamic.encyclopedia\shb_p2.tmp", 'w', 'utf-8') as f:
    f.write(part2)
print("Sahaba part 2 ready")
