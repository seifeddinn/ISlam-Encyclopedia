import codecs

part2 = """
<!-- TAB 1: KUTUB -->
<div class="tab-pane fade show active" id="t1" role="tabpanel">
  <div class="sec-head">
    <span class="tag">مصادر السنة النبوية</span>
    <h3>الصحاح والسنن <span>الكبرى</span></h3>
    <p>الكتب التسعة المعتمدة في الحديث النبوي الشريف — من أقدم جمعٍ للسنة إلى أكثرها شمولاً</p>
    <div class="divider"></div>
  </div>
  <div class="row g-4">

    <div class="col-lg-4 col-md-6">
      <div class="kitab-wrap">
        <div class="kitab-header" data-num="01" style="background:linear-gradient(135deg,#0d3320,#1a5c3a);">
          <div class="kitab-icon-wrap" style="background:rgba(255,255,255,.15);color:#e8d5a3;"><i class="fas fa-book"></i></div>
          <h5 style="color:white;">صحيح البخاري</h5>
          <small>الإمام محمد بن إسماعيل البخاري (ت 256 هـ)</small>
        </div>
        <div class="kitab-body">
          <p>أصح كتاب بعد القرآن الكريم بإجماع المحدثين. انتقاه الإمام البخاري من 600,000 رواية على مدى 16 عاماً، وكان يغتسل ويصلي ركعتين قبل كتابة كل حديث.</p>
          <div class="kitab-stat"><span><i class="fas fa-list-ol me-1 text-success"></i>عدد الأحاديث</span><strong style="color:#0d3320;">7,563</strong></div>
        </div>
      </div>
    </div>

    <div class="col-lg-4 col-md-6">
      <div class="kitab-wrap">
        <div class="kitab-header" data-num="02" style="background:linear-gradient(135deg,#145a90,#1a81cc);">
          <div class="kitab-icon-wrap" style="background:rgba(255,255,255,.15);color:#e8d5a3;"><i class="fas fa-book-open"></i></div>
          <h5 style="color:white;">صحيح مسلم</h5>
          <small>الإمام مسلم بن الحجاج النيسابوري (ت 261 هـ)</small>
        </div>
        <div class="kitab-body">
          <p>ثاني أصح كتب الحديث. امتاز بحسن التبويب وجمع طرق الحديث الواحد في موضع واحد. قال فيه ابن الأخرم: صنّف مسلم هذا المسند وعرضه على أبي زرعة فكل ما أشار إليه تركه.</p>
          <div class="kitab-stat"><span><i class="fas fa-list-ol me-1 text-primary"></i>عدد الأحاديث</span><strong style="color:#145a90;">5,362</strong></div>
        </div>
      </div>
    </div>

    <div class="col-lg-4 col-md-6">
      <div class="kitab-wrap">
        <div class="kitab-header" data-num="03" style="background:linear-gradient(135deg,#9a5e10,#c9a66b);">
          <div class="kitab-icon-wrap" style="background:rgba(255,255,255,.15);color:white;"><i class="fas fa-scroll"></i></div>
          <h5 style="color:white;">سنن أبي داود</h5>
          <small>الإمام أبو داود السجستاني (ت 275 هـ)</small>
        </div>
        <div class="kitab-body">
          <p>أهم مصدر للفقه الحديثي. قال الإمام أحمد: كفى بسنن أبي داود في الدين. اشتمل على أحاديث الأحكام الفقهية بصورة متفردة مع بيان درجة الحديث في أغلب الأحيان.</p>
          <div class="kitab-stat"><span><i class="fas fa-list-ol me-1 text-warning"></i>عدد الأحاديث</span><strong style="color:#9a5e10;">5,274</strong></div>
        </div>
      </div>
    </div>

    <div class="col-lg-4 col-md-6">
      <div class="kitab-wrap">
        <div class="kitab-header" data-num="04" style="background:linear-gradient(135deg,#6c2b9a,#9b59b6);">
          <div class="kitab-icon-wrap" style="background:rgba(255,255,255,.15);color:white;"><i class="fas fa-star-half-alt"></i></div>
          <h5 style="color:white;">جامع الترمذي</h5>
          <small>الإمام أبو عيسى الترمذي (ت 279 هـ)</small>
        </div>
        <div class="kitab-body">
          <p>جامع لأنه يشمل الأحكام والرقائق والفضائل وبيان درجة الحديث تفصيلاً. يُذكر فيه مذاهب الفقهاء وهو من تلاميذ البخاري المباشرين.</p>
          <div class="kitab-stat"><span><i class="fas fa-list-ol me-1" style="color:#9b59b6;"></i>عدد الأحاديث</span><strong style="color:#6c2b9a;">3,956</strong></div>
        </div>
      </div>
    </div>

    <div class="col-lg-4 col-md-6">
      <div class="kitab-wrap">
        <div class="kitab-header" data-num="05" style="background:linear-gradient(135deg,#8b1a1a,#c0392b);">
          <div class="kitab-icon-wrap" style="background:rgba(255,255,255,.15);color:white;"><i class="fas fa-feather"></i></div>
          <h5 style="color:white;">سنن النسائي</h5>
          <small>الإمام أحمد بن شعيب النسائي (ت 303 هـ)</small>
        </div>
        <div class="kitab-body">
          <p>أقل الكتب الستة رواية للضعيف والمنكر. امتاز بدقة انتقاد الأسانيد والتنبيه على العلل الخفية. قال الدارقطني: لا يُقدَّم أحد عليه في هذا الشأن.</p>
          <div class="kitab-stat"><span><i class="fas fa-list-ol me-1 text-danger"></i>عدد الأحاديث</span><strong style="color:#8b1a1a;">5,758</strong></div>
        </div>
      </div>
    </div>

    <div class="col-lg-4 col-md-6">
      <div class="kitab-wrap">
        <div class="kitab-header" data-num="06" style="background:linear-gradient(135deg,#a04000,#e67e22);">
          <div class="kitab-icon-wrap" style="background:rgba(255,255,255,.15);color:white;"><i class="fas fa-landmark"></i></div>
          <h5 style="color:white;">سنن ابن ماجه</h5>
          <small>الإمام محمد بن يزيد ابن ماجه (ت 273 هـ)</small>
        </div>
        <div class="kitab-body">
          <p>يشتمل على أحاديث لا توجد في الكتب الخمسة الأخرى وغالباً ما ينفرد بها. ضمّه ابن الأثير وابن طاهر إلى الأصول الخمسة ليكتمل به عِقد الكتب الستة.</p>
          <div class="kitab-stat"><span><i class="fas fa-list-ol me-1 text-warning"></i>عدد الأحاديث</span><strong style="color:#a04000;">4,341</strong></div>
        </div>
      </div>
    </div>

    <div class="col-lg-4 col-md-6">
      <div class="kitab-wrap">
        <div class="kitab-header" data-num="07" style="background:linear-gradient(135deg,#0d6b35,#27ae60);">
          <div class="kitab-icon-wrap" style="background:rgba(255,255,255,.15);color:white;"><i class="fas fa-leaf"></i></div>
          <h5 style="color:white;">موطأ الإمام مالك</h5>
          <small>الإمام مالك بن أنس (ت 179 هـ)</small>
        </div>
        <div class="kitab-body">
          <p>أقدم كتب الحديث الموثّقة وأوّلها تدويناً. قال الشافعي: ما على ظهر الأرض كتاب بعد كتاب الله أصح من موطأ مالك. عرضه على سبعين فقيهاً من فقهاء المدينة فصوّبوه.</p>
          <div class="kitab-stat"><span><i class="fas fa-list-ol me-1 text-success"></i>عدد الأحاديث</span><strong style="color:#0d6b35;">1,720</strong></div>
        </div>
      </div>
    </div>

    <div class="col-lg-4 col-md-6">
      <div class="kitab-wrap">
        <div class="kitab-header" data-num="08" style="background:linear-gradient(135deg,#1c1c2e,#2c3e50);">
          <div class="kitab-icon-wrap" style="background:rgba(255,255,255,.15);color:#c9a66b;"><i class="fas fa-archive"></i></div>
          <h5 style="color:white;">مسند الإمام أحمد</h5>
          <small>الإمام أحمد بن حنبل (ت 241 هـ)</small>
        </div>
        <div class="kitab-body">
          <p>أكبر مسانيد التاريخ الإسلامي. رتّبه على مسانيد الصحابة. قال الإمام أحمد: جمعت فيه من الحديث ما يكون للناس إماماً يرجعون إليه. يحتوي على أحاديث نادرة فريدة.</p>
          <div class="kitab-stat"><span><i class="fas fa-list-ol me-1 text-secondary"></i>عدد الأحاديث</span><strong>+40,000</strong></div>
        </div>
      </div>
    </div>

    <div class="col-lg-4 col-md-6">
      <div class="kitab-wrap">
        <div class="kitab-header" data-num="09" style="background:linear-gradient(135deg,#0d5c4a,#1abc9c);">
          <div class="kitab-icon-wrap" style="background:rgba(255,255,255,.15);color:white;"><i class="fas fa-book-reader"></i></div>
          <h5 style="color:white;">سنن الدارمي</h5>
          <small>الإمام عبد الله بن عبد الرحمن الدارمي (ت 255 هـ)</small>
        </div>
        <div class="kitab-body">
          <p>يشتمل على الأحاديث المرفوعة والموقوفة والمقطوعة وفيه مقدمة قيّمة في علوم الحديث. قال فيه العلماء: إسناده نقي وشيوخه أجلاء من طبقة الأئمة الكبار.</p>
          <div class="kitab-stat"><span><i class="fas fa-list-ol me-1 text-info"></i>عدد الأحاديث</span><strong style="color:#0d5c4a;">3,540</strong></div>
        </div>
      </div>
    </div>

  </div>
</div>

<!-- TAB 2: NAWAWI -->
<div class="tab-pane fade" id="t2" role="tabpanel">
  <div class="sec-head">
    <span class="tag">الإمام يحيى بن شرف النووي (ت 676 هـ)</span>
    <h3>الأربعون <span>النووية</span></h3>
    <p>أربعون حديثاً وحديثان جامعة لأصول الدين وقواعد الإسلام والإيمان والإحسان</p>
    <div class="divider"></div>
  </div>
  <div class="nawawi-search-wrap">
    <i class="fas fa-search text-muted ms-2"></i>
    <input type="text" id="nSearch" placeholder="ابحث بالكلمة أو رقم الحديث أو اسم الراوي...">
    <button onclick="filterNawawi()">بحث</button>
  </div>
  <div id="nawawi-count" class="text-muted small mb-3 text-center"></div>
  <div id="nawawi-list"></div>
</div>

<!-- TAB 3: MUSTALAH -->
<div class="tab-pane fade" id="t3" role="tabpanel">
  <div class="sec-head">
    <span class="tag">علم مصطلح الحديث</span>
    <h3>أسس قبول <span>الرواية</span></h3>
    <p>المعايير والقواعد التي وضعها المحدثون لنقد الأسانيد وتمييز الصحيح من الضعيف</p>
    <div class="divider"></div>
  </div>
  <div class="row g-4 mb-5">
    <div class="col-lg-3 col-md-6">
      <div class="term-card" style="border-top:4px solid #27ae60;">
        <div class="term-icon" style="background:linear-gradient(135deg,#1a7a3a,#27ae60);color:white;"><i class="fas fa-check-double"></i></div>
        <h5 style="color:#0d5c2a;font-weight:800;">الصحيح</h5>
        <p class="text-muted small">اتصل سنده بنقل العدل الضابط عن مثله من غير شذوذ ولا علة قادحة. يُحتج به في الأحكام والعقائد.</p>
        <div class="grade-bar"><div style="width:100%;height:100%;background:linear-gradient(90deg,#27ae60,#2ecc71);border-radius:4px;"></div></div>
        <small class="text-success fw-bold">أعلى درجة — يُحتج به</small>
      </div>
    </div>
    <div class="col-lg-3 col-md-6">
      <div class="term-card" style="border-top:4px solid #f39c12;">
        <div class="term-icon" style="background:linear-gradient(135deg,#c47d0e,#f39c12);color:white;"><i class="fas fa-check"></i></div>
        <h5 style="color:#9a5e0a;font-weight:800;">الحسن</h5>
        <p class="text-muted small">ما رواه عدل خفيف الضبط بسند غير شاذ ولا معلل. يُحتج به كالصحيح لكنه أدنى منه درجة عند التعارض.</p>
        <div class="grade-bar"><div style="width:75%;height:100%;background:linear-gradient(90deg,#f39c12,#f1c40f);border-radius:4px;"></div></div>
        <small class="text-warning fw-bold">درجة مقبولة — يُحتج به</small>
      </div>
    </div>
    <div class="col-lg-3 col-md-6">
      <div class="term-card" style="border-top:4px solid #95a5a6;">
        <div class="term-icon" style="background:linear-gradient(135deg,#7f8c8d,#95a5a6);color:white;"><i class="fas fa-times"></i></div>
        <h5 style="color:#4a5568;font-weight:800;">الضعيف</h5>
        <p class="text-muted small">فقد شرطاً أو أكثر من شروط الصحة والحسن. لا يُحتج به في الأحكام وأجاز بعضهم روايته في الفضائل بشروط.</p>
        <div class="grade-bar"><div style="width:40%;height:100%;background:linear-gradient(90deg,#95a5a6,#bdc3c7);border-radius:4px;"></div></div>
        <small class="text-secondary fw-bold">مردود — لا يُحتج به</small>
      </div>
    </div>
    <div class="col-lg-3 col-md-6">
      <div class="term-card" style="border-top:4px solid #e74c3c;">
        <div class="term-icon" style="background:linear-gradient(135deg,#a93226,#e74c3c);color:white;"><i class="fas fa-ban"></i></div>
        <h5 style="color:#7b241c;font-weight:800;">الموضوع</h5>
        <p class="text-muted small">ما اختُلق ونُسب كذباً إلى النبي ﷺ. أشد أنواع الحديث الضعيف وحرام روايته مع العلم بوضعه ونسبته للنبي.</p>
        <div class="grade-bar"><div style="width:5%;height:100%;background:#e74c3c;border-radius:4px;"></div></div>
        <small class="text-danger fw-bold">حرام روايته إطلاقاً!</small>
      </div>
    </div>
  </div>
  <div class="row g-4">
    <div class="col-md-4">
      <div class="p-4 rounded-4 h-100" style="background:white;box-shadow:0 8px 25px rgba(0,0,0,.05);border-right:4px solid #c9a66b;">
        <div class="d-flex align-items-center gap-3 mb-3"><div style="width:50px;height:50px;background:rgba(201,166,107,.15);border-radius:12px;display:flex;align-items:center;justify-content:center;color:#9a7940;font-size:1.4rem;"><i class="fas fa-link"></i></div><h5 class="fw-bold mb-0" style="color:#0d3320;">السند والمتن</h5></div>
        <p class="text-muted small mb-0"><strong>السند:</strong> سلسلة الرواة المتصلة من المصنِّف إلى النبي ﷺ.<br><strong>المتن:</strong> نص الحديث نفسه وألفاظه التي نُقلت عنه ﷺ.</p>
      </div>
    </div>
    <div class="col-md-4">
      <div class="p-4 rounded-4 h-100" style="background:white;box-shadow:0 8px 25px rgba(0,0,0,.05);border-right:4px solid #3498db;">
        <div class="d-flex align-items-center gap-3 mb-3"><div style="width:50px;height:50px;background:rgba(52,152,219,.1);border-radius:12px;display:flex;align-items:center;justify-content:center;color:#2980b9;font-size:1.4rem;"><i class="fas fa-user-check"></i></div><h5 class="fw-bold mb-0" style="color:#0d3320;">العدالة والضبط</h5></div>
        <p class="text-muted small mb-0"><strong>العدالة:</strong> الاستقامة الدينية وتجنب الكبائر والمخلّات بالمروءة.<br><strong>الضبط:</strong> دقة الراوي في الحفظ والأداء سواء صدرياً أم كتابياً.</p>
      </div>
    </div>
    <div class="col-md-4">
      <div class="p-4 rounded-4 h-100" style="background:white;box-shadow:0 8px 25px rgba(0,0,0,.05);border-right:4px solid #e74c3c;">
        <div class="d-flex align-items-center gap-3 mb-3"><div style="width:50px;height:50px;background:rgba(231,76,60,.1);border-radius:12px;display:flex;align-items:center;justify-content:center;color:#c0392b;font-size:1.4rem;"><i class="fas fa-cut"></i></div><h5 class="fw-bold mb-0" style="color:#0d3320;">الاتصال والانقطاع</h5></div>
        <p class="text-muted small mb-0"><strong>الاتصال:</strong> سماع كل راوٍ ممن فوقه مباشرةً.<br><strong>الانقطاع:</strong> سقوط راوٍ من السند (المرسل، المعضل، المعلق، المنقطع).</p>
      </div>
    </div>
  </div>
</div>
"""

with codecs.open(r"c:\Users\ST\Desktop\islamic.encyclopedia\hadith_p2.tmp", 'w', 'utf-8') as f:
    f.write(part2)
print("Part 2 done")
