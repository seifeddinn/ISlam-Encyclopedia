import codecs

html = """<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>أكاديمية التاريخ الإسلامي - الموسوعة الإسلامية الشاملة</title>
    <meta name="description" content="الموسوعة الإسلامية الشاملة - المنصة الرقمية الموثوقة لعلوم القرآن والسنة والفقه والسيرة والتاريخ بعقيدة صحيحة.">
    <meta name="keywords" content="قرآن, حديث, إسلام, فقه, عقيدة, سيرة, تاريخ إسلامي, الموسوعة الإسلامية">
    <meta name="author" content="ST Islamic Web">
    <meta property="og:title" content="الموسوعة الإسلامية الشاملة">
    <meta property="og:description" content="مرجعك الشامل للعلوم الشرعية الموثقة بتصميم عصري وتقنيات حديثة.">
    <meta property="og:type" content="website">
    <link rel="icon" href="https://cdn-icons-png.flaticon.com/512/3389/3389081.png" type="image/png">
<link href="https://fonts.googleapis.com/css2?family=Amiri:ital,wght@0,400;0,700;1,400&family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root{--gold:#d4af37;--gold-light:#f9f1d8;--gold-dark:#aa8a2a;--dark:#4a2c11;--primary:#b45309;--accent:#78350f;}
body{font-family:'Cairo',sans-serif;background:#f8fafc;color:#1e293b;overflow-x:hidden;}
h1,h2,h3,h4,h5,h6,.ar,.poetry, .title-amiri{font-family:'Amiri',serif;}

/* MEGA NAVBAR */
.navbar {background:linear-gradient(135deg,var(--dark),var(--primary))!important;box-shadow:0 4px 30px rgba(0,0,0,.5);z-index:1000;border-bottom:2px solid rgba(212,175,55,0.2);}
.navbar-brand{font-family:'Amiri',serif;font-size:1.8rem;color:white!important;text-shadow:0 2px 10px rgba(212,175,55,0.5);}
.nav-link{color:rgba(255,255,255,.8)!important;font-weight:700;letter-spacing:0.5px;transition:all .3s;}
.nav-link:hover, .nav-link.active{color:var(--gold)!important;transform:translateX(-2px);}

/* MEGA HERO - HISTORY (BRONZE & GOLD) */
.mega-hero{min-height:90vh;background:radial-gradient(circle at 50% 50%, var(--primary) 0%, var(--dark) 80%);position:relative;overflow:hidden;display:flex;align-items:center;padding:120px 0;}
.hero-glass{background:rgba(74,44,17,0.6);backdrop-filter:blur(15px);border:1px solid rgba(212,175,55,0.3);border-radius:30px;padding:60px 40px;box-shadow:0 20px 50px rgba(0,0,0,0.5);position:relative;z-index:5;text-align:center;}
.hero-pattern{position:absolute;inset:0;background:url('https://www.transparenttextures.com/patterns/arabesque.png');opacity:.15;mix-blend-mode:overlay;}
.hero-eyebrow{display:inline-block;background:linear-gradient(90deg,var(--gold-dark),var(--gold));color:#291504;padding:8px 30px;border-radius:50px;font-weight:bold;font-size:1rem;margin-bottom:25px;box-shadow:0 4px 15px rgba(212,175,55,0.4);}
.mega-hero h1{font-size:5.5rem;font-weight:900;color:white;text-shadow:0 10px 30px rgba(0,0,0,0.8);line-height:1.2;margin-bottom:20px;}
.mega-hero h1 span{background:linear-gradient(135deg,#fff,var(--gold));-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;}
.tagline{color:#ffedd5;font-size:1.3rem;line-height:2.2;text-shadow:0 2px 4px rgba(0,0,0,0.5);max-width:800px;margin:0 auto;}

/* ANIMATED ORBS */
.orb{position:absolute;border-radius:50%;filter:blur(120px);opacity:.4;animation:floatOrb 15s ease-in-out infinite alternate;}
.orb-1{width:600px;height:600px;background:var(--gold);top:-150px;right:-100px;}
.orb-2{width:500px;height:500px;background:#f59e0b;bottom:-100px;left:-50px;animation-delay:5s;}
@keyframes floatOrb{0%{transform:translate(0,0) scale(1);}100%{transform:translate(50px,50px) scale(1.1);}}

/* STATS MEGA */
.stats-mega{background:linear-gradient(90deg,var(--dark),var(--primary));border-top:2px solid var(--gold-dark);border-bottom:2px solid var(--gold-dark);padding:40px 0;position:relative;z-index:10;margin-top:-5px;}
.stat-box{text-align:center;color:white;padding:20px;border-left:1px solid rgba(212,175,55,0.2);}
.stat-box:last-child{border-left:none;}
.stat-num{font-family:'Amiri',serif;font-size:3.5rem;font-weight:bold;color:var(--gold);line-height:1;margin-bottom:10px;text-shadow:0 5px 15px rgba(212,175,55,0.3);}
.stat-label{font-size:1.1rem;font-weight:bold;letter-spacing:1px;color:#fde68a;}

/* SECTION HEADERS */
.sec-head{text-align:center;margin-bottom:60px;position:relative;}
.sec-head .tag{display:inline-block;background:rgba(212,175,55,0.1);color:var(--gold-dark);border:1px solid rgba(212,175,55,0.3);border-radius:30px;padding:8px 25px;font-size:1rem;font-weight:bold;margin-bottom:20px;}
.sec-head h3{font-size:3rem;font-family:'Amiri',serif;color:var(--dark);font-weight:900;margin-bottom:15px;}
.sec-head h3 span{color:var(--primary);}
.sec-head p{color:#64748b;font-size:1.2rem;max-width:800px;margin:0 auto;line-height:1.8;}
.sec-head .divider{width:80px;height:5px;background:linear-gradient(90deg,var(--gold),var(--primary));border-radius:5px;margin:25px auto 0;}

/* TABS NAVIGATION MEGA */
.main-tabs-wrapper{background:white;padding:20px;border-radius:20px;box-shadow:0 10px 40px rgba(0,0,0,0.05);margin:40px auto 60px;position:sticky;top:80px;z-index:900;border:1px solid #e2e8f0;}
.main-tabs{display:flex;gap:10px;overflow-x:auto;padding-bottom:10px;border-bottom:none;}
.main-tabs::-webkit-scrollbar{height:6px;}
.main-tabs::-webkit-scrollbar-thumb{background:var(--gold);border-radius:10px;}
.main-tabs .nav-link{border:1px solid #e2e8f0;border-radius:12px;color:#475569;font-weight:bold;padding:15px 25px;font-size:1.1rem;white-space:nowrap;transition:all .3s;}
.main-tabs .nav-link:hover{background:#f8fafc;border-color:var(--gold-dark);color:var(--dark);transform:translateY(-2px);}
.main-tabs .nav-link.active{background:linear-gradient(135deg,var(--dark),var(--primary));color:white;border-color:transparent;box-shadow:0 10px 20px rgba(180,83,9,0.3);}

/* CARDS */
.mega-card{background:white;border-radius:24px;padding:35px;box-shadow:0 15px 35px rgba(0,0,0,0.04);border:1px solid #fef3c7;transition:all .4s;height:100%;}
.mega-card:hover{transform:translateY(-8px);box-shadow:0 25px 50px rgba(180,83,9,0.1);border-color:var(--gold);}
.mega-icon{font-size:3.5rem;background:linear-gradient(135deg,var(--primary),var(--dark));-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;margin-bottom:20px;display:inline-block;}

/* MEGA BATTLE CARD (Specific design for history page) */
.battle-card{position:relative;overflow:hidden;border:none;border-radius:24px;background:white;box-shadow:0 10px 30px rgba(0,0,0,0.08);transition:all 0.4s;height:100%;}
.battle-card:hover{transform:translateY(-10px);box-shadow:0 20px 40px rgba(180,83,9,0.2);}
.battle-sword{position:absolute;top:-20px;right:-20px;opacity:0.05;font-size:10rem;color:var(--dark);transform:rotate(45deg);z-index:0;transition:0.6s;}
.battle-card:hover .battle-sword{transform:rotate(15deg) scale(1.1);opacity:0.1;color:var(--primary);}
.battle-content{position:relative;z-index:2;padding:40px;}
.b-date{background:linear-gradient(135deg,var(--primary),var(--dark));color:var(--gold-light);padding:5px 15px;border-radius:50px;font-weight:bold;font-size:0.9rem;display:inline-block;margin-bottom:20px;}
.b-parties{display:flex;align-items:center;gap:15px;margin-bottom:20px;}
.b-vs{font-weight:900;color:var(--gold);font-style:italic;}

/* MEGA FOOTER */
.mega-footer{background:linear-gradient(135deg,var(--dark),#020617);color:white;padding:80px 0 30px;margin-top:80px;border-top:3px solid var(--gold-dark);}
.mega-footer-link{color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;}
.mega-footer-link:hover{color:var(--gold);padding-right:5px;}

/* Specific History Timeline */
.timeline-vertical{position:relative;margin:0 auto;max-width:900px;}
.timeline-vertical::before{content:'';position:absolute;top:0;bottom:0;right:50px;width:4px;background:linear-gradient(to bottom, var(--primary), var(--gold-dark), var(--dark));border-radius:2px;}
.t-node{position:relative;margin-bottom:60px;padding-right:90px; opacity:0; transform:translateY(50px); transition:all 0.8s ease-out;}
.t-node.show{opacity:1; transform:translateY(0);}
.t-node::before{content:'';position:absolute;width:24px;height:24px;background:var(--gold);border:4px solid var(--dark);border-radius:50%;right:40px;top:40px;box-shadow:0 0 15px rgba(212,175,55,0.7); z-index:2;}
.t-node-content{background:white;border:1px solid #fef3c7;border-radius:20px;padding:30px;box-shadow:0 10px 30px rgba(0,0,0,0.05);transition:all .3s;position:relative;overflow:hidden;}
.t-node-content::after{content:'';position:absolute;top:0;right:0;width:6px;height:100%;background:linear-gradient(to bottom, var(--primary), var(--gold));}
.t-node:hover .t-node-content{transform:translateX(-10px);border-color:var(--gold);box-shadow:0 15px 40px rgba(180,83,9,0.15);}
.t-era{background:var(--primary);color:var(--gold-light);display:inline-block;padding:8px 25px;border-radius:30px;font-family:'Amiri',serif;font-weight:bold;margin-bottom:20px;box-shadow:0 4px 10px rgba(180,83,9,0.3);font-size:1.1rem;}

.hero-portrait{width:120px;height:120px;border-radius:50%;background:radial-gradient(circle, var(--gold-light), #fff);border:4px solid var(--gold);display:flex;align-items:center;justify-content:center;margin:0 auto 20px;box-shadow:0 10px 20px rgba(0,0,0,0.1);font-size:3rem;color:var(--primary);position:relative;}
.hero-portrait i{background:linear-gradient(135deg,var(--primary),var(--dark));-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;}

</style>
</head>
<body>

<!-- MEGA NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-dark sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold" href="index.html"><i class="fas fa-book-open me-2 text-warning"></i>الموسوعة الإسلامية الشاملة</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav1">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="nav1">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link " href="index.html">الرئيسية</a></li>
        <li class="nav-item"><a class="nav-link " href="recitations.html">القرآن والتلاوات</a></li>
        <li class="nav-item"><a class="nav-link " href="hadith.html">الحديث الشريف</a></li>
        <li class="nav-item"><a class="nav-link " href="fiqh.html">الفقه الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="fatwa.html">فتاوى العلماء <i class="fas fa-gavel"></i></a></li>
        <li class="nav-item"><a class="nav-link " href="seerah.html">السيرة والصحابة</a></li>
        <li class="nav-item"><a class="nav-link " href="aqeedah.html">العقيدة الإسلامية</a></li>
        <li class="nav-item"><a class="nav-link active" href="history.html">التاريخ الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="library.html">المكتبة الشاملة</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- MEGA HERO HISTORY -->
<section class="mega-hero">
  <div class="orb orb-1"></div><div class="orb orb-2"></div>
  <div class="hero-pattern"></div>
  <div class="container relative z-10">
    <div class="row justify-content-center text-center">
      <div class="col-lg-10">
        <div class="hero-glass">
            <div class="hero-eyebrow"><i class="fas fa-chess-knight me-2 text-dark pt-1"></i>سجل الأمجاد والانتصارات الإيمانية</div>
            <h1>موسوعة <span>التاريخ</span> الإسلامي</h1>
            <p class="tagline mt-4">رحلة شاملة ومفصلة في تاريخ أمة محمد ﷺ، منذ الفجر النبوي مروراً بالخلافة الراشدة، الأموية، العباسية، الأندلس، وصولاً للخلافة العثمانية. سجلات الحضارة التي أنارت الكوكب وقادت البشرية.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- STATS BAR -->
<div class="stats-mega">
  <div class="container">
    <div class="row g-0">
      <div class="col-6 col-md-3 stat-box"><div class="stat-num">14</div><div class="stat-label">قرناً من السيادة والعز</div></div>
      <div class="col-6 col-md-3 stat-box"><div class="stat-num">7</div><div class="stat-label">عصور وامبراطوريات عظمى</div></div>
      <div class="col-6 col-md-3 stat-box"><div class="stat-num">200+</div><div class="stat-label">معركة حاسمة غيَّرت العالم</div></div>
      <div class="col-6 col-md-3 stat-box"><div class="stat-num">1</div><div class="stat-label">أمة ربانية خالدة</div></div>
    </div>
  </div>
</div>

<div class="container">
  <!-- TABS NAV -->
  <div class="main-tabs-wrapper">
    <ul class="nav nav-pills main-tabs justify-content-center" id="historyTabs" role="tablist">
            <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#tab-eras"><i class="fas fa-hourglass-half fs-4 d-block mb-1"></i>عصور الخلافة والدول</button></li>
      <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-battles"><i class="fas fa-khanda fs-4 d-block mb-1"></i>المعارك الفاصلة</button></li>
      <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-heroes"><i class="fas fa-horse-head fs-4 d-block mb-1"></i>قادة وفرسان الأمة</button></li>
      <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-civ"><i class="fas fa-mosque fs-4 d-block mb-1"></i>روائع الحضارة والعلوم</button></li>
      <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-landmarks"><i class="fas fa-kaaba fs-4 d-block mb-1"></i>المعالم الكبرى</button></li>
      <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-stats"><i class="fas fa-chart-pie fs-4 d-block mb-1"></i>أرقام وإحصائيات</button></li>
    </ul>
  </div>

  <div class="tab-content pb-5">
    
    <!-- TAB 1: عصور الخلافة الموسعة -->
    <div class="tab-pane fade show active" id="tab-eras">
      <div class="sec-head">
        <span class="tag">من النبوة إلى الخلافة والملك</span>
        <h3>عصور <span>الخلافة</span> والدول</h3>
        <p>التسلسل التاريخي الدقيق للدول العظمى التي توالت على قيادة الأمة وحملت راية الإسلام في كافة القارات المأهولة.</p>
        <div class="divider"></div>
      </div>

      <div class="timeline-vertical">
         
         <!-- Era 0 -->
         <div class="t-node">
            <div class="t-node-content">
               <div class="t-era">العهد النبوي (1 هـ - 11 هـ)</div>
               <h3 class="title-amiri fw-bold text-dark">فجر الإسلام وتأسيس الدولة الأولى</h3>
               <p class="text-muted fs-5 mb-0">هو العقد الأول لبداية التاريخ الهجري، شهد تأسيس الركائز الكبرى للدولة في المدينة المنورة بوضع (صحيفة المدينة) وتكوين أول جيش إسلامي والفتح الأعظم لـ (مكة المكرمة)، وتوحيد شبه الجزيرة العربية لأول مرة تحت راية التوحيد.</p>
            </div>
         </div>

         <!-- Era 1 -->
         <div class="t-node">
            <div class="t-node-content">
               <div class="t-era">الخلافة الراشدة (11 هـ - 41 هـ)</div>
               <h3 class="title-amiri fw-bold text-dark">خلافة على منهاج النبوة - العصر الذهبي</h3>
               <p class="text-muted fs-5 mb-0">خير القرون بعد عهد رسول الله، تميزت بالشورى الخالصة والعدل المشهود. شهد هذا العصر القضاء على الردة بالكامل والفتوحات الإسلامية الكبرى التي أسقطت نهائياً إمبراطورية الفرس الساسانية وحجمت الإمبراطورية البيزنطية وفتحت الشام والعراق ومصر.</p>
            </div>
         </div>

         <!-- Era 2 -->
         <div class="t-node">
            <div class="t-node-content">
               <div class="t-era">الدولة الأموية (41 هـ - 132 هـ)</div>
               <h3 class="title-amiri fw-bold text-dark">عصر الفتوحات الكبرى وتعريب الدواوين العظمى</h3>
               <p class="text-muted fs-5 mb-0">مؤسسها معاوية بن أبي سفيان، والعاصمة دمشق. شهدت أقصى اتساع جغرافي لأمة في التاريخ حينها، امتدت من أبواب باريس وأسوار الصين شرقاً إلى الأندلس والمحيط الأطلسي غرباً. سكّ أمير المؤمنين عبد الملك بن مروان أول عملة ذهبية إسلامية صرفة (الدينار).</p>
            </div>
         </div>

         <!-- Era 3 -->
         <div class="t-node">
            <div class="t-node-content">
               <div class="t-era">الأندلس والمغرب الإسلامي (92 هـ - 897 هـ)</div>
               <h3 class="title-amiri fw-bold text-dark">الفردوس المفقود ومنارة أوروبا</h3>
               <p class="text-muted fs-5 mb-0">بقيت راية الأمويين خفاقة في الأندلس (شبه الجزيرة الأيبيرية) بعد سقوطهم ببغداد، لتأسس طرطبة كأكبر مدينة وأعظمها حضارة في أوروبا برمتها. تلاها المرابطون (يوسف بن تاشفين) ثم الموحدون وحافظوا على راية الإسلام في أوروبا الغربية لـ 800 سنة.</p>
            </div>
         </div>

         <!-- Era 4 -->
         <div class="t-node">
            <div class="t-node-content">
               <div class="t-era">الدولة العباسية (132 هـ - 656 هـ)</div>
               <h3 class="title-amiri fw-bold text-dark">عصر الترجمة والازدهار العلمي المشرق</h3>
               <p class="text-muted fs-5 mb-0">عاصمتها بغداد، درة تاج الدنيا. تميزت بالنهضة العلمية الجبارة وتأسيس "بيت الحكمة" إبان عهد هارون الرشيد والمأمون. برز فيها أئمة المذاهب وعباقرة العلوم من طب وفلك وكيمياء. سقطت عاصمتهم بشكل تراجيدي على يد جحافل المغول (التتار).</p>
            </div>
         </div>

         <!-- Era 5 -->
         <div class="t-node">
            <div class="t-node-content">
               <div class="t-era">الدول المتتابعة والمماليك (648 هـ - 923 هـ)</div>
               <h3 class="title-amiri fw-bold text-dark">درع الأمة وحماة الديار (كسر التتار والصليبيين)</h3>
               <p class="text-muted fs-5 mb-0">شهدت ظهور القادة العظام كعماد الدين زنكي وصلاح الدين الأيوبي لصد الحملات الصليبية المتعاقبة وفتح القدس. ثم استلم الراية دولة "المماليك" بمركزهم القاهرة، وهم الذين أنقذوا العالم الإسلامي من الإبادة المغولية في موقعة (عين جالوت) الكبرى.</p>
            </div>
         </div>

         <!-- Era 6 -->
         <div class="t-node">
            <div class="t-node-content">
               <div class="t-era">الخلافة العثمانية (699 هـ - 1342 هـ)</div>
               <h3 class="title-amiri fw-bold text-dark">قوة البحار وحامية المقدسات</h3>
               <p class="text-muted fs-5 mb-0">آخر خلافة إسلامية كبرى غطت 3 قارات. أتمّ السلطان الشاب محمد الفاتح الحلم الكبير بفتح (القسطنطينية)، وامتد نفوذهم حتى حصار فيينا في قلب أوروبا. حكموا مئات السنين وطوروا الأساطيل البحرية والمدفعية وكانوا درعاً منيعاً.</p>
            </div>
         </div>

      </div>
    </div>

    <!-- TAB 2: المعارك (Expanded) -->
    <div class="tab-pane fade" id="tab-battles">
      <div class="sec-head">
        <span class="tag">أيام الله الخالدة</span>
        <h3>المعارك <span>الفاصلة</span> الشاملة</h3>
        <p>عشر معارك غيرت مجرى مجرى دماء وعقائد البشرية، وثبتت فيها أقدام الأمة ورفعت راية التوحيد.</p>
        <div class="divider"></div>
      </div>

      <div class="row g-4">
         <!-- Battle 1 -->
         <div class="col-lg-6">
            <div class="battle-card">
               <i class="fas fa-meteor battle-sword"></i>
               <div class="battle-content">
                  <div class="b-date">غزوة بدر الكبرى (2 هـ)</div>
                  <h3 class="title-amiri fw-bold text-dark mb-3">يوم الفرقان</h3>
                  <div class="b-parties"><span class="badge bg-success">المسلمون (313)</span> <span class="b-vs">Vs</span> <span class="badge" style="background:var(--dark);">قريش (1000)</span></div>
                  <p class="text-muted">المواجهة العسكرية الأولى والأعظم. بقيادة النبي ﷺ، أنزل الله فيها الملائكة للقتال وانتهت بنصر إسلامي ساحق ومقتل رؤوس الكفر كأبي جهل، وأرست دعائم الأمة الأولى.</p>
               </div>
            </div>
         </div>
         
         <!-- Battle 2 -->
         <div class="col-lg-6">
            <div class="battle-card">
               <i class="fas fa-shield-alt battle-sword"></i>
               <div class="battle-content">
                  <div class="b-date">معركة اليرموك (15 هـ)</div>
                  <h3 class="title-amiri fw-bold text-dark mb-3">هزيمة الروم المطلقة</h3>
                  <div class="b-parties"><span class="badge bg-success">المسلمون (36 ألفاً)</span> <span class="b-vs">Vs</span> <span class="badge" style="background:#b91c1c;">البيزنطيون (200 ألف+)</span></div>
                  <p class="text-muted">قيادة العبقري خالد بن الوليد وأبو عبيدة. استمرت 6 أيام من التكتيك المذهل أسفرت عن إبادة جيش قيصر وإخراج الروم نهائياً من بلاد الشام.</p>
               </div>
            </div>
         </div>
         
         <!-- Battle 3 -->
         <div class="col-lg-6">
            <div class="battle-card">
               <i class="fas fa-khanda battle-sword"></i>
               <div class="battle-content">
                  <div class="b-date">معركة القادسية (15 هـ)</div>
                  <h3 class="title-amiri fw-bold text-dark mb-3">سقوط إيوان كسرى</h3>
                  <div class="b-parties"><span class="badge bg-success">المسلمون (30 ألفاً)</span> <span class="b-vs">Vs</span> <span class="badge" style="background:#c2410c;">الفرس الساسانيين (120 ألفاً)</span></div>
                  <p class="text-muted">بقيادة سعد بن أبي وقاص. معركة ملحمية استمرت بأيامها (أرماث، أغواث، عماس، والقادسية). أسفرت عن زوال إمبراطورية الفرس بالكامل ومقتل القائد رستم وفتح مدائن كسرى.</p>
               </div>
            </div>
         </div>

         <!-- Battle 4 -->
         <div class="col-lg-6">
            <div class="battle-card">
               <i class="fas fa-mountain battle-sword"></i>
               <div class="battle-content">
                  <div class="b-date">معركة وادي لكة (92 هـ)</div>
                  <h3 class="title-amiri fw-bold text-dark mb-3">فتح الأندلس المظفر</h3>
                  <div class="b-parties"><span class="badge bg-success">جيش طارق بن زياد (12 ألفاً)</span> <span class="b-vs">Vs</span> <span class="badge" style="background:#4338ca;">جيش القوط بقيادة لذريق (100 ألف)</span></div>
                  <p class="text-muted">المعركة التي دكت أبواب أوروبا. انتصار ساحق فتح الطريق للسيطرة على إسبانيا والبرتغال (الأندلس) لتؤسس أعظم حضارة أوروبية في العصور الوسطى.</p>
               </div>
            </div>
         </div>

         <!-- Battle 5 -->
         <div class="col-lg-6">
            <div class="battle-card">
               <i class="fas fa-horse battle-sword"></i>
               <div class="battle-content">
                  <div class="b-date">معركة الزلاقة (479 هـ / 1086 م)</div>
                  <h3 class="title-amiri fw-bold text-dark mb-3">تأخير سقوط الأندلس 4 قرون</h3>
                  <div class="b-parties"><span class="badge bg-success">المرابطون + الأندلسيون</span> <span class="b-vs">Vs</span> <span class="badge" style="background:#047857;">ممالك قشتالة الإسبانية</span></div>
                  <p class="text-muted">عبر يوسف بن تاشفين أمير المرابطين البحر لإنقاذ الأندلس. وهزم ألفونسو السادس هزيمة منكرة ساحقة، مما أطال عمر الوجود الإسلامي في الأندلس لأربعة قرون قادمة.</p>
               </div>
            </div>
         </div>

         <!-- Battle 6 -->
         <div class="col-lg-6">
            <div class="battle-card">
               <i class="fas fa-landmark battle-sword"></i>
               <div class="battle-content">
                  <div class="b-date">معركة ملاذكرد (463 هـ / 1071 م)</div>
                  <h3 class="title-amiri fw-bold text-dark mb-3">فتح آسيا الصغرى (تركيا)</h3>
                  <div class="b-parties"><span class="badge bg-success">السلاجقة (ألب أرسلان)</span> <span class="b-vs">Vs</span> <span class="badge" style="background:#6d28d9;">البيزنطيين (الإمبراطور رومانوس)</span></div>
                  <p class="text-muted">السلطان ألب أرسلان السلجوقي يرتدي كفنه الأبيض وينزل الميدان، ويأسر إمبراطور الروم شخصياً! فتحت المعركة أبواب تأسيس الأناضول الإسلامية (تركيا الحديثة).</p>
               </div>
            </div>
         </div>

         <!-- Battle 7 -->
         <div class="col-lg-6">
            <div class="battle-card">
               <i class="fas fa-gavel battle-sword"></i>
               <div class="battle-content">
                  <div class="b-date">معركة حطين (583 هـ / 1187 م)</div>
                  <h3 class="title-amiri fw-bold text-dark mb-3">مفتاح بيت المقدس</h3>
                  <div class="b-parties"><span class="badge bg-success">جيش صلاح الدين الأيوبي</span> <span class="b-vs">Vs</span> <span class="badge" style="background:#be123c;">الجيوش الصليبية المتحدة</span></div>
                  <p class="text-muted">استدراج عبقري هلك فيه الصليبيون عطشاً وضرباً، دمر صلاح الدين القوة الضاربة لممالك بيت المقدس وأسر ملكهم وأنهى الاحتلال الأول للقدس والأقصى الشريف.</p>
               </div>
            </div>
         </div>

         <!-- Battle 8 -->
         <div class="col-lg-6">
            <div class="battle-card">
               <i class="fas fa-bolt battle-sword"></i>
               <div class="battle-content">
                  <div class="b-date">معركة عين جالوت (658 هـ / 1260 م)</div>
                  <h3 class="title-amiri fw-bold text-dark mb-3">قاهر التتار وإنقاذ العالم</h3>
                  <div class="b-parties"><span class="badge bg-success">المماليك (قطز وبيبرس)</span> <span class="b-vs">Vs</span> <span class="badge" style="background:#171717;">الجيش المغولي (التتار)</span></div>
                  <p class="text-muted">المغول قوة لا تقهر أسقطت بغداد وقتلت الملايين! تصدى لهم المماليك بمعجزة تكتيكية في فلسطين وأبادوا جيش هولاكو ليرتفع نداء (وا إسلاماه!) محطماً أسطورة المغول للأبد.</p>
               </div>
            </div>
         </div>
      </div>
    </div>

    <!-- TAB 3: القادة (Expanded) -->
    <div class="tab-pane fade" id="tab-heroes">
      <div class="sec-head">
        <span class="tag">صناع التاريخ وصياغ الأمجاد</span>
        <h3>قادة وفرسان <span>الأمة الإسلامية</span></h3>
        <p>التاريخ يُصنع بالرجال. نبذة عن العظماء الذين تربعوا على حصان التاريخ فغيروا واجهة الإنسانية.</p>
        <div class="divider"></div>
      </div>

      <div class="row g-4 justify-content-center">
         <div class="col-lg-4 col-md-6">
            <div class="mega-card text-center pb-4">
               <div class="hero-portrait"><i class="fas fa-user-shield"></i></div>
               <h3 class="title-amiri fw-bold text-dark">الفاروق عمر بن الخطاب</h3>
               <div class="badge bg-dark mb-3 w-100 p-2">أمير المؤمنين ومؤسس الدولة المؤسسية</div>
               <p class="text-muted small">عبقري الإدارة والعدل، قاهر إمبراطوريتي كسرى وقيصر. أسس الدواوين والتاريخ الهجري وفتح بيت المقدس بالسلام. كان الشيطان يسلك فجاً غير فجه لشدة هيبته وعدله.</p>
            </div>
         </div>
         <div class="col-lg-4 col-md-6">
            <div class="mega-card text-center pb-4">
               <div class="hero-portrait"><i class="fas fa-khanda"></i></div>
               <h3 class="title-amiri fw-bold text-dark">خالد بن الوليد</h3>
               <div class="badge bg-dark mb-3 w-100 p-2">سيف الله المسلول (ت 21 هـ)</div>
               <p class="text-muted small">لم تفخر أمة بعبقرية عسكرية كما فخرت بخالد! صاحب خطة اليرموك المذهلة وقاهر المرتدين، خاض أكثر من مائة زحف ولم يهزم قط. أسلم وبكى على كل لحظة كان فيها مع غير الله.</p>
            </div>
         </div>
         <div class="col-lg-4 col-md-6">
            <div class="mega-card text-center pb-4">
               <div class="hero-portrait"><i class="fas fa-map-marker-alt"></i></div>
               <h3 class="title-amiri fw-bold text-dark">طارق بن زياد</h3>
               <div class="badge bg-dark mb-3 w-100 p-2">الفاتح الأمازيغي الملهم (92 هـ)</div>
               <p class="text-muted small">قائد مسلم بربري من أبطال الشمال الأفريقي، قاد حملة الفتح الكبرى للأندلس بجيش أغلبه من الأمازيغ ليصنع أكبر وأطول نصر استراتيجي ورفع التوحيد في أقاصي أوروبا.</p>
            </div>
         </div>
         <div class="col-lg-4 col-md-6">
            <div class="mega-card text-center pb-4">
               <div class="hero-portrait"><i class="fas fa-crown"></i></div>
               <h3 class="title-amiri fw-bold text-dark">عبد الرحمن الداخل</h3>
               <div class="badge bg-dark mb-3 w-100 p-2">صقر قريش والمؤسس العظيم</div>
               <p class="text-muted small">فرّ وحيداً مطارداً بعد سقوط أسرة بني أمية وقطع آلاف الأميال ليصل الأندلس ويؤسس دولة أموية مستقلة حمت الإسلام من السقوط والإبادة، شهد له أعداؤه بالعبقرية.</p>
            </div>
         </div>
         <div class="col-lg-4 col-md-6">
            <div class="mega-card text-center pb-4">
               <div class="hero-portrait"><i class="fas fa-drum-steelpan"></i></div>
               <h3 class="title-amiri fw-bold text-dark">يوسف بن تاشفين</h3>
               <div class="badge bg-dark mb-3 w-100 p-2">أمير المسلمين وقاهر الصليبيين</div>
               <p class="text-muted small">بطل معركة الزلاقة. مؤسس إمبراطورية المرابطين وعاصمتها مراكش المحصنة. رفض كل أشكال البذخ الفاسدة ولُقب بأمير المسلمين احتراماً للخلافة العباسية رغم قوته الجبارة.</p>
            </div>
         </div>
         <div class="col-lg-4 col-md-6">
            <div class="mega-card text-center pb-4">
               <div class="hero-portrait"><i class="fas fa-fist-raised"></i></div>
               <h3 class="title-amiri fw-bold text-dark">صلاح الدين الأيوبي</h3>
               <div class="badge bg-dark mb-3 w-100 p-2">السلطان الناصر محرر القدس</div>
               <p class="text-muted small">وحد مصر والشام وقاد معركة حطين. يُعد مضرب المثل في التسامح وشرف الفروسية والرحمة مع أعدائه المهزومين، خُلد اسمه في تاريخ الشرق والغرب باحترام مهيب والكل يعرف فروسيته.</p>
            </div>
         </div>
         <div class="col-lg-4 col-md-6">
            <div class="mega-card text-center pb-4">
               <div class="hero-portrait"><i class="fas fa-shield-alt"></i></div>
               <h3 class="title-amiri fw-bold text-dark">سيف الدين قطز</h3>
               <div class="badge bg-dark mb-3 w-100 p-2">قاهر التتار وإنقاذ العالم</div>
               <p class="text-muted small">أمير المماليك المملوك الذي بيع في الأسواق ثم صار سلطان مصر. صرخ صرخته المدوية 'وا إسلاماه' حين تراجع جيشه أمام المغول فرمى خوذته واندفع في صفوف التتار فأبادهم بعين جالوت.</p>
            </div>
         </div>
         <div class="col-lg-4 col-md-6">
            <div class="mega-card text-center pb-4">
               <div class="hero-portrait"><i class="fas fa-city"></i></div>
               <h3 class="title-amiri fw-bold text-dark">محمد الفاتح</h3>
               <div class="badge bg-dark mb-3 w-100 p-2">السلطان العثماني (نعم الأمير أميرها)</div>
               <p class="text-muted small">تسلم الحكم فتحدث لـ 6 لغات! حقق نبوءة أجداده بفتح القسطنطينية المحصنة التي عجزت أمامها الجيوش لمئات السنين، ونقل السفن العسكرية عبر الجبال في سابقة تاريخية عسكرية!</p>
            </div>
         </div>
      </div>
    </div>

    <!-- TAB 4: الحضارة (Massively Expanded) -->
    <div class="tab-pane fade" id="tab-civ">
      <div class="sec-head">
        <span class="tag">أخرجت العالم من عصور الظلام إلى التنوير</span>
        <h3>روائع <span>الحضارة والعلوم</span> وإسهاماتها</h3>
        <p>لم تكن حضارة المسلمين مقتصرة على الغزوات، بل كانت حضارة علمية مبهرة شملت فروع الفكر والهندسة والطب الكونية التي أسست النهضة المعاصرة.</p>
        <div class="divider"></div>
      </div>

      <div class="row g-4 text-center">
         <div class="col-lg-3 col-md-6">
            <div class="mega-card">
               <i class="fas fa-square-root-alt fa-3x mb-3 text-warning"></i>
               <h4 class="title-amiri fw-bold text-dark">الرياضيات الخوارزمية (الجبر)</h4>
               <p class="text-muted small" style="text-align:justify;">ابتكار (الصفر)، وتأسيس علم (الجبر) كعلم مستقل على يد الخوارزمي. وتسمية المعالجة المنطقية بـ (Algorithm) نسبة إلى اسمه باللاتينية، واختراع الأرقام الحديثة (الزوايا).</p>
            </div>
         </div>
         <div class="col-lg-3 col-md-6">
            <div class="mega-card">
               <i class="fas fa-heartbeat fa-3x mb-3 text-danger"></i>
               <h4 class="title-amiri fw-bold text-dark">الطب والجراحة (الزهراوي)</h4>
               <p class="text-muted small" style="text-align:justify;">ابن النفيس أول من اكتشف (الدورة الدموية الصغرى)، والرازي اكتشف الحصبة والجدري، بينما الزهراوي أبو الجراحة الحديثة ابتكر 200 أداة جراحية وخيوط الجراحة من أمعاء الحيوان المذابة.</p>
            </div>
         </div>
         <div class="col-lg-3 col-md-6">
            <div class="mega-card">
               <i class="fas fa-eye fa-3x mb-3 text-info"></i>
               <h4 class="title-amiri fw-bold text-dark">علم البصريات والكاميرا</h4>
               <p class="text-muted small" style="text-align:justify;">الحسن بن الهيثم العالم العملاق الذي صحح النظريات اليونانية وأثبت أن الضوء ينعكس على العين ولا يخرج منها، وهو أول من اخترع (القُمرة) (Camera Obscura) وصاغ قوانين الانكسار.</p>
            </div>
         </div>
         <div class="col-lg-3 col-md-6">
            <div class="mega-card">
               <i class="fas fa-flask fa-3x mb-3 text-purple" style="color:#7c3aed;"></i>
               <h4 class="title-amiri fw-bold text-dark">علم الكيمياء التجريبية</h4>
               <p class="text-muted small" style="text-align:justify;">انتقلت الكيمياء من الشعوذة والسحر والصنعة الوهمية إلى علم (التجربة والمنهج العلمي) على يد جابر بن حيان. اكتشف الأحماض الصعبة كـ (الماء الملكي) وعمليات التقطير الكهرماني والموازين.</p>
            </div>
         </div>
         <div class="col-lg-3 col-md-6">
            <div class="mega-card">
               <i class="fas fa-globe-africa fa-3x mb-3 text-success"></i>
               <h4 class="title-amiri fw-bold text-dark">الجغرافيا ورسم الخرائط</h4>
               <p class="text-muted small" style="text-align:justify;">الإدريسي العالم الباهر رسم أدق وأفضل خريطة للعالم في وقته (خريطة الإدريسي) للملك روجر الكرواتي، ومثلت الأرض بشكل كروي من مئات السنين قبل التطور التقني الغربي المعاصر.</p>
            </div>
         </div>
         <div class="col-lg-3 col-md-6">
            <div class="mega-card">
               <i class="fas fa-star-moon fa-3x mb-3 text-dark"></i>
               <h4 class="title-amiri fw-bold text-dark">الفلك والاسطرلاب</h4>
               <p class="text-muted small" style="text-align:justify;">صحح العلماء كالبيروني والزرقلّي جداول الفلك لتحديد الأوقات للصلاة وحركة الكواكب وابتكروا (الإسطرلاب) كحاسوب جيبي قديم لحساب الوقت والاتجاهات ومعرفة القبلة والملاحة البحرية.</p>
            </div>
         </div>
         <div class="col-lg-3 col-md-6">
            <div class="mega-card">
               <i class="fas fa-users fa-3x mb-3 text-secondary"></i>
               <h4 class="title-amiri fw-bold text-dark">علم العمران والاجتماع</h4>
               <p class="text-muted small" style="text-align:justify;">العلامة القاضي عبد الرحمن بن خلدون هو المؤسس والعبقري الأول لعلم الاجتماع البشري. شرح قيام الدول وسقوطها في كتابه الضخم (المقدمة) والذي لا تزال تدرس أطروحاته عالمياً حتى الآن في ستانفورد.</p>
            </div>
         </div>
         <div class="col-lg-3 col-md-6">
            <div class="mega-card">
               <i class="fas fa-university fa-3x mb-3 text-primary"></i>
               <h4 class="title-amiri fw-bold text-dark">المؤسسات والجامعات والبيمارستان</h4>
               <p class="text-muted small" style="text-align:justify;">بيمارستان (المستشفيات المتقدمة بالمجان). كما تأسست (جامعة القرويين) في فاس أقدم جامعة تعمل بلا توقف بالتاريخ بتمويل امرأة هي فاطمة الفهرية. وتأسس الأزهر الشريف بمصر والزيتونة بتونس كمنارات علم.</p>
            </div>
         </div>
      </div>
    </div> <!-- /TAB 4 -->

    <!-- TAB 5: المعالم الإسلامية -->
    <div class="tab-pane fade" id="tab-landmarks">
      <div class="sec-head">
        <span class="tag">إرث معماري خالد</span>
        <h3>أبرز <span>المعالم الإسلامية</span> وأمجاد العمارة</h3>
        <p>صروح عملاقة ومعالم مقدسة تعكس عظمة الفن الإسلامي والإبداع الهندسي عبر العصور.</p>
        <div class="divider"></div>
      </div>
      <div class="row g-4">
         <div class="col-lg-6">
            <div class="mega-card d-flex align-items-center gap-4 text-end">
               <i class="fas fa-kaaba fa-4x text-dark"></i>
               <div>
                  <h4 class="title-amiri fw-bold mb-2">المسجد الحرام والكعبة المشرفة</h4>
                  <p class="text-muted small mb-0">أقدس البقاع وأول بيت وضع للناس، بناه إبراهيم عليه السلام وطوره الخلفاء. يأتيه المسلمون من كل فج عميق.</p>
               </div>
            </div>
         </div>
         <div class="col-lg-6">
            <div class="mega-card d-flex align-items-center gap-4 text-end">
               <i class="fas fa-mosque fa-4x text-success"></i>
               <div>
                  <h4 class="title-amiri fw-bold mb-2">المسجد الأقصى (قبة الصخرة)</h4>
                  <p class="text-muted small mb-0">أولى القبلتين وثالث الحرمين ومسرى الرسول ﷺ. درة العمارة الأموية، بناه عبد الملك بن مروان وكساه بالذهب.</p>
               </div>
            </div>
         </div>
         <div class="col-lg-6">
            <div class="mega-card d-flex align-items-center gap-4 text-end">
               <i class="fas fa-archway fa-4x text-primary"></i>
               <div>
                  <h4 class="title-amiri fw-bold mb-2">الجامع الأموي بدمشق</h4>
                  <p class="text-muted small mb-0">من عجائب العمارة الإسلامية القديمة. أدخل الفسيفساء الذهبية العملاقة وأسس نظام المآذن المربعة وتأثرت به كل المساجد.</p>
               </div>
            </div>
         </div>
         <div class="col-lg-6">
            <div class="mega-card d-flex align-items-center gap-4 text-end">
               <i class="fas fa-vihara fa-4x text-danger"></i>
               <div>
                  <h4 class="title-amiri fw-bold mb-2">قصر الحمراء (غرناطة)</h4>
                  <p class="text-muted small mb-0">أعظم أثر إسلامي في الأندلس واوروبا. يُعد معجزة في هندسة المياه والمقرنصات والنقوش الجصية المعقدة.</p>
               </div>
            </div>
         </div>
      </div>
    </div> <!-- /TAB 5 -->

    <!-- TAB 6: إحصائيات -->
    <div class="tab-pane fade" id="tab-stats">
      <div class="sec-head">
        <span class="tag">لغة الماضي بلغة الأرقام</span>
        <h3>التاريخ <span>بالأرقام</span> المدهشة</h3>
        <p>حقائق رقمية تبرز حجم الامتداد والتأثير لأمة الإسلام في تاريخ الأرض.</p>
        <div class="divider"></div>
      </div>
      <div class="row g-4 text-center justify-content-center">
         <div class="col-md-4">
            <div class="battle-card py-5">
               <i class="fas fa-globe-asia battle-sword" style="color:var(--primary);opacity:0.1;font-size:12rem;"></i>
               <div class="position-relative z-index-2">
                  <h2 class="display-3 fw-bold text-dark font-amiri mb-2">22.5</h2>
                  <h5 class="text-muted fw-bold">مليون كم مربع</h5>
                  <p class="small text-muted mt-3">أقصى اتساع جغرافي وصلته الخلافة الأموية، وهي من أكبر الإمبراطوريات التي عرفها التاريخ البشري قاطبة.</p>
               </div>
            </div>
         </div>
         <div class="col-md-4">
            <div class="battle-card py-5">
               <i class="fas fa-book-reader battle-sword" style="color:var(--primary);opacity:0.1;font-size:12rem;"></i>
               <div class="position-relative z-index-2">
                  <h2 class="display-3 fw-bold text-dark font-amiri mb-2">781</h2>
                  <h5 class="text-muted fw-bold">عاماً هجرياً</h5>
                  <p class="small text-muted mt-3">مدة الحكم الإسلامي في الأندلس (شبه الجزيرة الأيبيرية)، أطول فترة استقرار حضاري في غرب أوروبا.</p>
               </div>
            </div>
         </div>
         <div class="col-md-4">
            <div class="battle-card py-5">
               <i class="fas fa-chart-line battle-sword" style="color:var(--primary);opacity:0.1;font-size:12rem;"></i>
               <div class="position-relative z-index-2">
                  <h2 class="display-3 fw-bold text-dark font-amiri mb-2">2.1</h2>
                  <h5 class="text-muted fw-bold">مليار مسلم</h5>
                  <p class="small text-muted mt-3">حصاد تلك الدعوة التي بدأت برجل واحد ﷺ في مكة، لتغطي شعوب وقبائل العالم في يومنا المعاصر.</p>
               </div>
            </div>
         </div>
      </div>
    </div> <!-- /TAB 6 -->

  </div> <!-- End Tabs -->
</div>

<!-- MEGA FOOTER -->
<footer class="mega-footer" style="background:linear-gradient(135deg,var(--dark),#020617);color:white;padding:80px 0 30px;margin-top:80px;border-top:3px solid var(--gold-dark);">
  <div class="container">
    <div class="row g-5 mb-5 border-bottom border-light border-opacity-10 pb-5">
      <div class="col-lg-4 text-md-end text-center">
        <i class="fas fa-mosque fa-4x text-warning mb-4 d-block"></i>
        <h4 class="fw-bold font-amiri fs-2 mb-3">الموسوعة الإسلامية الشاملة</h4>
        <p class="opacity-75 fs-6 line-height-2">أضخم صرح رقمي يجمع علوم القرآن العظيم، وأحاديث المصطفى، وفقهاء المذاهب، والتاريخ المجيد في منصة موثقة مصممة بأحدث التقنيات.</p>
      </div>
      <div class="col-lg-4 text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">تصفح الموسوعة</h5>
        <div class="d-flex flex-wrap justify-content-center gap-2">
          <a href="recitations.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">أكاديمية القرآن</a>
          <a href="hadith.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الحديث النبوي</a>
          <a href="seerah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">السيرة والصحابة</a>
          <a href="fiqh.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الفقه وأصوله</a>
          <a href="fatwa.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">فتاوى العلماء</a>
          <a href="aqeedah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">العقيدة الإسلامية</a>
          <a href="history.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">التاريخ المجيد</a>
          <a href="library.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">المكتبة الشاملة</a>
        </div>
      </div>
      <div class="col-lg-4 text-md-start text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">روابط سريعة</h5>
        <a href="contact.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> اتصل بالمطور</a>
        <a href="share.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> شارك الأجر</a>
        <a href="login.html" class="mega-footer-link text-warning mt-3" style="text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-user-circle me-2 ms-1"></i> تسجيل الدخول</a>
      </div>
    </div>
    <div class="text-center font-amiri fs-5 d-flex flex-column gap-2">
      <span class="opacity-75">الموسوعة الإسلامية الشاملة &copy; 2026 تم التصميم للإفادة | عمل مجاني لوجه الله</span>
      <span class="text-warning fw-bold fs-4 mt-2">تصميم وتطوير: لخذاري محمد سيف الدين</span>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Timeline Scroll Animation and overall reveals
document.addEventListener("DOMContentLoaded", function() {
  const observerOptions = { root: null, rootMargin: '0px', threshold: 0.1 };
  const observer = new IntersectionObserver((entries, obs) => {
    entries.forEach(entry => {
      if(entry.isIntersecting) {
        entry.target.classList.add('show');
        obs.unobserve(entry.target);
      }
    });
  }, observerOptions);

  document.querySelectorAll('.t-node, .battle-card, .hero-portrait').forEach(node => {
    // Ensuring everything has a baseline hidden state for animation
    if(node.classList.contains('battle-card') || node.classList.contains('hero-portrait')) {
        node.style.opacity = '0';
        node.style.transform = 'translateY(30px)';
        node.style.transition = 'all 0.6s ease-out';
    }
    observer.observe(node);
  });
  
  // Custom manual trigger for elements when tab changes
  const tabEls = document.querySelectorAll('button[data-bs-toggle="tab"]');
  tabEls.forEach(tab => {
      tab.addEventListener('shown.bs.tab', function (event) {
          const target = document.querySelector(event.target.getAttribute('data-bs-target'));
          target.querySelectorAll('.battle-card, .hero-portrait, .mega-card').forEach(el => {
              el.style.opacity = '1';
              el.style.transform = 'translateY(0)';
          });
      })
  });
});
</script>
</body>
</html>
"""

with codecs.open(r"C:\Users\ST\Desktop\islamic.encyclopedia\history.html", "w", "utf-8") as f:
    f.write(html)
print("history.html MEGA ENRICHED done.")
