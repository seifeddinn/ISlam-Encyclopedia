import codecs
f = codecs.open("seerah.html","a","utf-8")
f.write("""
<!-- TAB 2: MORALS (SHAMA'IL) -->
<div class="tab-pane fade" id="t2">
  <div class="sec-head" data-aos="fade-up">
    <div class="badge-tag">وَإِنَّكَ لَعَلَىٰ خُلُقٍ عَظِيمٍ</div>
    <h2 class="amiri">الشمائل <span>المحمدية</span></h2>
    <p>صفاته الخلقية والخُلقية ومعجزاته الحسية الشريفة صلوات الله وسلامه عليه اجمعين</p>
    <div class="gold-divider"></div>
  </div>

  <div class="bg-white rounded-4 shadow-lg p-5 mb-5 border-start border-5 border-danger" data-aos="fade-up">
    <div class="row align-items-center g-4">
      <div class="col-lg-8">
        <h3 class="amiri fw-bold text-dark mb-3"><i class="fas fa-quote-right text-danger me-2"></i>كَانَ خُلُقُهُ الْقُرْآن</h3>
        <p class="fs-4 text-muted lh-xl mb-0">سئلت السيدة عائشة رضي الله عنها عن خُلُق النبي ﷺ فقالت: "كان خلقه القرآن. أما تقرأ القرآن؟ قول الله: ﴿وَإِنَّكَ لَعَلَىٰ خُلُقٍ عَظِيمٍ﴾." — رواه مسلم. فكل خُلق حسن أمر به القرآن كان النبي ﷺ ذروته وتجسيده الحي والأتم.</p>
      </div>
      <div class="col-lg-4 text-center"><i class="fas fa-sun fa-6x text-warning" style="filter:drop-shadow(0 0 25px rgba(212,175,55,.6));"></i></div>
    </div>
  </div>

  <h3 class="amiri fw-bold text-dark mb-4 mt-4 text-center fs-2" data-aos="fade-up">أولاً: الصفة الخَلقية (الوصف الجسدي)</h3>
  <div class="bg-white rounded-4 p-4 mb-5 shadow" data-aos="fade-up">
    <p class="fs-5 text-muted lh-xl text-center amiri mb-0">قالت أم معبد في وصفها للنبي ﷺ: <strong class="text-dark">"ظاهر الوضاءة، أبلج الوجه، حسن الخَلق، لم تعبه نُحلة، ولم تُزرِ به صُعلة، جليٌّ مُشرب، في عينيه دعج، وفي أشفاره وطف، في صوته صحل، أحور أكحل، أزج، أقرن، شديد سواد الشعر... أبهى الناس وأجملهم من بعيد، وأحلاهم وأجملهم عند الدنو والمقاربة."</strong></p>
  </div>

  <h3 class="amiri fw-bold text-dark mb-4 text-center fs-2" data-aos="fade-up">ثانياً: الصفات الخُلقية</h3>
  <div class="row g-4 mb-5">
    <div class="col-lg-6 col-md-6" data-aos="fade-up"><div class="moral-card"><div class="moral-icon"><i class="fas fa-hand-holding-heart"></i></div><h3 class="amiri fw-bold mb-3">الرحمة الشاملة</h3><p class="text-muted fs-5">﴿وَمَا أَرْسَلْنَاكَ إِلَّا رَحْمَةً لِّلْعَالَمِينَ﴾. رحمته شملت الأعداء كفتح مكة، والأطفال، والحيوانات، وحتى الجماد كحنين جذع النخلة.</p></div></div>
    <div class="col-lg-6 col-md-6" data-aos="fade-up" data-aos-delay="50"><div class="moral-card"><div class="moral-icon"><i class="fas fa-balance-scale"></i></div><h3 class="amiri fw-bold mb-3">العدل المطلق</h3><p class="text-muted fs-5">"لو أن فاطمة بنت محمد سرقت لقطعت يدها." لا محاباة في الحق ولا ظلم، وكان أعدل حاكم وقاضٍ عرفه التاريخ.</p></div></div>
    <div class="col-lg-6 col-md-6" data-aos="fade-up"><div class="moral-card"><div class="moral-icon"><i class="fas fa-heart"></i></div><h3 class="amiri fw-bold mb-3">التواضع والبشاشة</h3><p class="text-muted fs-5">كان يخيط ثوبه ويحلب شاته ويجالس الفقراء. يدخل الغريب المسجد فلا يعرفه من بينهم. كان تبسمه في وجه كل من يلقاه صدقةً.</p></div></div>
    <div class="col-lg-6 col-md-6" data-aos="fade-up" data-aos-delay="50"><div class="moral-card"><div class="moral-icon"><i class="fas fa-shield-alt"></i></div><h3 class="amiri fw-bold mb-3">الشجاعة الثابتة</h3><p class="text-muted fs-5">في حنين حين ولّى الناس ثبت وحده على بغلته ينادي: "أنا النبي لا كذب". كانت الصحابة تحتمي به أشد ما يكون الكفاح.</p></div></div>
    <div class="col-lg-6 col-md-6" data-aos="fade-up"><div class="moral-card"><div class="moral-icon"><i class="fas fa-hands-helping"></i></div><h3 class="amiri fw-bold mb-3">الكرم والسخاء</h3><p class="text-muted fs-5">كان أجود الناس، لم يرد سائلاً قط. قال جابر: "ما سُئل ﷺ شيئاً قط فقال لا." وكان يعطي عطاء من لا يخشى الفقر.</p></div></div>
    <div class="col-lg-6 col-md-6" data-aos="fade-up" data-aos-delay="50"><div class="moral-card"><div class="moral-icon"><i class="fas fa-laugh-beam"></i></div><h3 class="amiri fw-bold mb-3">المزاح والمداعبة</h3><p class="text-muted fs-5">كان يمزح ولا يقول إلا حقاً. قال للعجوز: "لا تدخل العجائز الجنة" ثم أراها: يدخلن وهن شابات بنص القرآن. وناداه ابن عمر "يا رسول الله" فقال: هدأ يا أبا عبد الرحمن!</p></div></div>
    <div class="col-lg-6 col-md-6" data-aos="fade-up"><div class="moral-card"><div class="moral-icon"><i class="fas fa-pray"></i></div><h3 class="amiri fw-bold mb-3">العبادة والزهد</h3><p class="text-muted fs-5">كان يقوم الليل حتى تتفطر قدماه، فتقول له عائشة: قد غفر الله لك ما تقدم من ذنبك وما تأخر. فيقول: "أفلا أكون عبداً شكوراً؟"</p></div></div>
    <div class="col-lg-6 col-md-6" data-aos="fade-up" data-aos-delay="50"><div class="moral-card"><div class="moral-icon"><i class="fas fa-user-friends"></i></div><h3 class="amiri fw-bold mb-3">الوفاء والحياء</h3><p class="text-muted fs-5">كان أشد حياءً من العذراء في خدرها. وكان أوفى الناس بالعهود؛ ظل يكرم صواحب خديجة بعد وفاتها تكريماً لعهدها.</p></div></div>
  </div>

  <h3 class="amiri fw-bold text-dark mb-4 text-center fs-2" data-aos="fade-up">ثالثاً: المعجزات الحسية الكبرى</h3>
  <div class="row g-4">
    <div class="col-md-6 col-lg-3" data-aos="zoom-in"><div class="bayt-card"><div class="bayt-icon"><i class="fas fa-moon"></i></div><h4 class="amiri fw-bold text-dark">انشقاق القمر</h4><p class="text-muted">طلب المشركون آيةً فانشق القمر فلقتين بإذن الله. قال تعالى: ﴿اقْتَرَبَتِ السَّاعَةُ وَانشَقَّ الْقَمَر﴾.</p></div></div>
    <div class="col-md-6 col-lg-3" data-aos="zoom-in" data-aos-delay="50"><div class="bayt-card"><div class="bayt-icon"><i class="fas fa-tree"></i></div><h4 class="amiri fw-bold text-dark">حنين الجذع</h4><p class="text-muted">لما انتقل ﷺ من جذع نخلة كان يخطب عليه إلى المنبر، حنّ الجذعُ حنين الولد وبكى الصحابة.</p></div></div>
    <div class="col-md-6 col-lg-3" data-aos="zoom-in" data-aos-delay="100"><div class="bayt-card"><div class="bayt-icon"><i class="fas fa-faucet"></i></div><h4 class="amiri fw-bold text-dark">نبع الماء من أصابعه</h4><p class="text-muted">في الحديبية أخرج يده من الإناء فانبجس الماء من بين أصابعه وشرب منه الجيش كله.</p></div></div>
    <div class="col-md-6 col-lg-3" data-aos="zoom-in" data-aos-delay="150"><div class="bayt-card"><div class="bayt-icon"><i class="fas fa-bread-slice"></i></div><h4 class="amiri fw-bold text-dark">تكثير الطعام</h4><p class="text-muted">طعام جابر اليسير أشبع جيش الخندق كله. وطعام أبي هريرة أكل منه أهل الصُفّة جميعاً.</p></div></div>
  </div>
</div><!-- end t2 -->
""")
f.close()
print("Part 4 done")
