import codecs
f = codecs.open("seerah.html","a","utf-8")
f.write("""
<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-dark sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold" href="index.html"><i class="fas fa-book-open me-2 text-warning"></i>الموسوعة الإسلامية الشاملة</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav1">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="nav1">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link " href="index.html">الرئيسية</a></li>
        <li class="nav-item"><a class="nav-link " href="recitations.html">القرآن والتلاوات</a></li>
        <li class="nav-item"><a class="nav-link " href="hadith.html">الحديث الشريف</a></li>
        <li class="nav-item"><a class="nav-link " href="fiqh.html">الفقه الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="fatwa.html">فتاوى العلماء <i class="fas fa-gavel"></i></a></li>
        <li class="nav-item"><a class="nav-link active" href="seerah.html">السيرة والصحابة</a></li>
        <li class="nav-item"><a class="nav-link " href="aqeedah.html">العقيدة الإسلامية</a></li>
        <li class="nav-item"><a class="nav-link " href="history.html">التاريخ الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="library.html">المكتبة الشاملة</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- HERO -->
<section class="seerah-hero">
  <div class="hero-arabesque"></div>
  <div class="orb orb1"></div><div class="orb orb2"></div>
  <div class="container hero-content">
    <div class="hero-pill" data-aos="fade-down"><i class="fas fa-star text-warning me-2"></i>أكبر مرجع رقمي للسيرة النبوية الشريفة</div>
    <h1 class="hero-h1 amiri mb-4" data-aos="fade-up">موسوعة <em>السيرة النبوية</em><br>والصحابة الكرام</h1>
    <p class="hero-ayah" data-aos="fade-up" data-aos-delay="100">﴿ <span>لَقَدْ كَانَ لَكُمْ فِي رَسُولِ اللَّهِ أُسْوَةٌ حَسَنَةٌ لِّمَن كَانَ يَرْجُو اللَّهَ وَالْيَوْمَ الْآخِرَ</span> ﴾<br><small style="color:rgba(255,255,255,.6);">— سورة الأحزاب: 21</small></p>
    <div class="hero-badges" data-aos="fade-up" data-aos-delay="200">
      <div class="hero-badge"><strong>23</strong><small>سنة النبوة</small></div>
      <div class="hero-badge"><strong>27+</strong><small>غزوة ومعركة</small></div>
      <div class="hero-badge"><strong>10</strong><small>مبشرون بالجنة</small></div>
      <div class="hero-badge"><strong>11</strong><small>أم المؤمنين</small></div>
      <div class="hero-badge"><strong>∞</strong><small>محبةً وشوقاً</small></div>
    </div>
  </div>
</section>

<div class="container">
<!-- TABS NAV -->
<div class="tabs-bar" data-aos="fade-up">
  <ul class="nav nav-pills" id="sTabs" role="tablist">
    <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#t1"><i class="fas fa-route"></i>التسلسل الزمني</button></li>
    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t2"><i class="fas fa-seedling"></i>الشمائل المحمدية</button></li>
    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t3"><i class="fas fa-users"></i>الصحابة والأزواج</button></li>
    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t4"><i class="fas fa-map-marked-alt"></i>المعارك الفاصلة</button></li>
    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t5"><i class="fas fa-heart"></i>أهل البيت</button></li>
    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t6"><i class="fas fa-quran"></i>السيرة في القرآن</button></li>
    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t7"><i class="fas fa-scroll"></i>منارات الوحي</button></li>
  </ul>
</div>
<div class="tab-content pb-5">
""")
f.close()
print("Part 2 done")
