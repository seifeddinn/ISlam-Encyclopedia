import re
import json

file_path = r"c:\Users\ST\Desktop\islamic.encyclopedia\library.html"

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

# Regular expression to find all book items
# data-category="..." -> title, author, badge text, icon
book_pattern = re.compile(
    r'<div class="col-md-4 col-lg-3 book-item" data-category="([^"]+)">.*?<div class="icon-wrapper"><i class="fas fa-([a-z0-9-]+) mb-0"></i></div>.*?<h5 class="card-title">([^<]+)</h5>.*?<p class="card-text text-muted small">([^<]+)</p>.*?<span class="badge custom-badge [^"]+ mb-3">([^<]+)</span>',
    re.DOTALL
)

books = []
for match in book_pattern.finditer(content):
    category_id = match.group(1).strip()
    icon = match.group(2).strip()
    title = match.group(3).strip()
    author = match.group(4).strip()
    category_name = match.group(5).strip()

    books.append({
        "id": category_id,
        "icon": icon,
        "title": title,
        "author": author,
        "categoryName": category_name
    })

js_content = "const booksData = " + json.dumps(books, ensure_ascii=False, indent=4) + ";"

output_path = r"c:\Users\ST\Desktop\islamic.encyclopedia\books.js"
with open(output_path, 'w', encoding='utf-8') as f:
    f.write(js_content)

print(f"Extracted {len(books)} books successfully!")
