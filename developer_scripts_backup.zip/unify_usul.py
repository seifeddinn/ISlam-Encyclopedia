<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>أصول الفقه - الموسوعة الإسلامية الشاملة</title>
    <link href="https://fonts.googleapis.com/css2?family=Amiri:ital,wght@0,400;0,700;1,400&family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root{--gold:#d4af37;--dark:#064e3b;--primary:#047857;--secondary:#10b981;} /* Emerald green theme for Usul */
        body{font-family:'Cairo',sans-serif;background:#f8fafc;color:#1e293b;overflow-x:hidden;}
        h1,h2,h3,h4,h5,h6,.amiri{font-family:'Amiri',serif;}
        
        /* MEGA NAVBAR */
        .navbar {background:linear-gradient(135deg,var(--dark),#065f46)!important;box-shadow:0 4px 30px rgba(0,0,0,.5);z-index:1000;border-bottom:2px solid rgba(212,175,55,0.2);}
        .navbar-brand{font-family:'Amiri',serif;font-size:1.8rem;color:white!important;text-shadow:0 2px 10px rgba(212,175,55,0.5);}
        .nav-link{color:rgba(255,255,255,.8)!important;font-weight:700;letter-spacing:0.5px;transition:all .3s;}
        .nav-link:hover, .nav-link.active{color:var(--gold)!important;transform:translateX(-2px);}

        /* MEGA HERO */
        .mega-hero {background:radial-gradient(circle at 50% 50%, #065f46 0%, #022c22 80%); padding:120px 0 100px; text-align:center; position:relative; overflow:hidden;}
        .mega-hero::before {content:''; position:absolute; inset:0; background:url('https://www.transparenttextures.com/patterns/stardust.png'); opacity:0.15; mix-blend-mode:overlay;}
        .hero-diamond {width:120px; height:120px; background:linear-gradient(135deg, var(--gold), #baa54d); transform:rotate(45deg); display:flex; align-items:center; justify-content:center; margin:0 auto 40px; border:8px solid rgba(255,255,255,0.1); box-shadow:0 15px 35px rgba(212,175,55,0.3);}
        .hero-diamond i {transform:rotate(-45deg); font-size:3rem; color:#022c22;}
        
        /* INTRO BOX */
        .intro-box {background:white; border-radius:30px; padding:50px; text-align:center; margin-top:-60px; position:relative; z-index:10; box-shadow:0 20px 40px rgba(0,0,0,0.08); border-top:5px solid var(--secondary);}
        .highlight-word {color:var(--primary); font-family:'Amiri',serif; font-weight:bold; padding:0 5px; position:relative; cursor:help;}
        .highlight-word::after {content:''; position:absolute; bottom:0; left:0; right:0; height:2px; background:var(--gold); transform:scaleX(0); transition:0.3s; transform-origin:right;}
        .highlight-word:hover::after {transform:scaleX(1);}
        
        /* ADILLAH (SOURCES) CARDS */
        .adillah-section {padding:80px 0;}
        .section-badge {background:rgba(4,120,87,0.1); color:var(--primary); font-weight:bold; padding:10px 25px; border-radius:50px; display:inline-block; margin-bottom:20px; border:1px solid rgba(4,120,87,0.2);}
        .source-card {background:white; border-radius:20px; border:none; padding:40px 30px; text-align:center; transition:0.4s; position:relative; overflow:hidden; z-index:1; box-shadow:0 10px 30px rgba(0,0,0,0.03);}
        .source-card::before {content:''; position:absolute; top:0; right:0; width:100%; height:100%; background:linear-gradient(135deg, transparent 50%, rgba(212,175,55,0.03) 100%); z-index:-1;}
        .source-card:hover {transform:translateY(-10px); box-shadow:0 20px 40px rgba(4,120,87,0.1);}
        .source-num {position:absolute; top:-20px; right:-20px; font-size:8rem; font-family:'Amiri',serif; font-weight:900; color:rgba(4,120,87,0.05); z-index:-1;}
        .source-icon {width:80px; height:80px; border-radius:50%; background:linear-gradient(135deg, var(--primary), var(--secondary)); color:white; display:flex; align-items:center; justify-content:center; font-size:2.5rem; margin:0 auto 20px;}
        .source-card:hover .source-icon {background:linear-gradient(135deg, var(--gold), #baa54d); color:#022c22;}
        
        /* SECONDARY SOURCES ACCORDION */
        .custom-accordion .accordion-item {border:none; margin-bottom:15px; border-radius:15px!important; overflow:hidden; box-shadow:0 5px 15px rgba(0,0,0,0.02);}
        .custom-accordion .accordion-button {padding:25px; font-family:'Amiri',serif; font-size:1.4rem; font-weight:bold; background:white; color:var(--dark);}
        .custom-accordion .accordion-button:not(.collapsed) {background:linear-gradient(90deg, #f0fdf4, white); color:var(--primary); box-shadow:inset 0 -1px 0 rgba(0,0,0,0.05);}
        .custom-accordion .accordion-button::after {filter:contrast(0.5);}
        
        /* MAQASID SECTION (Animated floating items) */
        .maqasid-section {background:linear-gradient(135deg, var(--dark), #022c22); padding:100px 0; color:white; border-top:3px solid var(--gold); border-bottom:3px solid var(--gold); position:relative; overflow:hidden;}
        .maqasid-section::before {content:''; position:absolute; inset:0; background:url('https://www.transparenttextures.com/patterns/arabesque.png'); opacity:0.05;}
        .maqasid-circle {width:160px; height:160px; background:rgba(255,255,255,0.05); border:2px solid rgba(212,175,55,0.3); border-radius:50%; display:flex; flex-direction:column; align-items:center; justify-content:center; margin:0 auto; transition:0.5s; cursor:pointer;}
        .maqasid-circle:hover {background:var(--gold); border-color:white; transform:scale(1.1); box-shadow:0 0 30px rgba(212,175,55,0.5);}
        .maqasid-circle i {font-size:2.5rem; color:var(--gold); margin-bottom:10px; transition:0.3s;}
        .maqasid-circle:hover i {color:#022c22;}
        .maqasid-circle h5 {font-family:'Amiri',serif; font-weight:bold; margin:0; transition:0.3s;}
        .maqasid-circle:hover h5 {color:#022c22;}
        
    </style>
</head>
<body>

<!-- MEGA NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-dark sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold" href="index.html"><i class="fas fa-book-open me-2 text-warning"></i>الموسوعة الإسلامية الشاملة</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav1">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="nav1">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link " href="index.html">الرئيسية</a></li>
        <li class="nav-item"><a class="nav-link " href="recitations.html">القرآن والتلاوات</a></li>
        <li class="nav-item"><a class="nav-link " href="hadith.html">الحديث الشريف</a></li>
        <li class="nav-item"><a class="nav-link " href="fiqh.html">الفقه الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="fatwa.html">فتاوى العلماء <i class="fas fa-gavel"></i></a></li>
        <li class="nav-item"><a class="nav-link " href="seerah.html">السيرة والصحابة</a></li>
        <li class="nav-item"><a class="nav-link " href="aqeedah.html">العقيدة الإسلامية</a></li>
        <li class="nav-item"><a class="nav-link " href="history.html">التاريخ الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="library.html">المكتبة الشاملة</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- MEGA HERO -->
<section class="mega-hero">
    <div class="container position-relative z-10">
        <div class="hero-diamond"><i class="fas fa-balance-scale"></i></div>
        <h1 class="display-3 amiri text-white fw-bold mb-4">علم <span class="text-warning">أصـول الفقـه</span></h1>
        <p class="fs-4 amiri text-white opacity-75 max-w-700 mx-auto">
            ميزان الشريعة والدستور الدقيق الذي يعصم المجتهد من الزلل، ويوضح طرق استنباط الأحكام العملية من أدلتها التفصيلية.
        </p>
    </div>
</section>

<!-- INTRO DEFINITION BOX -->
<div class="container mb-5">
    <div class="intro-box">
        <h2 class="amiri fw-bold text-dark mb-4"><i class="fas fa-search me-2 text-primary"></i> ما هو أصول الفقه؟</h2>
        <p class="fs-4 line-height-2 text-muted">
            هو العلم بالقواعد التي يتوصل بها إلى <span class="highlight-word" data-bs-toggle="tooltip" title="استخراج الأحكام من مصادرها الشرعية بفهم دقيق">استنباط</span> الأحكام الشرعية العملية من <span class="highlight-word" data-bs-toggle="tooltip" title="الآيات والأحاديث المخصوصة بمسألة معينة">أدلتها التفصيلية</span>. وموضوعه هو الأدلة الشرعية الكلية (كالقرآن والسنة) وكيفية الاستفادة منها، وحال المستفيد وهو <span class="highlight-word" data-bs-toggle="tooltip" title="العالم الذي توفرت فيه شروط الاجتهاد">المجتهد</span>.
        </p>
    </div>
</div>

<!-- MAIN SOURCES -->
<section class="adillah-section mb-5">
    <div class="container text-center">
        <div class="section-badge">الأدلة المتفق عليها</div>
        <h2 class="amiri display-5 fw-bold text-dark mb-5">الأصول الكلية للتشريع</h2>
        
        <div class="row g-4">
            <!-- 1 -->
            <div class="col-lg-3 col-md-6">
                <div class="source-card">
                    <div class="source-num">1</div>
                    <div class="source-icon"><i class="fas fa-book-quran"></i></div>
                    <h3 class="amiri fw-bold text-dark mb-3">القرآن الكريم</h3>
                    <p class="text-muted">كلام الله المنزل على محمد ﷺ، المتعبد بتلاوته. وهو الأصل الأول والمصدر الأساسي والأعلى للتشريع الإسلامي.</p>
                </div>
            </div>
            <!-- 2 -->
            <div class="col-lg-3 col-md-6">
                <div class="source-card">
                    <div class="source-num">2</div>
                    <div class="source-icon"><i class="fas fa-comment-dots"></i></div>
                    <h3 class="amiri fw-bold text-dark mb-3">السنة النبوية</h3>
                    <p class="text-muted">ما صدر عن النبي ﷺ من قول أو فعل أو تقرير. وهي المصدر الثاني، وتأتي مؤكدة ومبينة ومفصلة للقرآن المكي والمدني.</p>
                </div>
            </div>
            <!-- 3 -->
            <div class="col-lg-3 col-md-6">
                <div class="source-card">
                    <div class="source-num">3</div>
                    <div class="source-icon"><i class="fas fa-users"></i></div>
                    <h3 class="amiri fw-bold text-dark mb-3">الإجـــمـاع</h3>
                    <p class="text-muted">اتفاق جميع المجتهدين من أمة محمد ﷺ في عصر من العصور بعد وفاته على حكم شرعي في واقعة مستجدة.</p>
                </div>
            </div>
            <!-- 4 -->
            <div class="col-lg-3 col-md-6">
                <div class="source-card">
                    <div class="source-num">4</div>
                    <div class="source-icon"><i class="fas fa-ruler-combined"></i></div>
                    <h3 class="amiri fw-bold text-dark mb-3">القيــــاس</h3>
                    <p class="text-muted">إلحاق مسألة لا نص على حكمها (كالمنبهات الحديثة) بمسألة ورد فيها نص (كالخمر)، لاشتراكهما في نفس العلة (الإسكار).</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- MAQASID SHARIAH (Floating items) -->
<section class="maqasid-section mb-5 text-center">
    <div class="container position-relative z-10">
        <h2 class="amiri display-5 fw-bold text-white mb-3">مقاصد الشريعة (الضروريات الخمس)</h2>
        <p class="fs-4 amiri text-white opacity-75 mb-5 max-w-700 mx-auto">جاءت الشريعة الإسلامية العظيمة لحفظ مصالح العباد في المعاش والمعاد، وأهمها الضروريات الخمس التي لا تستقيم الحياة بدونها:</p>
        
        <div class="row g-4 justify-content-center">
            <div class="col-6 col-md-2">
                <div class="maqasid-circle">
                    <i class="fas fa-praying-hands"></i>
                    <h5>حفظ الدين</h5>
                </div>
            </div>
            <div class="col-6 col-md-2">
                <div class="maqasid-circle">
                    <i class="fas fa-heartbeat"></i>
                    <h5>حفظ النفس</h5>
                </div>
            </div>
            <div class="col-6 col-md-2">
                <div class="maqasid-circle">
                    <i class="fas fa-brain"></i>
                    <h5>حفظ العقل</h5>
                </div>
            </div>
            <div class="col-6 col-md-2">
                <div class="maqasid-circle">
                    <i class="fas fa-users"></i>
                    <h5>حفظ النسل</h5>
                </div>
            </div>
            <div class="col-6 col-md-2">
                <div class="maqasid-circle">
                    <i class="fas fa-coins"></i>
                    <h5>حفظ المال</h5>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- SECONDARY SOURCES & LINGUISTIC RULES -->
<div class="container mb-5 pb-5">
    <div class="row g-5">
        <!-- Differed upon sources -->
        <div class="col-lg-6">
            <div class="section-badge mb-4">الأدلة التبعية (المختلف فيها)</div>
            <div class="accordion custom-accordion" id="accordionSecondary">
                <!-- 1 -->
                <div class="accordion-item">
                    <h2 class="accordion-header"><button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#col1">الاستحسان</button></h2>
                    <div id="col1" class="accordion-collapse collapse show" data-bs-parent="#accordionSecondary">
                        <div class="accordion-body text-muted fs-5">العدول عن مقتضى قياس جلي إلى مقتضى قياس خفي، أو عن حكم كلي إلى حكم استثنائي لدليل يقتضي ذلك.</div>
                    </div>
                </div>
                <!-- 2 -->
                <div class="accordion-item">
                    <h2 class="accordion-header"><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#col2">المصالح المرسلة</button></h2>
                    <div id="col2" class="accordion-collapse collapse" data-bs-parent="#accordionSecondary">
                        <div class="accordion-body text-muted fs-5">المصالح التي لم يشرع الشارع حكماً لعينها، ولم يقم دليل خاص على اعتبارها أو إلغائها، ولكنها تحقق مقصوداً شرعياً (كجمع القرآن في مصحف واحد).</div>
                    </div>
                </div>
                <!-- 3 -->
                <div class="accordion-item">
                    <h2 class="accordion-header"><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#col3">سد الذرائع</button></h2>
                    <div id="col3" class="accordion-collapse collapse" data-bs-parent="#accordionSecondary">
                        <div class="accordion-body text-muted fs-5">منع الوسائل المباحة في الأصل إذا كانت تفضي أو تؤول غالباً إلى المحرمات حسماً لمادة الفساد.</div>
                    </div>
                </div>
                <!-- 4 -->
                <div class="accordion-item">
                    <h2 class="accordion-header"><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#col4">العُـرف</button></h2>
                    <div id="col4" class="accordion-collapse collapse" data-bs-parent="#accordionSecondary">
                        <div class="accordion-body text-muted fs-5">ما استقر في النفوس وتلقته الطباع السليمة بالقبول واعتاده الناس في تعاملاتهم، بشرط ألا يخالف دليلاً شرعياً (كألفاظ العقود ومقادير الصداق).</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Linguistic Rules -->
        <div class="col-lg-6">
            <div class="section-badge mb-4">القواعد الأصولية والدلالات</div>
            <div class="row g-3">
                <div class="col-12">
                    <div class="p-4 bg-white rounded-4 border shadow-sm">
                        <h4 class="amiri text-dark fw-bold border-bottom pb-2 mb-3"><i class="fas fa-comment-alt me-2 text-warning"></i>الأمر والنهي</h4>
                        <p class="text-muted mb-0 fs-5">الأصل في <b>الأمر</b> يفيد الوجوب ما لم تصرفه قرينة للاستحباب أو غيره، والأصل في <b>النهي</b> يفيد التحريم ما لم تصرفه قرينة للكراهة.</p>
                    </div>
                </div>
                <div class="col-12">
                    <div class="p-4 bg-white rounded-4 border shadow-sm">
                        <h4 class="amiri text-dark fw-bold border-bottom pb-2 mb-3"><i class="fas fa-expand-arrows-alt me-2 text-warning"></i>العام والخاص</h4>
                        <p class="text-muted mb-0 fs-5"><b>العام:</b> اللفظ المستغرق لجميع ما يصلح له. <b>والخاص:</b> اللفظ الدال على مسمى واحد أو عدد محصور. والخاص يُقدم على العام أو يُخصصه.</p>
                    </div>
                </div>
                <div class="col-12">
                    <div class="p-4 bg-white rounded-4 border shadow-sm">
                        <h4 class="amiri text-dark fw-bold border-bottom pb-2 mb-3"><i class="fas fa-lock me-2 text-warning"></i>المطلق والمقيد</h4>
                        <p class="text-muted mb-0 fs-5"><b>المطلق:</b> اللفظ الدال على الماهية بلا قيد (مثل: رقبة). <b>والمقيد:</b> ما دل عليها بقيد زائد (مثل: رقبة مؤمنة). يُحمل المطلق على المقيد عند اتحاد الحكم والسبب.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<footer class="mega-footer" style="background:linear-gradient(135deg,var(--dark),#020617);color:white;padding:80px 0 30px;margin-top:80px;border-top:3px solid var(--gold-dark);">
  <div class="container">
    <div class="row g-5 mb-5 border-bottom border-light border-opacity-10 pb-5">
      <div class="col-lg-4 text-md-end text-center">
        <i class="fas fa-mosque fa-4x text-warning mb-4 d-block"></i>
        <h4 class="fw-bold font-amiri fs-2 mb-3">الموسوعة الإسلامية الشاملة</h4>
        <p class="opacity-75 fs-6 line-height-2">أضخم صرح رقمي يجمع علوم القرآن العظيم، وأحاديث المصطفى، وفقهاء المذاهب، والتاريخ المجيد في منصة موثقة مصممة بأحدث التقنيات.</p>
      </div>
      <div class="col-lg-4 text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">تصفح الموسوعة</h5>
        <div class="d-flex flex-wrap justify-content-center gap-2">
          <a href="recitations.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">أكاديمية القرآن</a>
          <a href="hadith.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الحديث النبوي</a>
          <a href="seerah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">السيرة والصحابة</a>
          <a href="fiqh.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الفقه وأصوله</a>
          <a href="fatwa.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">فتاوى العلماء</a>
          <a href="aqeedah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">العقيدة الإسلامية</a>
          <a href="history.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">التاريخ المجيد</a>
          <a href="library.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">المكتبة الشاملة</a>
        </div>
      </div>
      <div class="col-lg-4 text-md-start text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">روابط سريعة</h5>
        <a href="contact.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> اتصل بالمطور</a>
        <a href="share.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> شارك الأجر</a>
        <a href="login.html" class="mega-footer-link text-warning mt-3" style="text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-user-circle me-2 ms-1"></i> تسجيل الدخول</a>
      </div>
    </div>
    <div class="text-center font-amiri fs-5 d-flex flex-column gap-2">
      <span class="opacity-75">الموسوعة الإسلامية الشاملة &copy; 2026 تم التصميم للإفادة | عمل مجاني لوجه الله</span>
      <span class="text-warning fw-bold fs-4 mt-2">تصميم وتطوير: لخذاري محمد سيف الدين</span>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Initialize tooltips
    document.addEventListener('DOMContentLoaded', function () {
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl)
        })
    });
</script>
</body>
</html>
