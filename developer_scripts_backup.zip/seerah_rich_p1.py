import codecs

css = """<style>
:root{--gold:#c9a66b;--gold2:#e8d5a3;--dark:#1a0800;--brown:#5c2d00;--amber:#7a4000;}
body{font-family:'Cairo',sans-serif;background:#fdf9f4;color:#2c2010;overflow-x:hidden;}
h1,h2,h3,h4,.ar{font-family:'Amiri',serif;}
/* HERO */
.seerah-hero{min-height:580px;background:linear-gradient(160deg,#120400 0%,#2e0e00 45%,#5c2000 100%);position:relative;overflow:hidden;display:flex;align-items:center;padding:80px 0;}
.orb{position:absolute;border-radius:50%;filter:blur(90px);opacity:.2;animation:orb 12s infinite alternate;}
.orb:nth-child(1){width:500px;height:500px;background:#c9a66b;top:-150px;right:-80px;}
.orb:nth-child(2){width:350px;height:350px;background:#e68a00;bottom:-100px;left:5%;animation-delay:4s;}
.orb:nth-child(3){width:200px;height:200px;background:#fff;top:40%;left:45%;animation-delay:7s;}
@keyframes orb{from{transform:scale(1) translate(0,0)}to{transform:scale(1.3) translate(25px,25px)}}
.hero-pattern{position:absolute;inset:0;background:url('https://www.transparenttextures.com/patterns/arabesque.png');opacity:.07;}
.hero-content{position:relative;z-index:5;color:white;}
.hero-eyebrow{display:inline-block;border:1px solid rgba(201,166,107,.4);background:rgba(201,166,107,.1);backdrop-filter:blur(10px);color:var(--gold2);border-radius:40px;padding:8px 24px;font-size:.85rem;font-weight:700;margin-bottom:20px;}
.hero h1{font-size:3.8rem;font-weight:bold;margin-bottom:12px;background:linear-gradient(135deg,#fff 30%,var(--gold2) 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;line-height:1.2;}
.tagline{color:rgba(255,255,255,.65);font-size:1.1rem;margin-bottom:35px;line-height:2;}
.hero-quote{background:rgba(255,255,255,.06);border:1px solid rgba(201,166,107,.2);border-right:4px solid var(--gold);border-radius:16px;padding:22px 26px;max-width:680px;backdrop-filter:blur(12px);}
.hero-quote p{font-family:'Amiri',serif;font-size:1.3rem;line-height:2;color:white;margin:0;}
.hero-quote small{color:rgba(255,255,255,.4);font-size:.82rem;}
/* STATS */
.stats-strip{background:linear-gradient(90deg,#2e0e00,#5c2000);padding:22px 0;}
.stat-item{text-align:center;color:white;padding:8px;}
.stat-num{font-size:2.3rem;font-weight:800;color:var(--gold2);font-family:'Amiri',serif;line-height:1;}
.stat-label{font-size:.75rem;opacity:.6;margin-top:5px;}
/* TABS */
.sec-tabs{background:white;border-radius:60px;padding:8px;box-shadow:0 10px 40px rgba(90,40,0,.08);margin:45px 0 40px;display:flex;overflow-x:auto;border:1px solid rgba(90,40,0,.05);}
.sec-tabs::-webkit-scrollbar{height:0;}
.sec-tabs .nav-item{flex:1;min-width:130px;}
.sec-tabs .nav-link{border:none;border-radius:50px;color:#555;font-weight:700;padding:14px 12px;width:100%;text-align:center;transition:all .35s;white-space:nowrap;font-size:.9rem;}
.sec-tabs .nav-link.active{background:linear-gradient(135deg,#2e0e00,#6b3000);color:white;box-shadow:0 8px 20px rgba(90,40,0,.28);}
/* SEC HEAD */
.sec-head{text-align:center;margin-bottom:45px;}
.sec-head .tag{display:inline-block;background:rgba(90,40,0,.08);color:var(--brown);border-radius:40px;padding:6px 20px;font-size:.82rem;font-weight:700;margin-bottom:15px;}
.sec-head h3{font-size:2.2rem;color:#2e0e00;font-weight:700;margin-bottom:8px;}
.sec-head h3 span{color:var(--gold);}
.sec-head p{color:#888;max-width:620px;margin:0 auto;}
.sec-head .divider{width:60px;height:4px;background:linear-gradient(90deg,var(--gold),var(--gold2));border-radius:2px;margin:15px auto 0;}
/* TIMELINE */
.timeline{position:relative;padding:10px 0;}
.timeline::before{content:'';position:absolute;right:50%;top:0;bottom:0;width:3px;background:linear-gradient(180deg,var(--gold),rgba(201,166,107,.1));}
.tl-item{display:flex;gap:30px;margin-bottom:55px;position:relative;align-items:flex-start;}
.tl-item.right{flex-direction:row-reverse;}
.tl-dot{flex-shrink:0;width:58px;height:58px;border-radius:50%;background:linear-gradient(135deg,#2e0e00,#6b3000);display:flex;align-items:center;justify-content:center;color:var(--gold2);font-size:1.4rem;box-shadow:0 0 0 6px rgba(201,166,107,.15),0 0 0 14px rgba(201,166,107,.06);position:relative;z-index:2;margin-top:8px;}
.tl-year{position:absolute;top:50%;transform:translateY(-50%);background:var(--gold);color:#2e0e00;font-weight:800;padding:4px 14px;border-radius:20px;font-size:.78rem;white-space:nowrap;box-shadow:0 4px 12px rgba(201,166,107,.3);}
.tl-item:not(.right) .tl-year{left:calc(50% + 44px);}
.tl-item.right .tl-year{right:calc(50% + 44px);}
.tl-card{flex:1;background:white;border-radius:20px;padding:24px 26px;box-shadow:0 10px 30px rgba(90,40,0,.07);border-right:4px solid var(--gold);transition:all .4s;max-width:calc(50% - 65px);opacity:0;transform:translateY(30px);}
.tl-card.visible{opacity:1;transform:translateY(0);}
.tl-card:hover{box-shadow:0 18px 45px rgba(90,40,0,.13);}
.tl-card h5{color:#2e0e00;font-weight:800;margin-bottom:8px;}
.tl-card p{color:#666;font-size:.9rem;line-height:1.85;margin:0;}
.tl-tag{display:inline-block;background:rgba(61,21,0,.08);color:#5c2d00;border-radius:20px;padding:3px 12px;font-size:.75rem;font-weight:700;margin-bottom:10px;}
/* GHAZAWAT */
.ghaz-card{background:white;border-radius:20px;overflow:hidden;box-shadow:0 10px 30px rgba(90,40,0,.07);transition:all .4s;height:100%;}
.ghaz-card:hover{transform:translateY(-8px);box-shadow:0 22px 55px rgba(90,40,0,.13);}
.ghaz-top{padding:28px 24px 22px;position:relative;overflow:hidden;}
.ghaz-top::after{content:attr(data-ar);position:absolute;left:10px;bottom:-10px;font-size:5rem;font-family:'Amiri',serif;font-weight:bold;opacity:.07;color:#000;line-height:1;}
.ghaz-top h5{color:white;font-weight:800;font-size:1.05rem;margin-bottom:4px;}
.ghaz-top small{color:rgba(255,255,255,.7);}
.ghaz-body{padding:20px 24px 24px;}
.ghaz-body p{color:#555;font-size:.87rem;line-height:1.85;margin-bottom:14px;}
.ghaz-stats{display:flex;gap:8px;flex-wrap:wrap;}
.ghaz-stat{background:#fdf5eb;border-radius:10px;padding:7px 12px;font-size:.76rem;color:#7a4000;font-weight:700;border:1px solid rgba(201,166,107,.2);}
.ghaz-win{background:#e8f8ef;color:#0d5c2a;border-color:rgba(13,92,42,.2);}
.ghaz-lesson{background:#fef3e2;color:#8b5a00;border-color:rgba(139,90,0,.2);}
/* MIRACLES */
.miracle-card{background:white;border-radius:20px;padding:28px;box-shadow:0 10px 30px rgba(90,40,0,.06);transition:all .4s;height:100%;position:relative;overflow:hidden;}
.miracle-card:hover{transform:translateY(-7px);box-shadow:0 20px 50px rgba(90,40,0,.12);}
.miracle-card::before{content:'';position:absolute;top:-30px;left:-30px;width:100px;height:100px;border-radius:50%;opacity:.06;}
.miracle-num{position:absolute;top:18px;left:20px;font-family:'Amiri',serif;font-size:4rem;color:rgba(61,21,0,.04);font-weight:bold;line-height:1;}
.miracle-icon{width:65px;height:65px;border-radius:18px;display:flex;align-items:center;justify-content:center;font-size:1.7rem;margin-bottom:18px;box-shadow:0 8px 20px rgba(0,0,0,.12);}
.miracle-card h5{color:#2e0e00;font-weight:800;margin-bottom:10px;}
.miracle-card p{color:#666;font-size:.88rem;line-height:1.85;}
/* AKHLAQ */
.akhlaq-card{background:white;border-radius:20px;padding:28px;box-shadow:0 10px 30px rgba(90,40,0,.07);transition:all .3s;text-align:center;height:100%;border-bottom:4px solid var(--gold);}
.akhlaq-card:hover{transform:translateY(-6px);}
.akhlaq-icon{width:70px;height:70px;border-radius:50%;background:linear-gradient(135deg,#2e0e00,#6b3000);display:flex;align-items:center;justify-content:center;font-size:1.8rem;color:var(--gold2);margin:0 auto 18px;box-shadow:0 10px 25px rgba(61,21,0,.2);}
/* SIFAT */
.sifat-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:20px;}
.sifat-item{background:white;border-radius:18px;padding:22px;box-shadow:0 8px 25px rgba(90,40,0,.06);border-right:4px solid var(--gold);display:flex;align-items:flex-start;gap:15px;transition:.3s;}
.sifat-item:hover{transform:translateX(-4px);}
.sifat-icon{width:48px;height:48px;border-radius:14px;flex-shrink:0;background:rgba(61,21,0,.08);color:#7a4000;display:flex;align-items:center;justify-content:center;font-size:1.3rem;}
/* COMPANIONS */
.comp-card{background:white;border-radius:18px;padding:22px;box-shadow:0 8px 25px rgba(90,40,0,.06);transition:.3s;height:100%;border-top:3px solid var(--gold);}
.comp-card:hover{transform:translateY(-5px);}
.comp-avatar{width:55px;height:55px;border-radius:50%;background:linear-gradient(135deg,#2e0e00,#6b3000);display:flex;align-items:center;justify-content:center;font-size:1.3rem;color:var(--gold2);margin-bottom:14px;box-shadow:0 6px 15px rgba(61,21,0,.2);}
/* QUOTES */
.quote-strip{background:linear-gradient(135deg,#2e0e00,#5c2000);border-radius:20px;padding:40px;color:white;position:relative;overflow:hidden;margin:30px 0;}
.quote-strip::before{content:'"';position:absolute;right:20px;top:-20px;font-size:10rem;opacity:.07;font-family:'Amiri',serif;line-height:1;}
.quote-strip p{font-family:'Amiri',serif;font-size:1.5rem;line-height:2.2;margin:0;}
@media(max-width:768px){.timeline::before,.tl-year{display:none;}.tl-item,.tl-item.right{flex-direction:column;gap:15px;}.tl-card{max-width:100%;opacity:1;transform:none;}.hero h1{font-size:2.2rem;}.sec-tabs{gap:5px;}}
</style>"""

part1 = """<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>موسوعة السيرة النبوية الشريفة - الموسوعة الإسلامية</title>
<link href="https://fonts.googleapis.com/css2?family=Amiri:ital,wght@0,400;0,700;1,400&family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="styles.css">
""" + css + """
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold" href="index.html"><i class="fas fa-book-open me-2 text-warning"></i>الموسوعة الإسلامية الشاملة</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav1">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="nav1">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link " href="index.html">الرئيسية</a></li>
        <li class="nav-item"><a class="nav-link " href="recitations.html">القرآن والتلاوات</a></li>
        <li class="nav-item"><a class="nav-link " href="hadith.html">الحديث الشريف</a></li>
        <li class="nav-item"><a class="nav-link " href="fiqh.html">الفقه الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="fatwa.html">فتاوى العلماء <i class="fas fa-gavel"></i></a></li>
        <li class="nav-item"><a class="nav-link active" href="seerah.html">السيرة والصحابة</a></li>
        <li class="nav-item"><a class="nav-link " href="aqeedah.html">العقيدة الإسلامية</a></li>
        <li class="nav-item"><a class="nav-link " href="history.html">التاريخ الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="library.html">المكتبة الشاملة</a></li>
      </ul>
    </div>
  </div>
</nav>

<section class="seerah-hero">
  <div class="orb"></div><div class="orb"></div><div class="orb"></div>
  <div class="hero-pattern"></div>
  <div class="container hero-content">
    <div class="row align-items-center g-5">
      <div class="col-lg-7">
        <div class="hero-eyebrow"><i class="fas fa-star-and-crescent me-2"></i>موسوعة السيرة النبوية الشريفة</div>
        <h1>سيرة خير البشرية<br>محمد ﷺ</h1>
        <p class="tagline">من مكة إلى المدينة — رحلة إيمانية عبر المراحل والغزوات<br>والمعجزات والأخلاق والشمائل النبوية الكريمة</p>
        <div class="hero-quote">
          <p>«خَيرُكُم في الجاهليةِ خَيرُكُم في الإسلامِ إذا فَقُهوا»</p>
          <small>— البخاري ومسلم</small>
        </div>
      </div>
      <div class="col-lg-5 d-none d-lg-block text-center">
        <div style="position:relative;width:300px;height:300px;margin:0 auto;">
          <div style="position:absolute;inset:0;border-radius:50%;border:2px solid rgba(201,166,107,.2);animation:spin 25s linear infinite;"></div>
          <div style="position:absolute;inset:20px;border-radius:50%;border:1px dashed rgba(201,166,107,.3);animation:spin 18s linear infinite reverse;"></div>
          <div style="position:absolute;inset:40px;border-radius:50%;border:1px solid rgba(201,166,107,.15);animation:spin 30s linear infinite;"></div>
          <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;">
            <i class="fas fa-star-and-crescent" style="font-size:5.5rem;color:var(--gold);opacity:.85;filter:drop-shadow(0 0 20px rgba(201,166,107,.4));"></i>
          </div>
          <div style="position:absolute;top:5px;left:50%;transform:translateX(-50%);background:rgba(201,166,107,.15);border:1px solid rgba(201,166,107,.3);border-radius:20px;padding:5px 14px;font-size:.76rem;color:var(--gold2);white-space:nowrap;backdrop-filter:blur(8px);">مكة المكرمة ✦ 571م</div>
          <div style="position:absolute;bottom:5px;left:50%;transform:translateX(-50%);background:rgba(201,166,107,.15);border:1px solid rgba(201,166,107,.3);border-radius:20px;padding:5px 14px;font-size:.76rem;color:var(--gold2);white-space:nowrap;backdrop-filter:blur(8px);">المدينة المنورة ✦ 11هـ</div>
        </div>
      </div>
    </div>
  </div>
</section>

<div class="stats-strip">
  <div class="container">
    <div class="row text-center g-0">
      <div class="col-4 col-md-2 stat-item border-end border-white border-opacity-20"><div class="stat-num">63</div><div class="stat-label">سنة عمره ﷺ</div></div>
      <div class="col-4 col-md-2 stat-item border-end border-white border-opacity-20"><div class="stat-num">27</div><div class="stat-label">غزوة</div></div>
      <div class="col-4 col-md-2 stat-item border-end border-white border-opacity-20"><div class="stat-num">66</div><div class="stat-label">سرية</div></div>
      <div class="col-4 col-md-2 stat-item border-end border-white border-opacity-20"><div class="stat-num">23</div><div class="stat-label">سنة الدعوة</div></div>
      <div class="col-4 col-md-2 stat-item border-end border-white border-opacity-20"><div class="stat-num">11</div><div class="stat-label">زوجة</div></div>
      <div class="col-4 col-md-2 stat-item"><div class="stat-num">7</div><div class="stat-label">أبناء وبنات</div></div>
    </div>
  </div>
</div>

<div class="container mb-5">
<ul class="nav sec-tabs" id="sTabs" role="tablist">
  <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#t-tl"><i class="fas fa-history me-1"></i>التسلسل الزمني</button></li>
  <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t-gh"><i class="fas fa-flag me-1"></i>الغزوات والسرايا</button></li>
  <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t-mj"><i class="fas fa-star me-1"></i>المعجزات النبوية</button></li>
  <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t-akh"><i class="fas fa-heart me-1"></i>الأخلاق والشمائل</button></li>
  <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t-sf"><i class="fas fa-user me-1"></i>الصفة الجسدية</button></li>
  <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t-fam"><i class="fas fa-users me-1"></i>الآل والصحب</button></li>
</ul>

<div class="tab-content">
<!-- TIMELINE TAB -->
<div class="tab-pane fade show active" id="t-tl">
  <div class="sec-head">
    <span class="tag">من المهد إلى اللحد</span>
    <h3>التسلسل الزمني <span>الكامل</span></h3>
    <p>المحطات الكبرى في حياة النبي ﷺ من المولد الشريف حتى الوفاة</p>
    <div class="divider"></div>
  </div>
  <div class="timeline">
    <div class="tl-item"><div class="tl-dot"><i class="fas fa-baby"></i></div><div class="tl-card"><span class="tl-tag">مكة المكرمة</span><h5>المولد الشريف</h5><p>وُلد النبي ﷺ يوم الاثنين 12 ربيع الأول عام الفيل (571م). فُجع بوفاة والده عبد الله قبل ولادته. أرضعته حليمة السعدية في بادية بني سعد، وشُقّ صدره وهو في الرضاعة.</p></div><div class="tl-year">571م</div></div>
    <div class="tl-item right"><div class="tl-dot"><i class="fas fa-heart-broken"></i></div><div class="tl-card"><span class="tl-tag">6 سنوات</span><h5>وفاة الوالدة ثم الجد</h5><p>ماتت أمه آمنة بنت وهب في الأبواء راجعة من المدينة. تكفّله جده عبد المطلب ثم توفي بعد عامين، فانتقلت كفالته لعمه أبي طالب الذي أحبه وحماه حتى الوفاة.</p></div><div class="tl-year">577م</div></div>
    <div class="tl-item"><div class="tl-dot"><i class="fas fa-map-marked"></i></div><div class="tl-card"><span class="tl-tag">12 سنة</span><h5>رحلة الشام مع عمه</h5><p>رافق النبي ﷺ عمه أبا طالب في قافلة تجارية إلى الشام. تعرّف عليه الراهب بحيرا وأخبر عمه بنبوته القادمة وحذّره من اليهود عليه، فعاد به أبو طالب مسرعاً.</p></div><div class="tl-year">582م</div></div>
    <div class="tl-item right"><div class="tl-dot"><i class="fas fa-handshake"></i></div><div class="tl-card"><span class="tl-tag">15 سنة</span><h5>حلف الفضول</h5><p>شهد ﷺ حلف الفضول، وهو تحالف بين قبائل قريش لنصرة المظلوم. قال ﷺ بعد البعثة: "لو دُعيت إليه في الإسلام لأجبت"، دليل على أن مبادئ العدل لا تتعارض مع الإسلام.</p></div><div class="tl-year">586م</div></div>
    <div class="tl-item"><div class="tl-dot"><i class="fas fa-ring"></i></div><div class="tl-card"><span class="tl-tag">25 سنة</span><h5>الزواج من خديجة رضي الله عنها</h5><p>تزوج النبي ﷺ السيدة خديجة بنت خويلد وهو في الخامسة والعشرين وهي في الأربعين. رزق منها: القاسم، عبد الله، زينب، رقية، أم كلثوم، فاطمة رضي الله عنهم. ولم يتزوج عليها في حياتها.</p></div><div class="tl-year">595م</div></div>
    <div class="tl-item right"><div class="tl-dot"><i class="fas fa-book-open"></i></div><div class="tl-card"><span class="tl-tag">40 سنة</span><h5>البعثة النبوية والوحي الأول</h5><p>نزل جبريل في غار حراء بسورة العلق آخر رمضان: "اقرأ باسم ربك الذي خلق". هرع النبي ﷺ مرتجفاً لخديجة فطمأنته وذهبت به لابن عمها ورقة بن نوفل الذي بشّره بنبوته.</p></div><div class="tl-year">610م</div></div>
    <div class="tl-item"><div class="tl-dot"><i class="fas fa-user-plus"></i></div><div class="tl-card"><span class="tl-tag">3 سنوات من البعثة</span><h5>الدعوة السرية ثم الجهرية</h5><p>ظل الإسلام سراً ثلاث سنوات فآمن خيرة الصحابة: خديجة، وأبو بكر، وعلي، وزيد بن حارثة. ثم نزل الأمر بالجهر بها، فصدع بالدعوة في الصفا ودعا قريشاً.</p></div><div class="tl-year">613م</div></div>
    <div class="tl-item right"><div class="tl-dot"><i class="fas fa-plane-departure"></i></div><div class="tl-card"><span class="tl-tag">الهجرة الأولى</span><h5>هجرة الصحابة إلى الحبشة</h5><p>اشتد الأذى على المسلمين فأذن لهم النبي ﷺ بالهجرة إلى الحبشة. هاجر 15 صحابياً ثم 83 لاحقاً. استقبلهم النجاشي ملك الحبشة بكرم وحماهم من مطالب قريش.</p></div><div class="tl-year">615م</div></div>
    <div class="tl-item"><div class="tl-dot"><i class="fas fa-ban"></i></div><div class="tl-card"><span class="tl-tag">3 سنوات</span><h5>الحصار الاقتصادي في الشعب</h5><p>حاصرت قريش النبي ﷺ وبني هاشم في شعب أبي طالب ثلاث سنوات، مانعة عنهم البيع والشراء حتى كادوا يموتون جوعاً. ثم فُكّ الحصار بعد أن أكلت الأرضة الصحيفة.</p></div><div class="tl-year">617م</div></div>
    <div class="tl-item right"><div class="tl-dot"><i class="fas fa-cloud-rain"></i></div><div class="tl-card"><span class="tl-tag">عام الحزن</span><h5>وفاة خديجة وأبي طالب</h5><p>في عام واحد فقد النبي ﷺ زوجته خديجة ناصرته وحبيبته، ثم عمه أبا طالب حاميه وسنده. قال ﷺ لخديجة: "إني أرجو أن تكوني من نساء الجنة". وكان يُكثر ذكرها بعد موتها.</p></div><div class="tl-year">619م</div></div>
    <div class="tl-item"><div class="tl-dot"><i class="fas fa-moon"></i></div><div class="tl-card"><span class="tl-tag">رحلة إلهية</span><h5>الإسراء والمعراج</h5><p>أُسري بالنبي ﷺ من المسجد الحرام إلى الأقصى، ثم عُرج به إلى السماوات فالتقى بالأنبياء وانتهى إلى سدرة المنتهى. فُرضت الصلوات الخمس وكانت خمسين ثم خُففت رحمةً بالأمة.</p></div><div class="tl-year">621م</div></div>
    <div class="tl-item right"><div class="tl-dot"><i class="fas fa-comments"></i></div><div class="tl-card"><span class="tl-tag">بيعة العقبة</span><h5>بيعتا العقبة الأولى والثانية</h5><p>بايع 12 ثم 73 من أهل يثرب النبيَّ ﷺ في العقبة على الإسلام والدفاع عنه. كانت نقطة تحول فارقة؛ إذ مهّدت لهجرة المسلمين وتأسيس الدولة الإسلامية في المدينة.</p></div><div class="tl-year">621-622م</div></div>
    <div class="tl-item"><div class="tl-dot"><i class="fas fa-route"></i></div><div class="tl-card"><span class="tl-tag">انطلاق الدولة</span><h5>الهجرة المباركة إلى المدينة</h5><p>هاجر النبي ﷺ مع أبي بكر مخادعَيْن قريشاً الليلة التي خططوا لاغتياله فيها. اختبأا في غار ثور ثلاثة أيام. استقبله أهل يثرب بفرح عارم — تروي الروايات أن النساء والأطفال خرجوا يتغنون "طلع البدر علينا".</p></div><div class="tl-year">622م | 1هـ</div></div>
    <div class="tl-item right"><div class="tl-dot"><i class="fas fa-city"></i></div><div class="tl-card"><span class="tl-tag">تأسيس الدولة</span><h5>بناء المسجد والمؤاخاة والصحيفة</h5><p>بنى النبي ﷺ المسجد النبوي بيده ومعه الصحابة — كان يرتجز معهم "اللهم لا خير إلا خير الآخرة". آخى بين المهاجرين والأنصار وكتب الصحيفة مع القبائل ليقيم أول دولة قانونية في التاريخ.</p></div><div class="tl-year">622م</div></div>
    <div class="tl-item"><div class="tl-dot"><i class="fas fa-key"></i></div><div class="tl-card"><span class="tl-tag">الفتح الأعظم</span><h5>فتح مكة المكرمة</h5><p>دخل النبي ﷺ مكة في 10,000 مقاتل يوم 20 رمضان 8هـ — دخولاً أمنياً هادئاً. طاف بالكعبة وكسّر 360 صنماً وقرأ: ﴿جاء الحق وزهق الباطل﴾. ثم عفا عن قريش قائلاً: اذهبوا فأنتم الطلقاء.</p></div><div class="tl-year">630م | 8هـ</div></div>
    <div class="tl-item right"><div class="tl-dot"><i class="fas fa-scroll"></i></div><div class="tl-card"><span class="tl-tag">خطبة الوداع</span><h5>حجة الوداع والوصية الأخيرة</h5><p>أدّى ﷺ حجّه الوحيد في ربع مليون صحابي. في عرفة ألقى خطبته التاريخية: "أيها الناس إن دماءكم وأموالكم وأعراضكم حرام عليكم". وأُنزلت فيها: ﴿اليوم أكملت لكم دينكم﴾.</p></div><div class="tl-year">632م | 10هـ</div></div>
    <div class="tl-item"><div class="tl-dot"><i class="fas fa-star"></i></div><div class="tl-card"><span class="tl-tag">الرحيل الشريف</span><h5>الوفاة النبوية الشريفة</h5><p>توفي ﷺ يوم الاثنين 12 ربيع الأول 11هـ في بيت عائشة رضي الله عنها. كانت يده في يد عائشة ورأسه على صدرها. آخر ما قاله: "اللهم الرفيق الأعلى". دُفن في المكان الذي قُبض فيه.</p></div><div class="tl-year">632م | 11هـ</div></div>
  </div>
</div>
"""

with codecs.open(r"c:\Users\ST\Desktop\islamic.encyclopedia\s_part1.tmp",'w','utf-8') as f:
    f.write(part1)
print("Part 1 OK")
