<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>المكتبة الإسلامية الشاملة - الموسوعة الإسلامية</title>
<link href="https://fonts.googleapis.com/css2?family=Amiri:ital,wght@0,400;0,700;1,400&family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root{--gold:#d4af37;--gold-light:#f9f1d8;--gold-dark:#aa8a2a;--dark:#0b192c;--primary:#92400e;--secondary:#b45309;} /* Bronze/Brown Theme for Library */
body{font-family:'Cairo',sans-serif;background:#f8fafc;color:#1e293b;overflow-x:hidden;}
h1,h2,h3,h4,h5,h6,.ar,.poetry{font-family:'Amiri',serif;}

/* MEGA NAVBAR */
.navbar {background:linear-gradient(135deg,#0b192c,var(--dark))!important;box-shadow:0 4px 30px rgba(0,0,0,.5);z-index:1000;border-bottom:2px solid rgba(212,175,55,0.2);}
.navbar-brand{font-family:'Amiri',serif;font-size:1.8rem;color:white!important;text-shadow:0 2px 10px rgba(212,175,55,0.5);}
.nav-link{color:rgba(255,255,255,.8)!important;font-weight:700;letter-spacing:0.5px;transition:all .3s;}
.nav-link:hover, .nav-link.active{color:var(--gold)!important;transform:translateX(-2px);}

/* MEGA HERO - LIBRARY (BRONZE & GOLD) */
.mega-hero{min-height:70vh;background:linear-gradient(135deg, var(--dark) 0%, var(--primary) 100%);position:relative;overflow:hidden;display:flex;align-items:center;padding:120px 0;}
.hero-glass{background:rgba(11,25,44,0.4);backdrop-filter:blur(15px);border:1px solid rgba(212,175,55,0.3);border-radius:30px;padding:60px 40px;box-shadow:0 20px 50px rgba(0,0,0,0.5);position:relative;z-index:5;text-align:center;}
.hero-pattern{position:absolute;inset:0;background:url('https://www.transparenttextures.com/patterns/arabesque.png');opacity:.1;mix-blend-mode:overlay;}
.hero-eyebrow{display:inline-block;background:linear-gradient(90deg,var(--gold-dark),var(--gold));color:#0b192c;padding:8px 30px;border-radius:50px;font-weight:bold;font-size:1rem;margin-bottom:25px;box-shadow:0 4px 15px rgba(212,175,55,0.4);}
.mega-hero h1{font-size:5rem;font-weight:900;color:white;text-shadow:0 10px 30px rgba(0,0,0,0.8);line-height:1.2;margin-bottom:20px;}
.mega-hero h1 span{background:linear-gradient(135deg,#fff,var(--gold));-webkit-background-clip:text;-webkit-text-fill-color:transparent;}
.tagline{color:#e2e8f0;font-size:1.3rem;line-height:2.2;text-shadow:0 2px 4px rgba(0,0,0,0.5);max-width:800px;margin:0 auto;}

/* Floating Books Animation */
.book-float{position:absolute;opacity:0.1;color:var(--gold);animation:floatUp 20s linear infinite;}
@keyframes floatUp {0%{transform:translateY(100vh) rotate(0deg);opacity:0;}10%{opacity:0.2;}90%{opacity:0.2;}100%{transform:translateY(-20vh) rotate(360deg);opacity:0;}}

/* Search Area */
.search-container { position:relative; z-index:20; background:rgba(255,255,255,0.1); backdrop-filter:blur(10px); padding:15px; border-radius:30px; border:1px solid rgba(255,255,255,0.2); box-shadow:0 15px 35px rgba(0,0,0,0.2); display:flex; align-items:center; max-width:700px; margin:40px auto 0; }
.search-container input { border-radius:30px; padding:15px 25px; border:none; box-shadow:none; background:rgba(255,255,255,0.9); margin-left:10px; font-size:1.1rem; font-family:'Amiri',serif; }
.search-container input:focus { box-shadow:0 0 0 4px rgba(212,175,55,0.3); background:#fff; }
.btn-search { border-radius:30px; padding:15px 35px; background:linear-gradient(135deg,var(--gold-dark),var(--gold)); border:none; color:#0b192c; font-weight:bold; font-size:1.1rem; transition:all 0.3s; box-shadow:0 5px 15px rgba(212,175,55,0.3); }
.btn-search:hover { transform:translateY(-2px); box-shadow:0 8px 20px rgba(212,175,55,0.5); color:#000; }

/* Filter Tabs */
.mega-tabs { display:flex; justify-content:center; flex-wrap:wrap; gap:15px; margin:-30px auto 50px; position:relative; z-index:10; }
.mega-tabs button { background:white; color:var(--dark); border:1px solid #e2e8f0; padding:12px 30px; border-radius:50px; font-weight:bold; font-size:1.1rem; transition:all .3s; box-shadow:0 10px 20px rgba(0,0,0,0.05); }
.mega-tabs button:hover, .mega-tabs button.active { background:var(--gold); color:#0b192c; border-color:var(--gold); transform:translateY(-3px); box-shadow:0 15px 25px rgba(212,175,55,0.3); }

/* Book Cards */
.book-item { margin-bottom:30px; }
.book-card { border:none; border-radius:20px; overflow:hidden; background:#fff; transition:all 0.4s cubic-bezier(0.175,0.885,0.32,1.275); box-shadow:0 10px 20px rgba(0,0,0,0.03); position:relative; height:100%; border:1px solid rgba(0,0,0,0.04); }
.book-card:hover { transform:translateY(-10px); box-shadow:0 20px 40px rgba(146,64,14,0.15); border-color:var(--gold); }
.icon-wrapper { width:80px; height:80px; border-radius:50%; display:flex; align-items:center; justify-content:center; margin:0 auto 20px; background:linear-gradient(135deg,rgba(146,64,14,0.1),rgba(212,175,55,0.1)); color:var(--primary); transition:all 0.4s; font-size:2rem; }
.book-card:hover .icon-wrapper { background:linear-gradient(135deg,var(--primary),var(--gold)); color:white; transform:scale(1.1) rotate(5deg); box-shadow:0 10px 20px rgba(146,64,14,0.3); }
.card-title { font-weight:800; color:#1e293b; font-size:1.3rem; margin-bottom:0.5rem; font-family:'Amiri',serif; line-height:1.5; height:60px; overflow:hidden; }
.card-text { font-size:0.95rem; color:#64748b; margin-bottom:15px; }

/* Category Badges inside cards */
.badge-quran { background-color:#e8f5e9; color:#2e7d32; border:1px solid #c8e6c9;}
.badge-hadith { background-color:#e3f2fd; color:#1565c0; border:1px solid #bbdefb;}
.badge-fiqh { background-color:#fff3e0; color:#ef6c00; border:1px solid #ffe0b2;}
.badge-aqeedah { background-color:#fce4ec; color:#c2185b; border:1px solid #f8bbd0;}
.badge-seerah { background-color:#fff8e1; color:#f57f17; border:1px solid #ffecb3;}
.badge-tazkiyah { background-color:#e0f2f1; color:#00695c; border:1px solid #b2dfdb;}
.custom-badge { padding:8px 15px; border-radius:20px; font-weight:700; font-size:0.8rem; letter-spacing:0.5px; }

/* Quick View Button */
.quick-view-btn { background:#f8fafc; border:none; color:#475569; border-radius:15px; padding:12px; font-weight:bold; transition:all 0.3s; margin:0 20px 20px; width:calc(100% - 40px); }
.book-card:hover .quick-view-btn { background:linear-gradient(90deg,var(--primary),var(--gold-dark)); color:white; box-shadow:0 5px 15px rgba(212,175,55,0.3); }

/* Modal Mega Design */
.modal-content { border-radius:25px; border:none; overflow:hidden; }
.modal-header { background:linear-gradient(135deg,var(--primary),#0b192c); color:white; border:none; padding:25px; border-bottom:3px solid var(--gold); }
.modal-title { font-family:'Amiri',serif; font-size:1.8rem; font-weight:bold; }
.modal-header .btn-close { filter:brightness(0) invert(1); opacity:0.8; }
#qvDownloadBtn { border-radius:20px; padding:12px 30px; background:linear-gradient(135deg,var(--gold-dark),var(--gold)); border:none; box-shadow:0 5px 15px rgba(212,175,55,0.3); color:#0b192c; font-weight:bold; transition:0.3s; }
#qvDownloadBtn:hover { transform:translateY(-2px); box-shadow:0 8px 20px rgba(212,175,55,0.5); color:white; }

/* MEGA FOOTER */
.mega-footer{background:linear-gradient(135deg,#0b192c,#020617);color:white;padding:80px 0 30px;margin-top:0;border-top:3px solid var(--gold-dark);}
.mega-footer-link{color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;}
.mega-footer-link:hover{color:var(--gold);padding-right:5px;}
</style>
</head>
<body>

<!-- MEGA NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-dark sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold" href="index.html"><i class="fas fa-book-open me-2 text-warning"></i>الموسوعة الإسلامية الشاملة</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav1">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="nav1">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link " href="index.html">الرئيسية</a></li>
        <li class="nav-item"><a class="nav-link " href="recitations.html">القرآن والتلاوات</a></li>
        <li class="nav-item"><a class="nav-link " href="hadith.html">الحديث الشريف</a></li>
        <li class="nav-item"><a class="nav-link " href="fiqh.html">الفقه الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="fatwa.html">فتاوى العلماء <i class="fas fa-gavel"></i></a></li>
        <li class="nav-item"><a class="nav-link " href="seerah.html">السيرة والصحابة</a></li>
        <li class="nav-item"><a class="nav-link " href="aqeedah.html">العقيدة الإسلامية</a></li>
        <li class="nav-item"><a class="nav-link " href="history.html">التاريخ الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link active" style="color:var(--gold)!important;" href="library.html">المكتبة الشاملة</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- MEGA HERO LIBRARY -->
<section class="mega-hero">
  <!-- Decorative Books -->
  <i class="fas fa-book book-float" style="left:10%; font-size:4rem; animation-duration:15s;"></i>
  <i class="fas fa-scroll book-float" style="left:30%; font-size:3rem; animation-duration:22s; animation-delay:2s"></i>
  <i class="fas fa-quran book-float" style="right:15%; font-size:5rem; animation-duration:18s; animation-delay:5s"></i>
  <i class="fas fa-book-open book-float" style="right:40%; font-size:2.5rem; animation-duration:25s; animation-delay:1s"></i>
  
  <div class="hero-pattern"></div>
  <div class="container relative z-10">
    <div class="row justify-content-center">
      <div class="col-lg-10">
        <div class="hero-glass">
            <div class="hero-eyebrow"><i class="fas fa-book-reader me-2"></i>اقرأ باسم ربك الذي خلق</div>
            <h1>المكتبة <span>الإسلامية</span> الشاملة</h1>
            <p class="tagline mt-3">كنز من المصادر والمراجع العلمية الموثوقة في شتى العلوم الشرعية (أكثر من 150 كتاباً ومؤلفاً)، مصنفة بعناية وسهلة البحث لتُغني الباحث والطالب والمسلم في دينه ودنياه.</p>
            
            <div class="search-container">
                <input type="text" class="form-control" id="bookSearch" placeholder="ابحث في أكثر من 150 كتاباً (مثال: الشافعي، البخاري، التفسير)...">
                <button class="btn btn-search" type="button"><i class="fas fa-search"></i> بحث</button>
            </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- MAIN CONTENT -->
<section class="container" style="margin-bottom:100px;">
  <!-- FILTER TABS -->
  <div class="mega-tabs">
      <button class="active" data-filter="all">جميع الكتب</button>
      <button data-filter="quran">علوم القرآن</button>
      <button data-filter="hadith">الحديث الشريف</button>
      <button data-filter="fiqh">الفقه وأصوله</button>
      <button data-filter="aqeedah">العقيدة والتزكية</button>
      <button data-filter="seerah">السيرة والتاريخ</button>
  </div>

  <div class="row g-4" id="bookGrid">
      <div class="col-12 text-center py-5">
         <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status"></div>
         <h4 class="mt-3 font-amiri">جاري ترتيب رفوف المكتبة...</h4>
      </div>
  </div>
</section>

<!-- Quick View Modal -->
<div class="modal fade" id="quickViewModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header">
                <h5 class="modal-title" id="quickViewModalLabel"><i class="fas fa-book-open me-2 text-warning"></i>معاينة التفاصيل</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-4 p-md-5">
                <div class="row align-items-center">
                    <div class="col-md-4 text-center mb-4 mb-md-0 border-end border-1">
                        <div style="background:linear-gradient(135deg,rgba(146,64,14,0.1),rgba(212,175,55,0.1)); padding:30px; border-radius:50%; display:inline-block; margin-bottom:20px;">
                            <i id="qvIcon" class="fas fa-book fa-5x" style="color:var(--primary);"></i>
                        </div>
                        <h4 id="qvTitle" class="fw-bold mb-3" style="color:#0b192c; font-family:'Amiri',serif;">اسم الكتاب</h4>
                        <span class="badge mb-3 custom-badge badge-quran" id="qvCategory">القسم</span>
                    </div>
                    <div class="col-md-8 px-md-4">
                        <h5 id="qvAuthor" class="text-dark mb-4 fw-bold font-amiri fs-4">المؤلف: </h5>
                        
                        <h6 class="fw-bold text-muted border-bottom pb-2"><i class="fas fa-info-circle me-2 text-primary"></i> نبذة عن الكتاب:</h6>
                        <p id="qvDesc" class="text-secondary mb-4 fs-5" style="line-height:1.8; font-family:'Amiri',serif;"></p>
                        
                        <h6 class="fw-bold text-muted border-bottom pb-2"><i class="fas fa-list-ul me-2 text-primary"></i> محتويات (الفهرس):</h6>
                        <ul class="text-secondary list-unstyled fs-6">
                            <li class="mb-2"><i class="fas fa-check text-success me-2"></i>المقدمة والمنهجية العلمية للمؤلف.</li>
                            <li class="mb-2"><i class="fas fa-check text-success me-2"></i>أبواب ومقاصد الكتاب الرئيسية ومسائله.</li>
                            <li class="mb-2"><i class="fas fa-check text-success me-2"></i>الفهارس الملحقة والمراجع وتخريج الأحاديث.</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="modal-footer bg-light border-0">
                <button type="button" class="btn btn-outline-secondary px-4 rounded-pill fw-bold" data-bs-dismiss="modal">إغلاق</button>
                <a href="#" class="btn px-4" id="qvDownloadBtn"><i class="fas fa-download me-2"></i>تحميل وطباعة (PDF)</a>
            </div>
        </div>
    </div>
</div>

<!-- MEGA FOOTER -->
<footer class="mega-footer" style="background:linear-gradient(135deg,var(--dark),#020617);color:white;padding:80px 0 30px;margin-top:80px;border-top:3px solid var(--gold-dark);">
  <div class="container">
    <div class="row g-5 mb-5 border-bottom border-light border-opacity-10 pb-5">
      <div class="col-lg-4 text-md-end text-center">
        <i class="fas fa-mosque fa-4x text-warning mb-4 d-block"></i>
        <h4 class="fw-bold font-amiri fs-2 mb-3">الموسوعة الإسلامية الشاملة</h4>
        <p class="opacity-75 fs-6 line-height-2">أضخم صرح رقمي يجمع علوم القرآن العظيم، وأحاديث المصطفى، وفقهاء المذاهب، والتاريخ المجيد في منصة موثقة مصممة بأحدث التقنيات.</p>
      </div>
      <div class="col-lg-4 text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">تصفح الموسوعة</h5>
        <div class="d-flex flex-wrap justify-content-center gap-2">
          <a href="recitations.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">أكاديمية القرآن</a>
          <a href="hadith.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الحديث النبوي</a>
          <a href="seerah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">السيرة والصحابة</a>
          <a href="fiqh.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الفقه وأصوله</a>
          <a href="fatwa.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">فتاوى العلماء</a>
          <a href="aqeedah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">العقيدة الإسلامية</a>
          <a href="history.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">التاريخ المجيد</a>
          <a href="library.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">المكتبة الشاملة</a>
        </div>
      </div>
      <div class="col-lg-4 text-md-start text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">روابط سريعة</h5>
        <a href="contact.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> اتصل بالمطور</a>
        <a href="share.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> شارك الأجر</a>
        <a href="login.html" class="mega-footer-link text-warning mt-3" style="text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-user-circle me-2 ms-1"></i> تسجيل الدخول</a>
      </div>
    </div>
    <div class="text-center font-amiri fs-5 d-flex flex-column gap-2">
      <span class="opacity-75">الموسوعة الإسلامية الشاملة &copy; 2026 تم التصميم للإفادة | عمل مجاني لوجه الله</span>
      <span class="text-warning fw-bold fs-4 mt-2">تصميم وتطوير: لخذاري محمد سيف الدين</span>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/isotope-layout@3/dist/isotope.pkgd.min.js"></script>
<script src="books.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const grid = document.querySelector('#bookGrid');
    
    if (typeof booksData !== 'undefined') {
        let htmlContent = '';
        booksData.forEach(book => {
            // Map our fine-grained categories to the mega tab filters
            let filterCat = book.id; 
            if(book.id === 'tazkiyah') filterCat = 'aqeedah'; // Merge for filter simple
            
            let badgeClass = "badge-seerah";
            if(book.id === 'quran') badgeClass = "badge-quran";
            else if(book.id === 'hadith') badgeClass = "badge-hadith";
            else if(book.id === 'fiqh') badgeClass = "badge-fiqh";
            else if(book.id === 'aqeedah') badgeClass = "badge-aqeedah";
            else if(book.id === 'tazkiyah') badgeClass = "badge-tazkiyah";
            
            htmlContent += `
            <div class="col-md-4 col-lg-3 book-item" data-category="${filterCat}" data-original-id="${book.id}">
                <div class="card book-card">
                    <div class="card-body text-center p-4">
                        <div class="icon-wrapper"><i class="fas fa-${book.icon}"></i></div>
                        <h5 class="card-title" title="${book.title}">${book.title}</h5>
                        <p class="card-text fw-bold mb-2"><i class="fas fa-pen-nib me-1 opacity-50"></i>${book.author}</p>
                        <span class="badge custom-badge ${badgeClass} mb-0">${book.categoryName}</span>
                    </div>
                    <button type="button" class="btn quick-view-btn" data-bs-toggle="modal" data-bs-target="#quickViewModal">
                        <i class="fas fa-eye me-2"></i>تصفح الكتاب
                    </button>
                </div>
            </div>`;
        });
        grid.innerHTML = htmlContent;
    }

    let iso;
    setTimeout(() => {
        iso = new Isotope(grid, {
            itemSelector: '.book-item',
            layoutMode: 'fitRows',
            isOriginLeft: false
        });

        const filterButtons = document.querySelectorAll('[data-filter]');
        filterButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                filterButtons.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                const filterValue = btn.getAttribute('data-filter');
                iso.arrange({
                    filter: filterValue === 'all' ? '*' : `[data-category="${filterValue}"]`
                });
            });
        });

        const searchInput = document.getElementById('bookSearch');
        if (searchInput) {
            searchInput.addEventListener('keyup', function () {
                const query = this.value.trim().toLowerCase();
                const activeBtn = document.querySelector('[data-filter].active');
                const categoryFilter = activeBtn ? activeBtn.getAttribute('data-filter') : 'all';

                iso.arrange({
                    filter: function(itemElem) {
                        const title = itemElem.querySelector('.card-title').textContent.toLowerCase();
                        const author = itemElem.querySelector('.card-text').textContent.toLowerCase();
                        const filterCat = itemElem.getAttribute('data-category');
                        
                        const matchesSearch = title.includes(query) || author.includes(query);
                        const matchesCategory = categoryFilter === 'all' || filterCat === categoryFilter;

                        return matchesSearch && matchesCategory;
                    }
                });
            });
        }
    }, 200);

    grid.addEventListener('click', function(e) {
        const btn = e.target.closest('.quick-view-btn');
        if (!btn) return;
        
        const card = btn.closest('.book-card');
        const title = card.querySelector('.card-title').textContent.trim();
        const author = card.querySelector('.card-text').textContent.trim().replace('...', '');
        const badge = card.querySelector('.badge').textContent.trim();
        const iconClass = card.querySelector('.icon-wrapper i').className;
        const badgeClass = card.querySelector('.badge').className.match(/badge-[a-z]+/)[0];

        document.getElementById('qvTitle').textContent = title;
        document.getElementById('qvAuthor').innerHTML = `<i class="fas fa-user-edit me-2 text-warning"></i>${author}`;
        
        const catElem = document.getElementById('qvCategory');
        catElem.textContent = badge;
        catElem.className = `badge custom-badge mb-3 px-4 py-2 fs-6 ${badgeClass}`;
        
        document.getElementById('qvIcon').className = iconClass + " fa-5x";
        
        document.getElementById('qvDesc').textContent = `يُعنى كتاب (${title}) لفضيلة ${author} بتفصيل القول في ${badge}، وهو من المراجع الهامة التي لا غنى عنها لطالب العلم والباحث المتخصص. يعتمد الكتاب على متانة الاستدلال ووضوح العبارة.`;
        document.getElementById('qvDownloadBtn').setAttribute('href', '#download_' + encodeURIComponent(title));
    });
});
</script>
</body>
</html>
