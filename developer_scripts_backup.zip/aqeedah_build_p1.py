import codecs

css = """<style>
:root{--gold:#c9a66b;--gold2:#e8d5a3;--dark:#05101c;--blue:#0a2540;--blue2:#15457a;}
body{font-family:'Cairo',sans-serif;background:#f4f7fdf0;color:#1c252e;overflow-x:hidden;}
h1,h2,h3,h4,.ar{font-family:'Amiri',serif;}
/* HERO */
.aqeedah-hero{min-height:560px;background:linear-gradient(160deg,#030a12 0%,#0a2540 45%,#15457a 100%);position:relative;overflow:hidden;display:flex;align-items:center;padding:80px 0;}
.orb{position:absolute;border-radius:50%;filter:blur(90px);opacity:.25;animation:orb 12s infinite alternate;}
.orb:nth-child(1){width:450px;height:450px;background:#c9a66b;top:-100px;right:-100px;}
.orb:nth-child(2){width:300px;height:300px;background:#4fa8ff;bottom:-80px;left:5%;animation-delay:4s;}
@keyframes orb{from{transform:scale(1) translate(0,0)}to{transform:scale(1.2) translate(25px,25px)}}
.hero-pattern{position:absolute;inset:0;background:url('https://www.transparenttextures.com/patterns/stardust.png');opacity:.15;}
.hero-content{position:relative;z-index:5;color:white;}
.hero-eyebrow{display:inline-block;border:1px solid rgba(201,166,107,.4);background:rgba(201,166,107,.1);backdrop-filter:blur(10px);color:var(--gold2);border-radius:40px;padding:8px 24px;font-size:.85rem;font-weight:700;margin-bottom:20px;}
.hero h1{font-size:3.8rem;font-weight:bold;margin-bottom:12px;background:linear-gradient(135deg,#fff 30%,var(--gold2) 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;line-height:1.3;}
.tagline{color:rgba(255,255,255,.7);font-size:1.1rem;margin-bottom:35px;line-height:2;}
.hero-quote{background:rgba(255,255,255,.06);border:1px solid rgba(201,166,107,.2);border-right:4px solid var(--gold);border-radius:16px;padding:22px 26px;max-width:680px;backdrop-filter:blur(12px);}
.hero-quote p{font-family:'Amiri',serif;font-size:1.3rem;line-height:2;color:white;margin:0;}
/* STATS */
.stats-strip{background:linear-gradient(90deg,#0a2540,#15457a);padding:22px 0;border-top:1px solid rgba(255,255,255,0.05);}
.stat-item{text-align:center;color:white;padding:8px;}
.stat-num{font-size:2.3rem;font-weight:800;color:var(--gold2);font-family:'Amiri',serif;line-height:1;}
.stat-label{font-size:.75rem;opacity:.6;margin-top:5px;}
/* TABS */
.sec-tabs{background:white;border-radius:60px;padding:8px;box-shadow:0 10px 40px rgba(10,37,64,.08);margin:45px 0 40px;display:flex;overflow-x:auto;border:1px solid rgba(10,37,64,.05);}
.sec-tabs::-webkit-scrollbar{height:0;}
.sec-tabs .nav-item{flex:1;min-width:130px;}
.sec-tabs .nav-link{border:none;border-radius:50px;color:#555;font-weight:700;padding:14px 12px;width:100%;text-align:center;transition:all .35s;white-space:nowrap;font-size:.9rem;}
.sec-tabs .nav-link.active{background:linear-gradient(135deg,#0a2540,#15457a);color:white;box-shadow:0 8px 20px rgba(10,37,64,.3);}
/* SEC HEAD */
.sec-head{text-align:center;margin-bottom:45px;}
.sec-head .tag{display:inline-block;background:rgba(10,37,64,.08);color:var(--blue);border-radius:40px;padding:6px 20px;font-size:.82rem;font-weight:700;margin-bottom:15px;}
.sec-head h3{font-size:2.2rem;color:#0a2540;font-weight:700;margin-bottom:8px;}
.sec-head h3 span{color:var(--gold);}
.sec-head p{color:#666;max-width:620px;margin:0 auto;}
.sec-head .divider{width:60px;height:4px;background:linear-gradient(90deg,var(--gold),var(--gold2));border-radius:2px;margin:15px auto 0;}
/* CARDS */
.tawhid-card{background:white;border-radius:20px;overflow:hidden;box-shadow:0 10px 30px rgba(10,37,64,.07);transition:all .4s;height:100%;border-top:4px solid transparent;}
.tawhid-card:hover{transform:translateY(-8px);box-shadow:0 22px 55px rgba(10,37,64,.12);}
.t-rububiyyah{border-color:#3498db;} .t-uluhiyyah{border-color:#2ecc71;} .t-asma{border-color:#f1c40f;}
.tcard-icon{width:70px;height:70px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:1.8rem;color:white;margin:25px auto 15px;box-shadow:0 10px 20px rgba(0,0,0,.1);}
.t-rububiyyah .tcard-icon{background:linear-gradient(135deg,#2980b9,#3498db);}
.t-uluhiyyah .tcard-icon{background:linear-gradient(135deg,#27ae60,#2ecc71);}
.t-asma .tcard-icon{background:linear-gradient(135deg,#f39c12,#f1c40f);}
/* ARKAN */
.rukn-card{background:white;border-radius:18px;padding:25px;box-shadow:0 8px 25px rgba(10,37,64,.06);border-right:4px solid var(--gold);display:flex;align-items:flex-start;gap:15px;transition:.3s;height:100%;}
.rukn-card:hover{transform:translateX(-5px);}
.rukn-num{flex-shrink:0;width:50px;height:50px;border-radius:14px;background:linear-gradient(135deg,#0a2540,#15457a);color:var(--gold2);display:flex;align-items:center;justify-content:center;font-size:1.5rem;font-weight:bold;font-family:'Amiri',serif;}
/* NAWAQID */
.nawaqid-list{list-style:none;padding:0;margin:0;}
.nawaqid-item{background:white;border-radius:12px;padding:20px;margin-bottom:15px;box-shadow:0 5px 15px rgba(0,0,0,.04);border-right:4px solid #e74c3c;display:flex;gap:15px;align-items:center;}
.nawaqid-item i{font-size:1.5rem;color:#e74c3c;}
/* KUTUB */
.kitab-card{background:white;border-radius:20px;padding:25px;box-shadow:0 10px 30px rgba(0,0,0,.06);transition:all .3s;height:100%;text-align:center;}
.kitab-card:hover{transform:translateY(-5px);}
.kitab-icon{width:60px;height:60px;border-radius:15px;background:rgba(201,166,107,.15);color:#0a2540;font-size:1.5rem;display:flex;align-items:center;justify-content:center;margin:0 auto 15px;}
/* QUOTE STRIP */
.quote-strip{background:linear-gradient(135deg,#0a2540,#15457a);border-radius:20px;padding:40px;color:white;position:relative;overflow:hidden;margin:30px 0;}
.quote-strip::before{content:'"';position:absolute;right:20px;top:-20px;font-size:10rem;opacity:.07;font-family:'Amiri',serif;line-height:1;}
.quote-strip p{font-family:'Amiri',serif;font-size:1.4rem;line-height:2.2;margin:0;}

@media(max-width:768px){.hero h1{font-size:2.2rem;}.sec-tabs{gap:5px;}}
</style>"""

part1 = """<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>العقيدة الإسلامية - الموسوعة الإسلامية الشاملة</title>
<link href="https://fonts.googleapis.com/css2?family=Amiri:ital,wght@0,400;0,700;1,400&family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="styles.css">
""" + css + """
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold" href="index.html"><i class="fas fa-book-open me-2 text-warning"></i>الموسوعة الإسلامية الشاملة</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav1">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="nav1">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link " href="index.html">الرئيسية</a></li>
        <li class="nav-item"><a class="nav-link " href="recitations.html">القرآن والتلاوات</a></li>
        <li class="nav-item"><a class="nav-link " href="hadith.html">الحديث الشريف</a></li>
        <li class="nav-item"><a class="nav-link " href="fiqh.html">الفقه الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="fatwa.html">فتاوى العلماء <i class="fas fa-gavel"></i></a></li>
        <li class="nav-item"><a class="nav-link " href="seerah.html">السيرة والصحابة</a></li>
        <li class="nav-item"><a class="nav-link active" href="aqeedah.html">العقيدة الإسلامية</a></li>
        <li class="nav-item"><a class="nav-link " href="history.html">التاريخ الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="library.html">المكتبة الشاملة</a></li>
      </ul>
    </div>
  </div>
</nav>

<section class="aqeedah-hero">
  <div class="orb"></div><div class="orb"></div>
  <div class="hero-pattern"></div>
  <div class="container hero-content">
    <div class="row align-items-center g-5">
      <div class="col-lg-7">
        <div class="hero-eyebrow"><i class="fas fa-pray me-2"></i>موسوعة العقيدة الإسلامية</div>
        <h1>العقيدة الإسلامية<br>وأصول الإيمان</h1>
        <p class="tagline">الأساس المتين الذي يُبنى عليه الدين ـ توحيد الله في ربوبيته وألوهيته وأسمائه وصفاته، والتصديق بأركان الإيمان الستة وفهم نواقض الإسلام.</p>
        <div class="hero-quote">
          <p>«الْإِيمَانُ أَنْ تُؤْمِنَ بِاللَّهِ وَمَلَائِكَتِهِ وَكُتُبِهِ وَرُسُلِهِ وَالْيَوْمِ الْآخِرِ، وَتُؤْمِنَ بِالْقَدَرِ خَيْرِهِ وَشَرِّهِ»</p>
          <small>— صحيح مسلم (حديث جبريل)</small>
        </div>
      </div>
      <div class="col-lg-5 d-none d-lg-block text-center">
        <div style="position:relative;width:300px;height:300px;margin:0 auto;">
          <div style="position:absolute;inset:0;border-radius:50%;border:2px solid rgba(201,166,107,.2);animation:spin 30s linear infinite;"></div>
          <div style="position:absolute;inset:20px;border-radius:50%;border:1px dashed rgba(201,166,107,.3);animation:spin 20s linear infinite reverse;"></div>
          <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;">
             <i class="fas fa-kaaba" style="font-size:6rem;color:var(--gold);opacity:.9;filter:drop-shadow(0 0 20px rgba(201,166,107,.5));"></i>
          </div>
          <div style="position:absolute;bottom:-15px;left:50%;transform:translateX(-50%);background:rgba(201,166,107,.15);border:1px solid rgba(201,166,107,.3);border-radius:20px;padding:6px 18px;font-size:.8rem;color:var(--gold2);white-space:nowrap;backdrop-filter:blur(8px);font-weight:bold;">لا إله إلا الله محمد رسول الله</div>
        </div>
      </div>
    </div>
  </div>
</section>

<div class="stats-strip">
  <div class="container">
    <div class="row text-center g-0">
      <div class="col-4 col-md-2 stat-item border-end border-white border-opacity-25"><div class="stat-num">3</div><div class="stat-label">أقسام التوحيد</div></div>
      <div class="col-4 col-md-2 stat-item border-end border-white border-opacity-25"><div class="stat-num">6</div><div class="stat-label">أركان الإيمان</div></div>
      <div class="col-4 col-md-2 stat-item border-end border-white border-opacity-25"><div class="stat-num">99</div><div class="stat-label">اسماً حسنى</div></div>
      <div class="col-4 col-md-2 stat-item border-end border-white border-opacity-25"><div class="stat-num">10</div><div class="stat-label">نواقض للإسلام</div></div>
      <div class="col-4 col-md-2 stat-item border-end border-white border-opacity-25"><div class="stat-num">7</div><div class="stat-label">شروط التوحيد</div></div>
      <div class="col-4 col-md-2 stat-item"><div class="stat-num">+</div><div class="stat-label">متون ومراجع</div></div>
    </div>
  </div>
</div>

<div class="container mb-5">
<ul class="nav sec-tabs" id="aTabs" role="tablist">
  <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#t-tawhid"><i class="fas fa-hand-holding-heart me-1"></i>أقسام التوحيد</button></li>
  <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t-arkan"><i class="fas fa-layer-group me-1"></i>أركان الإيمان</button></li>
  <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t-asma"><i class="fas fa-book-open me-1"></i>الأسماء والصفات</button></li>
  <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t-nawaqid"><i class="fas fa-exclamation-triangle me-1"></i>نواقض الإسلام</button></li>
  <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t-kutub"><i class="fas fa-scroll me-1"></i>متون العقيدة</button></li>
</ul>

<div class="tab-content">
<!-- TAB 1: TAWHID -->
<div class="tab-pane fade show active" id="t-tawhid">
  <div class="sec-head">
    <span class="tag">إفراد الله بالعبادة</span>
    <h3>أقسام <span>التوحيد الثلاثة</span></h3>
    <p>التوحيد هو إفراد الله سبحانه بما يختص به من الربوبية، والألوهية، والأسماء والصفات.</p>
    <div class="divider"></div>
  </div>
  
  <div class="row g-4 mb-5 text-center">
    <div class="col-lg-4">
      <div class="tawhid-card t-rububiyyah">
        <div class="tcard-icon"><i class="fas fa-globe"></i></div>
        <h4 style="color:#2980b9;font-weight:700;">توحيد الربوبية</h4>
        <div class="p-4 pt-1">
          <p class="text-muted small mb-4">هو إفراد الله تعالى بأفعاله، كالخلق، والرزق، والإحياء، والإماتة، والتدبير. الإقرار بأن الله وحده هو الخالق الرازق المدبر لكل شيء.</p>
          <div style="background:#f4fbff;border-radius:10px;padding:12px;font-size:.85rem;color:#1a5a85;font-family:'Amiri',serif;">
            ﴿اللَّهُ خَالِقُ كُلِّ شَيْءٍ وَهُوَ عَلَى كُلِّ شَيْءٍ وَكِيلٌ﴾
          </div>
        </div>
      </div>
    </div>
    
    <div class="col-lg-4">
      <div class="tawhid-card t-uluhiyyah">
        <div class="tcard-icon"><i class="fas fa-praying-hands"></i></div>
        <h4 style="color:#27ae60;font-weight:700;">توحيد الألوهية</h4>
        <div class="p-4 pt-1">
          <p class="text-muted small mb-4">ويسمى توحيد العبادة. وهو إفراد الله تعالى بأفعال العباد من صلاة، وصيام، وحج، ودعاء، ونذر، وذبح، وخوف، ورجاء، وتوكل.</p>
          <div style="background:#f4fff8;border-radius:10px;padding:12px;font-size:.85rem;color:#186c3b;font-family:'Amiri',serif;">
            ﴿وَمَا خَلَقْتُ الْجِنَّ وَالْإِنسَ إِلَّا لِيَعْبُدُونِ﴾
          </div>
        </div>
      </div>
    </div>
    
    <div class="col-lg-4">
      <div class="tawhid-card t-asma">
        <div class="tcard-icon"><i class="fas fa-feather"></i></div>
        <h4 style="color:#d35400;font-weight:700;">توحيد الأسماء والصفات</h4>
        <div class="p-4 pt-1">
          <p class="text-muted small mb-4">إثبات ما أثبته الله لنفسه وما أثبته له رسوله من الأسماء والصفات، من غير تحريف ولا تعطيل ولا تكييف ولا تمثيل.</p>
          <div style="background:#fffaf4;border-radius:10px;padding:12px;font-size:.85rem;color:#a04000;font-family:'Amiri',serif;">
            ﴿لَيْسَ كَمِثْلِهِ شَيْءٌ وَهُوَ السَّمِيعُ البَصِيرُ﴾
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="quote-strip">
    <p>«مَنْ مَاتَ وَهُوَ يَعْلَمُ أَنَّهُ لاَ إِلَهَ إِلاَّ اللَّهُ، دَخَلَ الْجَنَّةَ»</p>
    <small class="d-block mt-2" style="opacity:.5;">— رواه مسلم</small>
  </div>
</div>
"""

with codecs.open(r"C:\Users\ST\Desktop\islamic.encyclopedia\aq_p1.tmp", 'w', 'utf-8') as f:
    f.write(part1)
print("Aqeedah part 1 ready")
