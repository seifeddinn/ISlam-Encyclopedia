import codecs

css = """<style>
:root{--gold:#c9a66b;--gold2:#e8d5a3;--dark:#011f15;--green:#043826;--green2:#116850;}
body{font-family:'Cairo',sans-serif;background:#f5f9f8;color:#1c2522;overflow-x:hidden;}
h1,h2,h3,h4,.ar{font-family:'Amiri',serif;}
/* HERO */
.sahaba-hero{min-height:560px;background:linear-gradient(160deg,#01120c 0%,#043826 45%,#0b543d 100%);position:relative;overflow:hidden;display:flex;align-items:center;padding:80px 0;}
.orb{position:absolute;border-radius:50%;filter:blur(90px);opacity:.2;animation:orb 12s infinite alternate;}
.orb:nth-child(1){width:450px;height:450px;background:#c9a66b;top:-100px;right:-100px;}
.orb:nth-child(2){width:350px;height:350px;background:#1abc9c;bottom:-80px;left:5%;animation-delay:4s;}
@keyframes orb{from{transform:scale(1) translate(0,0)}to{transform:scale(1.2) translate(25px,25px)}}
.hero-pattern{position:absolute;inset:0;background:url('https://www.transparenttextures.com/patterns/arabesque.png');opacity:.1;}
.hero-content{position:relative;z-index:5;color:white;}
.hero-eyebrow{display:inline-block;border:1px solid rgba(201,166,107,.4);background:rgba(201,166,107,.1);backdrop-filter:blur(10px);color:var(--gold2);border-radius:40px;padding:8px 24px;font-size:.85rem;font-weight:700;margin-bottom:20px;}
.hero h1{font-size:3.8rem;font-weight:bold;margin-bottom:12px;background:linear-gradient(135deg,#fff 30%,var(--gold2) 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;line-height:1.3;}
.tagline{color:rgba(255,255,255,.7);font-size:1.1rem;margin-bottom:35px;line-height:2;}
.hero-quote{background:rgba(255,255,255,.06);border:1px solid rgba(201,166,107,.2);border-right:4px solid var(--gold);border-radius:16px;padding:22px 26px;max-width:680px;backdrop-filter:blur(12px);}
.hero-quote p{font-family:'Amiri',serif;font-size:1.3rem;line-height:2;color:white;margin:0;}
/* STATS */
.stats-strip{background:linear-gradient(90deg,#043826,#0b543d);padding:22px 0;border-top:1px solid rgba(255,255,255,0.05);}
.stat-item{text-align:center;color:white;padding:8px;}
.stat-num{font-size:2.3rem;font-weight:800;color:var(--gold2);font-family:'Amiri',serif;line-height:1;}
.stat-label{font-size:.75rem;opacity:.6;margin-top:5px;}
/* TABS */
.sec-tabs{background:white;border-radius:60px;padding:8px;box-shadow:0 10px 40px rgba(4,56,38,.08);margin:45px 0 40px;display:flex;overflow-x:auto;border:1px solid rgba(4,56,38,.05);}
.sec-tabs::-webkit-scrollbar{height:0;}
.sec-tabs .nav-item{flex:1;min-width:130px;}
.sec-tabs .nav-link{border:none;border-radius:50px;color:#555;font-weight:700;padding:14px 12px;width:100%;text-align:center;transition:all .35s;white-space:nowrap;font-size:.9rem;}
.sec-tabs .nav-link.active{background:linear-gradient(135deg,#043826,#0b543d);color:white;box-shadow:0 8px 20px rgba(4,56,38,.3);}
/* SEC HEAD */
.sec-head{text-align:center;margin-bottom:45px;}
.sec-head .tag{display:inline-block;background:rgba(4,56,38,.08);color:var(--green);border-radius:40px;padding:6px 20px;font-size:.82rem;font-weight:700;margin-bottom:15px;}
.sec-head h3{font-size:2.2rem;color:#043826;font-weight:700;margin-bottom:8px;}
.sec-head h3 span{color:var(--gold);}
.sec-head p{color:#666;max-width:620px;margin:0 auto;}
.sec-head .divider{width:60px;height:4px;background:linear-gradient(90deg,var(--gold),var(--gold2));border-radius:2px;margin:15px auto 0;}
/* CARDS */
.fada-card{background:white;border-radius:20px;padding:30px;box-shadow:0 10px 30px rgba(4,56,38,.06);transition:all .4s;height:100%;position:relative;overflow:hidden;}
.fada-card:hover{transform:translateY(-8px);box-shadow:0 20px 40px rgba(4,56,38,.12);}
.fada-icon{width:60px;height:60px;border-radius:15px;background:linear-gradient(135deg,#043826,#116850);color:var(--gold2);display:flex;align-items:center;justify-content:center;font-size:1.5rem;margin-bottom:20px;box-shadow:0 8px 15px rgba(4,56,38,.2);}
/* PROFILE CARDS */
.comp-card{background:white;border-radius:20px;overflow:hidden;box-shadow:0 10px 30px rgba(4,56,38,.05);transition:all .3s;height:100%;}
.comp-card:hover{transform:translateY(-5px);box-shadow:0 15px 35px rgba(4,56,38,.1);}
.comp-head{background:linear-gradient(135deg,#043826,#0b543d);color:white;padding:25px 20px 20px;text-align:center;position:relative;}
.comp-head::after{content:attr(data-bg);position:absolute;right:10px;top:10px;font-family:'Amiri',serif;font-size:5rem;opacity:.05;color:white;line-height:1;}
.comp-body{padding:25px 20px;}
.comp-badge{display:inline-block;background:rgba(201,166,107,.2);color:var(--gold2);border-radius:20px;padding:4px 12px;font-size:.75rem;margin-bottom:12px;border:1px solid rgba(201,166,107,.3);}
/* QUOTE STRIP */
.quote-strip{background:linear-gradient(135deg,#043826,#116850);border-radius:20px;padding:40px;color:white;position:relative;overflow:hidden;margin:30px 0;}
.quote-strip::before{content:'"';position:absolute;right:20px;top:-20px;font-size:10rem;opacity:.05;font-family:'Amiri',serif;line-height:1;}
.quote-strip p{font-family:'Amiri',serif;font-size:1.4rem;line-height:2.2;margin:0;}

@media(max-width:768px){.hero h1{font-size:2.2rem;}.sec-tabs{gap:5px;}}
</style>"""

part1 = """<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>الصحابة الكرام - الموسوعة الإسلامية الشاملة</title>
<link href="https://fonts.googleapis.com/css2?family=Amiri:ital,wght@0,400;0,700;1,400&family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="styles.css">
""" + css + """
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold" href="index.html"><i class="fas fa-book-open me-2 text-warning"></i>الموسوعة الإسلامية الشاملة</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav1">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="nav1">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link " href="index.html">الرئيسية</a></li>
        <li class="nav-item"><a class="nav-link " href="recitations.html">القرآن والتلاوات</a></li>
        <li class="nav-item"><a class="nav-link " href="hadith.html">الحديث الشريف</a></li>
        <li class="nav-item"><a class="nav-link " href="fiqh.html">الفقه الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="fatwa.html">فتاوى العلماء <i class="fas fa-gavel"></i></a></li>
        <li class="nav-item"><a class="nav-link " href="seerah.html">السيرة والصحابة</a></li>
        <li class="nav-item"><a class="nav-link " href="aqeedah.html">العقيدة الإسلامية</a></li>
        <li class="nav-item"><a class="nav-link " href="history.html">التاريخ الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="library.html">المكتبة الشاملة</a></li>
      </ul>
    </div>
  </div>
</nav>

<section class="sahaba-hero">
  <div class="orb"></div><div class="orb"></div>
  <div class="hero-pattern"></div>
  <div class="container hero-content">
    <div class="row align-items-center g-5">
      <div class="col-lg-7">
        <div class="hero-eyebrow"><i class="fas fa-users me-2"></i>موسوعة الصحابة والآل</div>
        <h1>الصحابة الكرام<br>نجوم الأمة</h1>
        <p class="tagline">الجيل القرآني الفريد الذي حمل راية الإسلام ونشره في الآفاق، وبذلوا دماءهم وأموالهم في سبيل الله لنصرة نبيه ﷺ.</p>
        <div class="hero-quote">
          <p>«لَا تَسُبُّوا أَصْحَابِي، فَوَالَّذِي نَفْسِي بِيَدِهِ لَوْ أَنَّ أَحَدَكُمْ أَنْفَقَ مِثْلَ أُحُدٍ ذَهَبًا مَا أَدْرَكَ مُدَّ أَحَدِهِمْ وَلَا نَصِيفَهُ»</p>
          <small>— متفق عليه</small>
        </div>
      </div>
      <div class="col-lg-5 d-none d-lg-block text-center">
        <div style="position:relative;width:300px;height:300px;margin:0 auto;">
          <div style="position:absolute;inset:0;border-radius:50%;border:2px solid rgba(201,166,107,.2);animation:spin 30s linear infinite;"></div>
          <div style="position:absolute;inset:20px;border-radius:50%;border:1px dashed rgba(201,166,107,.3);animation:spin 20s linear infinite reverse;"></div>
          <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;">
             <i class="fas fa-crown" style="font-size:5.5rem;color:var(--gold);opacity:.9;filter:drop-shadow(0 0 20px rgba(201,166,107,.5));"></i>
          </div>
          <div style="position:absolute;top:-10px;left:50%;transform:translateX(-50%);background:rgba(201,166,107,.15);border:1px solid rgba(201,166,107,.3);border-radius:20px;padding:6px 18px;font-size:.8rem;color:var(--gold2);white-space:nowrap;backdrop-filter:blur(8px);font-weight:bold;">رضي الله عنهم ورضوا عنه</div>
        </div>
      </div>
    </div>
  </div>
</section>

<div class="stats-strip">
  <div class="container">
    <div class="row text-center g-0">
      <div class="col-4 col-md-2 stat-item border-end border-white border-opacity-25"><div class="stat-num">4</div><div class="stat-label">الخلفاء الراشدون</div></div>
      <div class="col-4 col-md-2 stat-item border-end border-white border-opacity-25"><div class="stat-num">10</div><div class="stat-label">مبشرون بالجنة</div></div>
      <div class="col-4 col-md-2 stat-item border-end border-white border-opacity-25"><div class="stat-num">313</div><div class="stat-label">أهل بدر</div></div>
      <div class="col-4 col-md-2 stat-item border-end border-white border-opacity-25"><div class="stat-num">1400</div><div class="stat-label">أهل بيعة الرضوان</div></div>
      <div class="col-4 col-md-2 stat-item border-end border-white border-opacity-25"><div class="stat-num">11</div><div class="stat-label">أمهات المؤمنين</div></div>
      <div class="col-4 col-md-2 stat-item"><div class="stat-num">114k+</div><div class="stat-label">صحابي تقريباً</div></div>
    </div>
  </div>
</div>

<div class="container mb-5">
<ul class="nav sec-tabs" id="aTabs" role="tablist">
  <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#t-fadail"><i class="fas fa-star me-1"></i>فضائل الصحابة</button></li>
  <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t-khulafa"><i class="fas fa-chess-king me-1"></i>الخلفاء الراشدون</button></li>
  <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t-ashara"><i class="fas fa-medal me-1"></i>العشرة المبشرون</button></li>
  <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t-ummahat"><i class="fas fa-female me-1"></i>أمهات المؤمنين</button></li>
  <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t-sahabiyat"><i class="fas fa-gem me-1"></i>أعلام الصحابيات</button></li>
</ul>

<div class="tab-content">
<!-- TAB 1: FADAIL -->
<div class="tab-pane fade show active" id="t-fadail">
  <div class="sec-head">
    <span class="tag">خير القرون</span>
    <h3>فضائل <span>الصحابة واعتقادنا فيهم</span></h3>
    <p>عقيدة أهل السنة والجماعة في الصحابة هي الحب والترضي عليهم والإمساك عما شجر بينهم</p>
    <div class="divider"></div>
  </div>
  
  <div class="row g-4 mb-5">
    <div class="col-lg-4 col-md-6">
      <div class="fada-card border-bottom border-4 border-warning">
        <div class="fada-icon"><i class="fas fa-heart"></i></div>
        <h5 style="color:#043826;font-weight:700;">محبتهم دين وإيمان</h5>
        <p class="text-muted small mt-3 mb-0" style="line-height:2;">حب الصحابة دين وإيمان وإحسان، وبغضهم كفر ونفاق وطغيان. فهم الذين نقلوا لنا الدين وصدّقوا الرسول ﷺ وأوصلوا القرآن إلينا.</p>
      </div>
    </div>
    <div class="col-lg-4 col-md-6">
      <div class="fada-card border-bottom border-4 border-warning">
        <div class="fada-icon"><i class="fas fa-shield-alt"></i></div>
        <h5 style="color:#043826;font-weight:700;">عدالتهم جميعاً</h5>
        <p class="text-muted small mt-3 mb-0" style="line-height:2;">أجمع أهل السنة على عدالة جميع الصحابة بلا استثناء، فقد عدّلهم الله تعالى من فوق سبع سماوات في آيات كثيرة من القرآن الكريم.</p>
      </div>
    </div>
    <div class="col-lg-4 col-md-6">
      <div class="fada-card border-bottom border-4 border-warning">
        <div class="fada-icon"><i class="fas fa-comment-slash"></i></div>
        <h5 style="color:#043826;font-weight:700;">الكف عما شجر بينهم</h5>
        <p class="text-muted small mt-3 mb-0" style="line-height:2;">قال عمر بن عبد العزيز: "تلك دماء طهّر الله منها سيوفنا، أفلا نطهّر منها ألسنتنا؟" نعتقد أنهم مجتهدون، للمصيب أجران وللمخطئ أجر.</p>
      </div>
    </div>
    <div class="col-lg-4 col-md-6">
      <div class="fada-card border-bottom border-4 border-warning">
        <div class="fada-icon"><i class="fas fa-quran"></i></div>
        <h5 style="color:#043826;font-weight:700;">تزكية القرآن لهم</h5>
        <p class="text-muted small mt-3 mb-0" style="line-height:2;">قال تعالى: ﴿مُحَمَّدٌ رَسُولُ اللَّهِ وَالَّذِينَ مَعَهُ أَشِدَّاءُ عَلَى الْكُفَّارِ رُحَمَاءُ بَيْنَهُمْ تَرَاهُمْ رُكَّعًا سُجَّدًا يَبْتَغُونَ فَضْلًا مِنَ اللَّهِ وَرِضْوَانًا﴾.</p>
      </div>
    </div>
    <div class="col-lg-4 col-md-6">
      <div class="fada-card border-bottom border-4 border-warning">
        <div class="fada-icon"><i class="fas fa-layer-group"></i></div>
        <h5 style="color:#043826;font-weight:700;">تفاضل مراتبهم</h5>
        <p class="text-muted small mt-3 mb-0" style="line-height:2;">أفضلهم الخلفاء الأربعة على ترتيب خلافتهم، ثم بقية العشرة، ثم أهل بدر، ثم أهل أحد، ثم بيعة الرضوان، والسابقون الأولون أفضل من المُسلمين بعد الفتح.</p>
      </div>
    </div>
    <div class="col-lg-4 col-md-6">
      <div class="fada-card border-bottom border-4 border-warning">
        <div class="fada-icon"><i class="fas fa-users"></i></div>
        <h5 style="color:#043826;font-weight:700;">فضل المهاجرين والأنصار</h5>
        <p class="text-muted small mt-3 mb-0" style="line-height:2;">قال ﷺ: "آية الإيمان حب الأنصار، وآية النفاق بغض الأنصار". والمهاجرون الذين تركوا ديارهم وأموالهم نصرة لله ورسوله مفضلون على غيرهم.</p>
      </div>
    </div>
  </div>
</div>
"""

with codecs.open(r"C:\Users\ST\Desktop\islamic.encyclopedia\shb_p1.tmp", 'w', 'utf-8') as f:
    f.write(part1)
print("Sahaba part 1 ready")
