import codecs
import re

txt = codecs.open('seerah.html','r','utf-8').read()

# 1. Update :root
txt = txt.replace(
    ':root{--gold:#d4af37;--gd:#aa8a2a;--dk:#450a0a;--pr:#b91c1c;--light-red:#fef2f2;}',
    ':root{--gold:#d4af37;--gold-light:#f9f1d8;--gold-dark:#aa8a2a;--dark:#0b192c;--primary:#0369a1;--light-blue:#f0f9ff;}'
)

# 2. Update CSS vars
txt = txt.replace('var(--dk)', 'var(--dark)')
txt = txt.replace('var(--pr)', 'var(--primary)')
txt = txt.replace('var(--gd)', 'var(--gold-dark)')
txt = txt.replace('var(--light-red)', 'var(--light-blue)')

# 3. Update hardcoded colors
txt = txt.replace('#7f1d1d', '#075985')
txt = txt.replace('#dc2626', '#0ea5e9')
txt = txt.replace('rgba(153,27,27', 'rgba(3,105,161')
txt = txt.replace('#fee2e2', '#e0f2fe')
txt = txt.replace('#1a0000', '#0b192c') # Dark text on gold button to dark navy
txt = txt.replace('#450a0a', '#0b192c') 

# 4. Bootstrap classes
txt = txt.replace('border-danger', 'border-primary')
txt = txt.replace('text-danger', 'text-primary')
txt = txt.replace('btn-outline-danger', 'btn-outline-primary')

# 5. Fix any stray mega-footer that might have been wrong, or wait, we'll sync again.
txt = txt.replace('btn-danger', 'btn-primary') # in footer? The footer script uses 'btn-danger' for seerah ?

with codecs.open('seerah.html','w','utf-8') as f:
    f.write(txt)

print("Redesigned seerah theme!")
