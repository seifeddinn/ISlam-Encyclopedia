import codecs

html = """<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>القرآن الكريم - الموسوعة الإسلامية الشاملة</title>
<link href="https://fonts.googleapis.com/css2?family=Amiri:ital,wght@0,400;0,700;1,400&family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root{--gold:#c9a66b;--gold2:#e8d5a3;--dark:#021a24;--cyan:#064b63;--cyan2:#05708a;}
body{font-family:'Cairo',sans-serif;background:#f0f6f8;color:#1c2528;overflow-x:hidden;padding-bottom:100px;}
h1,h2,h3,h4,.ar{font-family:'Amiri',serif;}

/* NAVBAR - Will be replaced globally but providing default here */
.navbar {background:linear-gradient(135deg,#01121a,#064b63)!important;box-shadow:0 4px 20px rgba(0,0,0,.4);}
.navbar-brand{font-family:'Amiri',serif;font-size:1.6rem;color:white!important;}
.nav-link{color:rgba(255,255,255,.8)!important;font-weight:700;}

/* HERO */
.quran-hero{min-height:500px;background:linear-gradient(160deg,#01121a 0%,#064b63 60%,#033547 100%);position:relative;overflow:hidden;display:flex;align-items:center;padding:80px 0;}
.orb{position:absolute;border-radius:50%;filter:blur(90px);opacity:.25;animation:orb 12s infinite alternate;}
.orb:nth-child(1){width:450px;height:450px;background:#c9a66b;top:-100px;right:-100px;}
.orb:nth-child(2){width:300px;height:300px;background:#1abc9c;bottom:-80px;left:5%;animation-delay:4s;}
@keyframes orb{from{transform:scale(1) translate(0,0)}to{transform:scale(1.2) translate(25px,25px)}}
.hero-pattern{position:absolute;inset:0;background:url('https://www.transparenttextures.com/patterns/arabesque.png');opacity:.1;}
.hero-content{position:relative;z-index:5;color:white;text-align:center;}
.hero-eyebrow{display:inline-block;border:1px solid rgba(201,166,107,.4);background:rgba(201,166,107,.1);backdrop-filter:blur(10px);color:var(--gold2);border-radius:40px;padding:8px 24px;font-size:.85rem;font-weight:700;margin-bottom:20px;}
.hero h1{font-size:4rem;font-weight:bold;margin-bottom:12px;background:linear-gradient(135deg,#fff 30%,var(--gold2) 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;line-height:1.3;}
.tagline{color:rgba(255,255,255,.8);font-size:1.2rem;margin-bottom:35px;line-height:2;max-width:800px;margin-left:auto;margin-right:auto;}

/* SEARCH BAR */
.search-container{background:white;border-radius:20px;padding:15px;box-shadow:0 10px 40px rgba(6,75,99,.08);margin:-40px auto 40px;max-width:800px;position:relative;z-index:10;display:flex;align-items:center;}
.search-container input{border:none;outline:none;flex:1;font-size:1.1rem;padding:10px;}
.search-container .btn-group .btn{border-radius:10px;margin:0 5px;font-weight:700;}

/* SURAH CARDS */
.surah-card{background:white;border-radius:15px;padding:20px;display:flex;align-items:center;box-shadow:0 5px 15px rgba(0,0,0,.04);transition:.3s;border:1px solid rgba(0,0,0,.03);cursor:pointer;position:relative;}
.surah-card:hover{transform:translateY(-4px);box-shadow:0 12px 25px rgba(6,75,99,.1);border-color:var(--gold);}
.surah-num{width:50px;height:50px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.2rem;font-weight:bold;color:var(--cyan);background:rgba(6,75,99,.08);margin-left:15px;flex-shrink:0;}
.surah-card h5{margin:0;font-size:1.5rem;font-family:'Amiri',serif;margin-bottom:5px;color:#1c2528;}
.surah-card span{font-size:.8rem;color:#777;display:block;}
.btn-play-s{position:absolute;left:20px;top:50%;transform:translateY(-50%);background:var(--cyan);color:white;width:40px;height:40px;border-radius:50%;display:flex;align-items:center;justify-content:center;border:none;opacity:0;transition:.3s;}
.surah-card:hover .btn-play-s{opacity:1;}

/* GLOBAL PLAYER */
.global-player{position:fixed;bottom:0;left:0;right:0;background:rgba(2,26,36,0.95);backdrop-filter:blur(20px);border-top:1px solid rgba(201,166,107,.3);padding:15px 0;z-index:1050;transform:translateY(100%);transition:.4s cubic-bezier(0.175,0.885,0.32,1.275);}
.global-player.active{transform:translateY(0);}

/* QURAN READER MODAL */
.quran-reader{font-family:'Amiri',serif;font-size:2rem;line-height:2.2;text-align:center;padding:20px;}
.quran-reader span.verse{display:inline;position:relative;color:#222;}
.quran-reader span.v-num{display:inline-flex;align-items:center;justify-content:center;width:38px;height:38px;background:url('https://upload.wikimedia.org/wikipedia/commons/e/e4/Aya_symbol.svg') no-repeat center center;background-size:contain;font-size:1rem;color:var(--cyan);margin:0 12px;vertical-align:middle;}
</style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold" href="index.html"><i class="fas fa-book-open me-2 text-warning"></i>الموسوعة الإسلامية الشاملة</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav1">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="nav1">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link " href="index.html">الرئيسية</a></li>
        <li class="nav-item"><a class="nav-link " href="recitations.html">القرآن والتلاوات</a></li>
        <li class="nav-item"><a class="nav-link " href="hadith.html">الحديث الشريف</a></li>
        <li class="nav-item"><a class="nav-link " href="fiqh.html">الفقه الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="fatwa.html">فتاوى العلماء <i class="fas fa-gavel"></i></a></li>
        <li class="nav-item"><a class="nav-link " href="seerah.html">السيرة والصحابة</a></li>
        <li class="nav-item"><a class="nav-link " href="aqeedah.html">العقيدة الإسلامية</a></li>
        <li class="nav-item"><a class="nav-link " href="history.html">التاريخ الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="library.html">المكتبة الشاملة</a></li>
      </ul>
    </div>
  </div>
</nav>

<section class="quran-hero">
  <div class="orb"></div><div class="orb"></div>
  <div class="hero-pattern"></div>
  <div class="container hero-content">
    <div class="hero-eyebrow"><i class="fas fa-quran me-2"></i>القرآن الكريم</div>
    <h1>المصحف الشريف</h1>
    <p class="tagline">اقرأ آيات الله بالرسم العثماني، واستمع للتلاوات الخاشعة عبر واجهة قراءة مريحة للعين وتجربة صوتية نقية.</p>
  </div>
</section>

<div class="container">
  <div class="search-container">
    <i class="fas fa-search text-muted ms-3 fs-5"></i>
    <input type="text" id="quickSurahSearch" placeholder="ابحث عن سورة (مثال: الكهف، مريم...)">
    <div class="btn-group border-end pe-3 me-3" id="surahFilters" role="group">
      <button type="button" class="btn btn-outline-secondary active" data-filter="all">الكل</button>
      <button type="button" class="btn btn-outline-secondary" data-filter="meccan">مكية</button>
      <button type="button" class="btn btn-outline-secondary" data-filter="medinan">مدنية</button>
    </div>
  </div>

  <div class="row g-4" id="surah-list">
    <!-- Populated by JS -->
  </div>
</div>

<!-- Reader Modal -->
<div class="modal fade" id="quranModal" tabindex="-1">
  <div class="modal-dialog modal-xl modal-dialog-scrollable">
    <div class="modal-content border-0 shadow-lg">
      <div class="modal-header text-white" style="background:linear-gradient(135deg,#064b63,#05708a);">
        <h5 class="modal-title font-amiri fs-3" id="quranModalTitle"></h5>
        <button type="button" class="btn-close btn-close-white ms-0 me-auto" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body quran-reader" id="quranModalBody" style="background:#fffcf4;">
        <!-- text -->
      </div>
    </div>
  </div>
</div>

<!-- Player -->
<div class="global-player" id="globalPlayer">
  <div class="container d-flex align-items-center justify-content-between position-relative">
    <button class="btn btn-sm btn-outline-secondary position-absolute top-0 end-0 mt-2 border-0 text-white" onclick="document.getElementById('globalPlayer').classList.remove('active')"><i class="fas fa-times"></i></button>
    <div class="d-flex align-items-center gap-3">
      <div style="width:50px;height:50px;background:var(--gold);border-radius:50%;display:flex;align-items:center;justify-content:center;color:#021a24;font-size:1.5rem;"><i class="fas fa-play"></i></div>
      <div class="text-white">
        <h6 class="mb-0 font-amiri fs-5 text-warning" id="playerTitle">جاري التحميل...</h6>
        <small class="opacity-75" id="playerReciter">مشارى العفاسي</small>
      </div>
    </div>
    <audio id="quranAudio" controls class="w-50" style="filter:invert(1) hue-rotate(180deg);"></audio>
  </div>
</div>

<!-- FOOTER -->
<footer class="mega-footer" style="background:linear-gradient(135deg,var(--dark),#020617);color:white;padding:80px 0 30px;margin-top:80px;border-top:3px solid var(--gold-dark);">
  <div class="container">
    <div class="row g-5 mb-5 border-bottom border-light border-opacity-10 pb-5">
      <div class="col-lg-4 text-md-end text-center">
        <i class="fas fa-mosque fa-4x text-warning mb-4 d-block"></i>
        <h4 class="fw-bold font-amiri fs-2 mb-3">الموسوعة الإسلامية الشاملة</h4>
        <p class="opacity-75 fs-6 line-height-2">أضخم صرح رقمي يجمع علوم القرآن العظيم، وأحاديث المصطفى، وفقهاء المذاهب، والتاريخ المجيد في منصة موثقة مصممة بأحدث التقنيات.</p>
      </div>
      <div class="col-lg-4 text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">تصفح الموسوعة</h5>
        <div class="d-flex flex-wrap justify-content-center gap-2">
          <a href="recitations.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">أكاديمية القرآن</a>
          <a href="hadith.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الحديث النبوي</a>
          <a href="seerah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">السيرة والصحابة</a>
          <a href="fiqh.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الفقه وأصوله</a>
          <a href="fatwa.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">فتاوى العلماء</a>
          <a href="aqeedah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">العقيدة الإسلامية</a>
          <a href="history.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">التاريخ المجيد</a>
          <a href="library.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">المكتبة الشاملة</a>
        </div>
      </div>
      <div class="col-lg-4 text-md-start text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">روابط سريعة</h5>
        <a href="contact.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> اتصل بالمطور</a>
        <a href="share.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> شارك الأجر</a>
        <a href="login.html" class="mega-footer-link text-warning mt-3" style="text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-user-circle me-2 ms-1"></i> تسجيل الدخول</a>
      </div>
    </div>
    <div class="text-center font-amiri fs-5 d-flex flex-column gap-2">
      <span class="opacity-75">الموسوعة الإسلامية الشاملة &copy; 2026 تم التصميم للإفادة | عمل مجاني لوجه الله</span>
      <span class="text-warning fw-bold fs-4 mt-2">تصميم وتطوير: لخذاري محمد سيف الدين</span>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="quran-script.js"></script>
</body>
</html>"""

with codecs.open(r"C:\Users\ST\Desktop\islamic.encyclopedia\quran.html", 'w', 'utf-8') as f:
    f.write(html)
print("quran.html built successfully.")
