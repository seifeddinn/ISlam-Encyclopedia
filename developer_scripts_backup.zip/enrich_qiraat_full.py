import codecs

file_path = r"c:\Users\ST\Desktop\islamic.encyclopedia\recitations.html"

with codecs.open(file_path, 'r', 'utf-8') as f:
    full_html = f.read()

# We'll replace the full Qiraat section between the two tab comments
old_start = '<!-- ===================== 2. QIRAAT TEN ===================== -->'
old_end   = '<!-- ===================== 3. TAJWEED RULES ===================== -->'

new_qiraat_section = '''<!-- ===================== 2. QIRAAT TEN ===================== -->
            <div class="tab-pane fade" id="qiraat-ten" role="tabpanel">
                <div class="section-title-wrapper">
                    <h3>أصول القراءات العشر المتواترة</h3>
                    <p class="text-muted mt-2">تعرف على أئمة القراءة، رواتهم، وثوابت أصولهم التي نقلت إلينا بالتواتر</p>
                </div>

                <div class="row g-4">

                    <!-- ===== 1. Nafi ===== -->
                    <div class="col-lg-6">
                        <div class="qiraat-card p-4">
                            <div class="qiraat-number">01</div>
                            <div class="ps-4">
                                <h4 class="reader-name">الإمام نافع المدني</h4>
                                <p class="text-muted small">إمام أهل المدينة المنورة وأحد الأئمة السبعة، قرأ على سبعين من التابعين. تُعدّ قراءته من أكثر القراءات انتشاراً في المغرب العربي وإفريقيا.</p>
                                <div class="mb-3">
                                    <span class="rawi-badge">رواية قالون</span>
                                    <span class="rawi-badge">رواية ورش</span>
                                </div>
                                <div class="accordion qiraat-accordion mt-3" id="acc-n1">
                                    <div class="accordion-item border-0">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button collapsed rounded py-2 px-3" type="button" data-bs-toggle="collapse" data-bs-target="#col-n1-1" style="font-size:0.92rem;">
                                                <i class="fas fa-book-open me-2 text-warning"></i> أصول قراءته
                                            </button>
                                        </h2>
                                        <div id="col-n1-1" class="accordion-collapse collapse" data-bs-parent="#acc-n1">
                                            <div class="accordion-body bg-light rounded mt-2 border-start border-3 border-warning small text-secondary">
                                                <ul class="mb-0">
                                                    <li><strong>قالون:</strong> إثبات البسملة بين السورتين، صلة ميم الجمع بخلف، قصر المنفصل وتوسطه.</li>
                                                    <li><strong>ورش:</strong> ثلاثة أوجه في البسملة، إشباع المدود 6 حركات، النقل، تغليظ اللامات وترقيق الراءات في مواضعها.</li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="accordion-item border-0 mt-2">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button collapsed rounded py-2 px-3" type="button" data-bs-toggle="collapse" data-bs-target="#col-n1-2" style="background:rgba(26,95,122,0.05);font-size:0.92rem;">
                                                <i class="fas fa-microphone-alt me-2 text-primary"></i> أشهر من يتلو بها
                                            </button>
                                        </h2>
                                        <div id="col-n1-2" class="accordion-collapse collapse" data-bs-parent="#acc-n1">
                                            <div class="accordion-body bg-light rounded mt-2 border-start border-3 border-primary small text-muted">
                                                محمود خليل الحصري (قالون وورش)، عبد الباسط عبد الصمد (ورش)، الدوكالي محمد العالم (قالون)، عمر القزابري (ورش)،، الشيخ إبراهيم الأخضر (ورش).
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- ===== 2. Ibn Kathir ===== -->
                    <div class="col-lg-6">
                        <div class="qiraat-card p-4">
                            <div class="qiraat-number">02</div>
                            <div class="ps-4">
                                <h4 class="reader-name">الإمام ابن كثير المكي</h4>
                                <p class="text-muted small">إمام أهل مكة المكرمة، التقى ببعض الصحابة كأنس بن مالك. تُميَّز قراءته بصلة هاء الكناية والميم الجمع بواو لفظية.</p>
                                <div class="mb-3">
                                    <span class="rawi-badge">رواية البزي</span>
                                    <span class="rawi-badge">رواية قنبل</span>
                                </div>
                                <div class="accordion qiraat-accordion mt-3" id="acc-n2">
                                    <div class="accordion-item border-0">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button collapsed rounded py-2 px-3" type="button" data-bs-toggle="collapse" data-bs-target="#col-n2-1" style="font-size:0.92rem;">
                                                <i class="fas fa-book-open me-2 text-warning"></i> أصول قراءته
                                            </button>
                                        </h2>
                                        <div id="col-n2-1" class="accordion-collapse collapse" data-bs-parent="#acc-n2">
                                            <div class="accordion-body bg-light rounded mt-2 border-start border-3 border-warning small text-secondary">
                                                <ul class="mb-0">
                                                    <li>البسملة بين السورتين وجوباً لكليهما.</li>
                                                    <li>صلة ميم الجمع بواو لفظية دائماً (عليهِمُو).</li>
                                                    <li>صلة هاء الكناية دائماً (يَعلمُهُو ويعملُهُو).</li>
                                                    <li>قصر المنفصل وتوسط المتصل.</li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="accordion-item border-0 mt-2">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button collapsed rounded py-2 px-3" type="button" data-bs-toggle="collapse" data-bs-target="#col-n2-2" style="background:rgba(26,95,122,0.05);font-size:0.92rem;">
                                                <i class="fas fa-microphone-alt me-2 text-primary"></i> أشهر من يتلو بها
                                            </button>
                                        </h2>
                                        <div id="col-n2-2" class="accordion-collapse collapse" data-bs-parent="#acc-n2">
                                            <div class="accordion-body bg-light rounded mt-2 border-start border-3 border-primary small text-muted">
                                                عبد الله الجهني، أبو العينين شعيشع، الشيخ أحمد خضر الطرابلسي، سعد الغامدي (في بعض المصاحف التعليمية).
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- ===== 3. Abu Amr ===== -->
                    <div class="col-lg-6">
                        <div class="qiraat-card p-4">
                            <div class="qiraat-number">03</div>
                            <div class="ps-4">
                                <h4 class="reader-name">الإمام أبو عمرو البصري</h4>
                                <p class="text-muted small">الإمام المازني البصري، إمام أهل البصرة وأحد أعلم الناس بكتاب الله واللغة. اشتُهر الإمام الدوري بتلاوته برواية السوسي وأبي عمرو.</p>
                                <div class="mb-3">
                                    <span class="rawi-badge">رواية الدوري</span>
                                    <span class="rawi-badge">رواية السوسي</span>
                                </div>
                                <div class="accordion qiraat-accordion mt-3" id="acc-n3">
                                    <div class="accordion-item border-0">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button collapsed rounded py-2 px-3" type="button" data-bs-toggle="collapse" data-bs-target="#col-n3-1" style="font-size:0.92rem;">
                                                <i class="fas fa-book-open me-2 text-warning"></i> أصول قراءته
                                            </button>
                                        </h2>
                                        <div id="col-n3-1" class="accordion-collapse collapse" data-bs-parent="#acc-n3">
                                            <div class="accordion-body bg-light rounded mt-2 border-start border-3 border-warning small text-secondary">
                                                <ul class="mb-0">
                                                    <li><strong>الدوري:</strong> الاختلاس في ضمائر المتكلم، الإمالة في الألفات والياءات.</li>
                                                    <li><strong>السوسي:</strong> الإدغام الكبير للمتماثلين والمتقاربين(الرحيمْ مَلك)، إبدال الهمز الساكن حرف مدٍّ مجانس.</li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="accordion-item border-0 mt-2">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button collapsed rounded py-2 px-3" type="button" data-bs-toggle="collapse" data-bs-target="#col-n3-2" style="background:rgba(26,95,122,0.05);font-size:0.92rem;">
                                                <i class="fas fa-microphone-alt me-2 text-primary"></i> أشهر من يتلو بها
                                            </button>
                                        </h2>
                                        <div id="col-n3-2" class="accordion-collapse collapse" data-bs-parent="#acc-n3">
                                            <div class="accordion-body bg-light rounded mt-2 border-start border-3 border-primary small text-muted">
                                                محمود خليل الحصري، محمد صديق المنشاوي (رواية الدوري)، عبد الرشيد صوفي (رواية السوسي والدوري).
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- ===== 4. Ibn Amir ===== -->
                    <div class="col-lg-6">
                        <div class="qiraat-card p-4">
                            <div class="qiraat-number">04</div>
                            <div class="ps-4">
                                <h4 class="reader-name">الإمام ابن عامر الشامي</h4>
                                <p class="text-muted small">إمام أهل الشام وقاضي دمشق في عهد الوليد بن عبد الملك. أخذ القراءة عرضاً عن أبي الدرداء رضي الله عنه.</p>
                                <div class="mb-3">
                                    <span class="rawi-badge">رواية هشام</span>
                                    <span class="rawi-badge">رواية ابن ذكوان</span>
                                </div>
                                <div class="accordion qiraat-accordion mt-3" id="acc-n4">
                                    <div class="accordion-item border-0">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button collapsed rounded py-2 px-3" type="button" data-bs-toggle="collapse" data-bs-target="#col-n4-1" style="font-size:0.92rem;">
                                                <i class="fas fa-book-open me-2 text-warning"></i> أصول قراءته
                                            </button>
                                        </h2>
                                        <div id="col-n4-1" class="accordion-collapse collapse" data-bs-parent="#acc-n4">
                                            <div class="accordion-body bg-light rounded mt-2 border-start border-3 border-warning small text-secondary">
                                                <ul class="mb-0">
                                                    <li>الفصل بين الهمزتين بألف في (أَأَنذَرتَهُم) عند هشام.</li>
                                                    <li>إبدال الهمز المتوسط عند الوقف وأحكام الهمزتين من كلمة.</li>
                                                    <li>تتميز قراءته ببعض الاستعارات اللغوية الشامية كالهمزة في (يأجوج ومأجوج).</li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="accordion-item border-0 mt-2">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button collapsed rounded py-2 px-3" type="button" data-bs-toggle="collapse" data-bs-target="#col-n4-2" style="background:rgba(26,95,122,0.05);font-size:0.92rem;">
                                                <i class="fas fa-microphone-alt me-2 text-primary"></i> أشهر من يتلو بها
                                            </button>
                                        </h2>
                                        <div id="col-n4-2" class="accordion-collapse collapse" data-bs-parent="#acc-n4">
                                            <div class="accordion-body bg-light rounded mt-2 border-start border-3 border-primary small text-muted">
                                                الشيخ أيمن سويد (تعليمياً)، عبد الرشيد صوفي، مشاري العفاسي (في بعض إصداراته).
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- ===== 5. Asim ===== -->
                    <div class="col-lg-6">
                        <div class="qiraat-card p-4">
                            <div class="qiraat-number">05</div>
                            <div class="ps-4">
                                <h4 class="reader-name">الإمام عاصم الكوفي</h4>
                                <p class="text-muted small">شيخ الإقراء بالكوفة والأكثر انتشاراً في العالم. برواية حفص يُقرأ أكثر من 95% من مصاحف العالم الإسلامي اليوم.</p>
                                <div class="mb-3">
                                    <span class="rawi-badge">رواية شعبة</span>
                                    <span class="rawi-badge">رواية حفص</span>
                                </div>
                                <div class="accordion qiraat-accordion mt-3" id="acc-n5">
                                    <div class="accordion-item border-0">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button collapsed rounded py-2 px-3" type="button" data-bs-toggle="collapse" data-bs-target="#col-n5-1" style="font-size:0.92rem;">
                                                <i class="fas fa-book-open me-2 text-warning"></i> أصول قراءته
                                            </button>
                                        </h2>
                                        <div id="col-n5-1" class="accordion-collapse collapse" data-bs-parent="#acc-n5">
                                            <div class="accordion-body bg-light rounded mt-2 border-start border-3 border-warning small text-secondary">
                                                <ul class="mb-0">
                                                    <li><strong>حفص:</strong> تحقيق الهمزات، المد المتصل 4-5 حركات، لا إمالة إلا في (مَجرَاهَا)، السكتة الخاصة في مواضع محددة.</li>
                                                    <li><strong>شعبة:</strong> إمالة بعض الألفات وحذف الغنة مع الياء والواو أحياناً.</li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="accordion-item border-0 mt-2">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button collapsed rounded py-2 px-3" type="button" data-bs-toggle="collapse" data-bs-target="#col-n5-2" style="background:rgba(26,95,122,0.05);font-size:0.92rem;">
                                                <i class="fas fa-microphone-alt me-2 text-primary"></i> أشهر من يتلو بها
                                            </button>
                                        </h2>
                                        <div id="col-n5-2" class="accordion-collapse collapse" data-bs-parent="#acc-n5">
                                            <div class="accordion-body bg-light rounded mt-2 border-start border-3 border-primary small text-muted">
                                                <strong>حفص:</strong> العفاسي، السديس، الشريم، المنشاوي، عبد الباسط، المعيقلي، الحذيفي، الغامدي، العجمي وأكثر قراء العالم. &#10; <strong>شعبة:</strong> الشيخ عبد الرازق موسى، أيمن رشدي سويد.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- ===== 6. Hamzah ===== -->
                    <div class="col-lg-6">
                        <div class="qiraat-card p-4">
                            <div class="qiraat-number">06</div>
                            <div class="ps-4">
                                <h4 class="reader-name">الإمام حمزة الكوفي</h4>
                                <p class="text-muted small">الإمام الزيات العابد الكوفي. قال عنه أبو حنيفة: "غلبنا حمزة في القرآن والفرائض". عُرفت قراءته بإشباع المدود والتغيير عند الوقف.</p>
                                <div class="mb-3">
                                    <span class="rawi-badge">رواية خلف</span>
                                    <span class="rawi-badge">رواية خلاد</span>
                                </div>
                                <div class="accordion qiraat-accordion mt-3" id="acc-n6">
                                    <div class="accordion-item border-0">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button collapsed rounded py-2 px-3" type="button" data-bs-toggle="collapse" data-bs-target="#col-n6-1" style="font-size:0.92rem;">
                                                <i class="fas fa-book-open me-2 text-warning"></i> أصول قراءته
                                            </button>
                                        </h2>
                                        <div id="col-n6-1" class="accordion-collapse collapse" data-bs-parent="#acc-n6">
                                            <div class="accordion-body bg-light rounded mt-2 border-start border-3 border-warning small text-secondary">
                                                <ul class="mb-0">
                                                    <li>إشباع المد المتصل والمنفصل ستة حركات.</li>
                                                    <li>السكت على (أل) التعريفية وعلى الساكن المفصول (مَن ءامن).</li>
                                                    <li>تغيير الهمز المتوسط والمتطرف عند الوقف بالتسهيل أو الإبدال.</li>
                                                    <li>الإمالة الكبرى المحضة لجميع الألفات تقريباً.</li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="accordion-item border-0 mt-2">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button collapsed rounded py-2 px-3" type="button" data-bs-toggle="collapse" data-bs-target="#col-n6-2" style="background:rgba(26,95,122,0.05);font-size:0.92rem;">
                                                <i class="fas fa-microphone-alt me-2 text-primary"></i> أشهر من يتلو بها
                                            </button>
                                        </h2>
                                        <div id="col-n6-2" class="accordion-collapse collapse" data-bs-parent="#acc-n6">
                                            <div class="accordion-body bg-light rounded mt-2 border-start border-3 border-primary small text-muted">
                                                عبد الباسط عبد الصمد (في محافله المباشرة)، الشيخ محمد أيوب، الشيخ أيمن سويد (تعليمياً)، عبد الرشيد صوفي.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- ===== 7. Al-Kisa'i ===== -->
                    <div class="col-lg-6">
                        <div class="qiraat-card p-4">
                            <div class="qiraat-number">07</div>
                            <div class="ps-4">
                                <h4 class="reader-name">الإمام الكسائي الكوفي</h4>
                                <p class="text-muted small">إمام النحاة بالكوفة وأحد الأئمة السبعة. كان معلم الرشيد وأبنائه. اشتُهر بكثرة الإمالة وجمال القراءة.</p>
                                <div class="mb-3">
                                    <span class="rawi-badge">رواية أبي الحارث</span>
                                    <span class="rawi-badge">رواية الدوري</span>
                                </div>
                                <div class="accordion qiraat-accordion mt-3" id="acc-n7">
                                    <div class="accordion-item border-0">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button collapsed rounded py-2 px-3" type="button" data-bs-toggle="collapse" data-bs-target="#col-n7-1" style="font-size:0.92rem;">
                                                <i class="fas fa-book-open me-2 text-warning"></i> أصول قراءته
                                            </button>
                                        </h2>
                                        <div id="col-n7-1" class="accordion-collapse collapse" data-bs-parent="#acc-n7">
                                            <div class="accordion-body bg-light rounded mt-2 border-start border-3 border-warning small text-secondary">
                                                <ul class="mb-0">
                                                    <li>كثرة الإمالة في الألفات وهاء التأنيث عند الوقف (الرحمةِ تُمال).</li>
                                                    <li>إدغام الحروف المتقاربة من كلمتين.</li>
                                                    <li>توسط المدود المتصلة والمنفصلة (4 حركات).</li>
                                                    <li>قراءة (وَالأرحامَ) بالجر وصلاً عند الكسائي.</li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="accordion-item border-0 mt-2">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button collapsed rounded py-2 px-3" type="button" data-bs-toggle="collapse" data-bs-target="#col-n7-2" style="background:rgba(26,95,122,0.05);font-size:0.92rem;">
                                                <i class="fas fa-microphone-alt me-2 text-primary"></i> أشهر من يتلو بها
                                            </button>
                                        </h2>
                                        <div id="col-n7-2" class="accordion-collapse collapse" data-bs-parent="#acc-n7">
                                            <div class="accordion-body bg-light rounded mt-2 border-start border-3 border-primary small text-muted">
                                                عبد الرشيد صوفي، الشيخ محمد أيوب (في محافله)، عبد الولي الأركاني.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- ===== 8. Abu Ja'far ===== -->
                    <div class="col-lg-6">
                        <div class="qiraat-card p-4">
                            <div class="qiraat-number">08</div>
                            <div class="ps-4">
                                <h4 class="reader-name">الإمام أبو جعفر المدني</h4>
                                <p class="text-muted small">إمام القراء بالمدينة قبل الإمام نافع، تابعيٌّ اسمه يزيد بن القعقاع. تتميز قراءته بتخفيف الهمز وبعض إبدالاته اللطيفة.</p>
                                <div class="mb-3">
                                    <span class="rawi-badge">رواية ابن وردان</span>
                                    <span class="rawi-badge">رواية ابن جماز</span>
                                </div>
                                <div class="accordion qiraat-accordion mt-3" id="acc-n8">
                                    <div class="accordion-item border-0">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button collapsed rounded py-2 px-3" type="button" data-bs-toggle="collapse" data-bs-target="#col-n8-1" style="font-size:0.92rem;">
                                                <i class="fas fa-book-open me-2 text-warning"></i> أصول قراءته
                                            </button>
                                        </h2>
                                        <div id="col-n8-1" class="accordion-collapse collapse" data-bs-parent="#acc-n8">
                                            <div class="accordion-body bg-light rounded mt-2 border-start border-3 border-warning small text-secondary">
                                                <ul class="mb-0">
                                                    <li>إبدال الهمز الساكن حرف مد مجانس (يُبْدَل إلى واو أو ياء أو ألف).</li>
                                                    <li>السكت الخفيف على الحروف المقطعة في أوائل السور.</li>
                                                    <li>تسهيل الهمزة المتحركة في الكلمة بدل تحقيقها.</li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="accordion-item border-0 mt-2">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button collapsed rounded py-2 px-3" type="button" data-bs-toggle="collapse" data-bs-target="#col-n8-2" style="background:rgba(26,95,122,0.05);font-size:0.92rem;">
                                                <i class="fas fa-microphone-alt me-2 text-primary"></i> أشهر من يتلو بها
                                            </button>
                                        </h2>
                                        <div id="col-n8-2" class="accordion-collapse collapse" data-bs-parent="#acc-n8">
                                            <div class="accordion-body bg-light rounded mt-2 border-start border-3 border-primary small text-muted">
                                                محمود خليل الحصري (أول من سجل مصحفاً كاملاً بها)، عبد الرشيد صوفي، الشيخ حسن صالح.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- ===== 9. Ya'qub ===== -->
                    <div class="col-lg-6">
                        <div class="qiraat-card p-4">
                            <div class="qiraat-number">09</div>
                            <div class="ps-4">
                                <h4 class="reader-name">الإمام يعقوب الحضرمي</h4>
                                <p class="text-muted small">إمام أهل البصرة عقب أبي عمرو البصري. يتميز بالوقف بهاء السكت على عدد من الكلمات والجمع الفريد بين الساكنين.</p>
                                <div class="mb-3">
                                    <span class="rawi-badge">رواية رويس</span>
                                    <span class="rawi-badge">رواية رَوْح</span>
                                </div>
                                <div class="accordion qiraat-accordion mt-3" id="acc-n9">
                                    <div class="accordion-item border-0">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button collapsed rounded py-2 px-3" type="button" data-bs-toggle="collapse" data-bs-target="#col-n9-1" style="font-size:0.92rem;">
                                                <i class="fas fa-book-open me-2 text-warning"></i> أصول قراءته
                                            </button>
                                        </h2>
                                        <div id="col-n9-1" class="accordion-collapse collapse" data-bs-parent="#acc-n9">
                                            <div class="accordion-body bg-light rounded mt-2 border-start border-3 border-warning small text-secondary">
                                                <ul class="mb-0">
                                                    <li>الوقف بهاء السكت على بعض الكلمات كـ(مالِيَهْ، سُلطانِيَهْ، تَرَكتُمُوهُ).</li>
                                                    <li>الجمع بين الساكنين في مواضعه (إذ الجمع أولى من الفك).</li>
                                                    <li>ضم هاء الضمير في جمع المذكر السالم إذا سبقت بياء ساكنة.</li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="accordion-item border-0 mt-2">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button collapsed rounded py-2 px-3" type="button" data-bs-toggle="collapse" data-bs-target="#col-n9-2" style="background:rgba(26,95,122,0.05);font-size:0.92rem;">
                                                <i class="fas fa-microphone-alt me-2 text-primary"></i> أشهر من يتلو بها
                                            </button>
                                        </h2>
                                        <div id="col-n9-2" class="accordion-collapse collapse" data-bs-parent="#acc-n9">
                                            <div class="accordion-body bg-light rounded mt-2 border-start border-3 border-primary small text-muted">
                                                الشيخ مشاري العفاسي (سجل ختمات كاملة بها)، الشيخ محمد أيوب، عبد الرشيد صوفي.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- ===== 10. Khalaf ===== -->
                    <div class="col-lg-6">
                        <div class="qiraat-card p-4">
                            <div class="qiraat-number">10</div>
                            <div class="ps-4">
                                <h4 class="reader-name">الإمام خلف العاشر</h4>
                                <p class="text-muted small">هو خلف بن هشام البزار الكوفي، أحد رواة حمزة الكوفي الذي اختار لنفسه قراءةً مستقلة فصار بها الإمام العاشر.</p>
                                <div class="mb-3">
                                    <span class="rawi-badge">رواية إدريس</span>
                                    <span class="rawi-badge">رواية إسحاق</span>
                                </div>
                                <div class="accordion qiraat-accordion mt-3" id="acc-n10">
                                    <div class="accordion-item border-0">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button collapsed rounded py-2 px-3" type="button" data-bs-toggle="collapse" data-bs-target="#col-n10-1" style="font-size:0.92rem;">
                                                <i class="fas fa-book-open me-2 text-warning"></i> أصول قراءته
                                            </button>
                                        </h2>
                                        <div id="col-n10-1" class="accordion-collapse collapse" data-bs-parent="#acc-n10">
                                            <div class="accordion-body bg-light rounded mt-2 border-start border-3 border-warning small text-secondary">
                                                <ul class="mb-0">
                                                    <li>تجمع قراءته بين اختيارات من حمزة والكسائي والقراء الكوفيين.</li>
                                                    <li>السكت على المفصول وعدم الغنة مع اللام والراء.</li>
                                                    <li>الإمالة الكبرى في الألفات المتطرفة.</li>
                                                    <li>إشباع المدود وتغيير الهمز عند الوقف مثل حمزة.</li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="accordion-item border-0 mt-2">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button collapsed rounded py-2 px-3" type="button" data-bs-toggle="collapse" data-bs-target="#col-n10-2" style="background:rgba(26,95,122,0.05);font-size:0.92rem;">
                                                <i class="fas fa-microphone-alt me-2 text-primary"></i> أشهر من يتلو بها
                                            </button>
                                        </h2>
                                        <div id="col-n10-2" class="accordion-collapse collapse" data-bs-parent="#acc-n10">
                                            <div class="accordion-body bg-light rounded mt-2 border-start border-3 border-primary small text-muted">
                                                عبد الرشيد صوفي، الشيخ ياسر سلامة، الشيخ مشاري العفاسي (في ألبومات متفرقة خاصة).
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            '''

if old_start in full_html and old_end in full_html:
    start_idx = full_html.index(old_start)
    end_idx   = full_html.index(old_end)
    full_html = full_html[:start_idx] + new_qiraat_section + full_html[end_idx:]
    with codecs.open(file_path, 'w', 'utf-8') as f:
        f.write(full_html)
    print("SUCCESS: Qiraat section replaced successfully!")
else:
    print("ERROR: Could not find markers in HTML.")
    if old_start not in full_html:
        print("  - Missing start marker")
    if old_end not in full_html:
        print("  - Missing end marker")
