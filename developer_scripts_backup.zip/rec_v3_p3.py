
    <!-- TAB 2: TAJWEED MEGA -->
    <div class="tab-pane fade" id="tab-tajweed">
      <div class="sec-head">
        <span class="tag">ورتل القرآن ترتيلاً</span>
        <h3>الموسوعة التجويدية <span>الشاملة</span></h3>
        <p>المرجع الأكبر لإعطاء كل حرف حقه ومستحقه من المخارج والصفات وأحكام الوقف والابتداء</p>
        <div class="divider"></div>
      </div>

      <!-- SECTION: NOON SAKINAH (Interactive) -->
      <div class="mb-5">
         <h4 class="font-amiri fw-bold text-dark mb-4 border-bottom pb-2 border-emerald d-inline-block">أولاً: أحكام النون الساكنة والتنوين (تفاعلي)</h4>
         <p class="text-muted mb-4 fs-5">للنون الساكنة والتنوين أربعة أحكام عند التقائها بحروف الهجاء. اضغط على كل حكم لتتعرف عليه:</p>
         
         <div class="row g-4 justify-content-center">
            <!-- Izhar -->
            <div class="col-lg-3 col-md-6">
               <div class="mega-card text-center text-white h-100 p-4" style="background:linear-gradient(135deg,#047857,#064e3b);border:none;cursor:pointer;transition:transform 0.3s;" onclick="alert('حروف الإظهار: ء، هـ، ع، ح، غ، خ\nيجب نطق النون بوضوح من غير غنة.')" onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
                  <i class="fas fa-volume-up fa-3x mb-3 text-warning"></i>
                  <h4 class="fw-bold mb-3">الإظهار الحلقي</h4>
                  <p class="small opacity-75 mb-0">نطق النون بوضوح من غير غنة إذا جاء بعدها: ء، هـ، ع، ح، غ، خ.</p>
               </div>
            </div>
            <!-- Idgham -->
            <div class="col-lg-3 col-md-6">
               <div class="mega-card text-center text-white h-100 p-4" style="background:linear-gradient(135deg,#b45309,#78350f);border:none;cursor:pointer;transition:transform 0.3s;" onclick="alert('حروف الإدغام: ي، ر، م، ل، و، ن (يرملون).\nينقسم بغنة (ينمو) وبغير غنة (لر).')" onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
                  <i class="fas fa-link fa-3x mb-3 text-warning"></i>
                  <h4 class="fw-bold mb-3">الإدغام</h4>
                  <p class="small opacity-75 mb-0">إدخال النون في الحرف المشدد الموالي (يرملون)، ويقسم إلى بغنة وبغير غنة.</p>
               </div>
            </div>
            <!-- Iqlab -->
            <div class="col-lg-3 col-md-6">
               <div class="mega-card text-center text-white h-100 p-4" style="background:linear-gradient(135deg,#1d4ed8,#1e3a8a);border:none;cursor:pointer;transition:transform 0.3s;" onclick="alert('حرف الإقلاب: الباء (ب)\nتُقلب النون ميماً مخفاة بغنة عند التقائها بالباء.')" onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
                  <i class="fas fa-exchange-alt fa-3x mb-3 text-warning"></i>
                  <h4 class="fw-bold mb-3">الإقلاب</h4>
                  <p class="small opacity-75 mb-0">قلب النون الساكنة أو التنوين ميماً مخفاة بغنة عند ملاقاتها بحرف (الباء).</p>
               </div>
            </div>
            <!-- Ikhfa -->
            <div class="col-lg-3 col-md-6">
               <div class="mega-card text-center text-white h-100 p-4" style="background:linear-gradient(135deg,#be123c,#881337);border:none;cursor:pointer;transition:transform 0.3s;" onclick="alert('حروف الإخفاء: 15 حرفاً متبقية\nتُنطق النون بحالة بين الإظهار والإدغام مع بقاء الغنة.')" onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
                  <i class="fas fa-eye-slash fa-3x mb-3 text-warning"></i>
                  <h4 class="fw-bold mb-3">الإخفاء الحقيقي</h4>
                  <p class="small opacity-75 mb-0">النطق بحالة وسط بين الإظهار والإدغام مع بقاء الغنة في باقي الحروف الـ 15.</p>
               </div>
            </div>
         </div>
      </div>

      <!-- SECTION: MAKHARIJ -->
      <div class="mb-5">
         <h4 class="font-amiri fw-bold text-dark mb-4 border-bottom pb-2 border-emerald d-inline-block">أولاً: مخارج الحروف الرئيسية (5 مخارج عامة)</h4>
         <p class="text-muted mb-4 fs-5">تتوزع الحروف العربية على 17 مخرجاً خاصاً تنحصر في 5 مخارج عامة وفقاً للإمام ابن الجزري.</p>
         
         <div class="row g-4 justify-content-center">
            <div class="col-lg-2 col-md-4 col-sm-6">
               <div class="mega-card text-center text-white" style="background:linear-gradient(135deg,#e11d48,#be123c);border:none;">
                  <i class="fas fa-wind fa-3x mb-3 opacity-75"></i>
                  <h4 class="fw-bold mb-3">الجوف</h4>
                  <p class="small opacity-75 mb-0">مخرج مقدر، وفيه مخرج خاص واحد تخرج منه حروف المد الثلاثة (الألف، الواو، الياء) السواكن.</p>
               </div>
            </div>
            
            <div class="col-lg-3 col-md-4 col-sm-6">
               <div class="mega-card text-center text-white" style="background:linear-gradient(135deg,#0369a1,#0c4a6e);border:none;">
                  <i class="fas fa-lungs fa-3x mb-3 opacity-75"></i>
                  <h4 class="fw-bold mb-3">الحلق</h4>
                  <p class="small opacity-75 mb-0">فيه 3 مخارج لـ 6 حروف: أقصى الحلق (ء، هـ)، وسط الحلق (ع، ح)، أدنى الحلق (غ، خ).</p>
               </div>
            </div>

            <div class="col-lg-3 col-md-4 col-sm-6">
               <div class="mega-card text-center text-white" style="background:linear-gradient(135deg,#15803d,#14532d);border:none;">
                  <i class="fas fa-comment-dots fa-3x mb-3 opacity-75"></i>
                  <h4 class="fw-bold mb-3">اللسان</h4>
                  <p class="small opacity-75 mb-0">أكبر المخارج العامة، فيه 10 مخارج خاصة لـ 18 حرفاً (ق، ك، ج، ش، ي، ض، ل، ن، ر، ط، د، ت، ص، س، ز، ظ، ذ، ث).</p>
               </div>
            </div>

            <div class="col-lg-2 col-md-4 col-sm-6">
               <div class="mega-card text-center text-white" style="background:linear-gradient(135deg,#a21caf,#701a75);border:none;">
                  <i class="fas fa-lips fa-3x mb-3 opacity-75"></i>
                  <h4 class="fw-bold mb-3">الشفتان</h4>
                  <p class="small opacity-75 mb-0">فيهما مخرجان لـ 4 حروف: باطن الشفة (ف)، ومن بين الشفتين معاً (ب، م، و).</p>
               </div>
            </div>

            <div class="col-lg-2 col-md-4 col-sm-6">
               <div class="mega-card text-center text-white" style="background:linear-gradient(135deg,#b45309,#78350f);border:none;">
                  <i class="fas fa-head-side-mask fa-3x mb-3 opacity-75"></i>
                  <h4 class="fw-bold mb-3">الخيشوم</h4>
                  <p class="small opacity-75 mb-0">أقصى الأنف، وهو مخرج مقدر تخرج منه صفة الغنة المصاحبة للنون والميم المشددتين والمخفاتين.</p>
               </div>
            </div>
         </div>
      </div>

      <!-- SECTION: SIFAT -->
      <div class="mb-5 pt-4">
         <h4 class="font-amiri fw-bold text-dark mb-4 border-bottom pb-2 border-emerald d-inline-block">ثانياً: صفات الحروف</h4>
         <p class="text-muted mb-4 fs-5">تنقسم إلى صفات لها ضد (كأن يهمس الحرف أو يجهر)، وصفات ليس لها ضد (كالقلقلة والصفير).</p>
         
         <div class="row g-4">
            <div class="col-md-6">
               <div class="p-4 bg-white rounded-4 shadow-sm h-100 border border-light">
                  <h5 class="text-primary fw-bold mb-4"><i class="fas fa-balance-scale text-warning me-2"></i>الصفات التي لها ضد</h5>
                  <table class="table table-borderless table-striped table-hover align-middle dir-rtl text-center">
                     <thead class="table-dark"><tr><th width="45%">الصفة</th><th width="10%">ضدها</th><th width="45%">الصفة المضادة</th></tr></thead>
                     <tbody>
                        <tr><td><strong>الهمس</strong> (جريان النفس)<br><small class="text-muted">فحثه شخص سكت</small></td><td>⇄</td><td><strong>الجهر</strong> (انحباس النفس)<br><small class="text-muted">باقي الحروف</small></td></tr>
                        <tr><td><strong>الشدة</strong> (انحباس الصوت)<br><small class="text-muted">أجد قط بكت</small></td><td>⇄</td><td><strong>الرخاوة</strong> (جريان الصوت)<br><small class="text-muted">وبينهما التوسط: لن عمر</small></td></tr>
                        <tr><td><strong>الاستعلاء</strong> (تفخيم الحرف)<br><small class="text-muted">خص ضغط قظ</small></td><td>⇄</td><td><strong>الاستفال</strong> (ترقيق الحرف)<br><small class="text-muted">باقي الحروف</small></td></tr>
                        <tr><td><strong>الإطباق</strong> (التصاق اللسان بالحنك)<br><small class="text-muted">ص، ض، ط، ظ</small></td><td>⇄</td><td><strong>الانفتاح</strong> (افتراق اللسان)<br><small class="text-muted">باقي الحروف</small></td></tr>
                     </tbody>
                  </table>
               </div>
            </div>
            
            <div class="col-md-6">
               <div class="p-4 bg-white rounded-4 shadow-sm h-100 border border-light">
                  <h5 class="text-success fw-bold mb-4"><i class="fas fa-layer-group text-warning me-2"></i>الصفات التي ليس لها ضد</h5>
                  <div class="d-flex flex-wrap gap-3">
                     <div class="bg-light p-3 rounded-3 flex-fill text-center"><h6 class="fw-bold text-dark">الصفير</h6><p class="small mb-0 text-muted">ص، ز، س</p></div>
                     <div class="bg-light p-3 rounded-3 flex-fill text-center"><h6 class="fw-bold text-dark">القلقلة</h6><p class="small mb-0 text-muted">قطب جد</p></div>
                     <div class="bg-light p-3 rounded-3 flex-fill text-center"><h6 class="fw-bold text-dark">اللين</h6><p class="small mb-0 text-muted">الواو والياء الساكنتان المفتوح ما قبلهما</p></div>
                     <div class="bg-light p-3 rounded-3 flex-fill text-center"><h6 class="fw-bold text-dark">الانحراف</h6><p class="small mb-0 text-muted">ل، ر</p></div>
                     <div class="bg-light p-3 rounded-3 flex-fill text-center"><h6 class="fw-bold text-dark">التكرير</h6><p class="small mb-0 text-muted">ر</p></div>
                     <div class="bg-light p-3 rounded-3 flex-fill text-center"><h6 class="fw-bold text-dark">التفشي</h6><p class="small mb-0 text-muted">ش</p></div>
                     <div class="bg-light p-3 rounded-3 flex-fill text-center"><h6 class="fw-bold text-dark">الاستطالة</h6><p class="small mb-0 text-muted">ض</p></div>
                  </div>
               </div>
            </div>
         </div>
      </div>

      <!-- SECTION: ENDING SIGNS -->
      <div class="mb-5 pt-4">
         <h4 class="font-amiri fw-bold text-dark mb-4 border-bottom pb-2 border-emerald d-inline-block">ثالثاً: علامات الوقف في المصحف</h4>
         <div class="row g-3">
            <div class="col-lg-2 col-md-4 col-6"><div class="mega-card text-center p-4">
               <div class="font-amiri fw-bold bg-danger text-white rounded-circle mx-auto d-flex align-items-center justify-content-center mb-3" style="width:50px;height:50px;font-size:1.5rem;">مـ</div>
               <h6 class="fw-bold">وقف لازم</h6><p class="small text-muted mb-0">يلزم الوقف لأن الوصل يغير المعنى</p>
            </div></div>
            <div class="col-lg-2 col-md-4 col-6"><div class="mega-card text-center p-4">
               <div class="font-amiri fw-bold bg-secondary text-white rounded-circle mx-auto d-flex align-items-center justify-content-center mb-3" style="width:50px;height:50px;font-size:1.5rem;">لا</div>
               <h6 class="fw-bold">وقف ممنوع</h6><p class="small text-muted mb-0">يمنع الوقف، إلا إذا كان رأس آية</p>
            </div></div>
            <div class="col-lg-2 col-md-4 col-6"><div class="mega-card text-center p-4">
               <div class="font-amiri fw-bold bg-success text-white rounded-circle mx-auto d-flex align-items-center justify-content-center mb-3" style="width:50px;height:50px;font-size:1.5rem;">ج</div>
               <h6 class="fw-bold">وقف جائز</h6><p class="small text-muted mb-0">جواز الوقف والوصل بمستوى واحد</p>
            </div></div>
            <div class="col-lg-2 col-md-4 col-6"><div class="mega-card text-center p-4">
               <div class="font-amiri fw-bold text-white rounded-circle mx-auto d-flex align-items-center justify-content-center mb-3" style="width:50px;height:50px;font-size:1.3rem;background:#0ea5e9;">صلي</div>
               <h6 class="fw-bold">الوصل أولى</h6><p class="small text-muted mb-0">يجوز الوقف، ولكن الوصل مفضل</p>
            </div></div>
            <div class="col-lg-2 col-md-4 col-6"><div class="mega-card text-center p-4">
               <div class="font-amiri fw-bold text-white rounded-circle mx-auto d-flex align-items-center justify-content-center mb-3" style="width:50px;height:50px;font-size:1.3rem;background:#f59e0b;">قلي</div>
               <h6 class="fw-bold">الوقف أولى</h6><p class="small text-muted mb-0">يجوز الوصل، ولكن الوقف مفضل</p>
            </div></div>
            <div class="col-lg-2 col-md-4 col-6"><div class="mega-card text-center p-4">
               <div class="font-amiri fw-bold text-white rounded-circle mx-auto d-flex align-items-center justify-content-center mb-3" style="width:50px;height:50px;font-size:1.3rem;background:#8b5cf6;">∴ ∴</div>
               <h6 class="fw-bold">تعانق الوقف</h6><p class="small text-muted mb-0">إذا وقفت على أحدهما لا تقف على الآخر</p>
            </div></div>
         </div>
      </div>

    </div>
