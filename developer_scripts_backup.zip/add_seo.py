import os
import glob
from bs4 import BeautifulSoup

def add_seo_tags():
    html_files = glob.glob('*.html')
    
    seo_tags = """
    <meta name="description" content="الموسوعة الإسلامية الشاملة - المنصة الرقمية الموثوقة لعلوم القرآن والسنة والفقه والسيرة والتاريخ بعقيدة صحيحة.">
    <meta name="keywords" content="قرآن, حديث, إسلام, فقه, عقيدة, سيرة, تاريخ إسلامي, الموسوعة الإسلامية">
    <meta name="author" content="ST Islamic Web">
    <meta property="og:title" content="الموسوعة الإسلامية الشاملة">
    <meta property="og:description" content="مرجعك الشامل للعلوم الشرعية الموثقة بتصميم عصري وتقنيات حديثة.">
    <meta property="og:type" content="website">
    <link rel="icon" href="https://cdn-icons-png.flaticon.com/512/3389/3389081.png" type="image/png">
    """
    
    for filepath in html_files:
        if filepath == "404.html":
            continue
            
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
            
        soup = BeautifulSoup(content, 'html.parser')
        
        if not soup.head:
            continue
            
        # Check if already has our description
        existing_desc = soup.find('meta', {'name': 'description'})
        if existing_desc:
            print(f"[{filepath}] SEO already present, skipping.")
            continue
            
        # Insert just before the closing </head> or after <title>
        title_tag = soup.find('title')
        if title_tag:
            # We can just do a string replace to be safe and avoid messing up formatting
            pass
            
        # Hard string replacement to maintain formatting
        new_content = content.replace('</title>', '</title>\n' + seo_tags)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(new_content)
            
        print(f"[{filepath}] SEO Tags Added Successfully.")

if __name__ == '__main__':
    add_seo_tags()
