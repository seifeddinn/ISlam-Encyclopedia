import codecs, re
txt = codecs.open("seerah.html","r","utf-8").read()

# Fix font-amiri -> amiri in footer
txt = txt.replace('font-amiri', 'amiri')

# Fix background-clip compatibility (add standard property alongside webkit)
txt = txt.replace(
    '-webkit-background-clip:text;-webkit-text-fill-color:transparent;',
    '-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;'
)

codecs.open("seerah.html","w","utf-8").write(txt)
print("Footer fixes applied. Size:", len(txt))
