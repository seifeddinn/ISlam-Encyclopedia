import codecs

css = """<style>
:root{--gold:#c9a66b;--gold2:#e8d5a3;--dark:#1a0a00;--brown:#5c2d00;--amber:#7a4000;}
body{font-family:'Cairo',sans-serif;background:#fdf9f4;color:#2c2010;overflow-x:hidden;}
h1,h2,h3,h4,.ar{font-family:'Amiri',serif;}

/* HERO */
.seerah-hero{
  min-height:560px;
  background:linear-gradient(160deg,#1a0800 0%,#3d1500 50%,#6b2b00 100%);
  position:relative;overflow:hidden;display:flex;align-items:center;padding:80px 0;
}
.hero-orbs span{
  position:absolute;border-radius:50%;filter:blur(80px);opacity:.25;animation:orb 10s infinite alternate;
}
.hero-orbs span:nth-child(1){width:400px;height:400px;background:#c9a66b;top:-100px;right:-100px;}
.hero-orbs span:nth-child(2){width:300px;height:300px;background:#e8943a;bottom:-80px;left:5%;animation-delay:3s;}
.hero-orbs span:nth-child(3){width:250px;height:250px;background:#fff4e0;top:40%;left:40%;animation-delay:5s;}
@keyframes orb{from{transform:scale(1) translate(0,0)}to{transform:scale(1.2) translate(20px,20px)}}
.hero-pattern{
  position:absolute;inset:0;
  background:url('https://www.transparenttextures.com/patterns/arabesque.png');
  opacity:.08;
}
.hero-content{position:relative;z-index:5;color:white;}
.hero-eyebrow{
  display:inline-block;border:1px solid rgba(201,166,107,.4);
  background:rgba(201,166,107,.1);backdrop-filter:blur(10px);
  color:var(--gold2);border-radius:40px;padding:8px 24px;
  font-size:.85rem;font-weight:700;margin-bottom:20px;letter-spacing:.5px;
}
.hero h1{
  font-size:3.8rem;font-weight:bold;margin-bottom:12px;
  background:linear-gradient(135deg,#fff 30%,var(--gold2) 100%);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;
  line-height:1.2;
}
.hero .tagline{color:rgba(255,255,255,.65);font-size:1.1rem;margin-bottom:35px;line-height:1.9;}
.hero-quote{
  background:rgba(255,255,255,.06);border:1px solid rgba(201,166,107,.2);
  border-right:4px solid var(--gold);border-radius:16px;
  padding:22px 26px;max-width:680px;backdrop-filter:blur(12px);
}
.hero-quote p{font-family:'Amiri',serif;font-size:1.3rem;line-height:2;color:white;margin:0;}
.hero-quote small{color:rgba(255,255,255,.45);font-size:.82rem;}

/* STATS */
.stats-strip{
  background:linear-gradient(90deg,#3d1500,#5c2500);
  padding:22px 0;
}
.stat-item{text-align:center;color:white;padding:8px;}
.stat-num{font-size:2.2rem;font-weight:800;color:var(--gold2);font-family:'Amiri',serif;line-height:1;}
.stat-label{font-size:.78rem;opacity:.65;margin-top:4px;}

/* TABS */
.sec-tabs{
  background:white;border-radius:60px;padding:8px;
  box-shadow:0 10px 40px rgba(90,40,0,.08);
  margin:45px 0 40px;display:flex;
  overflow-x:auto;border:1px solid rgba(90,40,0,.05);
}
.sec-tabs::-webkit-scrollbar{height:0;}
.sec-tabs .nav-item{flex:1;min-width:140px;}
.sec-tabs .nav-link{
  border:none;border-radius:50px;color:#555;font-weight:700;
  padding:14px 14px;width:100%;text-align:center;transition:all .35s;white-space:nowrap;
}
.sec-tabs .nav-link:hover{color:var(--brown);}
.sec-tabs .nav-link.active{
  background:linear-gradient(135deg,#3d1500,#7a4000);
  color:white;box-shadow:0 8px 20px rgba(90,40,0,.3);
}

/* SECTION HEAD */
.sec-head{text-align:center;margin-bottom:45px;}
.sec-head .tag{
  display:inline-block;background:rgba(90,40,0,.08);color:var(--brown);
  border-radius:40px;padding:6px 20px;font-size:.82rem;font-weight:700;margin-bottom:15px;
}
.sec-head h3{font-size:2.2rem;color:#3d1500;font-weight:700;margin-bottom:8px;}
.sec-head h3 span{color:var(--gold);}
.sec-head p{color:#888;max-width:600px;margin:0 auto;}
.sec-head .divider{width:60px;height:4px;background:linear-gradient(90deg,var(--gold),var(--gold2));border-radius:2px;margin:15px auto 0;}

/* TIMELINE */
.timeline{position:relative;padding:10px 0;}
.timeline::before{
  content:'';position:absolute;right:50%;top:0;bottom:0;
  width:3px;background:linear-gradient(180deg,var(--gold),rgba(201,166,107,.1));
}
.tl-item{display:flex;gap:30px;margin-bottom:50px;position:relative;align-items:flex-start;}
.tl-item.right{flex-direction:row-reverse;}
.tl-dot{
  flex-shrink:0;width:56px;height:56px;border-radius:50%;
  background:linear-gradient(135deg,#3d1500,#7a4000);
  display:flex;align-items:center;justify-content:center;
  color:var(--gold2);font-size:1.4rem;
  box-shadow:0 0 0 6px rgba(201,166,107,.15),0 0 0 12px rgba(201,166,107,.07);
  position:relative;z-index:2;margin-top:8px;
}
.tl-year{
  position:absolute;top:50%;transform:translateY(-50%);
  background:var(--gold);color:#3d1500;font-weight:800;padding:4px 14px;
  border-radius:20px;font-size:.82rem;white-space:nowrap;
  box-shadow:0 4px 12px rgba(201,166,107,.3);
}
.tl-item:not(.right) .tl-year{left:calc(50% + 40px);}
.tl-item.right .tl-year{right:calc(50% + 40px);}
.tl-card{
  flex:1;background:white;border-radius:20px;padding:24px;
  box-shadow:0 10px 30px rgba(90,40,0,.07);
  border-top:3px solid var(--gold);
  transition:all .3s;max-width:calc(50% - 60px);
}
.tl-card:hover{transform:translateY(-5px);box-shadow:0 18px 45px rgba(90,40,0,.12);}
.tl-card h5{color:#3d1500;font-weight:800;margin-bottom:8px;font-size:1.05rem;}
.tl-card p{color:#666;font-size:.9rem;line-height:1.8;margin:0;}
.tl-tag{
  display:inline-block;background:rgba(61,21,0,.08);color:#5c2d00;
  border-radius:20px;padding:3px 12px;font-size:.75rem;font-weight:700;margin-bottom:10px;
}

/* GHAZAWAT CARDS */
.ghaz-card{
  background:white;border-radius:20px;overflow:hidden;
  box-shadow:0 10px 30px rgba(90,40,0,.07);transition:all .4s;height:100%;
}
.ghaz-card:hover{transform:translateY(-8px);box-shadow:0 20px 50px rgba(90,40,0,.13);}
.ghaz-top{
  padding:28px 24px 20px;position:relative;overflow:hidden;
}
.ghaz-top::after{
  content:attr(data-year);position:absolute;left:15px;bottom:-10px;
  font-size:5rem;font-family:'Amiri',serif;font-weight:bold;opacity:.07;color:#000;line-height:1;
}
.ghaz-top h5{color:white;font-weight:800;font-size:1.1rem;margin-bottom:4px;}
.ghaz-top small{color:rgba(255,255,255,.7);}
.ghaz-body{padding:20px 24px 24px;}
.ghaz-body p{color:#555;font-size:.88rem;line-height:1.8;margin-bottom:14px;}
.ghaz-stats{display:flex;gap:10px;flex-wrap:wrap;}
.ghaz-stat{
  background:#fdf5eb;border-radius:10px;padding:8px 14px;
  font-size:.78rem;color:#7a4000;font-weight:700;
  border:1px solid rgba(201,166,107,.2);
}

/* AKHLAQ CARD */
.akhlaq-card{
  background:white;border-radius:20px;padding:28px;
  box-shadow:0 10px 30px rgba(90,40,0,.07);
  transition:all .3s;text-align:center;height:100%;
  border-bottom:4px solid var(--gold);
}
.akhlaq-card:hover{transform:translateY(-6px);}
.akhlaq-icon{
  width:70px;height:70px;border-radius:50%;
  background:linear-gradient(135deg,#3d1500,#7a4000);
  display:flex;align-items:center;justify-content:center;
  font-size:1.8rem;color:var(--gold2);margin:0 auto 18px;
  box-shadow:0 10px 25px rgba(61,21,0,.2);
}

/* SIFAT */
.sifat-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:20px;}
.sifat-item{
  background:white;border-radius:18px;padding:22px;
  box-shadow:0 8px 25px rgba(90,40,0,.06);
  border-right:4px solid var(--gold);
  display:flex;align-items:flex-start;gap:15px;
}
.sifat-icon{
  width:45px;height:45px;border-radius:12px;flex-shrink:0;
  background:rgba(61,21,0,.08);color:#7a4000;
  display:flex;align-items:center;justify-content:center;font-size:1.3rem;
}
@media(max-width:768px){
  .timeline::before{display:none;}
  .tl-item,.tl-item.right{flex-direction:column;gap:15px;}
  .tl-card{max-width:100%;}
  .tl-year{display:none;}
  .hero h1{font-size:2.2rem;}
}
</style>"""

part1 = """<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>موسوعة السيرة النبوية - الموسوعة الإسلامية الشاملة</title>
<link href="https://fonts.googleapis.com/css2?family=Amiri:ital,wght@0,400;0,700;1,400&family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="styles.css">
""" + css + """
</head>
<body>

<!-- NAV -->
<nav class="navbar navbar-expand-lg navbar-dark sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold" href="index.html"><i class="fas fa-book-open me-2 text-warning"></i>الموسوعة الإسلامية الشاملة</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav1">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="nav1">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link " href="index.html">الرئيسية</a></li>
        <li class="nav-item"><a class="nav-link " href="recitations.html">القرآن والتلاوات</a></li>
        <li class="nav-item"><a class="nav-link " href="hadith.html">الحديث الشريف</a></li>
        <li class="nav-item"><a class="nav-link " href="fiqh.html">الفقه الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="fatwa.html">فتاوى العلماء <i class="fas fa-gavel"></i></a></li>
        <li class="nav-item"><a class="nav-link active" href="seerah.html">السيرة والصحابة</a></li>
        <li class="nav-item"><a class="nav-link " href="aqeedah.html">العقيدة الإسلامية</a></li>
        <li class="nav-item"><a class="nav-link " href="history.html">التاريخ الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="library.html">المكتبة الشاملة</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- HERO -->
<section class="seerah-hero">
  <div class="hero-orbs"><span></span><span></span><span></span></div>
  <div class="hero-pattern"></div>
  <div class="container hero-content">
    <div class="row align-items-center g-5">
      <div class="col-lg-7">
        <div class="hero-eyebrow"><i class="fas fa-star-and-crescent me-2"></i>موسوعة السيرة النبوية الشريفة</div>
        <h1>حياة خير البشرية<br>محمد ﷺ</h1>
        <p class="tagline">من المولد الشريف إلى الوفاة — رحلة إيمانية عبر<br>المراحل والغزوات والمواقف والشمائل النبوية الكريمة</p>
        <div class="hero-quote">
          <p>«كَانَ رَسُولُ اللَّهِ ﷺ أَحْسَنَ النَّاسِ وَجْهًا، وَأَحْسَنَهُمْ خَلْقًا»</p>
          <small>— البخاري ومسلم</small>
        </div>
      </div>
      <div class="col-lg-5 text-center d-none d-lg-block">
        <div style="width:300px;height:300px;margin:0 auto;position:relative;">
          <div style="position:absolute;inset:0;border-radius:50%;border:2px solid rgba(201,166,107,.2);animation:spin 20s linear infinite;"></div>
          <div style="position:absolute;inset:20px;border-radius:50%;border:1px dashed rgba(201,166,107,.3);animation:spin 15s linear infinite reverse;"></div>
          <div style="position:absolute;inset:50%;width:160px;height:160px;transform:translate(-50%,-50%);background:rgba(201,166,107,.08);border-radius:50%;border:2px solid rgba(201,166,107,.3);display:flex;align-items:center;justify-content:center;">
            <i class="fas fa-star-and-crescent" style="font-size:5rem;color:var(--gold);opacity:.8;"></i>
          </div>
          <div style="position:absolute;top:10px;left:50%;transform:translateX(-50%);background:rgba(201,166,107,.15);border:1px solid rgba(201,166,107,.3);border-radius:20px;padding:5px 14px;font-size:.78rem;color:var(--gold2);white-space:nowrap;">مكة المكرمة 571م</div>
          <div style="position:absolute;bottom:10px;left:50%;transform:translateX(-50%);background:rgba(201,166,107,.15);border:1px solid rgba(201,166,107,.3);border-radius:20px;padding:5px 14px;font-size:.78rem;color:var(--gold2);white-space:nowrap;">المدينة المنورة 632م</div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- STATS -->
<div class="stats-strip">
  <div class="container">
    <div class="row text-center g-0">
      <div class="col-6 col-md-3 stat-item border-end border-white border-opacity-20"><div class="stat-num">63</div><div class="stat-label">سنة عمره ﷺ</div></div>
      <div class="col-6 col-md-3 stat-item border-end border-white border-opacity-20"><div class="stat-num">27</div><div class="stat-label">غزوة وسرية</div></div>
      <div class="col-6 col-md-3 stat-item border-end border-white border-opacity-20"><div class="stat-num">23</div><div class="stat-label">سنة الدعوة</div></div>
      <div class="col-6 col-md-3 stat-item"><div class="stat-num">9</div><div class="stat-label">أمهات المؤمنين</div></div>
    </div>
  </div>
</div>

<div class="container mb-5">
<!-- TABS -->
<ul class="nav sec-tabs" id="sTabs" role="tablist">
  <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#t-timeline"><i class="fas fa-history me-1"></i> التسلسل الزمني</button></li>
  <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t-ghazawat"><i class="fas fa-sword me-1"></i> الغزوات والسرايا</button></li>
  <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t-akhlaq"><i class="fas fa-heart me-1"></i> أخلاقه وشمائله</button></li>
  <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t-sifat"><i class="fas fa-star me-1"></i> صفاته الجسدية</button></li>
  <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t-family"><i class="fas fa-users me-1"></i> آل بيته وصحابته</button></li>
</ul>

<div class="tab-content">
<!-- TAB 1: TIMELINE -->
<div class="tab-pane fade show active" id="t-timeline" role="tabpanel">
  <div class="sec-head">
    <span class="tag">من المهد إلى اللحد</span>
    <h3>التسلسل الزمني <span>للسيرة</span></h3>
    <p>رحلة حياة النبي ﷺ عبر المراحل الزمنية — من المولد الشريف حتى الوفاة الشريفة</p>
    <div class="divider"></div>
  </div>
  <div class="timeline">

    <div class="tl-item">
      <div class="tl-dot"><i class="fas fa-baby"></i></div>
      <div class="tl-card">
        <span class="tl-tag">مكة المكرمة</span>
        <h5>المولد الشريف</h5>
        <p>وُلد النبي ﷺ يوم الاثنين 12 ربيع الأول عام الفيل (571م) في مكة المكرمة. توفي والده عبد الله قبل ولادته، فكفله جده عبد المطلب ثم أرضعته حليمة السعدية.</p>
      </div>
      <div class="tl-year">571م | قبل البعثة</div>
    </div>

    <div class="tl-item right">
      <div class="tl-dot"><i class="fas fa-heart-broken"></i></div>
      <div class="tl-card">
        <span class="tl-tag">6 سنوات</span>
        <h5>وفاة الأم ثم الجد</h5>
        <p>توفيت والدته آمنة بنت وهب وهو في السادسة من عمره في الأبواء راجعةً من المدينة، ثم توفي جده عبد المطلب بعد عامين، فكفله عمه أبو طالب.</p>
      </div>
      <div class="tl-year">577م</div>
    </div>

    <div class="tl-item">
      <div class="tl-dot"><i class="fas fa-ring"></i></div>
      <div class="tl-card">
        <span class="tl-tag">25 سنة</span>
        <h5>الزواج من خديجة</h5>
        <p>تزوج النبي ﷺ السيدة خديجة بنت خويلد رضي الله عنها، وهو في الخامسة والعشرين. كانت أول من آمن به وأعانه على الدعوة بنفسها ومالها.</p>
      </div>
      <div class="tl-year">595م</div>
    </div>

    <div class="tl-item right">
      <div class="tl-dot"><i class="fas fa-book-open"></i></div>
      <div class="tl-card">
        <span class="tl-tag">40 سنة</span>
        <h5>البعثة النبوية</h5>
        <p>نزل الوحي أول مرة في غار حراء بسورة العلق: ﴿اقْرَأْ بِاسْمِ رَبِّكَ الَّذِي خَلَقَ﴾. بدأ الدعوة سراً ثلاث سنوات ثم جهر بها في السنة الرابعة.</p>
      </div>
      <div class="tl-year">610م</div>
    </div>

    <div class="tl-item">
      <div class="tl-dot"><i class="fas fa-plane"></i></div>
      <div class="tl-card">
        <span class="tl-tag">12 سنة من البعثة</span>
        <h5>الإسراء والمعراج</h5>
        <p>أُسريَ بالنبي ﷺ من المسجد الحرام إلى المسجد الأقصى، ثم عُرج به إلى السماوات العلا حيث التقى بالأنبياء وفُرضت الصلوات الخمس.</p>
      </div>
      <div class="tl-year">621م</div>
    </div>

    <div class="tl-item right">
      <div class="tl-dot"><i class="fas fa-route"></i></div>
      <div class="tl-card">
        <span class="tl-tag">المرحلة المدنية</span>
        <h5>الهجرة إلى المدينة</h5>
        <p>هاجر النبي ﷺ رفقة أبي بكر الصديق إلى المدينة المنورة عام 622م. اختبأا في غار ثور ثلاثة أيام ثم واصلا الرحلة. استقبله أهل المدينة بالأغاني والأفراح.</p>
      </div>
      <div class="tl-year">622م | 1هـ</div>
    </div>

    <div class="tl-item">
      <div class="tl-dot"><i class="fas fa-mosque"></i></div>
      <div class="tl-card">
        <span class="tl-tag">المدينة المنورة</span>
        <h5>بناء المسجد النبوي وتأسيس الدولة</h5>
        <p>بنى النبي ﷺ المسجد النبوي بيده، وآخى بين المهاجرين والأنصار، وعقد المواثيق مع اليهود والقبائل الأخرى، مؤسساً أول دولة إسلامية في التاريخ.</p>
      </div>
      <div class="tl-year">622م | 1هـ</div>
    </div>

    <div class="tl-item right">
      <div class="tl-dot"><i class="fas fa-key"></i></div>
      <div class="tl-card">
        <span class="tl-tag">8 هـ</span>
        <h5>فتح مكة المكرمة</h5>
        <p>دخل النبي ﷺ مكة فاتحاً في عشرة آلاف مقاتل يوم الجمعة 20 رمضان 8هـ. طاف بالكعبة وكسر أصنامها وقال: "جاء الحق وزهق الباطل" ثم عفا عن أهل مكة.</p>
      </div>
      <div class="tl-year">630م | 8هـ</div>
    </div>

    <div class="tl-item">
      <div class="tl-dot"><i class="fas fa-scroll"></i></div>
      <div class="tl-card">
        <span class="tl-tag">حجة الوداع</span>
        <h5>الحجة الأخيرة والخطبة التاريخية</h5>
        <p>أدّى النبي ﷺ حجّه الوحيد وألقى خطبة الوداع في عرفة أمام أكثر من 100,000 صحابي، أعلن فيها اكتمال الدين: ﴿الْيَوْمَ أَكْمَلْتُ لَكُمْ دِينَكُمْ﴾.</p>
      </div>
      <div class="tl-year">632م | 10هـ</div>
    </div>

    <div class="tl-item right">
      <div class="tl-dot"><i class="fas fa-star"></i></div>
      <div class="tl-card">
        <span class="tl-tag">الوفاة الشريفة</span>
        <h5>انتقال النبي ﷺ إلى الرفيق الأعلى</h5>
        <p>توفي النبي ﷺ يوم الاثنين 12 ربيع الأول 11هـ في بيت عائشة رضي الله عنها بالمدينة المنورة عن عمر ناهز 63 عاماً. ودُفن في مكان وفاته.</p>
      </div>
      <div class="tl-year">632م | 11هـ</div>
    </div>

  </div>
</div>
"""

with codecs.open(r"c:\Users\ST\Desktop\islamic.encyclopedia\seerah_p1.tmp", 'w', 'utf-8') as f:
    f.write(part1)
print("Seerah Part 1 done")
