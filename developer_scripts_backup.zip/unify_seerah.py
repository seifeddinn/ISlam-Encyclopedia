import codecs

html = """<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>أكاديمية السيرة النبوية والصحابة - الموسوعة الإسلامية الشاملة</title>
<link href="https://fonts.googleapis.com/css2?family=Amiri:ital,wght@0,400;0,700;1,400&family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root{--gold:#d4af37;--gold-light:#f9f1d8;--gold-dark:#aa8a2a;--dark:#450a0a;--primary:#991b1b;}
body{font-family:'Cairo',sans-serif;background:#f8fafc;color:#1e293b;overflow-x:hidden;}
h1,h2,h3,h4,h5,h6,.ar,.poetry{font-family:'Amiri',serif;}

/* MEGA NAVBAR */
.navbar {background:linear-gradient(135deg,var(--dark),var(--primary))!important;box-shadow:0 4px 30px rgba(0,0,0,.5);z-index:1000;border-bottom:2px solid rgba(212,175,55,0.2);}
.navbar-brand{font-family:'Amiri',serif;font-size:1.8rem;color:white!important;text-shadow:0 2px 10px rgba(212,175,55,0.5);}
.nav-link{color:rgba(255,255,255,.8)!important;font-weight:700;letter-spacing:0.5px;transition:all .3s;}
.nav-link:hover, .nav-link.active{color:var(--gold)!important;transform:translateX(-2px);}

/* MEGA HERO - SEERAH (CRIMSON & GOLD) */
.mega-hero{min-height:90vh;background:radial-gradient(circle at 50% 50%, var(--primary) 0%, var(--dark) 80%);position:relative;overflow:hidden;display:flex;align-items:center;padding:120px 0;}
.hero-glass{background:rgba(69,10,10,0.5);backdrop-filter:blur(15px);border:1px solid rgba(212,175,55,0.3);border-radius:30px;padding:60px 40px;box-shadow:0 20px 50px rgba(0,0,0,0.5);position:relative;z-index:5;text-align:center;}
.hero-pattern{position:absolute;inset:0;background:url('https://www.transparenttextures.com/patterns/arabesque.png');opacity:.1;mix-blend-mode:overlay;}
.hero-eyebrow{display:inline-block;background:linear-gradient(90deg,var(--gold-dark),var(--gold));color:#290202;padding:8px 30px;border-radius:50px;font-weight:bold;font-size:1rem;margin-bottom:25px;box-shadow:0 4px 15px rgba(212,175,55,0.4);}
.mega-hero h1{font-size:5.5rem;font-weight:900;color:white;text-shadow:0 10px 30px rgba(0,0,0,0.8);line-height:1.2;margin-bottom:20px;}
.mega-hero h1 span{background:linear-gradient(135deg,#fff,var(--gold));-webkit-background-clip:text;-webkit-text-fill-color:transparent;}
.tagline{color:#fee2e2;font-size:1.3rem;line-height:2.2;text-shadow:0 2px 4px rgba(0,0,0,0.5);max-width:800px;margin:0 auto;}

/* ANIMATED ORBS */
.orb{position:absolute;border-radius:50%;filter:blur(120px);opacity:.3;animation:floatOrb 15s ease-in-out infinite alternate;}
.orb-1{width:600px;height:600px;background:var(--gold);top:-150px;right:-100px;}
.orb-2{width:500px;height:500px;background:#ef4444;bottom:-100px;left:-50px;animation-delay:5s;}
@keyframes floatOrb{0%{transform:translate(0,0) scale(1);}100%{transform:translate(50px,50px) scale(1.1);}}

/* STATS MEGA */
.stats-mega{background:linear-gradient(90deg,var(--dark),var(--primary));border-top:2px solid var(--gold-dark);border-bottom:2px solid var(--gold-dark);padding:40px 0;position:relative;z-index:10;margin-top:-5px;}
.stat-box{text-align:center;color:white;padding:20px;border-left:1px solid rgba(212,175,55,0.2);}
.stat-box:last-child{border-left:none;}
.stat-num{font-family:'Amiri',serif;font-size:3.5rem;font-weight:bold;color:var(--gold);line-height:1;margin-bottom:10px;text-shadow:0 5px 15px rgba(212,175,55,0.3);}
.stat-label{font-size:1.1rem;font-weight:bold;letter-spacing:1px;color:#fca5a5;}

/* SECTION HEADERS */
.sec-head{text-align:center;margin-bottom:60px;position:relative;}
.sec-head .tag{display:inline-block;background:rgba(212,175,55,0.1);color:var(--gold-dark);border:1px solid rgba(212,175,55,0.3);border-radius:30px;padding:8px 25px;font-size:1rem;font-weight:bold;margin-bottom:20px;}
.sec-head h3{font-size:3rem;font-family:'Amiri',serif;color:var(--dark);font-weight:900;margin-bottom:15px;}
.sec-head h3 span{color:var(--primary);}
.sec-head p{color:#64748b;font-size:1.2rem;max-width:800px;margin:0 auto;line-height:1.8;}
.sec-head .divider{width:80px;height:5px;background:linear-gradient(90deg,var(--gold),var(--primary));border-radius:5px;margin:25px auto 0;}

/* TABS NAVIGATION MEGA */
.main-tabs-wrapper{background:white;padding:20px;border-radius:20px;box-shadow:0 10px 40px rgba(0,0,0,0.05);margin:40px auto 60px;position:sticky;top:80px;z-index:900;border:1px solid #e2e8f0;}
.main-tabs{display:flex;gap:10px;overflow-x:auto;padding-bottom:10px;border-bottom:none;}
.main-tabs::-webkit-scrollbar{height:6px;}
.main-tabs::-webkit-scrollbar-thumb{background:var(--gold);border-radius:10px;}
.main-tabs .nav-link{border:1px solid #e2e8f0;border-radius:12px;color:#475569;font-weight:bold;padding:15px 25px;font-size:1.1rem;white-space:nowrap;transition:all .3s;}
.main-tabs .nav-link:hover{background:#f8fafc;border-color:var(--gold-dark);color:var(--dark);transform:translateY(-2px);}
.main-tabs .nav-link.active{background:linear-gradient(135deg,var(--dark),var(--primary));color:white;border-color:transparent;box-shadow:0 10px 20px rgba(153,27,27,0.3);}

/* CARDS */
.mega-card{background:white;border-radius:24px;padding:35px;box-shadow:0 15px 35px rgba(0,0,0,0.04);border:1px solid #fee2e2;transition:all .4s;height:100%;}
.mega-card:hover{transform:translateY(-8px);box-shadow:0 25px 50px rgba(153,27,27,0.1);border-color:var(--gold);}
.mega-icon{font-size:3.5rem;background:linear-gradient(135deg,var(--primary),var(--dark));-webkit-background-clip:text;-webkit-text-fill-color:transparent;margin-bottom:20px;display:inline-block;}

/* MEGA FOOTER */
.mega-footer{background:linear-gradient(135deg,var(--dark),#020617);color:white;padding:80px 0 30px;margin-top:80px;border-top:3px solid var(--gold-dark);}
.mega-footer-link{color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;}
.mega-footer-link:hover{color:var(--gold);padding-right:5px;}

/* TIMELINE */
.timeline{position:relative;max-width:1000px;margin:0 auto;padding-left:15px;}
.timeline::before{content:'';position:absolute;top:0;bottom:0;left:50%;width:4px;background:var(--primary);transform:translateX(-50%);border-radius:5px;}
.tl-item{position:relative;margin-bottom:50px;width:50%;}
.tl-item:nth-child(even){left:50%;padding-left:40px;}
.tl-item:nth-child(odd){left:0;padding-right:40px;text-align:left;}
.tl-dot{position:absolute;width:24px;height:24px;background:var(--gold);border:4px solid var(--dark);border-radius:50%;top:20px;}
.tl-item:nth-child(even) .tl-dot{left:-12px;}
.tl-item:nth-child(odd) .tl-dot{right:-12px;}
@media (max-width:768px){.timeline::before{left:20px;}.tl-item{width:100%;left:0!important;padding-left:50px!important;padding-right:0!important;text-align:right!important;}.tl-item .tl-dot{left:8px!important;right:auto!important;}}
.tl-content{background:white;padding:30px;border-radius:20px;box-shadow:0 10px 30px rgba(0,0,0,0.05);border:1px solid #f87171;transition:all .3s;}
.tl-item:hover .tl-content{transform:translateY(-5px);box-shadow:0 15px 40px rgba(153,27,27,0.1);border-color:var(--gold);}

/* SAHABA CARDS */
.sahaba-card{background:linear-gradient(145deg,#fff,#fef2f2);border-radius:20px;padding:30px;text-align:center;box-shadow:0 10px 25px rgba(0,0,0,0.05);border-bottom:5px solid var(--primary);transition:.3s;height:100%;}
.sahaba-card:hover{transform:translateY(-10px);border-color:var(--gold);}
.s-name{font-family:'Amiri',serif;font-size:2rem;color:var(--dark);font-weight:bold;margin:15px 0;}
.s-title{background:rgba(212,175,55,0.2);color:var(--gold-dark);padding:5px 15px;border-radius:20px;font-weight:bold;font-size:0.9rem;display:inline-block;margin-bottom:15px;}

.virtue-box{background:#fdfbf7;border:1px solid var(--gold);padding:30px;border-radius:15px;margin-bottom:20px;position:relative;}
.virtue-box::before{content:'';position:absolute;top:0;left:0;width:5px;height:100%;background:linear-gradient(to bottom,var(--primary),var(--gold));border-radius:15px 0 0 15px;}

/* BATTLE MAPS */
.map-container{background:#fdf6e3;border:2px solid var(--gold);border-radius:20px;position:relative;height:400px;overflow:hidden;box-shadow:inset 0 0 20px rgba(0,0,0,0.1);background-image:url('https://www.transparenttextures.com/patterns/aged-paper.png');}
.map-team{position:absolute;padding:10px 20px;border-radius:10px;font-weight:bold;font-family:'Amiri',serif;color:white;box-shadow:0 5px 15px rgba(0,0,0,0.3);animation:pulse 2s infinite alternate;}
.team-muslim{background:var(--primary);border:2px solid white;}
.team-enemy{background:#1e293b;border:2px solid #ef4444;}
.map-feature{position:absolute;color:#92400e;font-size:0.9rem;font-weight:bold;}
@keyframes pulse{0%{box-shadow:0 0 0 0 rgba(0,0,0,0.4);}100%{box-shadow:0 0 0 10px rgba(0,0,0,0);}}
</style>
</head>
<body>

<!-- MEGA NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-dark sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold" href="index.html"><i class="fas fa-book-open me-2 text-warning"></i>الموسوعة الإسلامية الشاملة</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav1">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="nav1">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link " href="index.html">الرئيسية</a></li>
        <li class="nav-item"><a class="nav-link " href="recitations.html">القرآن والتلاوات</a></li>
        <li class="nav-item"><a class="nav-link " href="hadith.html">الحديث الشريف</a></li>
        <li class="nav-item"><a class="nav-link " href="fiqh.html">الفقه الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="fatwa.html">فتاوى العلماء <i class="fas fa-gavel"></i></a></li>
        <li class="nav-item"><a class="nav-link active" href="seerah.html">السيرة والصحابة</a></li>
        <li class="nav-item"><a class="nav-link " href="aqeedah.html">العقيدة الإسلامية</a></li>
        <li class="nav-item"><a class="nav-link " href="history.html">التاريخ الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="library.html">المكتبة الشاملة</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- MEGA HERO SEERAH -->
<section class="mega-hero">
  <div class="orb orb-1"></div><div class="orb orb-2"></div>
  <div class="hero-pattern"></div>
  <div class="container relative z-10">
    <div class="row justify-content-center text-center">
      <div class="col-lg-10">
        <div class="hero-glass">
            <div class="hero-eyebrow"><i class="fas fa-heart me-2 text-danger"></i>سيرة خير الأنام والجيل الفريد</div>
            <h1>موسوعة <span>السيرة</span> والصحابة</h1>
            <p class="tagline mt-4">رحلة الإيمان، والجهاد، والهجرة، والنصرة. تصفح تفاصيل السيرة النبوية الطاهرة، واستلهم من سير الخلفاء الراشدين والصحابة الغر الميامين.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- STATS BAR -->
<div class="stats-mega">
  <div class="container">
    <div class="row g-0">
      <div class="col-6 col-md-3 stat-box"><div class="stat-num">23</div><div class="stat-label">سنة في النبوة والوحي</div></div>
      <div class="col-6 col-md-3 stat-box"><div class="stat-num">4</div><div class="stat-label">خلفاء راشدون أئمة</div></div>
      <div class="col-6 col-md-3 stat-box"><div class="stat-num">10</div><div class="stat-label">مبشرون بالجنة يقيناً</div></div>
      <div class="col-6 col-md-3 stat-box"><div class="stat-num">∞</div><div class="stat-label">محبة وشوق للنبي ﷺ</div></div>
    </div>
  </div>
</div>

<div class="container">
  <!-- TABS NAV -->
  <div class="main-tabs-wrapper">
    <ul class="nav nav-pills main-tabs justify-content-center" id="seerahTabs" role="tablist">
      <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#tab-timeline"><i class="fas fa-route fs-4 d-block mb-1"></i>التسلسل الزمني</button></li>
      <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-morals"><i class="fas fa-seedling fs-4 d-block mb-1"></i>الشمائل المحمدية</button></li>
      <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-khulafa"><i class="fas fa-crown fs-4 d-block mb-1"></i>الخلفاء الراشدون</button></li>
      <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-mubasharun"><i class="fas fa-star fs-4 d-block mb-1"></i>العشرة المبشرون</button></li>
      <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-battles"><i class="fas fa-map-marked-alt fs-4 d-block mb-1"></i>خرائط الغزوات</button></li>
      <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-mothers"><i class="fas fa-female fs-4 d-block mb-1"></i>أمهات المؤمنين</button></li>
    </ul>
  </div>

  <div class="tab-content pb-5">
    
    <!-- TAB 1: التسلسل -->
    <div class="tab-pane fade show active" id="tab-timeline">
      <div class="sec-head">
        <span class="tag">من المولد إلى الرفيق الأعلى</span>
        <h3>التسلسل <span>الزمني</span> للسيرة الطاهرة</h3>
        <p>مراحل تبليغ الرسالة والمواقف الفارقة في حياة أشرف الخلق نبينا محمد ﷺ.</p>
        <div class="divider"></div>
      </div>

      <div class="timeline mt-5">
         
         <div class="tl-item">
            <div class="tl-dot"></div>
            <div class="tl-content">
               <h3 class="font-amiri text-primary fw-bold mb-3">مولده ونشأته (عام الفيل - 571م)</h3>
               <p class="text-muted mb-0">وُلد يتيماً بمكة المكرمة في 12 ربيع الأول في عام الفيل. تربى في بني سعد، ثم كفله جده عبد المطلب ثم عمه أبو طالب. عُرف بالصادق الأمين، واشتغل بالرعي والتجارة، وتزوج خديجة رضي الله عنها وهو ابن 25 سنة.</p>
            </div>
         </div>

         <div class="tl-item">
            <div class="tl-dot"></div>
            <div class="tl-content">
               <h3 class="font-amiri text-primary fw-bold mb-3">البعثة والوحي (السنة 1 للبعثة)</h3>
               <p class="text-muted mb-0">نزل عليه الوحي جبريل عليه السلام في غار حراء وكان عمره 40 عاماً بقوله "اقرأ". بدأت الدعوة سراً لمدة 3 سنوات، ثم صُدع بالدعوة، ولَقِيَ وصحبه أشد أنواع العذاب والمقاطعة في شعب أبي طالب.</p>
            </div>
         </div>

         <div class="tl-item">
            <div class="tl-dot"></div>
            <div class="tl-content">
               <h3 class="font-amiri text-primary fw-bold mb-3">الإسراء والمعراج (السنة 10 للبعثة)</h3>
               <p class="text-muted mb-0">بعد عام الحزن ووفاة خديجة وأبي طالب، أُسري بالنبي ﷺ من مكة إلى المسجد الأقصى، ثم عُرج به إلى السماوات العلى، وفُرضت الصلاة، ليكون تسليةً وتثبيتاً إلهياً له.</p>
            </div>
         </div>

         <div class="tl-item">
            <div class="tl-dot"></div>
            <div class="tl-content">
               <h3 class="font-amiri text-primary fw-bold mb-3">الهجرة إلى المدينة (السنة 1 هـ)</h3>
               <p class="text-muted mb-0">خرج خلسة مع أبي بكر الصديق ووصل يثرب التي أضاءت بقدومه وأصبحت تُعرف بالمدينة المنورة. أسس هناك الدولة الإسلامية ببناء المسجد النبوي والمؤاخاة بين المهاجرين والأنصار وإصدار وثيقة المدينة.</p>
            </div>
         </div>

         <div class="tl-item">
            <div class="tl-dot"></div>
            <div class="tl-content">
               <h3 class="font-amiri text-primary fw-bold mb-3">الغزوات الكبرى (السنة 2 - 8 هـ)</h3>
               <p class="text-muted mb-0">تشريع الجهاد للدفاع عن الدعوة. بدأت ببدر الكبرى (نصر مؤزر للحق)، ثم أحد، ثم الأحزاب (الخندق)، وصلح الحديبية (فتح مبين)، فخيبر، ثم التتويج بفتح مكة العظيم في العام الثامن وتحطيم الأصنام.</p>
            </div>
         </div>

         <div class="tl-item">
            <div class="tl-dot"></div>
            <div class="tl-content">
               <h3 class="font-amiri text-primary fw-bold mb-3">حجة الوداع والوفاة (السنة 10 و 11 هـ)</h3>
               <p class="text-muted mb-0">حج النبي حجة الوداع وألقى خطبته العظيمة مقرراً حقوق الإنسان في الإسلام. وفي ربيع الأول من السنة 11هـ صعدت روحه الطاهرة للرفيق الأعلى، ودُفن في حجرته بالمسجد النبوي الشريف.</p>
            </div>
         </div>

      </div>
    </div>

    <!-- TAB 2: الشمائل -->
    <div class="tab-pane fade" id="tab-morals">
      <div class="sec-head">
        <span class="tag">وإنك لعلى خلق عظيم</span>
        <h3>الشمائل <span>المحمدية</span></h3>
        <p>أخلاقه وصفاته الخَلقية والخُلقية صلوات ربي وسلامه عليه الدائمة.</p>
        <div class="divider"></div>
      </div>

      <div class="row g-4">
         <div class="col-lg-6">
            <div class="mega-card">
               <div class="mega-icon"><i class="fas fa-hand-holding-heart text-danger"></i></div>
               <h3 class="font-amiri fw-bold text-dark mb-4">الرحمة والعدل</h3>
               <p class="text-muted fs-5 mb-0">كان أرحم الناس بالناس، بل بالحيوان، والجماد. قال تعالى: (وما أرسلناك إلا رحمة للعالمين). وكان أعدل قاضٍ وحاكم، لا يظلم أحداً بل يعفو ويصفح في أشد المواقف مثل فتح مكة "اذهبوا فأنتم الطلقاء".</p>
            </div>
         </div>
         <div class="col-lg-6">
            <div class="mega-card">
               <div class="mega-icon"><i class="fas fa-smile text-warning"></i></div>
               <h3 class="font-amiri fw-bold text-dark mb-4">التواضع والبشاشة</h3>
               <p class="text-muted fs-5 mb-0">كان يتبسم في وجه من يلقاه، وكان يخيط ثوبه، ويحلب شاته، ويجالس الفقراء في المسجد كأنه أحدهم حتى يدخل الغريب فلا يميزه من بينهم، رغم كونه سيد الأولين والآخرين.</p>
            </div>
         </div>
         <div class="col-lg-12 mt-4">
            <div class="bg-primary bg-opacity-10 rounded-4 p-5 text-center border border-primary">
               <h2 class="font-amiri fw-bold text-primary mb-3">وصف أم معبد للنبي ﷺ</h2>
               <p class="fs-4 fst-italic text-dark mb-0 font-amiri line-height-2">"ظاهر الوضاءة، أبلج الوجه، لم تعبه نُحلَة، ولم تُزْرِ به صُعْلَة، جليٌّ مُشْرِب، في عينيه دعج، وفي أشفاره وَطَف..." (أبهى الناس وأجملهم من بعيد، وأحلاهم من قريب).</p>
            </div>
         </div>
      </div>
    </div>

    <!-- TAB 3: الخلفاء -->
    <div class="tab-pane fade" id="tab-khulafa">
      <div class="sec-head">
        <span class="tag">عليكم بسنتي وسنة الخلفاء المهديين</span>
        <h3>الخلفاء <span>الراشدون</span> الأربعة</h3>
        <p>أعظم الأمة قدراً وأفضلها بعد نبيها، حملوا الراية وفتحوا الفتوح وأسسوا أعظم إمبراطورية للعدل.</p>
        <div class="divider"></div>
      </div>

      <div class="row g-4 justify-content-center">
         <div class="col-lg-5 col-md-6">
            <div class="sahaba-card">
               <i class="fas fa-gem fa-3x text-warning mb-3"></i>
               <h3 class="s-name">أبو بكر الصديق (رضي الله عنه)</h3>
               <div class="s-title">أول الخلفاء - العتيق - رفيق الغار</div>
               <p class="text-muted text-start mt-3">أفضل البشر بعد الأنبياء. أول من آمن من الرجال، هاجر مع النبي ﷺ. ثبت الأمة القلوب حين وفاة النبي، وحارب المرتدين مانعي الزكاة، وبدأت في عهده جمع القرآن. (مدة خلافته: سنتان و3 أشهر).</p>
            </div>
         </div>
         <div class="col-lg-5 col-md-6">
            <div class="sahaba-card">
               <i class="fas fa-balance-scale fa-3x text-warning mb-3"></i>
               <h3 class="s-name">عمر بن الخطاب (رضي الله عنه)</h3>
               <div class="s-title">ثاني الخلفاء - الفاروق - شهيد المحراب</div>
               <p class="text-muted text-start mt-3">مؤسس الدولة الإسلامية المدنية، وضع الدواوين والتقويم الهجري التاريخي. فُتحت في عهده بلاد الشام ومصر وفارس والقدس. عُرف بالعدل الصارم والزهد العظيم. (مدة خلافته: 10 سنوات ونصف).</p>
            </div>
         </div>
         <div class="col-lg-5 col-md-6">
            <div class="sahaba-card">
               <i class="fas fa-book-open fa-3x text-warning mb-3"></i>
               <h3 class="s-name">عثمان بن عفان (رضي الله عنه)</h3>
               <div class="s-title">ثالث الخلفاء - ذو النورين - جامع القرآن</div>
               <p class="text-muted text-start mt-3">تزوج ابنتي النبي ﷺ بالتعاقب (رقية وأم كلثوم). كان شديد الحياء غنياً سخياً حيث جهز جيش العسرة. في عهده جُمع المصحف على حرف واحد وانتشرت الفتوحات البحرية والإفريقية. (مدة خلافته: 12 سنة).</p>
            </div>
         </div>
         <div class="col-lg-5 col-md-6">
            <div class="sahaba-card">
               <i class="fas fa-fist-raised fa-3x text-warning mb-3"></i>
               <h3 class="s-name">علي بن أبي طالب (رضي الله عنه)</h3>
               <div class="s-title">رابع الخلفاء - أبو الحسن - فدائي الهجرة</div>
               <p class="text- শারীরিক mt-3 text-start text-muted">ابن عم النبي ﷺ وزوج ابنته فاطمة. أول من أسلم من الصبيان، ونام في فراش النبي ليلة الهجرة فداءً له. كان باب مدينة العلم وبطل المشاهد والنزالات وصاحب ذي الفقار. (مدة خلافته: 4 سنوات و9 أشهر).</p>
            </div>
         </div>
      </div>
    </div>

    <!-- TAB 4: المبشرون -->
    <div class="tab-pane fade" id="tab-mubasharun">
      <div class="sec-head">
        <span class="tag">الذين سبقت لهم منا الحسنى</span>
        <h3>العشرة <span>المبشرون</span> بالجنة</h3>
        <p>الصحابة الذين بشرهم النبي ﷺ صراحة باسمهم بدخول الجنة في حديث واحد، وهم صفوة الصحابة بعد الخلفاء الأربعة.</p>
        <div class="divider"></div>
      </div>

      <div class="row g-4 text-center">
         <!-- Without the 4 Khalifas because they are already highlighted, but they are from the 10 -->
         <!-- 5 -->
         <div class="col-lg-4 col-md-6">
            <div class="virtue-box">
               <h4 class="font-amiri text-dark fw-bold mb-2">سعد بن أبي وقاص</h4>
               <span class="badge bg-primary mb-2">خال النبي والفارس الرامي</span>
               <p class="text-muted small mb-0">أول من رمى بسهم في سبيل الله. كان مستجاب الدعوة، بطل القادسية وقاهر الفرس وفاتح المشرق.</p>
            </div>
         </div>
         <!-- 6 -->
         <div class="col-lg-4 col-md-6">
            <div class="virtue-box">
               <h4 class="font-amiri text-dark fw-bold mb-2">سعيد بن زيد</h4>
               <span class="badge bg-primary mb-2">من الأوائل والمستجاب الدعوة</span>
               <p class="text-muted small mb-0">كان سبب إسلام عمر بن الخطاب مع أخته فاطمة. شهد كل المشاهد إلا بدر حيث كان مكلفاً بمهمة، وشهد اليرموك.</p>
            </div>
         </div>
         <!-- 7 -->
         <div class="col-lg-4 col-md-6">
            <div class="virtue-box">
               <h4 class="font-amiri text-dark fw-bold mb-2">أبو عبيدة بن الجراح</h4>
               <span class="badge bg-primary mb-2">أمين هذه الأمة</span>
               <p class="text-muted small mb-0">أحد القادة العظام، نُزع السهمان من وجه النبي في أحد بثنيتيه، قائد جيوش الشام وفاتحها العبقري وصاحب الزهد.</p>
            </div>
         </div>
         <!-- 8 -->
         <div class="col-lg-4 col-md-6">
            <div class="virtue-box">
               <h4 class="font-amiri text-dark fw-bold mb-2">طلحة بن عبيد الله</h4>
               <span class="badge bg-primary mb-2">طلحة الخير والشهيد الحي</span>
               <p class="text-muted small mb-0">تلقى بجسده ويده السيوف والنبال عن رسول الله في أحد فشُلت يمينه، وسُمي بطلحة الجود والفياض.</p>
            </div>
         </div>
         <!-- 9 -->
         <div class="col-lg-4 col-md-6">
            <div class="virtue-box">
               <h4 class="font-amiri text-dark fw-bold mb-2">الزبير بن العوام</h4>
               <span class="badge bg-primary mb-2">حواري رسول الله</span>
               <p class="text-muted small mb-0">ابن عمة النبي، وأول من سلّ سيفاً في سبيل الله. كان من أعظم فرسان الإسلام الذين يقتحمون الصفوف بقوتهم.</p>
            </div>
         </div>
         <!-- 10 -->
         <div class="col-lg-4 col-md-6">
            <div class="virtue-box">
               <h4 class="font-amiri text-dark fw-bold mb-2">عبد الرحمن بن عوف</h4>
               <span class="badge bg-primary mb-2">التاجر الأمين الشكور</span>
               <p class="text-muted small mb-0">أغنى الصحابة، أنفق ماله وقوافل كلها مراراً في سبيل الله، وأحد الستة أصحاب الشورى ومن أصحاب الفتوى.</p>
            </div>
         </div>

      </div>
    </div>

    <!-- TAB 5: خرائط الغزوات -->
    <div class="tab-pane fade" id="tab-battles">
      <div class="sec-head">
        <span class="tag">أيام الله الخالدة</span>
        <h3>خرائط <span>الغزوات</span> الكبرى</h3>
        <p>تصور مرئي تفاعلي لأهم المعارك الفاصلة في تاريخ الإسلام السمح الدفاعي.</p>
        <div class="divider"></div>
      </div>

      <!-- Battles Nav -->
      <ul class="nav nav-pills justify-content-center mb-5 gap-3" id="battlesTabs" role="tablist">
        <li class="nav-item"><button class="btn btn-outline-danger active rounded-pill px-4 fw-bold" data-bs-toggle="tab" data-bs-target="#badr">غزوة بدر (2 هـ)</button></li>
        <li class="nav-item"><button class="btn btn-outline-danger rounded-pill px-4 fw-bold" data-bs-toggle="tab" data-bs-target="#uhud">غزوة أُحُد (3 هـ)</button></li>
        <li class="nav-item"><button class="btn btn-outline-danger rounded-pill px-4 fw-bold" data-bs-toggle="tab" data-bs-target="#khandaq">غزوة الخندق (5 هـ)</button></li>
      </ul>

      <div class="tab-content">
         <!-- Badr -->
         <div class="tab-pane fade show active" id="badr">
            <div class="row align-items-center">
               <div class="col-lg-7">
                  <div class="map-container mb-4 mb-lg-0">
                     <div class="map-feature" style="top:20px;right:20px;"><i class="fas fa-mountain me-1"></i> جبل العدوة القصوى</div>
                     <div class="map-feature" style="bottom:20px;left:20px;"><i class="fas fa-mountain me-1"></i> جبل العدوة الدنيا</div>
                     <!-- Water wells -->
                     <div class="position-absolute text-primary text-center" style="top:50%;left:30%;transform:translate(-50%,-50%);"><i class="fas fa-water fa-2x mb-1"></i><br><small class="fw-bold">آبار بدر</small></div>
                     
                     <!-- Teams -->
                     <div class="map-team team-muslim" style="top:50%;left:25%;transform:translateY(-50%);">
                        جيش المسلمين (313)<br><small class="opacity-75">بقيادة: محمد ﷺ</small>
                     </div>
                     <div class="map-team team-enemy" style="top:50%;right:15%;transform:translateY(-50%);">
                        جيش قريش (1000)<br><small class="opacity-75">بقيادة: أبو جهل</small>
                     </div>
                     
                     <!-- Arrows -->
                     <div class="position-absolute text-danger" style="top:50%;left:50%;transform:translate(-50%,-50%);font-size:2rem;">
                        <i class="fas fa-long-arrow-alt-left"></i> الملحمة <i class="fas fa-long-arrow-alt-right"></i>
                     </div>
                  </div>
               </div>
               <div class="col-lg-5">
                  <div class="mega-card bg-light border-0">
                     <h3 class="font-amiri fw-bold text-dark">غزوة بدر الكبرى (يوم الفرقان)</h3>
                     <p class="text-muted line-height-2 mt-3 fs-5">أول معركة فاصلة في الإسلام. خرج المسلمون لاعتراض قافلة قريش، فتحولت لمواجهة جيش ألفي بكامل عتاده. ألقت الملائكة الرعب في قلوب المشركين، وانتصر الحق انتصاراً مدوياً، وقُتل رؤوس الكفر وعلى رأسهم أبو جهل.</p>
                     <ul class="list-unstyled mt-4 fw-bold">
                        <li class="mb-2 text-success"><i class="fas fa-check-circle me-2"></i> شهداء المسلمين: 14</li>
                        <li class="mb-2 text-danger"><i class="fas fa-times-circle me-2"></i> قتلى المشركين: 70</li>
                        <li class="mb-2 text-warning"><i class="fas fa-link me-2"></i> الأسرى: 70</li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>

         <!-- Uhud -->
         <div class="tab-pane fade" id="uhud">
            <div class="row align-items-center">
               <div class="col-lg-7">
                  <div class="map-container mb-4 mb-lg-0">
                     <div class="map-feature text-muted font-amiri" style="top:10%;left:10%;font-size:1.5rem;"><i class="fas fa-mountain me-2 fa-2x"></i>جبل أُحُد</div>
                     
                     <div class="map-feature bg-warning text-dark px-2 rounded font-amiri fw-bold" style="top:35%;left:35%;">&lt; جبل الرماة (عينين)</div>
                     
                     <div class="map-team team-muslim" style="top:25%;left:25%;">
                        المسلمون (700)
                     </div>
                     <div class="map-team team-enemy" style="bottom:20%;right:30%;">
                        قريش (3000)<br><small class="opacity-75">خالد بن الوليد (ميسرة)</small>
                     </div>
                     
                     <!-- Arrow for خالد flank -->
                     <div class="position-absolute text-danger" style="top:45%;left:45%;transform:rotate(-45deg);font-size:2rem;opacity:0.6;">
                        <i class="fas fa-long-arrow-alt-up"></i> التفاف الفرسان
                     </div>
                  </div>
               </div>
               <div class="col-lg-5">
                  <div class="mega-card bg-light border-0">
                     <h3 class="font-amiri fw-bold text-dark">غزوة أُحُد (ابتلاء وتمحيص)</h3>
                     <p class="text-muted line-height-2 mt-3 fs-5">أرادت قريش الثأر لبدر. جعل النبي ﷺ الجبل خلفه ووضع 50 رامياً لحماية الظهره. ولما لاحت بوادر النصر، نزل الرماة لجمع الغنائم مخالفين الأمر النبوي، فالتف خالد بن الوليد (قبل إسلامه) بفرسانه وانقلبت الموازين.</p>
                     <ul class="list-unstyled mt-4 fw-bold">
                        <li class="mb-2 text-success"><i class="fas fa-check-circle me-2"></i> شهداء المسلمين: 70 (منهم أسد الله حمزة)</li>
                        <li class="mb-2 text-primary"><i class="fas fa-info-circle me-2"></i> الدرس العظيم: خطورة عصيان أمر القائد.</li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>

         <!-- Khandaq -->
         <div class="tab-pane fade" id="khandaq">
            <div class="row align-items-center">
               <div class="col-lg-7">
                  <div class="map-container mb-4 mb-lg-0">
                     <div class="map-feature bg-light px-3 py-1 rounded-pill" style="top:10px;left:50%;transform:translateX(-50%);border-bottom:5px dashed var(--dark);">الخـــــنـــــدق (الحفرة المانعة)</div>
                     
                     <div class="map-team team-muslim" style="top:40%;left:50%;transform:translateX(-50%);">
                        المدينة المنورة (المسلمون 3000)
                     </div>
                     <div class="map-team team-enemy" style="top:15%;left:50%;transform:translateX(-50%);">
                        الأحزاب (قريش وغطفان واليهود 10000)
                     </div>
                     
                     <div class="map-feature" style="bottom:20px;right:20px;"><i class="fas fa-home me-1"></i> حصون بني قريظة (غدر من الداخل)</div>
                  </div>
               </div>
               <div class="col-lg-5">
                  <div class="mega-card bg-light border-0">
                     <h3 class="font-amiri fw-bold text-dark">غزوة الخندق (الأحزاب)</h3>
                     <p class="text-muted line-height-2 mt-3 fs-5">تجمع المشركون واليهود لاستئصال دأفة المسلمين نهائياً. أشار سلمان الفارسي بحفر خندق يحمي المدينة من فرسانهم. طال الحصار قرابة الشهر وسط برد شديد وخيانة بني قريظة، حتى أرسل الله ريحاً عاتية اقتلعت خيام الأحزاب وكفت المؤمنين القتال.</p>
                     <ul class="list-unstyled mt-4 fw-bold">
                        <li class="mb-2 text-success"><i class="fas fa-wind me-2"></i> النتيجة: نصر رباني واندحار الأحزاب.</li>
                        <li class="mb-2 text-primary"><i class="fas fa-info-circle me-2"></i> الدرس العظيم: (الأخذ بالأسباب والشورى).</li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </div>
    </div>

    <!-- TAB 6: أمهات المؤمنين -->
    <div class="tab-pane fade" id="tab-mothers">
      <div class="sec-head">
        <span class="tag">الطيبات للطيبين</span>
        <h3>أمهات <span>المؤمنين</span> الطاهرات</h3>
        <p>زوجات النبي ﷺ في الدنيا والآخرة، المبرءات التقيات القانتات، رضوان الله عليهن جميعاً.</p>
        <div class="divider"></div>
      </div>

      <div class="row g-4 justify-content-center">
         <div class="col-lg-6">
            <div class="mega-card bg-light border-0" style="border-right:6px solid #e11d48;">
               <h3 class="font-amiri text-dark fw-bold mb-3">السيدة خديجة بنت خويلد</h3>
               <p class="text-muted fs-5 line-height-2 mb-0">الزوجة الأولى التي ناصرته ونصرته بمالها ونفسها. أحبها النبي حباً أسطورياً ولم يتزوج عليها حتى ماتت. أقرأها الله السلام من فوق سبع سماوات. هي الأم لمعظم أبناء النبي ﷺ.</p>
            </div>
         </div>
         <div class="col-lg-6">
            <div class="mega-card bg-light border-0" style="border-right:6px solid #e11d48;">
               <h3 class="font-amiri text-dark fw-bold mb-3">السيدة عائشة بنت أبي بكر</h3>
               <p class="text-muted fs-5 line-height-2 mb-0">أحب النساء للنبي، المبرأة من فوق سبع سماوات في حادثة الإفك، فصيحة بليغة عالمة فقيهة، المكثرة من رواية الحديث (2210 أحاديث). نزل الوحي وتوفي النبي صلوات الله عليه في حجرتها وعلى صدرها.</p>
            </div>
         </div>
      </div>
      
      <div class="text-center mt-5 w-75 mx-auto text-muted">
         <p class="fs-5">ومن أمهاتنا الطاهرات أيضاً: سودة بنت زمعة، وحفصة بنت عمر بن الخطاب رضي الله عنها حارسة القرآن التي حُوفظ عندها المصحف الجامع، وزينب بنت خزيمة، وأم سلمة الحكيمة ذات الرأي السديد، وزينب بنت جحش العابدة الصوامة، وجويرية بنت الحارث، وصفيّة بنت حُييّ، وأم حبيبة، وميمونة بنت الحارث... رضوان الله عليهن وعن بنات النبي: زينب ورقية وأم كلثوم وفاطمة الزهراء سيدة نساء أهل الجنة.</p>
      </div>

    </div>

  </div> <!-- End Tabs -->
</div>

<!-- MEGA FOOTER -->
<footer class="mega-footer" style="background:linear-gradient(135deg,var(--dark),#020617);color:white;padding:80px 0 30px;margin-top:80px;border-top:3px solid var(--gold-dark);">
  <div class="container">
    <div class="row g-5 mb-5 border-bottom border-light border-opacity-10 pb-5">
      <div class="col-lg-4 text-md-end text-center">
        <i class="fas fa-mosque fa-4x text-warning mb-4 d-block"></i>
        <h4 class="fw-bold font-amiri fs-2 mb-3">الموسوعة الإسلامية الشاملة</h4>
        <p class="opacity-75 fs-6 line-height-2">أضخم صرح رقمي يجمع علوم القرآن العظيم، وأحاديث المصطفى، وفقهاء المذاهب، والتاريخ المجيد في منصة موثقة مصممة بأحدث التقنيات.</p>
      </div>
      <div class="col-lg-4 text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">تصفح الموسوعة</h5>
        <div class="d-flex flex-wrap justify-content-center gap-2">
          <a href="recitations.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">أكاديمية القرآن</a>
          <a href="hadith.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الحديث النبوي</a>
          <a href="seerah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">السيرة والصحابة</a>
          <a href="fiqh.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الفقه وأصوله</a>
          <a href="fatwa.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">فتاوى العلماء</a>
          <a href="aqeedah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">العقيدة الإسلامية</a>
          <a href="history.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">التاريخ المجيد</a>
          <a href="library.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">المكتبة الشاملة</a>
        </div>
      </div>
      <div class="col-lg-4 text-md-start text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">روابط سريعة</h5>
        <a href="contact.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> اتصل بالمطور</a>
        <a href="share.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> شارك الأجر</a>
        <a href="login.html" class="mega-footer-link text-warning mt-3" style="text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-user-circle me-2 ms-1"></i> تسجيل الدخول</a>
      </div>
    </div>
    <div class="text-center font-amiri fs-5 d-flex flex-column gap-2">
      <span class="opacity-75">الموسوعة الإسلامية الشاملة &copy; 2026 تم التصميم للإفادة | عمل مجاني لوجه الله</span>
      <span class="text-warning fw-bold fs-4 mt-2">تصميم وتطوير: لخذاري محمد سيف الدين</span>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
"""

with codecs.open(r"C:\Users\ST\Desktop\islamic.encyclopedia\seerah.html", "w", "utf-8") as f:
    f.write(html)
print("seerah.html MEGA UNIQUE done.")
