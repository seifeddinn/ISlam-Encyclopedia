
    <!-- TAB 1: MEGA QURAN -->
    <div class="tab-pane fade show active" id="tab-quran">
      <div class="sec-head">
        <span class="tag">كِتَابٌ أَنْزَلْنَاهُ إِلَيْكَ مُبَارَكٌ</span>
        <h3>المصحف <span>الشريف</span></h3>
        <p>النسخة التفاعلية الكاملة للمصحف المرتل، استمع لقراءك المفضلين وتتبع الآيات أو ابحث في فهرس السور المقسم علمياً.</p>
        <div class="divider"></div>
      </div>
      
      <!-- Daily Wird Card -->
      <div class="row justify-content-center mb-5">
        <div class="col-lg-8">
           <div class="mega-card position-relative overflow-hidden" style="background:linear-gradient(135deg,var(--dark),var(--emerald));color:white;border:none;">
              <!-- Background pattern -->
              <div style="position:absolute;inset:0;background:url('https://www.transparenttextures.com/patterns/arabesque.png');opacity:0.1;pointer-events:none;"></div>
              
              <div class="d-flex align-items-center gap-4 position-relative z-1">
                 <div style="background:rgba(255,255,255,0.1);padding:25px;border-radius:20px;box-shadow:0 10px 20px rgba(0,0,0,0.2);">
                    <i class="fas fa-moon fa-3x text-warning"></i>
                 </div>
                 <div class="flex-grow-1">
                    <h4 class="text-warning font-amiri fw-bold mb-2">متابعة الحفظ والتلاوة (وِردُكَ اليومي)</h4>
                    <p class="mb-3 opacity-90 fs-5" id="wirdStatusText">لم تقم بتسجيل أي تلاوة اليوم.</p>
                    
                    <div class="progress mb-3 shadow-sm" style="height:12px; background:rgba(255,255,255,0.2); border-radius:10px;">
                      <div id="wirdProgressBar" class="progress-bar bg-warning progress-bar-striped progress-bar-animated" role="progressbar" style="width: 0%; border-radius:10px;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    
                    <button id="btnLogWird" class="btn btn-warning rounded-pill px-5 py-2 fw-bold shadow-sm" onclick="logDailyWird()" style="transition:0.3s;">
                        سجل قراءة اليوم <i class="fas fa-check-circle ms-2"></i>
                    </button>
                    <button id="btnResetWird" class="btn btn-outline-light rounded-pill px-3 py-2 ms-2 fw-bold opacity-75" onclick="resetWird()" style="transition:0.3s;" title="تصفير العداد">
                        <i class="fas fa-undo"></i>
                    </button>
                 </div>
              </div>
           </div>
        </div>
      </div>
      
      <!-- Logic for Wird Tracker -->
      <script>
      function updateWirdUI() {
          const lastRead = localStorage.getItem('last_wird_date');
          const today = new Date().toDateString();
          let streak = parseInt(localStorage.getItem('wird_streak')) || 0;
          
          if (lastRead === today) {
              document.getElementById('wirdStatusText').innerHTML = `أحسنت! لقد أتممت وردك اليوم. سلسلة الاستمرار: <strong class="text-warning">${streak} أيام</strong> 🔥`;
              document.getElementById('wirdProgressBar').style.width = '100%';
              document.getElementById('btnLogWird').disabled = true;
              document.getElementById('btnLogWird').innerHTML = `تم التسجيل بنجاح <i class="fas fa-check ms-2"></i>`;
              document.getElementById('btnLogWird').classList.add('opacity-50');
          } else {
              if (lastRead) {
                  const lastDate = new Date(lastRead);
                  const diffDays = Math.floor((new Date() - lastDate) / (1000 * 60 * 60 * 24));
                  if (diffDays > 1) { streak = 0; localStorage.setItem('wird_streak', '0'); }
              }
              document.getElementById('wirdStatusText').innerHTML = `هل قرأت وردك؟ سلسلة الاستمرار الحالية: <strong class="text-white">${streak} أيام</strong>`;
              document.getElementById('wirdProgressBar').style.width = '0%';
              document.getElementById('btnLogWird').disabled = false;
              document.getElementById('btnLogWird').innerHTML = `سجل قراءة اليوم <i class="fas fa-check-circle ms-2"></i>`;
              document.getElementById('btnLogWird').classList.remove('opacity-50');
          }
      }
      function logDailyWird() {
          const today = new Date().toDateString();
          let streak = parseInt(localStorage.getItem('wird_streak')) || 0;
          localStorage.setItem('last_wird_date', today);
          localStorage.setItem('wird_streak', (streak + 1).toString());
          updateWirdUI();
      }
      function resetWird() {
          if(confirm("هل أنت متأكد من تصفير سلسلة الاستمرار؟")) {
              localStorage.removeItem('last_wird_date');
              localStorage.setItem('wird_streak', '0');
              updateWirdUI();
          }
      }
      document.addEventListener('DOMContentLoaded', updateWirdUI);
      </script>

      <!-- Advanced Search & Filter -->
      <div class="bg-white p-4 rounded-4 shadow-sm border mb-5 d-flex flex-wrap align-items-center justify-content-between gap-3 max-w-1000 mx-auto" style="max-width:1000px;">
        <div class="d-flex align-items-center gap-3 flex-grow-1 bg-light rounded-pill px-4 py-2">
           <i class="fas fa-search text-muted"></i>
           <input type="text" id="megaSurahSearch" class="form-control border-0 bg-transparent shadow-none" placeholder="ابحث باسم السورة (مثال: البقرة، يوسف، الكهف...)">
        </div>
        <div class="btn-group" id="megaFilters" role="group">
          <button type="button" class="btn btn-outline-emerald active" data-filter="all">فهرس المصحف (114)</button>
          <button type="button" class="btn btn-outline-emerald" data-filter="tiwal">السبع الطوال</button>
          <button type="button" class="btn btn-outline-emerald" data-filter="miin">المئين</button>
          <button type="button" class="btn btn-outline-emerald" data-filter="mathani">المثاني</button>
          <button type="button" class="btn btn-outline-emerald" data-filter="mufassal">المفصل</button>
        </div>
      </div>
      <style>.btn-outline-emerald{color:var(--emerald);border-color:var(--emerald);font-weight:bold;}.btn-outline-emerald:hover,.btn-outline-emerald.active{background:var(--emerald);color:white;}</style>

      <div class="row g-4" id="mega-surah-list">
        <!-- Injected by external/inline JS -->
      </div>
    </div>
