import re

file_path = r"c:\Users\ST\Desktop\islamic.encyclopedia\library.html"

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

styles = """
    <style>
        /* Modern Premium Library Styles */
        body { background-color: #f8f9fa; font-family: 'Amiri', serif; }
        
        .library-hero {
            background: linear-gradient(135deg, #1A2980 0%, #26D0CE 100%);
            position: relative;
            overflow: hidden;
            padding: 80px 0 100px;
            color: white;
            border-bottom-left-radius: 50px;
            border-bottom-right-radius: 50px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            text-align: center;
        }
        .library-hero::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background: url('https://www.transparenttextures.com/patterns/arabesque.png');
            opacity: 0.1;
        }
        .library-hero h1 { font-weight: 700; font-size: 3rem; text-shadow: 2px 2px 4px rgba(0,0,0,0.2); }
        .library-hero .search-container {
            position: relative;
            z-index: 2;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            padding: 15px;
            border-radius: 20px;
            border: 1px solid rgba(255,255,255,0.2);
            box-shadow: 0 15px 35px rgba(0,0,0,0.2);
            display: flex;
            align-items: center;
            max-width: 600px;
            margin: 0 auto;
        }
        .library-hero .form-control {
            border-radius: 30px;
            padding: 12px 25px;
            border: none;
            box-shadow: none;
            background: rgba(255,255,255,0.9);
            margin-left: 10px;
        }
        .library-hero .btn-search {
            border-radius: 30px;
            padding: 12px 30px;
            background: linear-gradient(135deg, #f39c12, #e67e22);
            border: none;
            color: #fff;
            transition: all 0.3s;
            box-shadow: 0 5px 15px rgba(243, 156, 18, 0.3);
        }
        .library-hero .btn-search:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(243, 156, 18, 0.4); }

        /* Filter Buttons */
        .filter-wrapper { text-align: center; margin-top: -40px; position: relative; z-index: 10; padding: 0 20px; }
        .filter-container { background: white; border-radius: 30px; display: inline-flex; flex-wrap: wrap; justify-content: center; padding: 15px; box-shadow: 0 15px 35px rgba(0,0,0,0.08); }
        .filter-btn { border: none; background: transparent; color: #555; font-weight: bold; padding: 10px 25px; border-radius: 30px; margin: 5px; transition: all 0.4s ease; font-size: 1.05rem; }
        .filter-btn:hover, .filter-btn.active { background: linear-gradient(135deg, #1A2980, #26D0CE); color: white; box-shadow: 0 5px 15px rgba(38, 208, 206, 0.4); transform: translateY(-2px); }

        /* Book Cards */
        .book-item { margin-bottom: 25px; }
        .book-card { border: none; border-radius: 20px; overflow: hidden; background: #fff; transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275) !important; box-shadow: 0 10px 20px rgba(0,0,0,0.03); position: relative; }
        .book-card:hover { transform: translateY(-10px) !important; box-shadow: 0 20px 40px rgba(0,0,0,0.12) !important; }
        .icon-wrapper { width: 70px; height: 70px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 15px; background: rgba(38, 208, 206, 0.1); color: #1A2980; transition: all 0.3s; font-size: 1.5rem; }
        .book-card:hover .icon-wrapper { background: linear-gradient(135deg, #1A2980, #26D0CE); color: white; transform: scale(1.1) rotate(5deg); box-shadow: 0 10px 20px rgba(38, 208, 206, 0.3); }
        .card-title { font-weight: 700; color: #2c3e50; font-size: 1.15rem; margin-bottom: 0.5rem; }
        
        .badge-quran { background-color: #e8f5e9; color: #2e7d32; }
        .badge-hadith { background-color: #e3f2fd; color: #1565c0; }
        .badge-fiqh { background-color: #fff3e0; color: #ef6c00; }
        .badge-aqeedah { background-color: #fce4ec; color: #c2185b; }
        .badge-seerah { background-color: #fff8e1; color: #f57f17; }
        .badge-tazkiyah { background-color: #e0f2f1; color: #00695c; }
        
        .custom-badge { padding: 6px 12px; border-radius: 20px; font-weight: 600; font-size: 0.75rem; border: 1px solid rgba(0,0,0,0.05); }

        .quick-view-btn { background: #f8f9fa; border: none; color: #6c757d; border-radius: 15px; padding: 12px; font-weight: bold; transition: all 0.3s; }
        .book-card:hover .quick-view-btn { background: linear-gradient(135deg, #1A2980, #26D0CE); color: white; box-shadow: 0 5px 15px rgba(26, 41, 128, 0.3); }

        /* Modal */
        .modal-content { border-radius: 25px; border: none; overflow: hidden; }
        .modal-header { background: linear-gradient(135deg, #1A2980, #26D0CE); color: white; border: none; padding: 20px; }
        .modal-header .btn-close { filter: brightness(0) invert(1); opacity: 0.8; }
        .qv-icon-area { background: #f8f9fa; border-radius: 20px; padding: 30px 20px; }
        #qvDownloadBtn { border-radius: 20px; padding: 10px 25px; background: linear-gradient(135deg, #f39c12, #e67e22); border: none; box-shadow: 0 5px 15px rgba(243, 156, 18, 0.3); color: white; transition: 0.3s; text-decoration: none; }
        #qvDownloadBtn:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(243, 156, 18, 0.4); color: white; }
    </style>
</head>"""

if "<style>" not in content:
    content = content.replace("</head>", styles)

# Replace Header
hero_old = re.search(r'<section class="page-header.*?</section>', content, re.DOTALL)
if hero_old:
    hero_new = """    <section class="library-hero">
        <div class="container relative-z">
            <h1 class="mb-4"><i class="fas fa-book-reader me-3"></i>المكتبة الإسلامية</h1>
            <p class="lead mb-5">كنز من المصادر والمراجع العلمية في شتى العلوم الشرعية</p>
            <div class="search-container">
                <input type="text" class="form-control" id="bookSearch" placeholder="ابحث عن كتاب، مؤلف، أو قسم...">
                <button class="btn btn-search" type="button"><i class="fas fa-search me-2"></i>بحث</button>
            </div>
        </div>
    </section>"""
    content = content.replace(hero_old.group(0), hero_new)

# Replace Filter Buttons
filter_old = re.search(r'<!-- Filter Buttons -->\s*<div class="text-center mb-5">.*?</div>', content, re.DOTALL)
if filter_old:
    filter_new = """        <!-- Filter Buttons -->
        <div class="filter-wrapper mb-5">
            <div class="filter-container">
                <button class="filter-btn active" data-filter="all">الكل</button>
                <button class="filter-btn" data-filter="quran">علوم القرآن</button>
                <button class="filter-btn" data-filter="hadith">الحديث الشريف</button>
                <button class="filter-btn" data-filter="fiqh">الفقه وأصوله</button>
                <button class="filter-btn" data-filter="aqeedah">العقيدة</button>
                <button class="filter-btn" data-filter="seerah">السيرة والتاريخ</button>
                <button class="filter-btn" data-filter="tazkiyah">التزكية والرقائق</button>
            </div>
        </div>"""
    content = content.replace(filter_old.group(0), filter_new)

# Replace Cards
content = content.replace('class="card h-100 shadow-sm"', 'class="card h-100 book-card"')
content = content.replace('class="card-body text-center"', 'class="card-body text-center p-4"')
content = content.replace('class="card-footer bg-white border-top-0 text-center"', 'class="card-footer bg-white border-0 text-center pb-4 pt-0"')
content = content.replace('btn btn-sm btn-primary w-100 quick-view-btn', 'btn w-100 quick-view-btn')

def replace_icon(match):
    icon_cls = match.group(1)
    return f'<div class="icon-wrapper"><i class="fas fa-{icon_cls} mb-0"></i></div>'

content = re.sub(r'<i class="fas fa-([a-z0-9-]+) fa-3x text-[a-z]+ mb-3"></i>', replace_icon, content)

def replace_badge(match):
    text = match.group(1)
    cat_class = "badge-seerah"
    if "قرآن" in text: cat_class = "badge-quran"
    elif "حديث" in text or "أحكام" in text: cat_class = "badge-hadith"
    elif "فقه" in text: cat_class = "badge-fiqh"
    elif "عقيدة" in text: cat_class = "badge-aqeedah"
    elif "سير" in text or "تاريخ" in text or "شمائل" in text: cat_class = "badge-seerah"
    elif "تزكية" in text or "رقائق" in text: cat_class = "badge-tazkiyah"
    
    return f'<span class="badge custom-badge {cat_class} mb-3">{text}</span>'

content = re.sub(r'<span class="badge bg-[a-z]+(?: text-dark)? mb-2">(.*?)</span>', replace_badge, content)


with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)
print("Updated library.html successfully!")
