import codecs
import re

with codecs.open(r"C:\Users\ST\Desktop\islamic.encyclopedia\seerah.html", "r", "utf-8") as f:
    html = f.read()

# Check for unclosed divs
open_divs = len(re.findall(r'<div', html))
close_divs = len(re.findall(r'</div', html))
print(f"<div> count: {open_divs}, </div> count: {close_divs}")

# Check tab IDs and their corresponding tab panes
nav_tabs = re.findall(r'data-bs-target="#([^"]+)"', html)
tab_panes = re.findall(r'class="tab-pane[^"]*" id="([^"]+)"', html)

print("Nav targets:", nav_tabs)
print("Tab panes:", tab_panes)

missing_panes = set(nav_tabs) - set(tab_panes)
if missing_panes:
    print("Missing panes:", missing_panes)
else:
    print("All tabs have matching panes.")

# Check for duplicate IDs
ids = re.findall(r'id="([^"]+)"', html)
from collections import Counter
id_counts = Counter(ids)
duplicates = [id for id, count in id_counts.items() if count > 1]
if duplicates:
    print("Duplicate IDs found:", duplicates)

# Also let's output lines 200 to 250 just to see if the Sahaba tabs were injected weirdly
lines = html.splitlines()
print("\n--- Snippet around injection point ---")
for i, line in enumerate(lines[140:190]):
    print(f"{i+141}: {line}")

