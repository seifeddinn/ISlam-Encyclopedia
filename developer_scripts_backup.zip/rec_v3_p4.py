
    <!-- TAB 3: MAQAMAT MEGA -->
    <div class="tab-pane fade" id="tab-maqam">
      <div class="sec-head">
        <span class="tag">جماليات التصوير القرآني للصوت</span>
        <h3>المقامات <span>الصوتية</span> الثمانية</h3>
        <p>التوظيف الفني البديع للنغمات في تلاوة القرآن لتصوير المعاني، مجموعة في كلمتي (صنع بسحرك). لكل مقام طابع، ولكل سورة مقام يناسبها.</p>
        <div class="divider"></div>
      </div>
      
      <div class="row g-4">
        <!-- Bayati -->
        <div class="col-lg-3 col-md-6">
          <div class="mega-card" style="border-top:5px solid #0f766e;">
            <div class="d-flex align-items-center mb-3">
              <div class="bg-light p-3 rounded-circle me-3"><i class="fas fa-play text-cyan fs-4"></i></div>
              <h4 class="fw-bold m-0">الصَّبَا</h4>
            </div>
            <p class="text-muted small mb-3">مقام العاطفة والحزن الشديد والروحانية العميقة. يُستعمل لاستدرار الدموع وتصوير القهر والوعيد.</p>
            <div class="bg-light px-3 py-2 rounded-3 small"><strong>سورة مقترحة:</strong> القيامة، الحاقة</div>
          </div>
        </div>

        <!-- Nahawand -->
        <div class="col-lg-3 col-md-6">
          <div class="mega-card" style="border-top:5px solid #4f46e5;">
            <div class="d-flex align-items-center mb-3">
              <div class="bg-light p-3 rounded-circle me-3"><i class="fas fa-play text-primary fs-4"></i></div>
              <h4 class="fw-bold m-0">النَّهَاوَند</h4>
            </div>
            <p class="text-muted small mb-3">مقام الحنان والعاطفة والرقة المتناهية. مناسب جداً لآيات الرحمة وقصص الأنبياء والتفكر في خلق الله.</p>
            <div class="bg-light px-3 py-2 rounded-3 small"><strong>سورة مقترحة:</strong> مريم، يوسف</div>
          </div>
        </div>

        <!-- Ajam -->
        <div class="col-lg-3 col-md-6">
          <div class="mega-card" style="border-top:5px solid #eab308;">
            <div class="d-flex align-items-center mb-3">
              <div class="bg-light p-3 rounded-circle me-3"><i class="fas fa-play text-warning fs-4"></i></div>
              <h4 class="fw-bold m-0">العَجَم</h4>
            </div>
            <p class="text-muted small mb-3">مقام التعظيم الملوكي والانتصار والقوة والوضوح الكامل. لا حزن فيه بل حزم، يُناسب آيات الأحكام والنصر.</p>
            <div class="bg-light px-3 py-2 rounded-3 small"><strong>سورة مقترحة:</strong> الفتح، الصف</div>
          </div>
        </div>

        <!-- Bayati -->
        <div class="col-lg-3 col-md-6">
          <div class="mega-card" style="border-top:5px solid #10b981;">
            <div class="d-flex align-items-center mb-3">
              <div class="bg-light p-3 rounded-circle me-3"><i class="fas fa-play text-success fs-4"></i></div>
              <h4 class="fw-bold m-0">البَيَاتِي</h4>
            </div>
            <p class="text-muted small mb-3">أم المقامات وأوسعها وأطوعها للقارئ. مقام الخشوع والتأمل وفيه سعة هائلة، وهو المقام الافتتاحي لأغلب القراء.</p>
            <div class="bg-light px-3 py-2 rounded-3 small"><strong>سورة مقترحة:</strong> القصص، الأنعام</div>
          </div>
        </div>

        <!-- Sikah -->
        <div class="col-lg-3 col-md-6">
          <div class="mega-card" style="border-top:5px solid #f59e0b;">
            <div class="d-flex align-items-center mb-3">
              <div class="bg-light p-3 rounded-circle me-3"><i class="fas fa-play text-warning fs-4"></i></div>
              <h4 class="fw-bold m-0">السِّيكَا</h4>
            </div>
            <p class="text-muted small mb-3">مقام بطيء ذو طابع شرقي عميق يُصوّر معاني النصر والبشائر. يبعث على السرور والبهجة الهادئة والتأمل.</p>
            <div class="bg-light px-3 py-2 rounded-3 small"><strong>سورة مقترحة:</strong> الضحى، الشرح</div>
          </div>
        </div>

        <!-- Hijaz -->
        <div class="col-lg-3 col-md-6">
          <div class="mega-card" style="border-top:5px solid #ef4444;">
            <div class="d-flex align-items-center mb-3">
              <div class="bg-light p-3 rounded-circle me-3"><i class="fas fa-play text-danger fs-4"></i></div>
              <h4 class="fw-bold m-0">الحِجَاز</h4>
            </div>
            <p class="text-muted small mb-3">مقام أرضي عتيق يُنسب لمكة والمدينة، له نبرة حزينة ممزوجة بالشوق العارم والعظمة والجلال.</p>
            <div class="bg-light px-3 py-2 rounded-3 small"><strong>سورة مقترحة:</strong> إبراهيم، محمد</div>
          </div>
        </div>

        <!-- Rast -->
        <div class="col-lg-3 col-md-6">
          <div class="mega-card" style="border-top:5px solid #b45309;">
            <div class="d-flex align-items-center mb-3">
              <div class="bg-light p-3 rounded-circle me-3"><i class="fas fa-play" style="color:#b45309;"></i></div>
              <h4 class="fw-bold m-0">الرَّسْت</h4>
            </div>
            <p class="text-muted small mb-3">مقام الاستقامة والفخامة (أبو المقامات المشرقية). يناسب الآيات التي تتحدث عن الجنة والأحكام والتشريع.</p>
            <div class="bg-light px-3 py-2 rounded-3 small"><strong>سورة مقترحة:</strong> البقرة، الرحمن</div>
          </div>
        </div>

        <!-- Kurd -->
        <div class="col-lg-3 col-md-6">
          <div class="mega-card" style="border-top:5px solid #8b5cf6;">
            <div class="d-flex align-items-center mb-3">
              <div class="bg-light p-3 rounded-circle me-3"><i class="fas fa-play" style="color:#8b5cf6;"></i></div>
              <h4 class="fw-bold m-0">الكُرد</h4>
            </div>
            <p class="text-muted small mb-3">مقام خالٍ من الربع تون (سهل على غير العرب)، جميل ومبسط ويلامس القلب بشدة وتتلو به المدارس الحديثة كثيراً.</p>
            <div class="bg-light px-3 py-2 rounded-3 small"><strong>سورة مقترحة:</strong> الملك، طه</div>
          </div>
        </div>
      </div>
    </div>
