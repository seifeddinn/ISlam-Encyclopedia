<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>عن المشروع - الموسوعة الإسلامية الشاملة</title>
    <link href="https://fonts.googleapis.com/css2?family=Amiri:ital,wght@0,400;0,700;1,400&family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root{--gold:#d4af37;--dark:#0f172a;--primary:#1e293b;}
        body{font-family:'Cairo',sans-serif;background:#f8fafc;color:#1e293b;overflow-x:hidden;}
        h1,h2,h3,h4,.amiri{font-family:'Amiri',serif;}
        
        /* MEGA NAVBAR */
        .navbar {background:linear-gradient(135deg,var(--dark),var(--primary))!important;box-shadow:0 4px 30px rgba(0,0,0,.5);z-index:1000;border-bottom:2px solid rgba(212,175,55,0.2);}
        .navbar-brand{font-family:'Amiri',serif;font-size:1.8rem;color:white!important;text-shadow:0 2px 10px rgba(212,175,55,0.5);}
        .nav-link{color:rgba(255,255,255,.8)!important;font-weight:700;letter-spacing:0.5px;transition:all .3s;}
        .nav-link:hover, .nav-link.active{color:var(--gold)!important;transform:translateX(-2px);}

        /* ABOUT HERO */
        .about-hero {background:radial-gradient(circle at 50% 50%, #334155 0%, var(--dark) 80%); padding:120px 0 100px; text-align:center; position:relative; overflow:hidden;}
        .about-hero::before {content:''; position:absolute; inset:0; background:url('https://www.transparenttextures.com/patterns/arabesque.png'); opacity:0.1; mix-blend-mode:overlay;}
        .about-wrapper {position:relative; max-width:900px; margin:0 auto; z-index:10; background:rgba(255,255,255,0.05); backdrop-filter:blur(15px); border:1px solid rgba(212,175,55,0.2); padding:50px; border-radius:30px; box-shadow:0 20px 50px rgba(0,0,0,0.5);}
        .floating-icon {font-size:4rem; color:var(--gold); margin-bottom:20px; animation:float 3s ease-in-out infinite;}
        @keyframes float {0%{transform:translateY(0);} 50%{transform:translateY(-15px);} 100%{transform:translateY(0);}}
        
        /* MEGA CARDS SECTION */
        .about-cards {margin-top:-50px; position:relative; z-index:20;}
        .mega-card {background:white; border-radius:24px; padding:40px; box-shadow:0 15px 40px rgba(0,0,0,0.05); height:100%; text-align:center; border:1px solid #f1f5f9; transition:0.4s;}
        .mega-card:hover {transform:translateY(-10px); box-shadow:0 25px 50px rgba(212,175,55,0.15); border-color:var(--gold);}
        .card-icon {width:80px; height:80px; background:linear-gradient(135deg, var(--gold), #baa54d); color:white; border-radius:20px; display:inline-flex; align-items:center; justify-content:center; font-size:2.5rem; margin-bottom:25px; transform:rotate(-10deg); transition:0.3s;}
        .mega-card:hover .card-icon {transform:rotate(0deg) scale(1.1);}
        
        /* STATS SECTION */
        .stats-section {background:linear-gradient(135deg, var(--dark), #020617); padding:80px 0; color:white; border-top:3px solid var(--gold); border-bottom:3px solid var(--gold);}
        .stat-item {text-align:center; padding:20px;}
        .stat-num {font-family:'Amiri',serif; font-size:4rem; font-weight:bold; color:var(--gold); margin-bottom:10px; text-shadow:0 5px 15px rgba(212,175,55,0.3);}
        .stat-label {font-size:1.2rem; opacity:0.8; letter-spacing:1px;}
        
        /* DEVELOPER SPOTLIGHT */
        .dev-spotlight {background:white; padding:80px 0;}
        .dev-box {background:#f8fafc; border-radius:30px; padding:50px; border-right:8px solid var(--gold); box-shadow:0 15px 35px rgba(0,0,0,0.05); display:flex; gap:40px; align-items:center;}
        @media (max-width: 991px) {
            .dev-box {flex-direction:column; text-align:center; border-right:none; border-top:8px solid var(--gold);}
        }
        .dev-avatar-lg {width:150px; height:150px; border-radius:50%; background:linear-gradient(135deg, var(--dark), var(--primary)); color:var(--gold); display:flex; align-items:center; justify-content:center; font-size:4.5rem; flex-shrink:0; box-shadow:0 15px 30px rgba(0,0,0,0.2);}
        
    </style>
</head>
<body>

<!-- MEGA NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-dark sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold" href="index.html"><i class="fas fa-book-open me-2 text-warning"></i>الموسوعة الإسلامية الشاملة</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav1">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="nav1">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link " href="index.html">الرئيسية</a></li>
        <li class="nav-item"><a class="nav-link " href="recitations.html">القرآن والتلاوات</a></li>
        <li class="nav-item"><a class="nav-link " href="hadith.html">الحديث الشريف</a></li>
        <li class="nav-item"><a class="nav-link " href="fiqh.html">الفقه الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="fatwa.html">فتاوى العلماء <i class="fas fa-gavel"></i></a></li>
        <li class="nav-item"><a class="nav-link " href="seerah.html">السيرة والصحابة</a></li>
        <li class="nav-item"><a class="nav-link " href="aqeedah.html">العقيدة الإسلامية</a></li>
        <li class="nav-item"><a class="nav-link " href="history.html">التاريخ الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="library.html">المكتبة الشاملة</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- ABOUT HERO -->
<section class="about-hero">
    <div class="container px-3">
        <div class="about-wrapper">
            <i class="fas fa-globe-africa floating-icon"></i>
            <h1 class="display-3 amiri text-white fw-bold mb-4">صرح <span class="text-warning">المعرفة</span> الرقمية</h1>
            <p class="fs-4 amiri text-white opacity-90 mb-0 line-height-2">
                الموسوعة الإسلامية الشاملة هي منصة إلكترونية متكاملة تهدف إلى نشر العلوم الإسلامية الصحيحة من مصادرها الموثوقة بطريقة ميسرة وسهلة الوصول، لتبني جيلاً واثقاً بعقيدته وفاهماً لدينه.
            </p>
        </div>
    </div>
</section>

<!-- MEGA CARDS SECTION -->
<div class="container about-cards mb-5">
    <div class="row g-4 justify-content-center">
        <!-- Card 1 -->
        <div class="col-lg-4 col-md-6">
            <div class="mega-card">
                <div class="card-icon"><i class="fas fa-eye"></i></div>
                <h3 class="amiri fw-bold text-dark mb-3">رؤيتنــــا</h3>
                <p class="text-muted fs-5">أن نكون المنصة الرقمية الأولى والرائدة عالمياً في تقديم المحتوى الإسلامي الموثوق بنهج أهل السنة والجماعة، وبتجربة مستخدم لا تضاهى.</p>
            </div>
        </div>
        <!-- Card 2 -->
        <div class="col-lg-4 col-md-6">
            <div class="mega-card">
                <div class="card-icon"><i class="fas fa-bullseye"></i></div>
                <h3 class="amiri fw-bold text-dark mb-3">رسالتنـــا</h3>
                <p class="text-muted fs-5">حماية الثوابت وتيسير الوصول إلى المعرفة الدينية (قرآناً وحديثاً وفقهاً وسيرة) لكل مسلم حول العالم باستخدام أحدث تقنيات الويب.</p>
            </div>
        </div>
        <!-- Card 3 -->
        <div class="col-lg-4 col-md-6">
            <div class="mega-card">
                <div class="card-icon"><i class="fas fa-shield-alt"></i></div>
                <h3 class="amiri fw-bold text-dark mb-3">عهدنا وموثوقيتنا</h3>
                <p class="text-muted fs-5">الموسوعة خالية من الإعلانات تماماً. نلتزم بالدقة العلمية واستقاء المعلومات من أمهات الكتب والمصادر الإسلامية المعتمدة فقط.</p>
            </div>
        </div>
    </div>
</div>

<!-- STATS SECTION -->
<section class="stats-section">
    <div class="container">
        <div class="row g-4 justify-content-center">
            <div class="col-6 col-md-3 stat-item">
                <div class="stat-num" data-target="114">0</div>
                <div class="stat-label">سورة قرآنية مجودة</div>
            </div>
            <div class="col-6 col-md-3 stat-item">
                <div class="stat-num" data-target="200">0</div>
                <div class="stat-label">+ قارئ عالمي</div>
            </div>
            <div class="col-6 col-md-3 stat-item">
                <div class="stat-num" data-target="4">0</div>
                <div class="stat-label">مذاهب فقهية ميسرة</div>
            </div>
            <div class="col-6 col-md-3 stat-item">
                <div class="stat-num" data-target="100">0</div>
                <div class="stat-label">% محتوى موثق</div>
            </div>
        </div>
    </div>
</section>

<!-- DEVELOPER SPOTLIGHT -->
<section class="dev-spotlight">
    <div class="container">
        <div class="dev-box">
            <div class="dev-avatar-lg">
                <i class="fas fa-user-astronaut"></i>
            </div>
            <div>
                <span class="badge bg-dark text-warning px-3 py-2 rounded-pill mb-3 fs-6">الجهة المطورة للمشروع</span>
                <h2 class="amiri fw-bold text-dark mb-3 display-5">لخذاري محمد سيف الدين</h2>
                <p class="text-muted fs-4 line-height-2 mb-4">
                    مشروع الموسوعة الإسلامية تم تصميمه وبنائه وهيكلته بالكامل كصدقة جارية بجهد فردي، مستهدفاً إثراء المحتوى العربي والإسلامي على شبكة الإنترنت بواجهات عصرية تفاعلية لتواكب الجيل الحديث.
                </p>
                <a href="contact.html" class="btn btn-dark rounded-pill px-4 py-2 fs-5 me-2"><i class="fas fa-envelope me-2 text-warning"></i> تواصل معي</a>
                <a href="share.html" class="btn btn-outline-dark rounded-pill px-4 py-2 fs-5"><i class="fas fa-share-nodes me-2"></i> شارك الأجر</a>
            </div>
        </div>
    </div>
</section>

<footer class="mega-footer" style="background:linear-gradient(135deg,var(--dark),#020617);color:white;padding:80px 0 30px;margin-top:80px;border-top:3px solid var(--gold-dark);">
  <div class="container">
    <div class="row g-5 mb-5 border-bottom border-light border-opacity-10 pb-5">
      <div class="col-lg-4 text-md-end text-center">
        <i class="fas fa-mosque fa-4x text-warning mb-4 d-block"></i>
        <h4 class="fw-bold font-amiri fs-2 mb-3">الموسوعة الإسلامية الشاملة</h4>
        <p class="opacity-75 fs-6 line-height-2">أضخم صرح رقمي يجمع علوم القرآن العظيم، وأحاديث المصطفى، وفقهاء المذاهب، والتاريخ المجيد في منصة موثقة مصممة بأحدث التقنيات.</p>
      </div>
      <div class="col-lg-4 text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">تصفح الموسوعة</h5>
        <div class="d-flex flex-wrap justify-content-center gap-2">
          <a href="recitations.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">أكاديمية القرآن</a>
          <a href="hadith.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الحديث النبوي</a>
          <a href="seerah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">السيرة والصحابة</a>
          <a href="fiqh.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الفقه وأصوله</a>
          <a href="fatwa.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">فتاوى العلماء</a>
          <a href="aqeedah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">العقيدة الإسلامية</a>
          <a href="history.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">التاريخ المجيد</a>
          <a href="library.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">المكتبة الشاملة</a>
        </div>
      </div>
      <div class="col-lg-4 text-md-start text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">روابط سريعة</h5>
        <a href="contact.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> اتصل بالمطور</a>
        <a href="share.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> شارك الأجر</a>
        <a href="login.html" class="mega-footer-link text-warning mt-3" style="text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-user-circle me-2 ms-1"></i> تسجيل الدخول</a>
      </div>
    </div>
    <div class="text-center font-amiri fs-5 d-flex flex-column gap-2">
      <span class="opacity-75">الموسوعة الإسلامية الشاملة &copy; 2026 تم التصميم للإفادة | عمل مجاني لوجه الله</span>
      <span class="text-warning fw-bold fs-4 mt-2">تصميم وتطوير: لخذاري محمد سيف الدين</span>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Stats Counter Animation
    const counters = document.querySelectorAll('.stat-num');
    const speed = 200; // The lower the slower

    const startCounters = () => {
        counters.forEach(counter => {
            const updateCount = () => {
                const target = +counter.getAttribute('data-target');
                const count = +counter.innerText;
                const inc = target / speed;

                if (count < target) {
                    counter.innerText = Math.ceil(count + inc);
                    setTimeout(updateCount, 15);
                } else {
                    counter.innerText = target + (target > 100 ? '+' : '');
                }
            };
            updateCount();
        });
    }

    // Intersection Observer to start animation when scrolled into view
    const observer = new IntersectionObserver((entries) => {
        if(entries[0].isIntersecting){
            startCounters();
            observer.disconnect();
        }
    }, { threshold: 0.5 });
    
    observer.observe(document.querySelector('.stats-section'));
</script>
</body>
</html>
