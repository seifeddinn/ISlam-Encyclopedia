import sys
import codecs
import re

try:
    with codecs.open(r"c:\Users\ST\Desktop\islamic.encyclopedia\unify_history.py", "r", "utf-8") as f:
        content = f.read()

    # Fix the typo
    content = content.replace('w>أمير المؤمنين', 'w-100 p-2>أمير المؤمنين')

    # Inject SEO tags
    seo_tags = """<title>أكاديمية التاريخ الإسلامي - الموسوعة الإسلامية الشاملة</title>
    <meta name="description" content="الموسوعة الإسلامية الشاملة - المنصة الرقمية الموثوقة لعلوم القرآن والسنة والفقه والسيرة والتاريخ بعقيدة صحيحة.">
    <meta name="keywords" content="قرآن, حديث, إسلام, فقه, عقيدة, سيرة, تاريخ إسلامي, الموسوعة الإسلامية">
    <meta name="author" content="ST Islamic Web">
    <meta property="og:title" content="الموسوعة الإسلامية الشاملة">
    <meta property="og:description" content="مرجعك الشامل للعلوم الشرعية الموثقة بتصميم عصري وتقنيات حديثة.">
    <meta property="og:type" content="website">
    <link rel="icon" href="https://cdn-icons-png.flaticon.com/512/3389/3389081.png" type="image/png">"""

    content = content.replace('<title>أكاديمية التاريخ الإسلامي - الموسوعة الإسلامية الشاملة</title>', seo_tags)

    # Inject new tabs links
    nav_links = """      <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#tab-eras"><i class="fas fa-hourglass-half fs-4 d-block mb-1"></i>عصور الخلافة والدول</button></li>
      <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-battles"><i class="fas fa-khanda fs-4 d-block mb-1"></i>المعارك الفاصلة</button></li>
      <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-heroes"><i class="fas fa-horse-head fs-4 d-block mb-1"></i>قادة وفرسان الأمة</button></li>
      <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-civ"><i class="fas fa-mosque fs-4 d-block mb-1"></i>روائع الحضارة والعلوم</button></li>
      <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-landmarks"><i class="fas fa-kaaba fs-4 d-block mb-1"></i>المعالم الكبرى</button></li>
      <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-stats"><i class="fas fa-chart-pie fs-4 d-block mb-1"></i>أرقام وإحصائيات</button></li>"""
      
    content = re.sub(
        r'<li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#tab-eras">.*?</button></li>.*?<li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-civ">.*?</button></li>',
        nav_links,
        content,
        flags=re.DOTALL
    )

    # Inject new content blocks
    new_blocks = """      </div>
    </div> <!-- /TAB 4 -->

    <!-- TAB 5: المعالم الإسلامية -->
    <div class="tab-pane fade" id="tab-landmarks">
      <div class="sec-head">
        <span class="tag">إرث معماري خالد</span>
        <h3>أبرز <span>المعالم الإسلامية</span> وأمجاد العمارة</h3>
        <p>صروح عملاقة ومعالم مقدسة تعكس عظمة الفن الإسلامي والإبداع الهندسي عبر العصور.</p>
        <div class="divider"></div>
      </div>
      <div class="row g-4">
         <div class="col-lg-6">
            <div class="mega-card d-flex align-items-center gap-4 text-end">
               <i class="fas fa-kaaba fa-4x text-dark"></i>
               <div>
                  <h4 class="title-amiri fw-bold mb-2">المسجد الحرام والكعبة المشرفة</h4>
                  <p class="text-muted small mb-0">أقدس البقاع وأول بيت وضع للناس، بناه إبراهيم عليه السلام وطوره الخلفاء. يأتيه المسلمون من كل فج عميق.</p>
               </div>
            </div>
         </div>
         <div class="col-lg-6">
            <div class="mega-card d-flex align-items-center gap-4 text-end">
               <i class="fas fa-mosque fa-4x text-success"></i>
               <div>
                  <h4 class="title-amiri fw-bold mb-2">المسجد الأقصى (قبة الصخرة)</h4>
                  <p class="text-muted small mb-0">أولى القبلتين وثالث الحرمين ومسرى الرسول ﷺ. درة العمارة الأموية، بناه عبد الملك بن مروان وكساه بالذهب.</p>
               </div>
            </div>
         </div>
         <div class="col-lg-6">
            <div class="mega-card d-flex align-items-center gap-4 text-end">
               <i class="fas fa-archway fa-4x text-primary"></i>
               <div>
                  <h4 class="title-amiri fw-bold mb-2">الجامع الأموي بدمشق</h4>
                  <p class="text-muted small mb-0">من عجائب العمارة الإسلامية القديمة. أدخل الفسيفساء الذهبية العملاقة وأسس نظام المآذن المربعة وتأثرت به كل المساجد.</p>
               </div>
            </div>
         </div>
         <div class="col-lg-6">
            <div class="mega-card d-flex align-items-center gap-4 text-end">
               <i class="fas fa-vihara fa-4x text-danger"></i>
               <div>
                  <h4 class="title-amiri fw-bold mb-2">قصر الحمراء (غرناطة)</h4>
                  <p class="text-muted small mb-0">أعظم أثر إسلامي في الأندلس واوروبا. يُعد معجزة في هندسة المياه والمقرنصات والنقوش الجصية المعقدة.</p>
               </div>
            </div>
         </div>
      </div>
    </div> <!-- /TAB 5 -->

    <!-- TAB 6: إحصائيات -->
    <div class="tab-pane fade" id="tab-stats">
      <div class="sec-head">
        <span class="tag">لغة الماضي بلغة الأرقام</span>
        <h3>التاريخ <span>بالأرقام</span> المدهشة</h3>
        <p>حقائق رقمية تبرز حجم الامتداد والتأثير لأمة الإسلام في تاريخ الأرض.</p>
        <div class="divider"></div>
      </div>
      <div class="row g-4 text-center justify-content-center">
         <div class="col-md-4">
            <div class="battle-card py-5">
               <i class="fas fa-globe-asia battle-sword" style="color:var(--primary);opacity:0.1;font-size:12rem;"></i>
               <div class="position-relative z-index-2">
                  <h2 class="display-3 fw-bold text-dark font-amiri mb-2">22.5</h2>
                  <h5 class="text-muted fw-bold">مليون كم مربع</h5>
                  <p class="small text-muted mt-3">أقصى اتساع جغرافي وصلته الخلافة الأموية، وهي من أكبر الإمبراطوريات التي عرفها التاريخ البشري قاطبة.</p>
               </div>
            </div>
         </div>
         <div class="col-md-4">
            <div class="battle-card py-5">
               <i class="fas fa-book-reader battle-sword" style="color:var(--primary);opacity:0.1;font-size:12rem;"></i>
               <div class="position-relative z-index-2">
                  <h2 class="display-3 fw-bold text-dark font-amiri mb-2">781</h2>
                  <h5 class="text-muted fw-bold">عاماً هجرياً</h5>
                  <p class="small text-muted mt-3">مدة الحكم الإسلامي في الأندلس (شبه الجزيرة الأيبيرية)، أطول فترة استقرار حضاري في غرب أوروبا.</p>
               </div>
            </div>
         </div>
         <div class="col-md-4">
            <div class="battle-card py-5">
               <i class="fas fa-chart-line battle-sword" style="color:var(--primary);opacity:0.1;font-size:12rem;"></i>
               <div class="position-relative z-index-2">
                  <h2 class="display-3 fw-bold text-dark font-amiri mb-2">2.1</h2>
                  <h5 class="text-muted fw-bold">مليار مسلم</h5>
                  <p class="small text-muted mt-3">حصاد تلك الدعوة التي بدأت برجل واحد ﷺ في مكة، لتغطي شعوب وقبائل العالم في يومنا المعاصر.</p>
               </div>
            </div>
         </div>
      </div>
    </div> <!-- /TAB 6 -->"""

    content = content.replace('      </div>\r\n    </div> <!-- /TAB 4 -->', new_blocks)
    content = content.replace('      </div>\n    </div> <!-- /TAB 4 -->', new_blocks)

    with codecs.open(r"c:\Users\ST\Desktop\islamic.encyclopedia\unify_history.py", "w", "utf-8") as f:
        f.write(content)
        
    print("PATCH APPLIED SUCCESSFULLY")
except Exception as e:
    print(f"ERROR: {e}")
