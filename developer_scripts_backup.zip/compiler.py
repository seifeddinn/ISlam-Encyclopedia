import codecs

files = [
    r"C:\Users\ST\Desktop\islamic.encyclopedia\rec_v3_p1.py",
    r"C:\Users\ST\Desktop\islamic.encyclopedia\rec_v3_p2.py",
    r"C:\Users\ST\Desktop\islamic.encyclopedia\rec_v3_p3.py",
    r"C:\Users\ST\Desktop\islamic.encyclopedia\rec_v3_p4.py",
    r"C:\Users\ST\Desktop\islamic.encyclopedia\rec_v3_p5.py",
    r"C:\Users\ST\Desktop\islamic.encyclopedia\rec_v3_p6.py"
]

final_html = ""
for file in files:
    with codecs.open(file, 'r', 'utf-8') as f:
        final_html += f.read()

with codecs.open(r"C:\Users\ST\Desktop\islamic.encyclopedia\recitations.html", "w", "utf-8") as f:
    f.write(final_html)

print("Compiled successfully from raw HTML chunks")
