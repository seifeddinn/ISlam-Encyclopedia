import codecs

file_path = r"c:\Users\ST\Desktop\islamic.encyclopedia\recitations.html"

html_content = """<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>أكاديمية علوم القرآن - الموسوعة الإسلامية الشاملة</title>
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Amiri:wght@400;700&family=Cairo:wght@400;600;700;800&family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <!-- FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <link rel="stylesheet" href="styles.css">

    <style>
        /* Modern Premium Quran Academy Styles */
        :root {
            --primary-color: #1a5f7a;
            --secondary-color: #c9a66b;
            --accent-color: #e67e22;
            --bg-light: #f8fbfa;
            --card-bg: rgba(255, 255, 255, 0.95);
            --text-dark: #2c3e50;
            --glass-bg: rgba(255, 255, 255, 0.85);
            --glass-border: rgba(255, 255, 255, 0.2);
            --glass-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.1);
            --gradient-primary: linear-gradient(135deg, #1a5f7a 0%, #227b9c 100%);
            --gradient-gold: linear-gradient(135deg, #c9a66b 0%, #e0c28f 100%);
        }

        body {
            font-family: 'Cairo', sans-serif;
            background-color: var(--bg-light);
            background-image: url('data:image/svg+xml,%3Csvg width="60" height="60" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg"%3E%3Cg fill="none" fill-rule="evenodd"%3E%3Cg fill="%231a5f7a" fill-opacity="0.03"%3E%3Cpath d="M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z"/%3E%3C/g%3E%3C/g%3E%3C/svg%3E');
            color: var(--text-dark);
            overflow-x: hidden;
        }

        h1, h2, h3, h4, .quran-text {
            font-family: 'Amiri', serif;
        }

        /* Hero Section */
        .quran-hero {
            background: var(--gradient-primary);
            position: relative;
            padding: 100px 0 80px;
            color: white;
            overflow: hidden;
            margin-bottom: 50px;
        }

        .quran-hero::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('https://www.transparenttextures.com/patterns/arabesque.png');
            opacity: 0.2;
            animation: moveBackground 60s linear infinite;
        }

        @keyframes moveBackground {
            from { background-position: 0 0; }
            to { background-position: 1000px 1000px; }
        }

        .hero-content {
            position: relative;
            z-index: 2;
        }

        .hero-icon-wrapper {
            width: 100px;
            height: 100px;
            background: rgba(255,255,255,0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            border: 2px solid rgba(255,255,255,0.2);
            backdrop-filter: blur(5px);
            font-size: 3rem;
            color: var(--secondary-color);
            box-shadow: 0 0 30px rgba(201, 166, 107, 0.4);
            animation: pulse-gold 2s infinite;
        }

        @keyframes pulse-gold {
            0% { box-shadow: 0 0 0 0 rgba(201, 166, 107, 0.4); }
            70% { box-shadow: 0 0 0 20px rgba(201, 166, 107, 0); }
            100% { box-shadow: 0 0 0 0 rgba(201, 166, 107, 0); }
        }

        /* Custom Tabs */
        .academy-tabs {
            background: white;
            padding: 10px;
            border-radius: 50px;
            box-shadow: var(--glass-shadow);
            margin-bottom: 40px;
            border: 1px solid rgba(0,0,0,0.05);
            display: flex;
            justify-content: space-between;
            overflow-x: auto;
            flex-wrap: nowrap;
            white-space: nowrap;
        }

        .academy-tabs::-webkit-scrollbar {
            height: 4px;
        }
        .academy-tabs::-webkit-scrollbar-thumb {
            background-color: var(--secondary-color);
            border-radius: 10px;
        }

        .academy-tabs .nav-item {
            flex: 1;
            text-align: center;
            min-width: 150px;
        }

        .academy-tabs .nav-link {
            border: none;
            border-radius: 40px;
            color: var(--text-dark);
            font-weight: 700;
            padding: 15px 20px;
            transition: all 0.4s ease;
            position: relative;
            z-index: 1;
        }

        .academy-tabs .nav-link i {
            margin-left: 8px;
            font-size: 1.2rem;
            transition: transform 0.3s;
        }

        .academy-tabs .nav-link:hover {
            color: var(--primary-color);
        }

        .academy-tabs .nav-link.active {
            background: var(--gradient-gold);
            color: white;
            box-shadow: 0 4px 15px rgba(201, 166, 107, 0.4);
            transform: translateY(-2px);
        }

        .academy-tabs .nav-link.active i {
            transform: scale(1.2);
            color: white;
        }

        /* Section Titles */
        .section-title-wrapper {
            text-align: center;
            margin-bottom: 40px;
            position: relative;
        }
        
        .section-title-wrapper h3 {
            display: inline-block;
            color: var(--primary-color);
            font-weight: 700;
            padding-bottom: 15px;
            position: relative;
            font-size: 2rem;
        }
        
        .section-title-wrapper h3::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 4px;
            background: var(--gradient-gold);
            border-radius: 2px;
        }

        /* --- Section 1: Audio Library --- */
        .audio-player-container {
            background: var(--glass-bg);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            box-shadow: var(--glass-shadow);
            border: 1px solid var(--glass-border);
            margin-bottom: 30px;
        }

        .player-controls {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 20px;
            margin-top: 20px;
        }

        .btn-play-main {
            width: 70px;
            height: 70px;
            border-radius: 50%;
            background: var(--gradient-primary);
            color: white;
            border: none;
            font-size: 1.8rem;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 10px 20px rgba(26, 95, 122, 0.3);
            transition: all 0.3s;
        }

        .btn-play-main:hover {
            transform: scale(1.1);
            background: var(--gradient-gold);
            box-shadow: 0 10px 20px rgba(201, 166, 107, 0.4);
        }

        .btn-control {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: white;
            color: var(--primary-color);
            border: 1px solid rgba(0,0,0,0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s;
        }

        .btn-control:hover {
            background: var(--primary-color);
            color: white;
        }

        .audio-progress {
            height: 8px;
            border-radius: 4px;
            background-color: #e9ecef;
            cursor: pointer;
            margin: 20px 0;
            position: relative;
        }
        
        .audio-progress-bar {
            height: 100%;
            border-radius: 4px;
            background: var(--gradient-gold);
            width: 0%;
            position: relative;
        }

        .audio-progress-bar::after {
            content: '';
            position: absolute;
            right: -6px; /* RTL */
            top: -4px;
            width: 16px;
            height: 16px;
            background: white;
            border: 2px solid var(--secondary-color);
            border-radius: 50%;
            box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        }

        .reciters-list {
            max-height: 500px;
            overflow-y: auto;
            border-radius: 15px;
            background: white;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }

        .reciter-item {
            padding: 15px 20px;
            border-bottom: 1px solid #f1f1f1;
            cursor: pointer;
            transition: all 0.2s;
            display: flex;
            align-items: center;
        }

        .reciter-item:hover {
            background-color: #f8fbfa;
            padding-right: 25px;
            color: var(--primary-color);
        }

        .reciter-item.active {
            background: rgba(26, 95, 122, 0.05);
            border-right: 4px solid var(--primary-color);
            font-weight: bold;
            color: var(--primary-color);
        }

        .reciter-item i {
            margin-left: 15px;
            color: var(--secondary-color);
        }

        .surah-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
            gap: 10px;
            margin-top: 20px;
            max-height: 400px;
            overflow-y: auto;
            padding-right: 5px;
        }

        .surah-btn {
            background: white;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            padding: 10px;
            text-align: center;
            cursor: pointer;
            transition: all 0.2s;
            font-family: 'Amiri', serif;
            font-size: 1.1rem;
        }

        .surah-btn:hover, .surah-btn.active {
            background: var(--primary-color);
            color: white;
            border-color: var(--primary-color);
            transform: translateY(-2px);
        }

        /* --- Section 2: Qira'at --- */
        .qiraat-card {
            background: white;
            border-radius: 20px;
            border: none;
            box-shadow: 0 10px 30px rgba(0,0,0,0.05);
            overflow: hidden;
            transition: all 0.4s;
            height: 100%;
            position: relative;
        }

        .qiraat-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 40px rgba(26, 95, 122, 0.15);
        }

        .qiraat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 5px;
            background: var(--gradient-gold);
        }

        .qiraat-number {
            position: absolute;
            top: 15px;
            left: 15px;
            font-size: 3.5rem;
            font-family: 'Amiri', serif;
            color: rgba(26, 95, 122, 0.05);
            font-weight: bold;
            line-height: 1;
        }

        .reader-name {
            color: var(--primary-color);
            font-family: 'Amiri', serif;
            font-size: 1.8rem;
            font-weight: bold;
            margin-bottom: 5px;
            margin-top: 15px;
        }

        .rawi-badge {
            display: inline-block;
            padding: 5px 15px;
            background: rgba(201, 166, 107, 0.1);
            color: #b58d4a;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 700;
            margin: 5px;
            border: 1px solid rgba(201, 166, 107, 0.3);
        }

        .qiraat-accordion .accordion-button {
            background-color: #f8fbfa;
            color: var(--primary-color);
            font-weight: bold;
            box-shadow: none !important;
            padding: 1rem;
        }
        
        .qiraat-accordion .accordion-button:not(.collapsed) {
            background-color: rgba(26, 95, 122, 0.1);
            color: var(--primary-color);
        }

        /* --- Section 3: Tajweed --- */
        .tajweed-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 30px;
        }

        .tajweed-box {
            background: white;
            border-radius: 20px;
            padding: 30px;
            text-align: center;
            box-shadow: 0 8px 25px rgba(0,0,0,0.06);
            transition: all 0.4s;
            position: relative;
            overflow: hidden;
            z-index: 1;
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        .tajweed-box::after {
            content: '';
            position: absolute;
            top: -50px;
            right: -50px;
            width: 100px;
            height: 100px;
            background: radial-gradient(circle, rgba(201,166,107,0.2) 0%, rgba(255,255,255,0) 70%);
            border-radius: 50%;
            z-index: -1;
            transition: all 0.4s;
        }

        .tajweed-box:hover {
            transform: translateY(-5px);
        }

        .tajweed-box:hover::after {
            transform: scale(3);
        }

        .tajweed-icon {
            width: 80px;
            height: 80px;
            background: var(--gradient-primary);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2.5rem;
            margin: 0 auto 20px;
            box-shadow: 0 10px 20px rgba(26, 95, 122, 0.2);
        }

        .tajweed-title {
            color: var(--primary-color);
            font-weight: 800;
            margin-bottom: 15px;
            font-size: 1.3rem;
        }

        .tajweed-desc {
            flex-grow: 1;
        }

        /* --- Section 4: Maqamat --- */
        .maqam-card {
            display: flex;
            background: white;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.05);
            margin-bottom: 30px;
            overflow: hidden;
            transition: all 0.3s;
            border: 1px solid rgba(0,0,0,0.03);
            height: 100%;
        }

        .maqam-card:hover {
            box-shadow: 0 15px 40px rgba(26, 95, 122, 0.1);
            transform: translateX(-5px);
        }

        .maqam-visual {
            background: var(--gradient-primary);
            width: 150px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            color: white;
            padding: 20px;
            position: relative;
            text-align: center;
        }

        .maqam-visual::after {
            content: '\\f001';
            font-family: 'Font Awesome 6 Free';
            font-weight: 900;
            position: absolute;
            font-size: 5rem;
            opacity: 0.1;
            right: -10px;
            bottom: -10px;
        }

        .maqam-content {
            padding: 25px;
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .maqam-title {
            font-family: 'Amiri', serif;
            font-size: 1.8rem;
            color: var(--primary-color);
            margin-bottom: 10px;
            font-weight: bold;
        }

        .wave-animation {
            display: flex;
            align-items: center;
            height: 30px;
            gap: 3px;
        }

        .wave-bar {
            width: 4px;
            background: var(--secondary-color);
            border-radius: 2px;
            animation: makeSound 1s infinite alternate;
        }

        @keyframes makeSound {
            0% { height: 5px; }
            100% { height: 25px; }
        }

        .maqam-card:hover .wave-bar:nth-child(1) { animation-delay: 0.1s; }
        .maqam-card:hover .wave-bar:nth-child(2) { animation-delay: 0.2s; }
        .maqam-card:hover .wave-bar:nth-child(3) { animation-delay: 0.3s; }
        .maqam-card:hover .wave-bar:nth-child(4) { animation-delay: 0.4s; }
        .maqam-card:hover .wave-bar:nth-child(5) { animation-delay: 0.5s; }

    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold" href="index.html"><i class="fas fa-book-open me-2 text-warning"></i>الموسوعة الإسلامية الشاملة</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav1">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="nav1">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link " href="index.html">الرئيسية</a></li>
        <li class="nav-item"><a class="nav-link active" href="recitations.html">القرآن والتلاوات</a></li>
        <li class="nav-item"><a class="nav-link " href="hadith.html">الحديث الشريف</a></li>
        <li class="nav-item"><a class="nav-link " href="fiqh.html">الفقه الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="fatwa.html">فتاوى العلماء <i class="fas fa-gavel"></i></a></li>
        <li class="nav-item"><a class="nav-link " href="seerah.html">السيرة والصحابة</a></li>
        <li class="nav-item"><a class="nav-link " href="aqeedah.html">العقيدة الإسلامية</a></li>
        <li class="nav-item"><a class="nav-link " href="history.html">التاريخ الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="library.html">المكتبة الشاملة</a></li>
      </ul>
    </div>
  </div>
</nav>

    <!-- Hero Section -->
    <section class="quran-hero text-center">
        <div class="hero-content container">
            <div class="hero-icon-wrapper">
                <i class="fas fa-quran"></i>
            </div>
            <h1 class="display-4 fw-bold mb-3">أكاديمية علوم القرآن</h1>
            <p class="lead mb-4 mx-auto" style="max-width: 700px; font-size: 1.5rem; line-height: 1.8;">
                «اقْرَأُوا الْقُرْآنَ فَإِنَّهُ يَأْتِي يَوْمَ الْقِيَامَةِ شَفِيعًا لِأَصْحَابِهِ»
            </p>
            <p class="fs-5 opacity-75">المكتبة الصوتية الشاملة، أصول القراءات العشر الكبرى، وأحكام التجويد</p>
        </div>
    </section>

    <div class="container mb-5">
        <!-- Main Tabs Navigation -->
        <ul class="nav academy-tabs" id="academyTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="audio-tab" data-bs-toggle="tab" data-bs-target="#audio-library" type="button" role="tab">
                    <i class="fas fa-headphones-alt"></i> المكتبة الصوتية
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="qiraat-tab" data-bs-toggle="tab" data-bs-target="#qiraat-ten" type="button" role="tab">
                    <i class="fas fa-book-open"></i> القراءات العشر
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="tajweed-tab" data-bs-toggle="tab" data-bs-target="#tajweed-rules" type="button" role="tab">
                    <i class="fas fa-chalkboard-teacher"></i> علوم التجويد
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="maqamat-tab" data-bs-toggle="tab" data-bs-target="#maqamat" type="button" role="tab">
                    <i class="fas fa-microphone-alt"></i> المقامات (صنع بسحر)
                </button>
            </li>
        </ul>

        <!-- Tab Content -->
        <div class="tab-content" id="academyTabContent">
            
            <!-- ===================== 1. AUDIO LIBRARY ===================== -->
            <div class="tab-pane fade show active" id="audio-library" role="tabpanel">
                <div class="section-title-wrapper">
                    <h3>المكتبة الصوتية القرآنية الشاملة</h3>
                    <p class="text-muted mt-2">تصفح واستمع لآلاف التلاوات من كبار القراء بمختلف الروايات</p>
                </div>

                <div class="row">
                    <!-- Reciters Sidebar -->
                    <div class="col-lg-4 mb-4">
                        <div class="card border-0 shadow-sm rounded-4 h-100">
                            <div class="card-header bg-white border-bottom pb-0 pt-4 px-4 border-0">
                                <h5 class="fw-bold text-primary"><i class="fas fa-users me-2"></i>اختر القارئ</h5>
                                <div class="input-group my-3">
                                    <span class="input-group-text bg-light border-end-0"><i class="fas fa-search text-muted"></i></span>
                                    <input type="text" class="form-control bg-light border-start-0 ps-0" placeholder="بحث عن قارئ أو رواية..." id="searchReciter">
                                </div>
                            </div>
                            <div class="card-body p-0">
                                <div class="reciters-list" id="recitersList">
                                    <div class="text-center p-5 text-muted">
                                        <div class="spinner-border text-primary" role="status"></div>
                                        <p class="mt-2">جاري التحميل من الخادم العالمي...</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Player & Surahs -->
                    <div class="col-lg-8">
                        <!-- Player Box -->
                        <div class="audio-player-container">
                            <div class="row align-items-center">
                                <div class="col-md-8 text-center text-md-start">
                                    <h4 id="currentSurahName" class="fw-bold text-primary mb-1">اختر سورة للبدء</h4>
                                    <p id="currentReciterName" class="text-muted mb-0">يرجى اختيار المقرئ ثم السورة</p>
                                    <span class="badge bg-opacity-10 bg-warning text-warning border border-warning mt-2 d-none" id="currentRiwaya">الرواية</span>
                                </div>
                                <div class="col-md-4 mt-3 mt-md-0 d-flex justify-content-center justify-content-md-end">
                                    <div class="player-controls">
                                        <button class="btn-control" id="prevBtn"><i class="fas fa-step-forward"></i></button>
                                        <button class="btn-play-main" id="playPauseBtn"><i class="fas fa-play" id="playIcon"></i></button>
                                        <button class="btn-control" id="nextBtn"><i class="fas fa-step-backward"></i></button>
                                    </div>
                                </div>
                            </div>
                            <!-- Progress Bar -->
                            <div class="audio-progress" id="progressBarContainer">
                                <div class="audio-progress-bar" id="progressBar"></div>
                            </div>
                            <div class="d-flex justify-content-between text-muted small fw-bold">
                                <span id="timeCurrent">00:00</span>
                                <span id="timeTotal">00:00</span>
                            </div>
                            <audio id="mainAudioPlayer"></audio>
                        </div>

                        <!-- Surah Grid -->
                        <div class="card border-0 shadow-sm rounded-4">
                            <div class="card-body p-4">
                                <h5 class="fw-bold text-dark mb-3"><i class="fas fa-list-ol me-2 text-warning"></i>قائمة السور المتاحة للقارئ</h5>
                                <div class="surah-grid" id="surahGrid">
                                    <div class="text-center p-4 text-muted" style="grid-column: 1 / -1;">
                                        اختر قارئاً من القائمة الجانبية لعرض السور المتوفرة له
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ===================== 2. QIRAAT TEN ===================== -->
            <div class="tab-pane fade" id="qiraat-ten" role="tabpanel">
                <div class="section-title-wrapper">
                    <h3>أصول القراءات العشر المتواترة</h3>
                    <p class="text-muted mt-2">تعرف على أئمة القراءة، رواتهم، وثوابت أصولهم التي نقلت إلينا بالتواتر</p>
                </div>

                <div class="row g-4">
                    <!-- Nafi -->
                    <div class="col-lg-6">
                        <div class="qiraat-card p-4">
                            <div class="qiraat-number">01</div>
                            <div class="ps-4">
                                <h4 class="reader-name">الإمام نافع المدني</h4>
                                <p class="text-muted small">إمام أهل المدينة المنورة وأحد الأئمة السبعة، قرأ على سبعين من التابعين.</p>
                                <div class="mb-3">
                                    <span class="rawi-badge">رواية قالون</span>
                                    <span class="rawi-badge">رواية ورش</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Ibn Kathir -->
                    <div class="col-lg-6">
                        <div class="qiraat-card p-4">
                            <div class="qiraat-number">02</div>
                            <div class="ps-4">
                                <h4 class="reader-name">الإمام ابن كثير المكي</h4>
                                <p class="text-muted small">إمام أهل مكة المكرمة، التقى ببعض الصحابة كأنس بن مالك.</p>
                                <div class="mb-3">
                                    <span class="rawi-badge">رواية البزي</span>
                                    <span class="rawi-badge">رواية قنبل</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Abu Amr -->
                    <div class="col-lg-6">
                        <div class="qiraat-card p-4">
                            <div class="qiraat-number">03</div>
                            <div class="ps-4">
                                <h4 class="reader-name">الإمام أبو عمرو البصري</h4>
                                <p class="text-muted small">الإمام المازني البصري، إمام أهل البصرة وأحد أعلم الناس بكتاب الله واللغة.</p>
                                <div class="mb-3">
                                    <span class="rawi-badge">رواية الدُّوري</span>
                                    <span class="rawi-badge">رواية السوسي</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Ibn Amir -->
                    <div class="col-lg-6">
                        <div class="qiraat-card p-4">
                            <div class="qiraat-number">04</div>
                            <div class="ps-4">
                                <h4 class="reader-name">الإمام ابن عامر الشامي</h4>
                                <p class="text-muted small">إمام أهل الشام وقاضي دمشق في عهد الوليد بن عبد الملك، أخذ القراءة عرضاً عن أبي الدرداء.</p>
                                <div class="mb-3">
                                    <span class="rawi-badge">رواية هشام</span>
                                    <span class="rawi-badge">رواية ابن ذكوان</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Asim -->
                    <div class="col-lg-6">
                        <div class="qiraat-card p-4">
                            <div class="qiraat-number">05</div>
                            <div class="ps-4">
                                <h4 class="reader-name">الإمام عاصم الكوفي</h4>
                                <p class="text-muted small">شيخ الإقراء بالكوفة، وصاحب القراءة الأشهر والأكثر انتشاراً في العالم الإسلامي.</p>
                                <div class="mb-3">
                                    <span class="rawi-badge">رواية شعبة</span>
                                    <span class="rawi-badge">رواية حفص</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Hamzah -->
                    <div class="col-lg-6">
                        <div class="qiraat-card p-4">
                            <div class="qiraat-number">06</div>
                            <div class="ps-4">
                                <h4 class="reader-name">الإمام حمزة الكوفي</h4>
                                <p class="text-muted small">الإمام العابد، قال عنه أبو حنيفة: "غلبنا حمزة في القرآن والفرائض".</p>
                                <div class="mb-3">
                                    <span class="rawi-badge">رواية خلف</span>
                                    <span class="rawi-badge">رواية خلاد</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Al-Kisa'i -->
                    <div class="col-lg-6">
                        <div class="qiraat-card p-4">
                            <div class="qiraat-number">07</div>
                            <div class="ps-4">
                                <h4 class="reader-name">الإمام الكسائي الكوفي</h4>
                                <p class="text-muted small">إمام النحاة بالكوفة، قيل عنه: كان إذا قرأ فكأنما يتحدث من جمال قراءته ومراعاته للوقف والابتداء.</p>
                                <div class="mb-3">
                                    <span class="rawi-badge">رواية أبي الحارث</span>
                                    <span class="rawi-badge">رواية الدُّوري</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Abu Ja'far -->
                    <div class="col-lg-6">
                        <div class="qiraat-card p-4">
                            <div class="qiraat-number">08</div>
                            <div class="ps-4">
                                <h4 class="reader-name">الإمام أبو جعفر المدني</h4>
                                <p class="text-muted small">إمام القراء بالمدينة قبل عهد الإمام نافع وهو من التابعين واسمه يزيد بن القعقاع.</p>
                                <div class="mb-3">
                                    <span class="rawi-badge">رواية ابن وردان</span>
                                    <span class="rawi-badge">رواية ابن جماز</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Ya'qub -->
                    <div class="col-lg-6">
                        <div class="qiraat-card p-4">
                            <div class="qiraat-number">09</div>
                            <div class="ps-4">
                                <h4 class="reader-name">الإمام يعقوب الحضرمي</h4>
                                <p class="text-muted small">إمام أهل البصرة في القراءة بعد الإمام أبي عمرو بن العلاء المازني.</p>
                                <div class="mb-3">
                                    <span class="rawi-badge">رواية رويس</span>
                                    <span class="rawi-badge">رواية رَوْح</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Khalaf -->
                    <div class="col-lg-6">
                        <div class="qiraat-card p-4">
                            <div class="qiraat-number">10</div>
                            <div class="ps-4">
                                <h4 class="reader-name">الإمام خلف العاشر</h4>
                                <p class="text-muted small">هو خلف بن هشام البزار، كان أحد رواة الإمام حمزة لكنه اختار لنفسه قراءة خالده فصار الإمام العاشر.</p>
                                <div class="mb-3">
                                    <span class="rawi-badge">رواية إدريس</span>
                                    <span class="rawi-badge">رواية إسحاق</span>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <!-- ===================== 3. TAJWEED RULES ===================== -->
            <div class="tab-pane fade" id="tajweed-rules" role="tabpanel">
                <div class="section-title-wrapper">
                    <h3>أحكام التجويد الشاملة</h3>
                    <p class="text-muted mt-2">عِلْمٌ يُعْرَفُ بِهِ إِعْطَاءُ كُلِّ حَرْفٍ حَقَّهُ وَمُسْتَحَقَّهُ مِنَ الصِّفَاتِ</p>
                </div>

                <div class="tajweed-grid">
                    <!-- Rule 1 -->
                    <div class="tajweed-box">
                        <div class="tajweed-icon"><i class="fas fa-sign-language"></i></div>
                        <h4 class="tajweed-title">مخارج الحروف</h4>
                        <p class="text-muted small tajweed-desc">محل خروج الحرف المتميز به عن غيره. وتنقسم إلى 5 مخارج عامة: الجوف، الحلق، اللسان، الشفتان، الخيشوم.</p>
                    </div>

                    <!-- Rule 2 -->
                    <div class="tajweed-box">
                        <div class="tajweed-icon" style="background: linear-gradient(135deg, #e67e22 0%, #f39c12 100%);"><i class="fas fa-language"></i></div>
                        <h4 class="tajweed-title text-warning">أحكام النون الساكنة</h4>
                        <p class="text-muted small tajweed-desc">لها أربعة أحكام عند التقائها بحروف الهجاء: الإظهار الحلقي، الإدغام (بغنّة وبغير غنّة)، الإقلاب، والإخفاء الحقيقي.</p>
                    </div>

                    <!-- Rule 3 -->
                    <div class="tajweed-box">
                        <div class="tajweed-icon" style="background: linear-gradient(135deg, #16a085 0%, #1abc9c 100%);"><i class="fas fa-wave-square"></i></div>
                        <h4 class="tajweed-title" style="color: #16a085">أحكام الميم الساكنة</h4>
                        <p class="text-muted small tajweed-desc">لها ثلاثة أحكام فقط: الإخفاء الشفوي (عند حرف الباء)، الإدغام الشفوي (عند حرف الميم)، والإظهار الشفوي (عند باقي الحروف).</p>
                    </div>

                    <!-- Rule 4 -->
                    <div class="tajweed-box">
                        <div class="tajweed-icon" style="background: linear-gradient(135deg, #8e44ad 0%, #9b59b6 100%);"><i class="fas fa-ruler-horizontal"></i></div>
                        <h4 class="tajweed-title" style="color: #8e44ad">أحكام المدود</h4>
                        <p class="text-muted small tajweed-desc">إطالة الصوت بحرف المد. وينقسم إلى طبيعي وفرعي (كمدصل ومنفصل وبدل وعارض للسكون).</p>
                    </div>

                    <!-- Rule 5 -->
                    <div class="tajweed-box">
                        <div class="tajweed-icon" style="background: linear-gradient(135deg, #d35400 0%, #e67e22 100%);"><i class="fas fa-hammer"></i></div>
                        <h4 class="tajweed-title" style="color: #d35400">القلقلة</h4>
                        <p class="text-muted small tajweed-desc">اضطراب مخرج الحرف عند النطق به ساكناً حتى يُسمَع له نبرة قوية. حروفها (قطب جد) وتنقسم لصغرى وكبرى.</p>
                    </div>

                    <!-- Rule 6 -->
                    <div class="tajweed-box">
                        <div class="tajweed-icon" style="background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);"><i class="fas fa-balance-scale-left"></i></div>
                        <h4 class="tajweed-title" style="color: #2c3e50">التفخيم والترقيق</h4>
                        <p class="text-muted small tajweed-desc">التفخيم تسمين الحرف (حروف الاستعلاء: خص ضغط قظ)، والترقيق تنحيفه (باقي الحروف إلا ما استثني كالراء واللام).</p>
                    </div>

                    <!-- Rule 7 -->
                    <div class="tajweed-box">
                        <div class="tajweed-icon" style="background: linear-gradient(135deg, #c0392b 0%, #e74c3c 100%);"><i class="fas fa-copyright"></i></div>
                        <h4 class="tajweed-title" style="color: #c0392b">أحكام الراء</h4>
                        <p class="text-muted small tajweed-desc">حرف الراء له حالات للتفخيم (إذا كانت مفتوحة أو مضمومة) وحالات للترقيق (إذا كانت مكسورة) وحالات يجوز فيها الوجهان.</p>
                    </div>

                    <!-- Rule 8 -->
                    <div class="tajweed-box">
                        <div class="tajweed-icon" style="background: var(--gradient-gold);"><i class="fas fa-pause-circle"></i></div>
                        <h4 class="tajweed-title text-warning">الوقف والابتداء</h4>
                        <p class="text-muted small tajweed-desc">قطع الصوت على الكلمة القرآنية زمناً يتنفس فيه القارئ عادة. من أهم علوم التجويد للحفاظ على المعاني وعدم الإخلال بها.</p>
                    </div>
                </div>
            </div>

            <!-- ===================== 4. MAQAMAT ===================== -->
            <div class="tab-pane fade" id="maqamat" role="tabpanel">
                <div class="section-title-wrapper">
                    <h3>المقامات القرآنية (صنع بسحر)</h3>
                    <p class="text-muted mt-2">السبع مقامات الأساسية التي يستخدمها القراء لتصوير معاني القرآن الكريم</p>
                </div>

                <div class="row">
                    <div class="col-12 mb-4">
                        <div class="alert alert-info border-0 shadow-sm rounded-4 text-center">
                            <i class="fas fa-info-circle fa-2x mb-2 d-block"></i>
                            <strong>ملاحظة:</strong> المقامات القرآنية مجموعة في كلمة (صُنِعَ بِسَحَر). هي أداة لتجميل التلاوة وتصوير الآيات لا تؤثر على أحكام التجويد متى التزم بها القارئ الحاذق.
                        </div>
                    </div>

                    <!-- 1. Saba (ص) -->
                    <div class="col-md-6">
                        <div class="maqam-card">
                            <div class="maqam-visual" style="background: #1a5f7a;">
                                <i class="fas fa-hand-holding-heart fa-2x mb-2"></i>
                                <span class="fw-bold fs-3">صَ</span>
                                <span>مقام الصَبا</span>
                            </div>
                            <div class="maqam-content">
                                <h4 class="maqam-title" style="color: #1a5f7a;">مقام الحزن والشجن</h4>
                                <p class="text-muted small mb-3">يمتاز بالروحانية العالية والحزن العميق. يُقرأ به عادة في آيات العذاب والوعيد وتذكر الموت ويوم القيامة.</p>
                                <div class="wave-animation">
                                    <div class="wave-bar bg-dark opacity-50"></div><div class="wave-bar bg-dark opacity-50"></div><div class="wave-bar bg-dark opacity-50"></div><div class="wave-bar bg-dark opacity-50"></div><div class="wave-bar bg-dark opacity-50"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- 2. Nahawand (ن) -->
                    <div class="col-md-6">
                        <div class="maqam-card">
                            <div class="maqam-visual bg-success">
                                <i class="fas fa-leaf fa-2x mb-2"></i>
                                <span class="fw-bold fs-3">نـ</span>
                                <span>مقام النَهاوَند</span>
                            </div>
                            <div class="maqam-content">
                                <h4 class="maqam-title" style="color: #198754;">مقام العاطفة والرقة</h4>
                                <p class="text-muted small mb-3">يبعث على الهدوء والتأمل. يُقرأ به كثيراً في آيات الجنة والرحمة والقصص القرآني لرقته وعذوبته.</p>
                                <div class="wave-animation">
                                    <div class="wave-bar bg-success opacity-50"></div><div class="wave-bar bg-success opacity-50"></div><div class="wave-bar bg-success opacity-50"></div><div class="wave-bar bg-success opacity-50"></div><div class="wave-bar bg-success opacity-50"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- 3. Ajam (ع) -->
                    <div class="col-md-6">
                        <div class="maqam-card">
                            <div class="maqam-visual" style="background: #8e44ad;">
                                <i class="fas fa-fist-raised fa-2x mb-2"></i>
                                <span class="fw-bold fs-3">عـ</span>
                                <span>مقام العَجَم</span>
                            </div>
                            <div class="maqam-content">
                                <h4 class="maqam-title" style="color: #8e44ad;">مقام القوة والوضوح</h4>
                                <p class="text-muted small mb-3">مقام يمتاز بالقوة والعظمة. يُقرأ به في الآيات التي تتحدث عن خلق السموات والأرض والأنبياء ذوي العزم.</p>
                                <div class="wave-animation">
                                    <div class="wave-bar opacity-50" style="background: #8e44ad;"></div><div class="wave-bar opacity-50" style="background: #8e44ad;"></div><div class="wave-bar opacity-50" style="background: #8e44ad;"></div><div class="wave-bar opacity-50" style="background: #8e44ad;"></div><div class="wave-bar opacity-50" style="background: #8e44ad;"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- 4. Bayati (ب) -->
                    <div class="col-md-6">
                        <div class="maqam-card">
                            <div class="maqam-visual" style="background: #3498db;">
                                <i class="fas fa-water fa-2x mb-2"></i>
                                <span class="fw-bold fs-3">بـ</span>
                                <span>مقام البَياتي</span>
                            </div>
                            <div class="maqam-content">
                                <h4 class="maqam-title" style="color: #3498db;">أم المقامات (المرونة)</h4>
                                <p class="text-muted small mb-3">من أوسع المقامات استخداماً لمرونته وتعدد طبقاته. يبعث على الشوق والسكينة ويُقرأ به في معظم الآيات الحرة.</p>
                                <div class="wave-animation">
                                    <div class="wave-bar opacity-50" style="background: #3498db;"></div><div class="wave-bar opacity-50" style="background: #3498db;"></div><div class="wave-bar opacity-50" style="background: #3498db;"></div><div class="wave-bar opacity-50" style="background: #3498db;"></div><div class="wave-bar opacity-50" style="background: #3498db;"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- 5. Sikah (س) -->
                    <div class="col-md-6">
                        <div class="maqam-card">
                            <div class="maqam-visual" style="background: #e67e22;">
                                <i class="fas fa-kaaba fa-2x mb-2"></i>
                                <span class="fw-bold fs-3">سـ</span>
                                <span>مقام السِيكاه</span>
                            </div>
                            <div class="maqam-content">
                                <h4 class="maqam-title" style="color: #e67e22;">مقام الروحانية القديمة</h4>
                                <p class="text-muted small mb-3">مقام شرقي أصيل وبطيء الإيقاع يعبر عن التضرع والمناجاة. يستخدمه القراء بكثرة في مواضع الدعاء والمغفرة.</p>
                                <div class="wave-animation">
                                    <div class="wave-bar opacity-50" style="background: #e67e22;"></div><div class="wave-bar opacity-50" style="background: #e67e22;"></div><div class="wave-bar opacity-50" style="background: #e67e22;"></div><div class="wave-bar opacity-50" style="background: #e67e22;"></div><div class="wave-bar opacity-50" style="background: #e67e22;"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- 6. Hijaz (ح) -->
                    <div class="col-md-6">
                        <div class="maqam-card">
                            <div class="maqam-visual bg-danger">
                                <i class="fas fa-fire fa-2x mb-2"></i>
                                <span class="fw-bold fs-3">حـ</span>
                                <span>مقام الحِجاز</span>
                            </div>
                            <div class="maqam-content">
                                <h4 class="maqam-title text-danger">مقام الأنين والصحراء</h4>
                                <p class="text-muted small mb-3">مقام عربي نابع من أرض الحجاز. يُقرأ به أذان الحرم المكي، ويبعث على الرهبة والشوق إلى الديار المقدسة.</p>
                                <div class="wave-animation">
                                    <div class="wave-bar bg-danger opacity-50"></div><div class="wave-bar bg-danger opacity-50"></div><div class="wave-bar bg-danger opacity-50"></div><div class="wave-bar bg-danger opacity-50"></div><div class="wave-bar bg-danger opacity-50"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- 7. Rast (ر) -->
                    <div class="col-md-6">
                        <div class="maqam-card">
                            <div class="maqam-visual bg-warning text-dark">
                                <i class="fas fa-crown fa-2x mb-2"></i>
                                <span class="fw-bold fs-3" style="color: #fff; mix-blend-mode: difference;">ر</span>
                                <span style="color: #fff; mix-blend-mode: difference;">مقام الرَسْت</span>
                            </div>
                            <div class="maqam-content">
                                <h4 class="maqam-title text-warning text-darken" style="color: #b38600;">سيد المقامات (الاستقامة)</h4>
                                <p class="text-muted small mb-3">كلمة فارسية تعني الاستقامة. مقام يمتاز بالفخامة والوقار ويستخدم في الآيات التي تتحدث عن التشريع والأحكام.</p>
                                <div class="wave-animation">
                                    <div class="wave-bar bg-warning opacity-50"></div><div class="wave-bar bg-warning opacity-50"></div><div class="wave-bar bg-warning opacity-50"></div><div class="wave-bar bg-warning opacity-50"></div><div class="wave-bar bg-warning opacity-50"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>

    <!-- Footer -->
    <footer class="mega-footer" style="background:linear-gradient(135deg,var(--dark),#020617);color:white;padding:80px 0 30px;margin-top:80px;border-top:3px solid var(--gold-dark);">
  <div class="container">
    <div class="row g-5 mb-5 border-bottom border-light border-opacity-10 pb-5">
      <div class="col-lg-4 text-md-end text-center">
        <i class="fas fa-mosque fa-4x text-warning mb-4 d-block"></i>
        <h4 class="fw-bold font-amiri fs-2 mb-3">الموسوعة الإسلامية الشاملة</h4>
        <p class="opacity-75 fs-6 line-height-2">أضخم صرح رقمي يجمع علوم القرآن العظيم، وأحاديث المصطفى، وفقهاء المذاهب، والتاريخ المجيد في منصة موثقة مصممة بأحدث التقنيات.</p>
      </div>
      <div class="col-lg-4 text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">تصفح الموسوعة</h5>
        <div class="d-flex flex-wrap justify-content-center gap-2">
          <a href="recitations.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">أكاديمية القرآن</a>
          <a href="hadith.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الحديث النبوي</a>
          <a href="seerah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">السيرة والصحابة</a>
          <a href="fiqh.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الفقه وأصوله</a>
          <a href="fatwa.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">فتاوى العلماء</a>
          <a href="aqeedah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">العقيدة الإسلامية</a>
          <a href="history.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">التاريخ المجيد</a>
          <a href="library.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">المكتبة الشاملة</a>
        </div>
      </div>
      <div class="col-lg-4 text-md-start text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">روابط سريعة</h5>
        <a href="contact.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> اتصل بالمطور</a>
        <a href="share.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> شارك الأجر</a>
        <a href="login.html" class="mega-footer-link text-warning mt-3" style="text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-user-circle me-2 ms-1"></i> تسجيل الدخول</a>
      </div>
    </div>
    <div class="text-center font-amiri fs-5 d-flex flex-column gap-2">
      <span class="opacity-75">الموسوعة الإسلامية الشاملة &copy; 2026 تم التصميم للإفادة | عمل مجاني لوجه الله</span>
      <span class="text-warning fw-bold fs-4 mt-2">تصميم وتطوير: لخذاري محمد سيف الدين</span>
    </div>
  </div>
</footer>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="recitations.js"></script>
</body>
</html>"""

with codecs.open(file_path, 'w', 'utf-8') as f:
    f.write(html_content)

print("Updated Qiraat, Tajweed, and Maqamat completely!")
