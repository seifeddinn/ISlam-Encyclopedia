import codecs

css = """<style>
:root{--gold:#c9a66b;--gold2:#e8d5a3;--dark:#021a24;--cyan:#064b63;--cyan2:#05708a;}
body{font-family:'Cairo',sans-serif;background:#f0f6f8;color:#1c2528;overflow-x:hidden;}
h1,h2,h3,h4,.ar{font-family:'Amiri',serif;}
/* HERO */
.rec-hero{min-height:560px;background:linear-gradient(160deg,#01121a 0%,#064b63 45%,#05708a 100%);position:relative;overflow:hidden;display:flex;align-items:center;padding:80px 0;}
.orb{position:absolute;border-radius:50%;filter:blur(90px);opacity:.25;animation:orb 12s infinite alternate;}
.orb:nth-child(1){width:450px;height:450px;background:#c9a66b;top:-100px;right:-100px;}
.orb:nth-child(2){width:300px;height:300px;background:#1abc9c;bottom:-80px;left:5%;animation-delay:4s;}
@keyframes orb{from{transform:scale(1) translate(0,0)}to{transform:scale(1.2) translate(25px,25px)}}
.hero-pattern{position:absolute;inset:0;background:url('https://www.transparenttextures.com/patterns/arabesque.png');opacity:.1;}
.hero-content{position:relative;z-index:5;color:white;}
.hero-eyebrow{display:inline-block;border:1px solid rgba(201,166,107,.4);background:rgba(201,166,107,.1);backdrop-filter:blur(10px);color:var(--gold2);border-radius:40px;padding:8px 24px;font-size:.85rem;font-weight:700;margin-bottom:20px;}
.hero h1{font-size:3.5rem;font-weight:bold;margin-bottom:12px;background:linear-gradient(135deg,#fff 30%,var(--gold2) 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;line-height:1.3;}
.tagline{color:rgba(255,255,255,.7);font-size:1.1rem;margin-bottom:35px;line-height:2;}
.hero-quote{background:rgba(255,255,255,.06);border:1px solid rgba(201,166,107,.2);border-right:4px solid var(--gold);border-radius:16px;padding:22px 26px;max-width:680px;backdrop-filter:blur(12px);}
.hero-quote p{font-family:'Amiri',serif;font-size:1.4rem;line-height:2;color:white;margin:0;}
/* STATS */
.stats-strip{background:linear-gradient(90deg,#064b63,#05708a);padding:22px 0;border-top:1px solid rgba(255,255,255,0.05);}
.stat-item{text-align:center;color:white;padding:8px;}
.stat-num{font-size:2.3rem;font-weight:800;color:var(--gold2);font-family:'Amiri',serif;line-height:1;}
.stat-label{font-size:.75rem;opacity:.6;margin-top:5px;}
/* TABS */
.sec-tabs{background:white;border-radius:60px;padding:8px;box-shadow:0 10px 40px rgba(6,75,99,.08);margin:45px 0 40px;display:flex;overflow-x:auto;border:1px solid rgba(6,75,99,.05);}
.sec-tabs::-webkit-scrollbar{height:0;}
.sec-tabs .nav-item{flex:1;min-width:130px;}
.sec-tabs .nav-link{border:none;border-radius:50px;color:#555;font-weight:700;padding:14px 12px;width:100%;text-align:center;transition:all .35s;white-space:nowrap;font-size:.9rem;}
.sec-tabs .nav-link.active{background:linear-gradient(135deg,#064b63,#05708a);color:white;box-shadow:0 8px 20px rgba(6,75,99,.3);}
/* SEC HEAD */
.sec-head{text-align:center;margin-bottom:45px;}
.sec-head .tag{display:inline-block;background:rgba(6,75,99,.08);color:var(--cyan);border-radius:40px;padding:6px 20px;font-size:.82rem;font-weight:700;margin-bottom:15px;}
.sec-head h3{font-size:2.2rem;color:#064b63;font-weight:700;margin-bottom:8px;}
.sec-head h3 span{color:var(--gold);}
.sec-head p{color:#666;max-width:620px;margin:0 auto;}
.sec-head .divider{width:60px;height:4px;background:linear-gradient(90deg,var(--gold),var(--gold2));border-radius:2px;margin:15px auto 0;}
/* QURAN SURAH CARD */
.surah-card{background:white;border-radius:15px;padding:15px;display:flex;align-items:center;box-shadow:0 5px 15px rgba(0,0,0,.04);transition:.3s;border:1px solid rgba(0,0,0,.03);cursor:pointer;position:relative;}
.surah-card:hover{transform:translateY(-4px);box-shadow:0 12px 25px rgba(6,75,99,.1);border-color:var(--gold);}
.surah-num{width:45px;height:45px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.2rem;font-weight:bold;color:var(--cyan);background:rgba(6,75,99,.08);margin-left:15px;position:relative;}
.surah-card h5{margin:0;font-size:1.4rem;font-family:'Amiri',serif;margin-bottom:4px;}
.surah-card span{font-size:.7rem;color:#777;display:block;}
.btn-play-s{position:absolute;left:15px;top:50%;transform:translateY(-50%);background:var(--cyan);color:white;width:35px;height:35px;border-radius:50%;display:flex;align-items:center;justify-content:center;border:none;opacity:0;transition:.3s;}
.surah-card:hover .btn-play-s{opacity:1;}
/* RECITATIONS CARDS */
.qiraat-card{background:white;border-radius:20px;padding:25px;box-shadow:0 8px 25px rgba(6,75,99,.06);transition:.3s;height:100%;border-top:3px solid var(--gold);}
.qiraat-card:hover{transform:translateY(-5px);}
.qiraat-icon{width:55px;height:55px;border-radius:14px;background:linear-gradient(135deg,#064b63,#05708a);display:flex;align-items:center;justify-content:center;font-size:1.5rem;color:var(--gold2);margin-bottom:15px;}
/* QURA CARDS */
.reciter-card{background:white;border-radius:15px;overflow:hidden;box-shadow:0 8px 25px rgba(0,0,0,.06);transition:.3s;text-align:center;}
.reciter-card:hover{transform:translateY(-5px);box-shadow:0 12px 30px rgba(6,75,99,.15);}
.r-img{width:100%;height:140px;background:rgba(6,75,99,.08);display:flex;align-items:center;justify-content:center;font-size:3rem;color:var(--cyan);}
.r-body{padding:20px;}
/* GLOBAL PLAYER */
.global-player{position:fixed;bottom:0;left:0;right:0;background:rgba(2,26,36,0.95);backdrop-filter:blur(20px);border-top:1px solid rgba(201,166,107,.3);padding:15px 0;z-index:1050;transform:translateY(100%);transition:.4s cubic-bezier(0.175,0.885,0.32,1.275);}
.global-player.active{transform:translateY(0);}
/* QURAN READER MODAL */
.quran-reader{font-family:'Amiri',serif;font-size:2rem;line-height:2.2;text-align:center;padding:20px;}
.quran-reader span.verse{display:inline;position:relative;}
.quran-reader span.v-num{display:inline-flex;align-items:center;justify-content:center;width:35px;height:35px;background:url('https://upload.wikimedia.org/wikipedia/commons/e/e4/Aya_symbol.svg') no-repeat center center;background-size:contain;font-size:1rem;color:var(--cyan);margin:0 10px;vertical-align:middle;}
</style>"""

part1 = """<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>أكاديمية القرآن والمصحف الشريف - الموسوعة الإسلامية</title>
<link href="https://fonts.googleapis.com/css2?family=Amiri:ital,wght@0,400;0,700;1,400&family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
""" + css + """
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold" href="index.html"><i class="fas fa-book-open me-2 text-warning"></i>الموسوعة الإسلامية الشاملة</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav1">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="nav1">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link " href="index.html">الرئيسية</a></li>
        <li class="nav-item"><a class="nav-link " href="recitations.html">القرآن والتلاوات</a></li>
        <li class="nav-item"><a class="nav-link " href="hadith.html">الحديث الشريف</a></li>
        <li class="nav-item"><a class="nav-link " href="fiqh.html">الفقه الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="fatwa.html">فتاوى العلماء <i class="fas fa-gavel"></i></a></li>
        <li class="nav-item"><a class="nav-link " href="seerah.html">السيرة والصحابة</a></li>
        <li class="nav-item"><a class="nav-link " href="aqeedah.html">العقيدة الإسلامية</a></li>
        <li class="nav-item"><a class="nav-link " href="history.html">التاريخ الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="library.html">المكتبة الشاملة</a></li>
      </ul>
    </div>
  </div>
</nav>

<section class="rec-hero">
  <div class="orb"></div><div class="orb"></div>
  <div class="hero-pattern"></div>
  <div class="container hero-content">
    <div class="row align-items-center g-5">
      <div class="col-lg-7">
        <div class="hero-eyebrow"><i class="fas fa-quran me-2"></i>أكاديمية القرآن المجيد</div>
        <h1>المصحف الشريف<br>وعلوم التلاوة</h1>
        <p class="tagline">اقرأ، استمع، وتدبر. مكتبة متكاملة للمصحف الشريف بجميع السور، مع القراءات العشر المتواترة، وأحكام التجويد، وتلاوات خاشعة لأشهر القراء.</p>
        <div class="hero-quote">
          <p>«خَيْرُكُمْ مَنْ تَعَلَّمَ الْقُرْآنَ وَعَلَّمَهُ»</p>
          <small>— رواه البخاري</small>
        </div>
      </div>
      <div class="col-lg-5 d-none d-lg-block text-center">
        <div style="position:relative;width:300px;height:300px;margin:0 auto;">
          <div style="position:absolute;inset:0;border-radius:50%;border:2px solid rgba(201,166,107,.2);animation:spin 30s linear infinite;"></div>
          <div style="position:absolute;inset:20px;border-radius:50%;border:1px dashed rgba(201,166,107,.3);animation:spin 20s linear infinite reverse;"></div>
          <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;">
             <i class="fas fa-book-reader" style="font-size:6rem;color:var(--gold);opacity:.9;filter:drop-shadow(0 0 20px rgba(201,166,107,.5));"></i>
          </div>
          <div style="position:absolute;bottom:-10px;left:50%;transform:translateX(-50%);background:rgba(201,166,107,.15);border:1px solid rgba(201,166,107,.3);border-radius:20px;padding:6px 18px;font-size:.8rem;color:var(--gold2);white-space:nowrap;backdrop-filter:blur(8px);font-weight:bold;">القرآن نور وهدى</div>
        </div>
      </div>
    </div>
  </div>
</section>

<div class="stats-strip">
  <div class="container">
    <div class="row text-center g-0">
      <div class="col-4 col-md-2 stat-item border-end border-white border-opacity-25"><div class="stat-num">114</div><div class="stat-label">سورة</div></div>
      <div class="col-4 col-md-2 stat-item border-end border-white border-opacity-25"><div class="stat-num">30</div><div class="stat-label">جزءاً</div></div>
      <div class="col-4 col-md-2 stat-item border-end border-white border-opacity-25"><div class="stat-num">6236</div><div class="stat-label">أية كريمة</div></div>
      <div class="col-4 col-md-2 stat-item border-end border-white border-opacity-25"><div class="stat-num">10</div><div class="stat-label">قراءات متواترة</div></div>
      <div class="col-4 col-md-2 stat-item border-end border-white border-opacity-25"><div class="stat-num">20</div><div class="stat-label">رواية صحيحة</div></div>
      <div class="col-4 col-md-2 stat-item"><div class="stat-num">∞</div><div class="stat-label">أجر يتضاعف</div></div>
    </div>
  </div>
</div>

<div class="container mb-5">
<ul class="nav sec-tabs" id="rTabs" role="tablist">
  <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#t-quran"><i class="fas fa-quran me-1"></i>المصحف الشريف</button></li>
  <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t-10"><i class="fas fa-book-open me-1"></i>القراءات العشر</button></li>
  <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t-qura"><i class="fas fa-headphones me-1"></i>أشهر القراء</button></li>
  <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t-tajweed"><i class="fas fa-star me-1"></i>علوم التجويد</button></li>
</ul>

<div class="tab-content">
<!-- TAB 1: QURAN -->
<div class="tab-pane fade show active" id="t-quran">
  <div class="sec-head">
    <span class="tag">كتاب الله المكنون</span>
    <h3>المصحف <span>الشريف</span></h3>
    <p>تصفح سور القرآن الكريم، اقرأها بالتشكيل الكامل، واستمع للتلاوة</p>
    <div class="divider"></div>
  </div>
  
  <div class="row mb-5 justify-content-center">
    <div class="col-lg-8">
      <div class="d-flex gap-2 p-3 bg-white rounded-4 shadow-sm align-items-center">
        <i class="fas fa-search text-muted ms-2"></i>
        <input type="text" id="quickSurahSearch" class="form-control border-0 shadow-none" placeholder="ابحث عن سورة (مثال: الكهف، البقرة...)">
        <div class="btn-group" id="surahFilters" role="group">
          <button type="button" class="btn btn-outline-primary active" data-filter="all">الكل</button>
          <button type="button" class="btn btn-outline-primary" data-filter="meccan">مكية</button>
          <button type="button" class="btn btn-outline-primary" data-filter="medinan">مدنية</button>
        </div>
      </div>
    </div>
  </div>

  <div class="row g-3" id="surah-list">
    <!-- Will be injected by quran-script.js -->
  </div>
</div>
"""

with codecs.open(r"C:\Users\ST\Desktop\islamic.encyclopedia\rec_p1.tmp", 'w', 'utf-8') as f:
    f.write(part1)
print("recitations part 1 ready")
