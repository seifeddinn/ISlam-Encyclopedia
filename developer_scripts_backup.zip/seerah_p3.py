import codecs
f = codecs.open("seerah.html","a","utf-8")
f.write("""
<!-- TAB 1: TIMELINE -->
<div class="tab-pane fade show active" id="t1">
  <div class="sec-head" data-aos="fade-up">
    <div class="badge-tag">من المولد إلى الرفيق الأعلى</div>
    <h2 class="amiri">التسلسل الزمني <span>للسيرة الطاهرة</span></h2>
    <p>المحطات الكبرى في حياة النبي الكريم صلوات الله وسلامه عليه، مرتبةً ترتيباً تاريخياً تفاعلياً.</p>
    <div class="gold-divider"></div>
  </div>
  <div class="seerah-tl">

    <div class="tl-row" data-aos="fade-right">
      <div class="tl-card-wrap"><div class="tl-card"><div class="tl-tag">571م — مكة المكرمة</div><h3><i class="fas fa-star text-warning me-2"></i>المولد الشريف والنشأة الطاهرة</h3><p>وُلد النبي محمد ﷺ يتيماً بمكة المكرمة يوم الاثنين من ربيع الأول في عام الفيل. أرضعته حليمة السعدية في بني سعد، وكفله جده عبد المطلب ثم عمه أبو طالب. عُرف منذ شبابه بـ"الصادق الأمين"، واشتغل بالرعي والتجارة، وتزوج السيدة خديجة رضي الله عنها وهو ابن خمس وعشرين سنة.</p></div></div>
      <div class="tl-center"><span class="tl-dot"></span><span class="tl-year">المولد</span></div>
      <div class="tl-card-wrap"></div>
    </div>

    <div class="tl-row" data-aos="fade-left">
      <div class="tl-card-wrap"></div>
      <div class="tl-center"><span class="tl-dot"></span><span class="tl-year">610م</span></div>
      <div class="tl-card-wrap"><div class="tl-card"><div class="tl-tag">610م — غار حراء</div><h3><i class="fas fa-book-reader text-warning me-2"></i>البعثة النبوية ونزول الوحي</h3><p>نزل جبريل عليه السلام في غار حراء بـ"اقرأ باسم ربك الذي خلق" وبدأ عهد الوحي. بدأت الدعوة سراً ثلاث سنوات ثم جهراً. عانى المسلمون الأوائل التعذيب والحصار في شعب أبي طالب ثلاث سنوات كاملة، وكان على رأسهم بلال وياسر وسمية وخباب وعمار.</p></div></div>
    </div>

    <div class="tl-row" data-aos="fade-right">
      <div class="tl-card-wrap"><div class="tl-card"><div class="tl-tag">619م — عام الأحزان</div><h3><i class="fas fa-cloud text-warning me-2"></i>عام الحزن ووفاة خديجة وأبي طالب</h3><p>في عام واحد فقد النبي ﷺ زوجته الأولى وناصرته خديجة الكبرى، ثم عمه أبو طالب درعه القبلية. فقد أشد السند والنصرة في وقت واحد، حتى سُمي ذاك العام بـ"عام الحزن". ذهب إلى الطائف يبتغي النصرة فرُدَّ بالحجارة، ولم يجد أحداً يجيره حتى أجاره المطعم بن عدي.</p></div></div>
      <div class="tl-center"><span class="tl-dot"></span><span class="tl-year">619م</span></div>
      <div class="tl-card-wrap"></div>
    </div>

    <div class="tl-row" data-aos="fade-left">
      <div class="tl-card-wrap"></div>
      <div class="tl-center"><span class="tl-dot"></span><span class="tl-year">620م</span></div>
      <div class="tl-card-wrap"><div class="tl-card"><div class="tl-tag">620م — تسليةٌ ربانية</div><h3><i class="fas fa-moon text-warning me-2"></i>الإسراء والمعراج</h3><p>بعد عام الأحزان وتهاطل الابتلاءات، أسرى الله بعبده من المسجد الحرام إلى المسجد الأقصى، ثم عُرج به إلى السماوات العُلى. كلّمه ربه تكليماً وأرسل عليه الصلاة والسلام عليه من الرفيق الأعلى وفُرضت الصلوات الخمس. معجزة كونية هي أعظم تشريف في تاريخ البشر.</p></div></div>
    </div>

    <div class="tl-row" data-aos="fade-right">
      <div class="tl-card-wrap"><div class="tl-card"><div class="tl-tag">621-622م — بيعتا العقبة</div><h3><i class="fas fa-handshake text-warning me-2"></i>بيعتا العقبة الأولى والثانية</h3><p>في بيعة العقبة الأولى آمن به بضعة عشر من أهل يثرب وعاهدوه على التوحيد. ثم في الثانية جاءه سبعون رجلاً وامرأتان وبايعوه على المناصرة والدفاع، وقال لهم: "أنتم أصحابي وأنا منكم"، وكانا الأساس الحقيقي لقيام الدولة الإسلامية الأولى.</p></div></div>
      <div class="tl-center"><span class="tl-dot"></span><span class="tl-year">621م</span></div>
      <div class="tl-card-wrap"></div>
    </div>

    <div class="tl-row" data-aos="fade-left">
      <div class="tl-card-wrap"></div>
      <div class="tl-center"><span class="tl-dot"></span><span class="tl-year">1 هـ</span></div>
      <div class="tl-card-wrap"><div class="tl-card"><div class="tl-tag">622م — 1 هجري</div><h3><i class="fas fa-walking text-warning me-2"></i>الهجرة المباركة وتأسيس الدولة</h3><p>خرج مع الصديق أبي بكر خلسةً ليلاً إلى يثرب التي أضاءت بقدومه وأصبحت المدينة المنورة. شيّد المسجد النبوي الجامع، وآخى بين المهاجرين والأنصار مؤاخاةً شهيرةً في التاريخ، وأصدر وثيقة المدينة أول دستور مكتوب في العالم ينظم العلاقة بين مكونات المجتمع الجديد.</p></div></div>
    </div>

    <div class="tl-row" data-aos="fade-right">
      <div class="tl-card-wrap"><div class="tl-card"><div class="tl-tag">6 هـ — صلح الحديبية</div><h3><i class="fas fa-dove text-warning me-2"></i>صلح الحديبية — الفتح المبين</h3><p>خرج النبي ﷺ ومعه ألف وأربعمائة صحابي معتمرين، فصدهم المشركون. عقد صلحاً مع قريش على هدنة عشر سنوات بشروط ظاهرها إجحاف. لكن الله سمّاه "فتحاً مبيناً" لأنه أتاح الفرصة للدعوة وجاء بعده إسلام الآلاف وبيعة الرضوان تحت الشجرة.</p></div></div>
      <div class="tl-center"><span class="tl-dot"></span><span class="tl-year">6 هـ</span></div>
      <div class="tl-card-wrap"></div>
    </div>

    <div class="tl-row" data-aos="fade-left">
      <div class="tl-card-wrap"></div>
      <div class="tl-center"><span class="tl-dot"></span><span class="tl-year">8 هـ</span></div>
      <div class="tl-card-wrap"><div class="tl-card"><div class="tl-tag">8 هـ — مكة المكرمة</div><h3><i class="fas fa-kaaba text-warning me-2"></i>الفتح الأعظم لمكة المكرمة</h3><p>دخل النبي ﷺ مكة فاتحاً منتصراً، مُطأطئَ الرأس شكراً وتواضعاً لله، يردد سورة الفتح. طاف بالبيت وحطّم الأصنام، ثم جمع أهل مكة وقال لهم: "يا معشر قريش، ما تظنون أني فاعلٌ بكم؟ اذهبوا فأنتم الطلقاء". كان فتحاً بلا سفك دماء يُعجز التاريخ عن مثيله.</p></div></div>
    </div>

    <div class="tl-row" data-aos="fade-right">
      <div class="tl-card-wrap"><div class="tl-card"><div class="tl-tag">9 هـ — العسرة</div><h3><i class="fas fa-thermometer-full text-warning me-2"></i>غزوة تبوك — آخر الغزوات الكبرى</h3><p>خرج ﷺ في حر الصيف الشديد بثلاثين ألف مقاتل لمواجهة الروم البيزنطيين المحتشدين على الحدود الشامية. سُمي جيشه بـ"جيش العسرة" لشدة الضائقة الاقتصادية. بلغ تبوك فلم يلقَ قتالاً وعقد معاهدات سلام مع أهل دَوْمة الجندل وأيلة، ثم عاد منتصراً دون قتال.</p></div></div>
      <div class="tl-center"><span class="tl-dot"></span><span class="tl-year">9 هـ</span></div>
      <div class="tl-card-wrap"></div>
    </div>

    <div class="tl-row" data-aos="fade-left">
      <div class="tl-card-wrap"></div>
      <div class="tl-center"><span class="tl-dot"></span><span class="tl-year">10 هـ</span></div>
      <div class="tl-card-wrap"><div class="tl-card"><div class="tl-tag">10 هـ — حجة الوداع</div><h3><i class="fas fa-people-arrows text-warning me-2"></i>حجة الوداع وخطبة الحقوق</h3><p>حج النبي ﷺ حجته الوحيدة وألقى خطبة الوداع الخالدة أمام أكثر من مئة ألف صحابي: "أيها الناس، إن دماءكم وأموالكم وأعراضكم حرام..." — أول ميثاق لحقوق الإنسان في التاريخ. ونزلت: ﴿الْيَوْمَ أَكْمَلْتُ لَكُمْ دِينَكُمْ﴾.</p></div></div>
    </div>

    <div class="tl-row" data-aos="fade-right">
      <div class="tl-card-wrap"><div class="tl-card"><div class="tl-tag">11 هـ — الرحيل الأخير</div><h3><i class="fas fa-moon text-warning me-2"></i>الانتقال إلى الرفيق الأعلى</h3><p>بعد مرض دام أيانا، صعدت روحه الطاهرة ﷺ إلى بارئها ضحنى يوم الاثنين 12 ربيع الأول، في حجرة زوجته عائشة رضي الله عنها التي وضع رأسه على صدرها لحظة الوفاة، ودُفن في مكانه تحت الحجرة الشريفة ملاصقةً للمسجد النبوي.</p></div></div>
      <div class="tl-center"><span class="tl-dot"></span><span class="tl-year">11 هـ</span></div>
      <div class="tl-card-wrap"></div>
    </div>

  </div>
</div><!-- end t1 -->
""")
f.close()
print("Part 3 done")
