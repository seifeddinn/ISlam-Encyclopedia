import os
import re
import codecs

# Files to delete
files_to_delete = ['quran.html', 'sahaba.html', 'scholars.html']
for fd in files_to_delete:
    path = os.path.join(r"C:\Users\ST\Desktop\islamic.encyclopedia", fd)
    if os.path.exists(path):
        os.remove(path)
        print("Deleted:", fd)

# The standard inner UL for the navbar
new_ul = """<ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link" href="index.html">الرئيسية</a></li>
        <li class="nav-item"><a class="nav-link" href="recitations.html">القرآن والتلاوات</a></li>
        <li class="nav-item"><a class="nav-link" href="hadith.html">الحديث الشريف</a></li>
        <li class="nav-item"><a class="nav-link" href="fiqh.html">الفقه الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link" href="seerah.html">السيرة والصحابة</a></li>
        <li class="nav-item"><a class="nav-link" href="aqeedah.html">العقيدة الإسلامية</a></li>
        <li class="nav-item"><a class="nav-link" href="history.html">التاريخ الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link" href="library.html" style="color:var(--gold)!important;">المكتبة الشاملة <i class="fas fa-book-reader"></i></a></li>
      </ul>"""

# Iterate over all HTML files
DIR = r"C:\Users\ST\Desktop\islamic.encyclopedia"
for filename in os.listdir(DIR):
    if filename.endswith(".html"):
        filepath = os.path.join(DIR, filename)
        with codecs.open(filepath, 'r', 'utf-8') as f:
            content = f.read()
        
        # Replace the <ul class="navbar-nav ..."> ... </ul> with the new one
        # Note: In some files it could be <ul class="navbar-nav me-auto mb-2 mb-lg-0"> or similar,
        # so we will use regex
        
        # The regex pattern looks for <ul starting with class="navbar-nav" and ending with </ul>
        pattern = re.compile(r'<ul[^>]*class=["\'][^"\']*navbar-nav[^"\']*["\'][^>]*>.*?</ul>', re.DOTALL)
        
        # We need to make sure we don't accidentally replace the footer list if it shares classes (rare, but possible)
        # Assuming only one navbar-nav per standard page (in the header)
        if pattern.search(content):
            new_content = pattern.sub(new_ul, content, count=1)
            with codecs.open(filepath, 'w', 'utf-8') as f:
                f.write(new_content)
            print("Updated navbar in:", filename)
        else:
            print("No navbar found in:", filename)

print("Navbar synchronization complete.")
