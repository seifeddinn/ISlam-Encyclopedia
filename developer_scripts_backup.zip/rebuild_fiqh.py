import codecs

html = """<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>موسوعة الفقه الإسلامي - الموسوعة الشاملة</title>
<link href="https://fonts.googleapis.com/css2?family=Amiri:ital,wght@0,400;0,700;1,400&family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root{--gold:#d4af37;--gold2:#f3e5ab;--dark:#022c22;--emerald:#064e3b;--slate:#0f172a;}
body{font-family:'Cairo',sans-serif;background:#f8fafc;color:#0f172a;overflow-x:hidden;}
h1,h2,h3,h4,.ar{font-family:'Amiri',serif;}

/* NAVBAR */
.navbar {background:linear-gradient(135deg,#022c22,#064e3b)!important;box-shadow:0 10px 30px rgba(0,0,0,.5);border-bottom:1px solid rgba(212,175,55,.15);}
.navbar-brand{font-family:'Amiri',serif;font-size:1.6rem;color:white!important;}
.nav-link{color:rgba(255,255,255,.8)!important;font-weight:700;transition:.3s;}
.nav-link:hover, .nav-link.active{color:var(--gold)!important;transform:translateY(-2px);}

/* HERO */
.fiqh-hero{min-height:580px;background:linear-gradient(160deg,#022c22 0%,#064e3b 45%,#065f46 100%);position:relative;overflow:hidden;display:flex;align-items:center;padding:100px 0;}
.orb{position:absolute;border-radius:50%;filter:blur(100px);opacity:.15;animation:orb 12s infinite alternate;}
.orb:nth-child(1){width:600px;height:600px;background:#d4af37;top:-200px;right:-100px;}
.orb:nth-child(2){width:400px;height:400px;background:#10b981;bottom:-100px;left:0;animation-delay:4s;}
@keyframes orb{from{transform:scale(1) translate(0,0)}to{transform:scale(1.2) translate(30px,30px)}}
.hero-pattern{position:absolute;inset:0;background:url('https://www.transparenttextures.com/patterns/arabesque.png');opacity:.05;}
.hero-content{position:relative;z-index:5;color:white;}
.hero-eyebrow{display:inline-block;border:1px solid rgba(212,175,55,.3);background:rgba(212,175,55,.1);backdrop-filter:blur(10px);color:var(--gold2);border-radius:40px;padding:8px 24px;font-size:.85rem;font-weight:700;margin-bottom:20px;}
.fiqh-hero h1{font-size:4.2rem;font-weight:bold;margin-bottom:15px;background:linear-gradient(135deg,#fff 30%,var(--gold2) 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;line-height:1.2;}
.tagline{color:rgba(255,255,255,.7);font-size:1.15rem;margin-bottom:40px;line-height:2;}
.hero-quote{background:rgba(255,255,255,.05);border:1px solid rgba(212,175,55,.2);border-right:4px solid var(--gold);border-radius:16px;padding:22px 26px;max-width:650px;backdrop-filter:blur(12px);}
.hero-quote p{font-family:'Amiri',serif;font-size:1.4rem;line-height:2;color:white;margin:0;}
.hero-quote small{color:rgba(255,255,255,.5);font-size:.85rem;}

/* SECTIONS HEAD */
.sec-head{text-align:center;margin-bottom:50px;}
.sec-head .tag{display:inline-block;background:rgba(6,78,59,.1);color:var(--emerald);border-radius:40px;padding:6px 20px;font-size:.85rem;font-weight:700;margin-bottom:15px;}
.sec-head h2{font-size:2.6rem;color:var(--dark);font-weight:800;margin-bottom:10px;}
.sec-head p{color:#64748b;max-width:600px;margin:0 auto;font-size:1.05rem;}
.sec-head .divider{width:70px;height:4px;background:linear-gradient(90deg,var(--gold),var(--gold2));border-radius:2px;margin:20px auto 0;}

/* MADHABS */
.madhab-section{padding:80px 0;background:white;}
.madhab-card{border-radius:20px;overflow:hidden;background:white;box-shadow:0 10px 30px rgba(2,44,34,.06);transition:.5s;height:100%;position:relative;border:1px solid rgba(0,0,0,.04);text-align:center;}
.madhab-card:hover{transform:translateY(-8px);box-shadow:0 20px 40px rgba(2,44,34,.12);}
.madhab-header{padding:40px 30px;background:linear-gradient(135deg,#022c22,#064e3b);position:relative;overflow:hidden;color:white;}
.mh-icon{position:absolute;left:-20px;bottom:-20px;font-size:8rem;opacity:.08;}
.madhab-header h3{font-family:'Amiri',serif;font-size:2rem;font-weight:bold;margin-bottom:5px;position:relative;z-index:2;color:var(--gold);}
.mh-founder{font-size:.9rem;opacity:.8;position:relative;z-index:2;}
.madhab-body{padding:30px;}
.madhab-body p{color:#475569;line-height:1.8;font-size:.95rem;margin-bottom:20px;}
.btn-madhab{background:var(--emerald);color:white;border-radius:30px;padding:8px 25px;font-weight:700;transition:.3s;}
.btn-madhab:hover{background:var(--dark);color:var(--gold);}

/* ABWAB */
.abwab-section{padding:80px 0;background:#f8fafc;}
.bab-card{background:white;border-radius:16px;padding:25px;box-shadow:0 8px 20px rgba(2,44,34,.04);transition:.4s;height:100%;border-right:3px solid transparent;}
.bab-card:hover{border-right-color:var(--gold);transform:translateX(-5px);box-shadow:0 15px 35px rgba(2,44,34,.08);}
.bab-icon{width:60px;height:60px;border-radius:14px;background:rgba(6,78,59,.08);color:var(--emerald);display:flex;align-items:center;justify-content:center;font-size:1.6rem;margin-bottom:15px;}
.bab-card h4{font-weight:800;color:var(--dark);margin-bottom:10px;}
.bab-card p{color:#64748b;font-size:.88rem;line-height:1.8;}

/* USUL */
.usul-section{padding:80px 0;background:linear-gradient(135deg,#022c22,#064e3b);color:white;position:relative;overflow:hidden;}
.usul-orb{position:absolute;right:-5%;top:-10%;width:300px;height:300px;background:var(--gold);filter:blur(80px);opacity:.2;border-radius:50%;}
.usul-card{background:rgba(255,255,255,.05);border:1px solid rgba(212,175,55,.2);border-radius:20px;padding:40px;text-align:center;backdrop-filter:blur(10px);}
.usul-card h2{font-size:2.5rem;color:var(--gold2);margin-bottom:15px;font-weight:bold;}
.usul-card p{font-size:1.1rem;line-height:2;color:rgba(255,255,255,.8);max-width:700px;margin:0 auto 30px;}
.btn-gold{background:linear-gradient(135deg,var(--gold),#b48600);color:#022c22;border:none;border-radius:30px;padding:12px 35px;font-weight:800;font-size:1.05rem;transition:.3s;box-shadow:0 10px 20px rgba(212,175,55,.3);}
.btn-gold:hover{transform:scale(1.05);color:#fff;}

/* FOOTER */
.site-footer{background:linear-gradient(135deg,#022c22,#021b14);color:white;padding:70px 0 30px;margin-top:60px;}

@media(max-width:768px){
  .fiqh-hero h1{font-size:2.8rem;}
}
</style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold" href="index.html"><i class="fas fa-book-open me-2 text-warning"></i>الموسوعة الإسلامية الشاملة</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav1">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="nav1">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link " href="index.html">الرئيسية</a></li>
        <li class="nav-item"><a class="nav-link " href="recitations.html">القرآن والتلاوات</a></li>
        <li class="nav-item"><a class="nav-link " href="hadith.html">الحديث الشريف</a></li>
        <li class="nav-item"><a class="nav-link active" href="fiqh.html">الفقه الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="fatwa.html">فتاوى العلماء <i class="fas fa-gavel"></i></a></li>
        <li class="nav-item"><a class="nav-link " href="seerah.html">السيرة والصحابة</a></li>
        <li class="nav-item"><a class="nav-link " href="aqeedah.html">العقيدة الإسلامية</a></li>
        <li class="nav-item"><a class="nav-link " href="history.html">التاريخ الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="library.html">المكتبة الشاملة</a></li>
      </ul>
    </div>
  </div>
</nav>

<section class="fiqh-hero">
  <div class="orb"></div><div class="orb"></div>
  <div class="hero-pattern"></div>
  <div class="container hero-content">
    <div class="row align-items-center">
      <div class="col-lg-7">
        <div class="hero-eyebrow"><i class="fas fa-balance-scale me-2"></i>موسوعة الفقه الإسلامي</div>
        <h1>الأحكام الشرعية<br>للحياة الإنسانية</h1>
        <p class="tagline">استكشف المذاهب الأربعة وأبواب الفقه الإسلامي التفصيلية، من الطهارة والعبادات إلى المعاملات والمواريث، بمنهجية علمية ميسرة.</p>
        <div class="hero-quote">
          <p>«مَنْ يُرِدِ اللهُ بِهِ خَيْرًا يُفَقِّهْهُ فِي الدِّينِ»</p>
          <small>— متفق عليه</small>
        </div>
      </div>
      <div class="col-lg-5 d-none d-lg-block text-center">
        <i class="fas fa-book-open me-2" style="font-size:16rem;color:rgba(212,175,55,.12);animation:spin 30s linear infinite;"></i>
      </div>
    </div>
  </div>
</section>

<!-- MADHABS SECT -->
<section class="madhab-section">
  <div class="container">
    <div class="sec-head">
      <span class="tag">المدارس الفقهية الكبرى</span>
      <h2>المذاهب الأربعة المعتبرة</h2>
      <p>الأئمة الأعلام الذين أضاءت فتاواهم ومنهجياتهم الأمة الإسلامية لقرون</p>
      <div class="divider"></div>
    </div>
    <div class="row g-4 justify-content-center">
      <div class="col-lg-3 col-md-6">
        <div class="madhab-card">
          <div class="madhab-header">
            <i class="fas fa-university mh-icon"></i>
            <h3>المذهب الحنفي</h3>
            <span class="mh-founder">الإمام أبو حنيفة النعمان</span>
          </div>
          <div class="madhab-body">
            <p>أول المذاهب الأربعة وأوسعها انتشاراً في العالم الإسلامي، يمتاز بالاعتماد على مدرسة الرأي والقياس الدقيق وتفريغ المسائل.</p>
            <a href="fiqh_hanafi.html" class="btn btn-madhab">استكشف المذهب</a>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-md-6">
        <div class="madhab-card">
          <div class="madhab-header">
            <i class="fas fa-mosque mh-icon"></i>
            <h3>المذهب المالكي</h3>
            <span class="mh-founder">الإمام مالك بن أنس</span>
          </div>
          <div class="madhab-body">
            <p>مدرسة المدينة المنورة. اعتمد الإمام مالك بقوة على عمل أهل المدينة كدليل شرعي معتبر بعد القرآن الكريم والسنة النبوية.</p>
            <a href="fiqh_maliki.html" class="btn btn-madhab">استكشف المذهب</a>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-md-6">
        <div class="madhab-card">
          <div class="madhab-header">
            <i class="fas fa-pen-nib mh-icon"></i>
            <h3>المذهب الشافعي</h3>
            <span class="mh-founder">الإمام محمد بن إدريس الشافعي</span>
          </div>
          <div class="madhab-body">
            <p>مؤسس علم "أصول الفقه". جمع مذهبه بين مدرستي أهل الحديث وأهل الرأي في توازن دقيق وتأصيل منهجي عميق جداً.</p>
            <a href="fiqh_shafi.html" class="btn btn-madhab">استكشف المذهب</a>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-md-6">
        <div class="madhab-card">
          <div class="madhab-header">
            <i class="fas fa-book-reader mh-icon"></i>
            <h3>المذهب الحنبلي</h3>
            <span class="mh-founder">الإمام أحمد بن حنبل</span>
          </div>
          <div class="madhab-body">
            <p>أكثر المذاهب اعتماداً على نصوص الحديث والأثر، وتشدد في التمسك بالسنن وترك الآراء والقياس ما لم توجد ضرورة قصوى.</p>
            <a href="fiqh_hanbali.html" class="btn btn-madhab">استكشف المذهب</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ABWAB SECT -->
<section class="abwab-section">
  <div class="container">
    <div class="sec-head">
      <span class="tag">التبويب الشامل</span>
      <h2>أبواب الفقه الإسلامي</h2>
      <p>تفاصيل الأحكام حسب التصنيف المعتمد في الموسوعات الفقهية</p>
      <div class="divider"></div>
    </div>
    
    <div class="row g-4">
      <div class="col-lg-3 col-md-4 col-sm-6"><div class="bab-card"><div class="bab-icon"><i class="fas fa-water"></i></div><h4>الطهارة</h4><p>شروط صحة الصلاة من وضوء وغسل وتيمم وإزالة النجاسات.</p></div></div>
      <div class="col-lg-3 col-md-4 col-sm-6"><div class="bab-card"><div class="bab-icon"><i class="fas fa-pray"></i></div><h4>الصلاة</h4><p>عمود الدين؛ وتشمل أحكام صلاة الجماعة وقصر الصلاة والسهو والجمعة.</p></div></div>
      <div class="col-lg-3 col-md-4 col-sm-6"><div class="bab-card"><div class="bab-icon"><i class="fas fa-coins"></i></div><h4>الزكاة</h4><p>أنصبة الأموال النقدية والزروع والأنعام، ومصارفها الثمانية المحددة.</p></div></div>
      <div class="col-lg-3 col-md-4 col-sm-6"><div class="bab-card"><div class="bab-icon"><i class="fas fa-moon"></i></div><h4>الصيام</h4><p>أحكام الإمساك عن المفطرات، ورؤية الهلال، وكفارة الإفطار وفديته.</p></div></div>
      <div class="col-lg-3 col-md-4 col-sm-6"><div class="bab-card"><div class="bab-icon"><i class="fas fa-kaaba"></i></div><h4>الحج والعمرة</h4><p>أركان الحج وواجباته، ومحظورات الإحرام، وأحكام الهدي والإنابة.</p></div></div>
      <div class="col-lg-3 col-md-4 col-sm-6"><div class="bab-card"><div class="bab-icon"><i class="fas fa-handshake"></i></div><h4>المعاملات المالية</h4><p>أحكام البيوع المشروعة والمحرمة، والربا، والشركات، والإجارة، والقروض.</p></div></div>
      <div class="col-lg-3 col-md-4 col-sm-6"><div class="bab-card"><div class="bab-icon"><i class="fas fa-ring"></i></div><h4>فقه الأسرة</h4><p>الأحوال الشخصية مثل أركان النكاح وشروطه، والطلاق المعلق، والحضانة.</p></div></div>
      <div class="col-lg-3 col-md-4 col-sm-6"><div class="bab-card"><div class="bab-icon"><i class="fas fa-gavel"></i></div><h4>الجنايات والحدود</h4><p>حفظ النفس والأمن عبر القصاص وأنواع الحدود في الشريعة العادلة.</p></div></div>
    </div>
  </div>
</section>

<!-- USUL -->
<section class="usul-section">
  <div class="usul-orb"></div>
  <div class="container position-relative z-2">
    <div class="usul-card">
      <i class="fas fa-balance-scale-right fa-4x mb-3" style="color:var(--gold);"></i>
      <h2>أصول الفقه وقواعد الاستنباط</h2>
      <p>علم أصول الفقه هو عقل الشريعة. من خلاله تُفهم دلالات الألفاظ، وتُنظم الأدلة بين محكم ومتشابه، ناسخ ومنسوخ، ومنطوق ومفهوم.</p>
      <a href="usul.html" class="btn btn-gold px-4 py-2"><i class="fas fa-arrow-left ms-2 d-inline-block" style="vertical-align:middle;"></i> الدخول لقسم الأصول</a>
    </div>
  </div>
</section>

<footer class="mega-footer" style="background:linear-gradient(135deg,var(--dark),#020617);color:white;padding:80px 0 30px;margin-top:80px;border-top:3px solid var(--gold-dark);">
  <div class="container">
    <div class="row g-5 mb-5 border-bottom border-light border-opacity-10 pb-5">
      <div class="col-lg-4 text-md-end text-center">
        <i class="fas fa-mosque fa-4x text-warning mb-4 d-block"></i>
        <h4 class="fw-bold font-amiri fs-2 mb-3">الموسوعة الإسلامية الشاملة</h4>
        <p class="opacity-75 fs-6 line-height-2">أضخم صرح رقمي يجمع علوم القرآن العظيم، وأحاديث المصطفى، وفقهاء المذاهب، والتاريخ المجيد في منصة موثقة مصممة بأحدث التقنيات.</p>
      </div>
      <div class="col-lg-4 text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">تصفح الموسوعة</h5>
        <div class="d-flex flex-wrap justify-content-center gap-2">
          <a href="recitations.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">أكاديمية القرآن</a>
          <a href="hadith.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الحديث النبوي</a>
          <a href="seerah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">السيرة والصحابة</a>
          <a href="fiqh.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الفقه وأصوله</a>
          <a href="fatwa.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">فتاوى العلماء</a>
          <a href="aqeedah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">العقيدة الإسلامية</a>
          <a href="history.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">التاريخ المجيد</a>
          <a href="library.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">المكتبة الشاملة</a>
        </div>
      </div>
      <div class="col-lg-4 text-md-start text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">روابط سريعة</h5>
        <a href="contact.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> اتصل بالمطور</a>
        <a href="share.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> شارك الأجر</a>
        <a href="login.html" class="mega-footer-link text-warning mt-3" style="text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-user-circle me-2 ms-1"></i> تسجيل الدخول</a>
      </div>
    </div>
    <div class="text-center font-amiri fs-5 d-flex flex-column gap-2">
      <span class="opacity-75">الموسوعة الإسلامية الشاملة &copy; 2026 تم التصميم للإفادة | عمل مجاني لوجه الله</span>
      <span class="text-warning fw-bold fs-4 mt-2">تصميم وتطوير: لخذاري محمد سيف الدين</span>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<style>@keyframes spin{to{transform:rotate(360deg)}}</style>
</body>
</html>"""

with codecs.open(r"C:\Users\ST\Desktop\islamic.encyclopedia\fiqh.html", 'w', 'utf-8') as f:
    f.write(html)
print("Rebuilt fiqh.html successfully!")
