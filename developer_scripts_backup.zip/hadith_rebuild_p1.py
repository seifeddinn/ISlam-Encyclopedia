import codecs

css = """
<style>
:root{--g1:#0d3320;--g2:#1a5c3a;--gold:#c9a66b;--gold2:#e8d5a3;--light:#f9fdf9;--shadow:0 20px 60px rgba(0,0,0,0.12);}
*{box-sizing:border-box;}
body{font-family:'Cairo',sans-serif;background:#f2f8f4;color:#222;overflow-x:hidden;}
h1,h2,h3,h4,.ar{font-family:'Amiri',serif;}

/* ===== HERO ===== */
.hero{
  min-height:520px;
  background:linear-gradient(160deg,#051c0e 0%,#0d3320 40%,#165c35 100%);
  position:relative;overflow:hidden;display:flex;align-items:center;justify-content:center;
  padding:80px 20px;
}
.hero-bg-pattern{
  position:absolute;inset:0;
  background-image:
    radial-gradient(circle at 20% 50%, rgba(201,166,107,.08) 0%,transparent 50%),
    radial-gradient(circle at 80% 20%, rgba(201,166,107,.06) 0%,transparent 40%),
    url('https://www.transparenttextures.com/patterns/arabesque.png');
  background-size:auto,auto,300px;
  opacity:.7;animation:float 30s linear infinite;
}
@keyframes float{from{transform:translate(0,0)} to{transform:translate(20px,20px)}}
.hero-content{position:relative;z-index:5;text-align:center;color:white;}
.hero-badge{
  display:inline-block;background:rgba(201,166,107,.15);border:1px solid rgba(201,166,107,.3);
  color:var(--gold2);border-radius:40px;padding:8px 24px;font-size:.85rem;margin-bottom:20px;
  backdrop-filter:blur(10px);
}
.hero h1{font-size:3.5rem;font-weight:bold;margin-bottom:10px;
  background:linear-gradient(135deg,#fff 0%,var(--gold2) 100%);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;}
.hero .sub{color:rgba(255,255,255,.7);font-size:1.1rem;margin-bottom:35px;}
.hotd-box{
  background:rgba(255,255,255,.06);border:1px solid rgba(201,166,107,.2);
  border-radius:20px;padding:25px 30px;max-width:720px;margin:0 auto;
  backdrop-filter:blur(15px);border-top:2px solid var(--gold);
}
.hotd-label{color:var(--gold);font-size:.85rem;font-weight:700;letter-spacing:.5px;margin-bottom:10px;}
.hotd-text{font-family:'Amiri',serif;font-size:1.3rem;line-height:2.2;color:white;margin:0;}
.hotd-source{color:rgba(255,255,255,.5);font-size:.85rem;margin-top:10px;}

/* ===== STATS BAR ===== */
.stats-bar{
  background:linear-gradient(90deg,var(--g1),var(--g2));
  padding:20px 0;
}
.stat-item{text-align:center;color:white;}
.stat-num{font-size:2rem;font-weight:800;color:var(--gold);font-family:'Amiri',serif;}
.stat-label{font-size:.8rem;opacity:.75;margin-top:2px;}

/* ===== TABS ===== */
.tabs-wrapper{
  background:white;border-radius:60px;padding:8px;
  box-shadow:0 10px 40px rgba(0,0,0,.08);
  margin:45px 0 40px;display:flex;overflow-x:auto;
  border:1px solid rgba(0,0,0,.04);
}
.tabs-wrapper::-webkit-scrollbar{height:0;}
.tabs-wrapper .nav-item{flex:1;min-width:150px;}
.tabs-wrapper .nav-link{
  border:none;border-radius:50px;color:#555;font-weight:700;
  padding:14px 16px;width:100%;text-align:center;transition:all .35s;white-space:nowrap;
}
.tabs-wrapper .nav-link:hover{color:var(--g2);}
.tabs-wrapper .nav-link.active{
  background:linear-gradient(135deg,var(--g1),var(--g2));color:white;
  box-shadow:0 8px 20px rgba(13,51,32,.3);
}
.tabs-wrapper .nav-link i{margin-left:6px;}

/* ===== SECTION HEADER ===== */
.sec-head{text-align:center;margin-bottom:45px;}
.sec-head .tag{
  display:inline-block;background:rgba(13,51,32,.08);color:var(--g2);
  border-radius:40px;padding:6px 20px;font-size:.82rem;font-weight:700;margin-bottom:15px;
}
.sec-head h3{font-size:2.2rem;color:var(--g1);font-weight:700;margin-bottom:8px;}
.sec-head h3 span{color:var(--gold);}
.sec-head p{color:#888;max-width:600px;margin:0 auto;}
.sec-head .divider{width:60px;height:4px;background:linear-gradient(90deg,var(--gold),var(--gold2));border-radius:2px;margin:15px auto 0;}

/* ===== KITAB CARDS ===== */
.kitab-wrap{border-radius:24px;overflow:hidden;box-shadow:0 15px 40px rgba(0,0,0,.07);transition:all .4s;height:100%;background:white;}
.kitab-wrap:hover{transform:translateY(-10px);box-shadow:0 25px 60px rgba(0,0,0,.13);}
.kitab-header{padding:30px 25px 20px;position:relative;overflow:hidden;}
.kitab-header::after{
  content:attr(data-num);position:absolute;left:-10px;bottom:-15px;
  font-family:'Amiri',serif;font-size:6rem;font-weight:bold;opacity:.06;color:#000;line-height:1;
}
.kitab-icon-wrap{width:60px;height:60px;border-radius:16px;display:flex;align-items:center;justify-content:center;font-size:1.6rem;margin-bottom:15px;box-shadow:0 8px 20px rgba(0,0,0,.15);}
.kitab-header h5{font-size:1.2rem;font-weight:800;margin-bottom:4px;color:#1a1a2e;}
.kitab-header small{color:rgba(255,255,255,.7);font-size:.78rem;}
.kitab-body{padding:20px 25px 25px;}
.kitab-body p{font-size:.88rem;color:#555;line-height:1.8;margin-bottom:15px;}
.kitab-stat{
  background:var(--light);border-radius:12px;padding:12px 18px;
  display:flex;justify-content:space-between;align-items:center;
}
.kitab-stat span{font-size:.8rem;color:#888;}
.kitab-stat strong{color:var(--g1);font-size:1rem;}

/* ===== NAWAWI ===== */
.nawawi-search-wrap{
  background:white;border-radius:60px;box-shadow:0 8px 30px rgba(0,0,0,.07);
  padding:8px 8px 8px 25px;display:flex;align-items:center;margin-bottom:35px;
}
.nawawi-search-wrap input{border:none;outline:none;flex:1;font-family:'Cairo',sans-serif;font-size:1rem;color:#333;}
.nawawi-search-wrap button{
  background:linear-gradient(135deg,var(--g1),var(--g2));color:white;
  border:none;border-radius:50px;padding:12px 28px;font-weight:700;font-size:.9rem;cursor:pointer;
}
.hadith-card{
  background:white;border-radius:20px;padding:28px 28px 22px;margin-bottom:22px;
  box-shadow:0 8px 25px rgba(0,0,0,.05);position:relative;overflow:hidden;
  border-right:6px solid var(--gold);transition:all .3s;
}
.hadith-card:hover{box-shadow:0 15px 40px rgba(13,51,32,.1);transform:translateX(-4px);}
.hadith-num-bg{
  position:absolute;left:15px;top:10px;
  font-family:'Amiri',serif;font-size:5rem;color:rgba(13,51,32,.04);font-weight:bold;line-height:1;
}
.hadith-header{display:flex;align-items:center;gap:15px;margin-bottom:18px;}
.hadith-num-badge{
  width:48px;height:48px;border-radius:50%;flex-shrink:0;
  background:linear-gradient(135deg,var(--g1),var(--g2));
  display:flex;align-items:center;justify-content:center;
  color:white;font-family:'Amiri',serif;font-size:1.3rem;font-weight:bold;
  box-shadow:0 6px 15px rgba(13,51,32,.2);
}
.hadith-title{font-weight:800;color:var(--g1);font-size:1.05rem;}
.hadith-narrator{color:#888;font-size:.82rem;}
.hadith-text{font-family:'Amiri',serif;font-size:1.18rem;line-height:2.2;color:#2a2a2a;margin-bottom:16px;}
.hadith-source-tag{
  display:inline-flex;align-items:center;gap:7px;
  background:rgba(201,166,107,.1);border:1px solid rgba(201,166,107,.3);
  color:#9a7940;border-radius:25px;padding:6px 16px;font-size:.82rem;font-weight:700;
}

/* ===== MUSTALAH ===== */
.term-card{
  border-radius:20px;padding:30px;text-align:center;
  box-shadow:0 10px 30px rgba(0,0,0,.06);transition:all .4s;height:100%;
  position:relative;overflow:hidden;background:white;
}
.term-card::before{
  content:'';position:absolute;top:-40px;right:-40px;
  width:120px;height:120px;border-radius:50%;opacity:.07;
}
.term-card:hover{transform:translateY(-8px);box-shadow:0 20px 50px rgba(0,0,0,.1);}
.term-icon{
  width:75px;height:75px;border-radius:50%;
  display:flex;align-items:center;justify-content:center;
  font-size:2rem;margin:0 auto 18px;box-shadow:0 10px 25px rgba(0,0,0,.15);
}
.grade-bar{height:8px;border-radius:4px;margin:12px 0;background:#eee;}

/* ===== IMAMS ===== */
.imam-card{
  background:white;border-radius:22px;box-shadow:0 10px 30px rgba(0,0,0,.06);
  overflow:hidden;transition:all .4s;height:100%;
}
.imam-card:hover{transform:translateY(-8px);box-shadow:0 20px 50px rgba(13,51,32,.12);}
.imam-top{height:90px;position:relative;display:flex;align-items:flex-end;padding:0 20px;}
.imam-avatar{
  width:70px;height:70px;border-radius:50%;
  background:linear-gradient(135deg,var(--g1),var(--g2));
  display:flex;align-items:center;justify-content:center;
  font-size:1.8rem;color:white;
  border:3px solid white;box-shadow:0 8px 20px rgba(0,0,0,.15);
  position:relative;z-index:2;
  transform:translateY(35px);
}
.imam-body{padding:45px 22px 22px;}
.imam-name{font-weight:800;color:var(--g1);font-size:1.05rem;margin-bottom:3px;}
.imam-date{font-size:.78rem;color:var(--gold);font-weight:700;margin-bottom:10px;}
.imam-body p{font-size:.85rem;color:#666;line-height:1.8;}

/* ===== BAHETH ===== */
.baheth-wrapper{background:white;border-radius:24px;padding:35px;box-shadow:0 15px 40px rgba(0,0,0,.06);margin-bottom:30px;}
.baheth-input-wrap{
  background:var(--light);border-radius:60px;
  display:flex;align-items:center;padding:8px 8px 8px 24px;gap:10px;
  border:2px solid transparent;transition:border .3s;
}
.baheth-input-wrap:focus-within{border-color:var(--gold);background:white;}
.baheth-input-wrap input{border:none;background:transparent;outline:none;flex:1;font-size:1rem;font-family:'Cairo',sans-serif;}
.baheth-btn{
  background:linear-gradient(135deg,var(--gold),var(--gold2));color:var(--g1);
  border:none;border-radius:50px;padding:13px 30px;font-weight:800;cursor:pointer;
  box-shadow:0 6px 15px rgba(201,166,107,.35);transition:all .3s;
}
.baheth-btn:hover{transform:scale(1.04);}
.result-card{
  background:white;border-radius:18px;padding:25px;border-right:4px solid var(--g2);
  margin-bottom:16px;box-shadow:0 5px 20px rgba(0,0,0,.05);
  opacity:0;animation:fadeUp .4s forwards;
}
@keyframes fadeUp{from{opacity:0;transform:translateY(15px)}to{opacity:1;transform:translateY(0)}}
</style>
"""

part1 = """<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>أكاديمية الحديث النبوي - الموسوعة الإسلامية الشاملة</title>
<link href="https://fonts.googleapis.com/css2?family=Amiri:ital,wght@0,400;0,700;1,400&family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="styles.css">
""" + css + """
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-dark sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold" href="index.html"><i class="fas fa-book-open me-2 text-warning"></i>الموسوعة الإسلامية الشاملة</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav1">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="nav1">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link " href="index.html">الرئيسية</a></li>
        <li class="nav-item"><a class="nav-link " href="recitations.html">القرآن والتلاوات</a></li>
        <li class="nav-item"><a class="nav-link active" href="hadith.html">الحديث الشريف</a></li>
        <li class="nav-item"><a class="nav-link " href="fiqh.html">الفقه الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="fatwa.html">فتاوى العلماء <i class="fas fa-gavel"></i></a></li>
        <li class="nav-item"><a class="nav-link " href="seerah.html">السيرة والصحابة</a></li>
        <li class="nav-item"><a class="nav-link " href="aqeedah.html">العقيدة الإسلامية</a></li>
        <li class="nav-item"><a class="nav-link " href="history.html">التاريخ الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="library.html">المكتبة الشاملة</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- HERO -->
<section class="hero">
  <div class="hero-bg-pattern"></div>
  <div class="container hero-content">
    <div class="hero-badge"><i class="fas fa-star me-2"></i>المرجع الحديثي الشامل</div>
    <h1>أكاديمية الحديث النبوي</h1>
    <p class="sub">الصحاح الستة · الأربعون النووية · علوم الحديث · أئمة المحدثين</p>
    <div class="hotd-box">
      <div class="hotd-label"><i class="fas fa-sun me-1"></i>حديث اليوم</div>
      <p class="hotd-text" id="hotd-text">«إنما الأعمال بالنيات، وإنما لكل امرئ ما نوى...»</p>
      <p class="hotd-source" id="hotd-source">رواه البخاري ومسلم</p>
    </div>
  </div>
</section>

<!-- STATS BAR -->
<div class="stats-bar">
  <div class="container">
    <div class="row text-center g-0">
      <div class="col-6 col-md-3 stat-item border-end border-white border-opacity-25">
        <div class="stat-num">9</div><div class="stat-label">كتب الحديث الكبرى</div>
      </div>
      <div class="col-6 col-md-3 stat-item border-end border-white border-opacity-25">
        <div class="stat-num">42</div><div class="stat-label">حديثاً نووياً</div>
      </div>
      <div class="col-6 col-md-3 stat-item border-end border-white border-opacity-25">
        <div class="stat-num">+70K</div><div class="stat-label">حديث في المسانيد</div>
      </div>
      <div class="col-6 col-md-3 stat-item">
        <div class="stat-num">8</div><div class="stat-label">أئمة المحدثين</div>
      </div>
    </div>
  </div>
</div>

<div class="container mb-5">

<!-- TABS -->
<ul class="nav tabs-wrapper" id="hTabs" role="tablist">
  <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#t1"><i class="fas fa-book-open"></i> الصحاح والسنن</button></li>
  <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t2"><i class="fas fa-scroll"></i> الأربعون النووية</button></li>
  <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t3"><i class="fas fa-graduation-cap"></i> علوم الحديث</button></li>
  <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t4"><i class="fas fa-user-tie"></i> أئمة المحدثين</button></li>
  <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t5"><i class="fas fa-search"></i> الباحث الحديثي</button></li>
</ul>

<div class="tab-content">
"""

with codecs.open(r"c:\Users\ST\Desktop\islamic.encyclopedia\hadith_p1.tmp", 'w', 'utf-8') as f:
    f.write(part1)
print("Part 1 done")
