<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>محرك البحث - الموسوعة الإسلامية الشاملة</title>
    <link href="https://fonts.googleapis.com/css2?family=Amiri:ital,wght@0,400;0,700;1,400&family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root{--gold:#d4af37;--dark:#0f172a;--primary:#3b82f6;}
        body{font-family:'Cairo',sans-serif;background:#f8fafc;color:#1e293b;overflow-x:hidden;}
        h1,h2,h3,h4,.amiri{font-family:'Amiri',serif;}
        
        /* MEGA NAVBAR */
        .navbar {background:linear-gradient(135deg,var(--dark),#1e3a8a)!important;box-shadow:0 4px 30px rgba(0,0,0,.5);z-index:1000;border-bottom:2px solid rgba(212,175,55,0.2);}
        .navbar-brand{font-family:'Amiri',serif;font-size:1.8rem;color:white!important;text-shadow:0 2px 10px rgba(212,175,55,0.5);}
        .nav-link{color:rgba(255,255,255,.8)!important;font-weight:700;letter-spacing:0.5px;transition:all .3s;}
        .nav-link:hover, .nav-link.active{color:var(--gold)!important;transform:translateX(-2px);}

        /* MEGA SEARCH BAR HERO */
        .search-hero {background:radial-gradient(circle at 50% 50%, #1e3a8a 0%, var(--dark) 80%); padding:120px 0 100px; text-align:center; position:relative; overflow:hidden;}
        .search-hero::before {content:''; position:absolute; inset:0; background:url('https://www.transparenttextures.com/patterns/stardust.png'); opacity:0.2;}
        .search-wrapper {position:relative; max-width:800px; margin:0 auto; z-index:10;}
        .mega-input {width:100%; border:none; border-radius:50px; padding:25px 30px; padding-right:70px; font-size:1.5rem; background:rgba(255,255,255,0.1); backdrop-filter:blur(10px); color:white; border:2px solid rgba(212,175,55,0.5); box-shadow:0 20px 50px rgba(0,0,0,0.4); transition:0.3s;}
        .mega-input:focus {outline:none; border-color:var(--gold); background:rgba(255,255,255,0.15); box-shadow:0 20px 60px rgba(212,175,55,0.3);}
        .mega-input::placeholder {color:rgba(255,255,255,0.5);}
        .search-icon {position:absolute; right:25px; top:50%; transform:translateY(-50%); font-size:1.8rem; color:var(--gold);}
        
        /* SEARCH RESULTS */
        .results-container {max-width:900px; margin:-50px auto 100px; position:relative; z-index:20; min-height:400px;}
        .result-card {background:white; border-radius:20px; padding:30px; box-shadow:0 15px 35px rgba(0,0,0,0.05); margin-bottom:20px; border:1px solid #f1f5f9; transition:all 0.3s; display:flex; flex-direction:column; align-items:flex-start; text-decoration:none; color:inherit;}
        .result-card:hover {transform:translateY(-5px); border-color:var(--primary); box-shadow:0 20px 40px rgba(59,130,246,0.1);}
        .result-badge {background:rgba(59,130,246,0.1); color:var(--primary); padding:5px 15px; border-radius:50px; font-size:0.9rem; font-weight:bold; margin-bottom:15px;}
        .result-title {font-family:'Amiri',serif; font-size:1.8rem; font-weight:bold; color:var(--dark); margin-bottom:10px;}
        .result-snippet {color:#64748b; line-height:1.7; font-size:1.1rem;}
        .highlight {background-color:#fef08a; padding:0 3px; border-radius:3px; color:#854d0e; font-weight:bold;}
        .empty-state {text-align:center; padding:50px; color:#94a3b8;}
    </style>
</head>
<body>

<!-- MEGA NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-dark sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold" href="index.html"><i class="fas fa-book-open me-2 text-warning"></i>الموسوعة الإسلامية الشاملة</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav1">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="nav1">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link " href="index.html">الرئيسية</a></li>
        <li class="nav-item"><a class="nav-link " href="recitations.html">القرآن والتلاوات</a></li>
        <li class="nav-item"><a class="nav-link " href="hadith.html">الحديث الشريف</a></li>
        <li class="nav-item"><a class="nav-link " href="fiqh.html">الفقه الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="fatwa.html">فتاوى العلماء <i class="fas fa-gavel"></i></a></li>
        <li class="nav-item"><a class="nav-link " href="seerah.html">السيرة والصحابة</a></li>
        <li class="nav-item"><a class="nav-link " href="aqeedah.html">العقيدة الإسلامية</a></li>
        <li class="nav-item"><a class="nav-link " href="history.html">التاريخ الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="library.html">المكتبة الشاملة</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- SEARCH HERO -->
<section class="search-hero">
    <div class="search-wrapper px-3">
        <h1 class="display-4 amiri text-white fw-bold mb-4">ابحث في <span class="text-warning">الموسوعة الشاملة</span></h1>
        <p class="fs-4 amiri text-white opacity-75 mb-5">محرك بحث فوري وذكي يشمل القرآن، الحديث، الفقه، السيرة، والتاريخ.</p>
        <div class="position-relative">
            <i class="fas fa-search search-icon"></i>
            <input type="text" id="megaSearchInput" class="mega-input" placeholder="اكتب ما تبحث عنه (مثال: غزوة بدر، الزكاة، الفاتحة)..." autocomplete="off" autofocus>
        </div>
    </div>
</section>

<!-- RESULTS AREA -->
<div class="container results-container">
    <div id="resultsCount" class="text-muted fw-bold mb-3 d-none">تم العثور على <span id="countNum" class="text-primary">0</span> نتيجة</div>
    <div id="resultsList">
        <div class="empty-state bg-white rounded-4 shadow-sm border p-5">
            <i class="fas fa-keyboard fa-4x text-light mb-4 text-opacity-50"></i>
            <h3 class="amiri fw-bold text-dark">ابدأ بكتابة الكلمات المفتاحية</h3>
            <p class="fs-5">ستظهر النتائج المطابقة هنا فوراً وبشكل تلقائي.</p>
        </div>
    </div>
</div>

<footer class="mega-footer" style="background:linear-gradient(135deg,var(--dark),#020617);color:white;padding:80px 0 30px;margin-top:80px;border-top:3px solid var(--gold-dark);">
  <div class="container">
    <div class="row g-5 mb-5 border-bottom border-light border-opacity-10 pb-5">
      <div class="col-lg-4 text-md-end text-center">
        <i class="fas fa-mosque fa-4x text-warning mb-4 d-block"></i>
        <h4 class="fw-bold font-amiri fs-2 mb-3">الموسوعة الإسلامية الشاملة</h4>
        <p class="opacity-75 fs-6 line-height-2">أضخم صرح رقمي يجمع علوم القرآن العظيم، وأحاديث المصطفى، وفقهاء المذاهب، والتاريخ المجيد في منصة موثقة مصممة بأحدث التقنيات.</p>
      </div>
      <div class="col-lg-4 text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">تصفح الموسوعة</h5>
        <div class="d-flex flex-wrap justify-content-center gap-2">
          <a href="recitations.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">أكاديمية القرآن</a>
          <a href="hadith.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الحديث النبوي</a>
          <a href="seerah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">السيرة والصحابة</a>
          <a href="fiqh.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الفقه وأصوله</a>
          <a href="fatwa.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">فتاوى العلماء</a>
          <a href="aqeedah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">العقيدة الإسلامية</a>
          <a href="history.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">التاريخ المجيد</a>
          <a href="library.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">المكتبة الشاملة</a>
        </div>
      </div>
      <div class="col-lg-4 text-md-start text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">روابط سريعة</h5>
        <a href="contact.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> اتصل بالمطور</a>
        <a href="share.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> شارك الأجر</a>
        <a href="login.html" class="mega-footer-link text-warning mt-3" style="text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-user-circle me-2 ms-1"></i> تسجيل الدخول</a>
      </div>
    </div>
    <div class="text-center font-amiri fs-5 d-flex flex-column gap-2">
      <span class="opacity-75">الموسوعة الإسلامية الشاملة &copy; 2026 تم التصميم للإفادة | عمل مجاني لوجه الله</span>
      <span class="text-warning fw-bold fs-4 mt-2">تصميم وتطوير: لخذاري محمد سيف الدين</span>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Mock Database spanning the entire encyclopedia
    const encyclopediaData = [
        { title: "سورة الفاتحة", section: "القرآن والتلاوات", url: "recitations.html", content: "سورة الفاتحة أم الكتاب والسبع المثاني والقرآن العظيم الحمد لله رب العالمين الرحمن الرحيم مالك يوم الدين إياك نعبد وإياك نستعين" },
        { title: "سورة البقرة", section: "القرآن والتلاوات", url: "recitations.html", content: "سورة البقرة أطول سورة في القرآن وفيها آية الكرسي الم ذلك الكتاب لا ريب فيه هدى للمتقين" },
        { title: "أحكام التلاوة والتجويد", section: "القرآن والتلاوات", url: "recitations.html", content: "أحكام النون الساكنة والتنوين الإظهار الإدغام بغنة وبدون غنة الإقلاب الميم الساكنة الإخفاء" },
        { title: "الأربعون النووية", section: "الحديث الشريف", url: "hadith.html", content: "الأربعون النووية يحيى بن شرف النووي أحاديث جامعة لعقائد وأحكام الإسلام" },
        { title: "حديث الأعمال بالنيات", section: "الحديث الشريف", url: "hadith.html", content: "عن عمر بن الخطاب إنما الأعمال بالنيات وإنما لكل امرئ ما نوى فمن كانت هجرته إلى الله ورسوله" },
        { title: "حاسبة الزكاة الذكية", section: "الفقه الإسلامي", url: "fiqh.html", content: "حساب زكاة المال وزكاة الذهب عيار 24 وعيار 21 النصاب ربع العشر التجارة" },
        { title: "المذاهب الفقهية", section: "الفقه الإسلامي", url: "fiqh.html", content: "المذهب الحنفي المالكي الشافعي الحنبلي الإمام أبو حنيفة النعمان أنس مالك الغزالي أحمد بن حنبل" },
        { title: "غزوة بدر الكبرى", section: "السيرة والصحابة", url: "seerah.html", content: "يوم الفرقان في 17 رمضان السنة الثانية للهجرة جيش المسلمين 313 وجيش المشركين 1000 انتصار المسلمين أسرى قريش" },
        { title: "غزوة أحد", section: "السيرة والصحابة", url: "seerah.html", content: "السنة الثالثة للهجرة جبل الرماة استشهاد حمزة بن عبد المطلب إصابة النبي الرماة خالفوا الأمر" },
        { title: "غزوة الخندق (الأحزاب)", section: "السيرة والصحابة", url: "seerah.html", content: "مؤامرة يهود بني النضير وقريش سلمان الفارسي أشار بحفر الخندق ريح شديدة وجنود من الله" },
        { title: "العشرة المبشرون بالجنة", section: "السيرة والصحابة", url: "seerah.html", content: "أبو بكر الصديق عمر بن الخطاب عثمان بن عفان علي بن أبي طالب طلحة بن عبيد الله الزبير بن العوام عبد الرحمن بن عوف سعد بن أبي وقاص سعيد بن زيد أبو عبيدة بن الجراح" },
        { title: "أقسام التوحيد", section: "العقيدة الإسلامية", url: "aqeedah.html", content: "توحيد الربوبية توحيد الألوهية توحيد الأسماء والصفات الخالق الرزاق المدبر إفراد العبادة لله وحده" },
        { title: "نواقض الإسلام", section: "العقيدة الإسلامية", url: "aqeedah.html", content: "الشرك الأكبر السحر من أبغض شيئاً مما جاء به الرسول الاستهزاء بالدين مظاهرة المشركين على المسلمين" },
        { title: "شبهة هل انتشر الإسلام بالسيف؟", section: "العقيدة الإسلامية", url: "aqeedah.html", content: "الرد على الشبهة لا إكراه في الدين الفتوحات الإسلامية كانت لإزالة الطواغيت إندونيسيا دخلها الإسلام بالدعوة والأخلاق" },
        { title: "الخلافة الراشدة", section: "التاريخ الإسلامي", url: "history.html", content: "العصر الذهبي القدوة الحسنة الفتوحات الكبرى الشام العراق فارس أبو بكر عمر عثمان علي" },
        { title: "الدولة الأموية", section: "التاريخ الإسلامي", url: "history.html", content: "معاوية بن أبي سفيان الأندلس دمشق الفتوحات إلى سور الصين العظيم" },
        { title: "الدولة العباسية", section: "التاريخ الإسلامي", url: "history.html", content: "هارون الرشيد بغداد بيت الحكمة عصر الترجمة والازدهار العلمي الخوارزمي سقوط بغداد على يد التتار" },
        { title: "صلاح الدين الأيوبي", section: "التاريخ الإسلامي", url: "history.html", content: "معركة حطين التحرير السلطان محرر القدس المسجد الأقصى دحر الصليبيين" },
        { title: "علم أصول الفقه", section: "أصول الفقه", url: "usul.html", content: "الأدلة الشرعية الكتاب السنة الإجماع القياس دلالات الألفاظ الأمر والنهي العام والخاص المطلق والمقيد" },
        { title: "معركة عين جالوت", section: "التاريخ الإسلامي", url: "history.html", content: "المغول التتار سيف الدين قطز الظاهر بيبرس المماليك إنقاذ العالم الإسلامي" }
    ];

    const input = document.getElementById('megaSearchInput');
    const resultsList = document.getElementById('resultsList');
    const resultsCount = document.getElementById('resultsCount');
    const countNum = document.getElementById('countNum');

    function highlightText(text, keyword) {
        if (!keyword) return text;
        const regex = new RegExp(`(${keyword})`, "gi");
        return text.replace(regex, `<span class="highlight">$1</span>`);
    }

    input.addEventListener('input', function(e) {
        const query = e.target.value.trim().toLowerCase();
        
        if (query.length === 0) {
            resultsCount.classList.add('d-none');
            resultsList.innerHTML = `
                <div class="empty-state bg-white rounded-4 shadow-sm border p-5">
                    <i class="fas fa-keyboard fa-4x text-light mb-4 text-opacity-50"></i>
                    <h3 class="amiri fw-bold text-dark">ابدأ بكتابة الكلمات المفتاحية</h3>
                    <p class="fs-5">ستظهر النتائج المطابقة هنا فوراً وبشكل تلقائي.</p>
                </div>
            `;
            return;
        }

        const filtered = encyclopediaData.filter(item => 
            item.title.toLowerCase().includes(query) || 
            item.content.toLowerCase().includes(query) ||
            item.section.toLowerCase().includes(query)
        );

        resultsCount.classList.remove('d-none');
        countNum.textContent = filtered.length;

        if (filtered.length === 0) {
            resultsList.innerHTML = `
                <div class="empty-state bg-white rounded-4 shadow-sm border p-5">
                    <i class="fas fa-search-minus fa-4x text-warning mb-4"></i>
                    <h3 class="amiri fw-bold text-dark">عذراً، لا توجد نتائج مطابقة!</h3>
                    <p class="fs-5">يرجى المحاولة بكلمات بديلة (مثل: البقرة، الزكاة، أحد).</p>
                </div>
            `;
            return;
        }

        let html = '';
        filtered.forEach(res => {
            // Find context snippet
            let snippet = res.content;
            const idx = snippet.toLowerCase().indexOf(query);
            if (idx > -1) {
                const start = Math.max(0, idx - 40);
                const end = Math.min(snippet.length, idx + query.length + 40);
                snippet = (start > 0 ? "... " : "") + snippet.substring(start, end) + (end < snippet.length ? " ..." : "");
            } else {
                snippet = snippet.substring(0, 100) + "...";
            }

            html += `
                <a href="${res.url}" class="result-card">
                    <span class="result-badge"><i class="fas fa-bookmark me-2"></i>${highlightText(res.section, query)}</span>
                    <h3 class="result-title">${highlightText(res.title, query)}</h3>
                    <p class="result-snippet mb-0">${highlightText(snippet, query)}</p>
                </a>
            `;
        });

        resultsList.innerHTML = html;
    });
</script>
</body>
</html>
