import re
import json

file_path = r"c:\Users\ST\Desktop\islamic.encyclopedia\books.js"

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

# Extract the JSON array part
json_str_match = re.search(r'const booksData = (\[.*?\]);', content, re.DOTALL)
if json_str_match:
    json_str = json_str_match.group(1)
    
    # Ensure keys are quoted to be valid JSON (if they aren't already from previous python json.dumps edit)
    # The previous edits generated valid JSON inside books.js but let's be safe.
    try:
        books = json.loads(json_str)
        
        # Remove duplicates based on title
        unique_books = []
        seen_titles = set()
        
        for book in books:
            title = book.get("title", "").strip()
            if title not in seen_titles:
                seen_titles.add(title)
                unique_books.append(book)
                
        # Write back
        new_json_str = json.dumps(unique_books, ensure_ascii=False, indent=4)
        new_content = f"const booksData = {new_json_str};\n"
        
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(new_content)
            
        print(f"Removed duplicates. Original count: {len(books)}, New count: {len(unique_books)} ({len(books) - len(unique_books)} removed)")
    except json.JSONDecodeError as e:
        # If the manual replacements introduced trailing commas or unquoted keys
        print(f"Error decoding JSON: {e}")
        # Very simple fallback for valid python-like json
        import ast
        try:
            # We must convert json string from js object notation if it's strict
            # but our manual adds were strictly formatted for JSON
            books_ast = ast.literal_eval(json_str)
            unique_books = []
            seen_titles = set()
            for book in books_ast:
                title = book.get("title", "").strip()
                if title not in seen_titles:
                    seen_titles.add(title)
                    unique_books.append(book)
                    
            new_json_str = json.dumps(unique_books, ensure_ascii=False, indent=4)
            new_content = f"const booksData = {new_json_str};\n"
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(new_content)
            print(f"Used AST fallback. New count: {len(unique_books)}")
        except Exception as ex:
             print(f"AST also failed: {ex}")
else:
    print("Could not find booksData array in books.js")
