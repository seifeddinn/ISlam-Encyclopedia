import codecs
import re

def extract_block(html, start_marker, end_marker):
    start = html.find(start_marker)
    if start == -1: return ""
    # Find the matching closing tag or just use string split if simple enough
    # For simplicity, we just find the string between start_marker and some known text
    return html.split(start_marker)[1].split(end_marker)[0]

try:
    with codecs.open(r"C:\Users\ST\Desktop\islamic.encyclopedia\sahaba.html", 'r', 'utf-8') as f:
        shb = f.read()
except Exception as e:
    print("Could not read sahaba.html:", e)
    exit(1)

# Extract Nav items from Sahaba
# <ul class="nav sec-tabs" id="aTabs" role="tablist"> ... </ul>
nav_match = re.search(r'<ul class="nav sec-tabs".*?>(.*?)</ul>', shb, re.DOTALL)
if nav_match:
    shb_navs = nav_match.group(1)
    # Remove 'active' class and 'show' from sahaba navs so they don't conflict
    shb_navs = shb_navs.replace('active', '')
else:
    print("Could not find navs in sahaba")
    exit(1)

# Extract Tab Contents from Sahaba
# <div class="tab-content"> ... </div><!-- /tab-content -->
tabs_match = re.search(r'<div class="tab-content">(.*?)</div><!-- /tab-content -->', shb, re.DOTALL)
if tabs_match:
    shb_tabs = tabs_match.group(1)
    # Remove 'show active' from sahaba tabs
    shb_tabs = shb_tabs.replace('show active', '')
    shb_tabs = shb_tabs.replace('active', '')
else:
    print("Could not find tabs in sahaba")
    exit(1)

# Now read seerah.html
try:
    with codecs.open(r"C:\Users\ST\Desktop\islamic.encyclopedia\seerah.html", 'r', 'utf-8') as f:
        srh = f.read()
except Exception as e:
    print("Could not read seerah.html:", e)
    exit(1)

# Inject Navs
srh = srh.replace('</ul>\n\n<div class="tab-content">', shb_navs + '\n</ul>\n\n<div class="tab-content">')

# Inject Tabs
srh = srh.replace('</div><!-- /tab-content -->', shb_tabs + '\n</div><!-- /tab-content -->')

# Save merged seerah.html
with codecs.open(r"C:\Users\ST\Desktop\islamic.encyclopedia\seerah.html", 'w', 'utf-8') as f:
    f.write(srh)

print("Merged sahaba.html into seerah.html successfully!")
