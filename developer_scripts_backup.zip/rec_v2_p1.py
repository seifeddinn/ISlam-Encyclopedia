<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>أكاديمية القرآن والتلاوات - الموسوعة الإسلامية الشاملة</title>
<link href="https://fonts.googleapis.com/css2?family=Amiri:ital,wght@0,400;0,700;1,400&family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root{--gold:#c9a66b;--gold2:#e8d5a3;--dark:#01121a;--cyan:#05708a;--cyan-dark:#033547;--emerald:#059669;}
body{font-family:'Cairo',sans-serif;background:#f4f9f9;color:#1c2528;overflow-x:hidden;padding-bottom:100px;}
h1,h2,h3,h4,.ar, .quran-text{font-family:'Amiri',serif;}

/* NAVBAR */
.navbar {background:linear-gradient(135deg,#01121a,#033547)!important;box-shadow:0 4px 20px rgba(0,0,0,.4);z-index:1000;}
.navbar-brand{font-family:'Amiri',serif;font-size:1.6rem;color:white!important;}
.nav-link{color:rgba(255,255,255,.8)!important;font-weight:700;}
.nav-link:hover, .nav-link.active{color:var(--gold)!important;}

/* HERO */
.rec-hero{min-height:550px;background:linear-gradient(160deg,#01121a 0%,#033547 50%,#05708a 100%);position:relative;overflow:hidden;display:flex;align-items:center;padding:80px 0;}
.orb{position:absolute;border-radius:50%;filter:blur(100px);opacity:.2;animation:orb 12s infinite alternate;}
.orb:nth-child(1){width:500px;height:500px;background:#c9a66b;top:-100px;right:-100px;}
.orb:nth-child(2){width:400px;height:400px;background:#059669;bottom:-80px;left:0%;animation-delay:4s;}
@keyframes orb{from{transform:scale(1) translate(0,0)}to{transform:scale(1.2) translate(30px,30px)}}
.hero-pattern{position:absolute;inset:0;background:url('https://www.transparenttextures.com/patterns/arabesque.png');opacity:.07;}
.hero-content{position:relative;z-index:5;color:white;}
.hero-eyebrow{display:inline-block;border:1px solid rgba(201,166,107,.4);background:rgba(201,166,107,.1);backdrop-filter:blur(10px);color:var(--gold2);border-radius:40px;padding:8px 24px;font-size:.85rem;font-weight:700;margin-bottom:20px;}
.hero h1{font-size:3.8rem;font-weight:bold;margin-bottom:15px;background:linear-gradient(135deg,#fff 30%,var(--gold2) 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;line-height:1.3;}
.tagline{color:rgba(255,255,255,.7);font-size:1.15rem;margin-bottom:35px;line-height:2;max-width:700px;}

/* MAIN TABS NAV */
.main-tabs{background:white;border-radius:60px;padding:10px;box-shadow:0 15px 40px rgba(5,112,138,.08);margin:-40px auto 50px;max-width:1100px;display:flex;position:relative;z-index:10;border:1px solid rgba(5,112,138,.05);overflow-x:auto;}
.main-tabs::-webkit-scrollbar{height:0;}
.main-tabs .nav-item{flex:1;min-width:140px;}
.main-tabs .nav-link{border:none;border-radius:50px;color:#444;font-weight:bold;padding:15px 10px;width:100%;text-align:center;transition:all .35s;font-size:.95rem;white-space:nowrap;}
.main-tabs .nav-link:hover{color:var(--cyan);background:rgba(5,112,138,.03);}
.main-tabs .nav-link.active{background:linear-gradient(135deg,#05708a,#033547);color:white;box-shadow:0 8px 20px rgba(5,112,138,.3);}

/* SEC HEAD */
.sec-head{text-align:center;margin-bottom:50px;}
.sec-head .tag{display:inline-block;background:rgba(5,112,138,.08);color:var(--cyan);border-radius:40px;padding:6px 20px;font-size:.85rem;font-weight:800;margin-bottom:15px;}
.sec-head h3{font-size:2.5rem;color:#033547;font-weight:900;margin-bottom:10px;}
.sec-head h3 span{color:var(--gold);}
.sec-head p{color:#64748b;max-width:650px;margin:0 auto;font-size:1.05rem;line-height:1.8;}
.sec-head .divider{width:60px;height:4px;background:linear-gradient(90deg,var(--gold),var(--gold2));border-radius:2px;margin:15px auto 0;}

/* QURAN TAB */
.search-container{background:white;border-radius:20px;padding:15px;box-shadow:0 10px 30px rgba(0,0,0,.04);margin-bottom:30px;display:flex;align-items:center;}
.search-container input{border:none;outline:none;flex:1;font-size:1.1rem;padding:10px;}
.search-container .btn-group .btn{border-radius:10px;margin:0 5px;font-weight:700;}
.surah-card{background:white;border-radius:15px;padding:20px;display:flex;align-items:center;box-shadow:0 5px 15px rgba(0,0,0,.03);transition:.3s;border:1px solid rgba(0,0,0,.03);cursor:pointer;position:relative;}
.surah-card:hover{transform:translateY(-4px);box-shadow:0 12px 25px rgba(5,112,138,.1);border-color:var(--gold);}
.surah-num{width:50px;height:50px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.3rem;font-weight:bold;color:var(--cyan);background:rgba(5,112,138,.08);margin-left:15px;flex-shrink:0;}
.surah-card h5{margin:0;font-size:1.5rem;font-family:'Amiri',serif;color:#1c2528;}
.btn-play-s{position:absolute;left:20px;top:50%;transform:translateY(-50%);background:var(--cyan);color:white;width:40px;height:40px;border-radius:50%;display:flex;align-items:center;justify-content:center;border:none;opacity:0;transition:.3s;}
.surah-card:hover .btn-play-s{opacity:1;}

/* 10 QIRAAT TREE */
.qiraat-tree-box{background:white;border-radius:24px;padding:40px;box-shadow:0 15px 40px rgba(0,0,0,.05);position:relative;overflow:hidden;border-top:5px solid var(--gold);}
.imam-box{background:linear-gradient(135deg,#033547,#05708a);color:white;border-radius:16px;padding:20px;text-align:center;box-shadow:0 10px 25px rgba(5,112,138,.2);position:relative;z-index:2;margin-bottom:20px;}
.imam-box h4{font-weight:bold;margin-top:10px;}
.rawi-box{background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;padding:15px;text-align:center;color:#334155;font-weight:bold;transition:.3s;cursor:pointer;}
.rawi-box:hover{background:var(--cyan);color:white;border-color:var(--cyan);box-shadow:0 10px 20px rgba(5,112,138,.15);transform:translateY(-3px);}
.connector-line{position:absolute;width:2px;background:#cbd5e1;z-index:1;}

/* MAQAMAT (NEW) */
.maqam-card{border-radius:20px;overflow:hidden;box-shadow:0 10px 30px rgba(0,0,0,.06);transition:.4s;background:white;height:100%;}
.maqam-card:hover{transform:translateY(-8px);box-shadow:0 20px 40px rgba(0,0,0,.12);}
.maqam-header{padding:30px;background:linear-gradient(135deg,#033547,#01121a);color:white;position:relative;overflow:hidden;text-align:center;}
.maqam-header::after{content:'🎵';position:absolute;right:-10px;bottom:-20px;font-size:5rem;opacity:.05;}
.maqam-header h3{font-family:'Amiri',serif;font-weight:bold;color:var(--gold);}
.maqam-body{padding:30px;}
.maqam-feature{display:flex;align-items:center;gap:12px;margin-bottom:15px;color:#475569;}
.btn-maqam-play{background:rgba(5,112,138,.1);color:var(--cyan);border:none;border-radius:30px;padding:10px 20px;font-weight:bold;width:100%;transition:.3s;}
.btn-maqam-play:hover{background:var(--cyan);color:white;}

/* TAJWEED & MAKHARIJ */
.tajweed-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:25px;}
.taj-item{background:white;border-radius:20px;padding:25px;border-right:4px solid var(--emerald);box-shadow:0 10px 25px rgba(0,0,0,.04);transition:.3s;}
.taj-item:hover{transform:translateX(-5px);box-shadow:0 15px 35px rgba(5,150,105,.1);}
.taj-icon{width:55px;height:55px;border-radius:15px;background:rgba(5,150,105,.1);color:var(--emerald);display:flex;align-items:center;justify-content:center;font-size:1.8rem;margin-bottom:15px;}
.makharij-img{width:100%;border-radius:20px;box-shadow:0 10px 30px rgba(0,0,0,.1);}

/* RECITER LEGENDS */
.legend-card{background:white;border-radius:20px;overflow:hidden;box-shadow:0 15px 35px rgba(0,0,0,.08);transition:.4s;text-align:center;position:relative;}
.legend-card:hover{transform:translateY(-10px);box-shadow:0 25px 50px rgba(5,112,138,.15);}
.l-img{width:100%;height:220px;background:linear-gradient(135deg,#e2e8f0,#cbd5e1);display:flex;align-items:center;justify-content:center;position:relative;}
.l-img i{font-size:6rem;color:#94a3b8;opacity:.5;}
.l-badge{position:absolute;top:15px;right:15px;background:var(--gold);color:#01121a;padding:5px 15px;border-radius:20px;font-weight:bold;font-size:.8rem;box-shadow:0 5px 15px rgba(201,166,107,.4);}
.legend-body{padding:25px;}
.legend-body h4{font-weight:900;color:#033547;margin-bottom:5px;}

/* IJAZAH CHAIN */
.ijazah-box{background:linear-gradient(135deg,#033547,#01121a);border-radius:24px;padding:50px;color:white;text-align:center;position:relative;overflow:hidden;}
.chain-step{display:inline-block;background:rgba(255,255,255,.1);border:1px solid rgba(201,166,107,.3);padding:15px 30px;border-radius:50px;font-family:'Amiri',serif;font-size:1.5rem;color:var(--gold2);margin:10px;backdrop-filter:blur(5px);}

/* GLOBAL PLAYER */
.global-player{position:fixed;bottom:0;left:0;right:0;background:rgba(2,26,36,0.95);backdrop-filter:blur(20px);border-top:1px solid rgba(201,166,107,.3);padding:15px 0;z-index:1050;transform:translateY(100%);transition:.4s cubic-bezier(0.175,0.885,0.32,1.275);}
.global-player.active{transform:translateY(0);}

/* MODALS */
.quran-reader{font-family:'Amiri',serif;font-size:2.2rem;line-height:2.3;text-align:center;padding:30px;}
.quran-reader span.verse{display:inline;position:relative;color:#01121a;transition:color .3s;}
.quran-reader span.verse:hover{color:var(--cyan);background:rgba(5,112,138,.05);border-radius:5px;}
.v-num{display:inline-flex;align-items:center;justify-content:center;width:40px;height:40px;background:url('https://upload.wikimedia.org/wikipedia/commons/e/e4/Aya_symbol.svg') no-repeat center center;background-size:contain;font-size:1rem;color:var(--cyan);margin:0 15px;vertical-align:middle;}
</style>

</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold" href="index.html"><i class="fas fa-book-open me-2 text-warning"></i>الموسوعة الإسلامية الشاملة</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav1">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="nav1">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link " href="index.html">الرئيسية</a></li>
        <li class="nav-item"><a class="nav-link " href="recitations.html">القرآن والتلاوات</a></li>
        <li class="nav-item"><a class="nav-link " href="hadith.html">الحديث الشريف</a></li>
        <li class="nav-item"><a class="nav-link " href="fiqh.html">الفقه الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="fatwa.html">فتاوى العلماء <i class="fas fa-gavel"></i></a></li>
        <li class="nav-item"><a class="nav-link " href="seerah.html">السيرة والصحابة</a></li>
        <li class="nav-item"><a class="nav-link " href="aqeedah.html">العقيدة الإسلامية</a></li>
        <li class="nav-item"><a class="nav-link " href="history.html">التاريخ الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="library.html">المكتبة الشاملة</a></li>
      </ul>
    </div>
  </div>
</nav>

<section class="rec-hero">
  <div class="orb"></div><div class="orb"></div>
  <div class="hero-pattern"></div>
  <div class="container hero-content">
    <div class="row align-items-center g-5">
      <div class="col-lg-7 text-lg-start text-center">
        <div class="hero-eyebrow"><i class="fas fa-crown me-2"></i>أكبر مرجع رقمي لعلوم القرآن</div>
        <h1>أكاديمية التلاوات<br>وعلوم القراءات</h1>
        <p class="tagline">اقرأ واستمع للقرآن الكريم، واكتشف النغمات والمقامات القرآنية، وتعرف على القراءات العشر المتواترة، وتدرج في علوم التجويد ومخارج الحروف حتى الإجازة.</p>
      </div>
      <div class="col-lg-5 d-none d-lg-block text-center position-relative">
        <div style="position:absolute;inset:0;border:2px dashed rgba(201,166,107,.3);border-radius:50%;width:350px;height:350px;margin:0 auto;animation:spin 40s linear infinite;"></div>
        <i class="fas fa-book-open" style="font-size:12rem;color:var(--gold);filter:drop-shadow(0 0 30px rgba(201,166,107,.4));line-height:350px;"></i>
      </div>
    </div>
  </div>
</section>

<div class="container mb-5">
  <ul class="nav main-tabs" id="myTab" role="tablist">
    <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#t-quran"><i class="fas fa-quran me-2"></i>المصحف الشريف</button></li>
    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t-10"><i class="fas fa-tree me-2"></i>القراءات العشر</button></li>
    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t-maqam"><i class="fas fa-music me-2"></i>المقامات القرآنية</button></li>
    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t-taj"><i class="fas fa-microphone-alt me-2"></i>علم التجويد</button></li>
    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t-qura"><i class="fas fa-headphones me-2"></i>أساطير التلاوة</button></li>
    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#t-ijazah"><i class="fas fa-certificate me-2"></i>الإجازة والسند</button></li>
  </ul>
  <div class="tab-content" id="myTabContent">
