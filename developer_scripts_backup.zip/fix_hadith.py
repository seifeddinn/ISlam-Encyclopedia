import codecs

html = codecs.open('hadith.html', 'r', 'utf-8').read()
start_idx = html.find('function performHadithSearch()')
end_idx = html.find('</script>', start_idx)

js_replace = '''function performHadithSearch() {
    const query = document.getElementById('hadithSearchInput').value.trim();
    const resultsContainer = document.getElementById('hadithSearchResults');
    const resultsList = document.getElementById('hadithResultsList');
    const countBadge = document.getElementById('hadithResultCount');
    
    if(!query) return;
    
    // Merge Nawawi to Full DB
    let fullDB = [...hadithDatabase];
    if(typeof nawawiData !== 'undefined') {
        nawawiData.forEach(n => {
            fullDB.push({text: n.text, book: 'الأربعون النووية — ' + n.narrator, حكم: 'صحيح/حسن'});
        });
    }
    
    resultsContainer.classList.remove('d-none');
    resultsList.innerHTML = `<div class="text-center py-4"><div class="spinner-border text-primary"></div><p class="mt-2 text-muted">جاري البحث ومطابقة المصادر...</p></div>`;
    
    setTimeout(() => {
        const matches = fullDB.filter(h => h.text.includes(query) || h.book.includes(query));
        countBadge.innerText = matches.length;
        
        let out = '';
        if(matches.length > 0) {
            matches.forEach(m => {
                const highlightedText = m.text.replace(new RegExp(query, 'gi'), match => `<mark class="bg-warning text-dark px-1 rounded">${match}</mark>`);
                out += `
                    <div class="mb-3 p-3 bg-light rounded-3 border border-light shadow-sm">
                        <p class="font-amiri fs-4 fw-bold mb-2 text-dark">« ${highlightedText} »</p>
                        <div class="d-flex gap-2">
                            <span class="badge bg-primary px-3 py-2"><i class="fas fa-book me-1"></i> ${m.book}</span>
                            <span class="badge bg-success px-3 py-2"><i class="fas fa-check-circle me-1"></i> ${m.حكم}</span>
                        </div>
                    </div>
                `;
            });
        } else {
            out = `<div class="alert alert-warning text-center fw-bold"><i class="fas fa-exclamation-circle me-2"></i>عذراً، لم نجد نتائج مطابقة في القاعدة المحلية المصغرة.</div>`;
        }
        
        // Always show Dorar link
        out += `
            <div class="text-center mt-5 pt-4 border-top border-2 border-primary border-opacity-10">
               <h5 class="text-primary fw-bold font-amiri mb-3"><i class="fas fa-search-plus text-warning me-2"></i>الباحث الحديثي الشامل</h5>
               <p class="text-muted small mb-4">للتحقق من مئات الآلاف من الأحاديث والتخريجات العلمية، ابحث في موسوعة الدرر السنية.</p>
               <a href="https://dorar.net/hadith/search?q=${encodeURIComponent(query)}" target="_blank" class="btn btn-outline-primary rounded-pill px-5 py-2 fw-bold shadow-sm" style="transition:0.3s; border-width:2px; font-family:'Amiri',serif; font-size:1.2rem;">
                  ابحث في الدرر السنية عن : "${query}" <i class="fas fa-external-link-alt ms-2 shrink-0"></i>
               </a>
            </div>
        `;
        
        resultsList.innerHTML = out;
    }, 800);
}
'''

if start_idx != -1 and end_idx != -1:
    html = html[:start_idx] + js_replace + html[end_idx:]
    codecs.open('hadith.html', 'w', 'utf-8').write(html)
    print("Replaced successfully!")
else:
    print("Indices not found!")
