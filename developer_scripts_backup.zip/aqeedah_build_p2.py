import codecs

part2 = """
<!-- TAB 2: ARKAN -->
<div class="tab-pane fade" id="t-arkan">
  <div class="sec-head">
    <span class="tag">الأسس الستة</span>
    <h3>أركان <span>الإيمان</span></h3>
    <p>الأصول الستة التي لا يصح إيمان العبد إلا بها، مبنية على حديث جبريل عليه السلام</p>
    <div class="divider"></div>
  </div>

  <div class="row g-4 mb-5">
    <!-- Rukn 1 -->
    <div class="col-md-6">
      <div class="rukn-card">
        <div class="rukn-num">١</div>
        <div>
          <h5 style="color:#0a2540;font-weight:700;">الإيمان بالله تعالى</h5>
          <p class="text-muted small mb-0">التصديق الجازم بوجوده، وبأنه رب كل شيء ومليكه، وأنه المستحق للعبادة وحده دون سواه، وأنه مُتصف بصفات الكمال ومُنزه عن كل نقص. يتضمن توحيد الربوبية والألوهية والأسماء والصفات.</p>
        </div>
      </div>
    </div>
    <!-- Rukn 2 -->
    <div class="col-md-6">
      <div class="rukn-card">
        <div class="rukn-num">٢</div>
        <div>
          <h5 style="color:#0a2540;font-weight:700;">الإيمان بالملائكة</h5>
          <p class="text-muted small mb-0">أنهم عالم غيبي، خُلقوا من نور، لا يأكلون ولا يشربون، ولا يعصون الله ما أمرهم ويفعلون ما يُؤمرون. لكل منهم وظيفة، منهم جبريل الموكل بالوحي، وميكائيل للقطر، وإسرافيل للنفخ في الصور.</p>
        </div>
      </div>
    </div>
    <!-- Rukn 3 -->
    <div class="col-md-6">
      <div class="rukn-card">
        <div class="rukn-num">٣</div>
        <div>
          <h5 style="color:#0a2540;font-weight:700;">الإيمان بالكتب السماوية</h5>
          <p class="text-muted small mb-0">التصديق بأن الله أنزل كتباً على رسله، كالقرآن على محمد، والتوراة على موسى، والإنجيل على عيسى، والزبور على داود. والإيمان بأن القرآن الكريم هو خاتمها وناسخها والمهيمن عليها ومحفوظ من التحريف.</p>
        </div>
      </div>
    </div>
    <!-- Rukn 4 -->
    <div class="col-md-6">
      <div class="rukn-card">
        <div class="rukn-num">٤</div>
        <div>
          <h5 style="color:#0a2540;font-weight:700;">الإيمان بالرسل</h5>
          <p class="text-muted small mb-0">بعث الله في كل أمة رسولاً يدعوهم إلى عبادة الله المحض، أولهم نوح وآخرهم محمد ﷺ. نتساوى في تصديقهم ولا نفرق بين أحد من رسله. والإيمان بعصمتهم فيما يبلغونه عن الله.</p>
        </div>
      </div>
    </div>
    <!-- Rukn 5 -->
    <div class="col-md-6">
      <div class="rukn-card">
        <div class="rukn-num">٥</div>
        <div>
          <h5 style="color:#0a2540;font-weight:700;">الإيمان باليوم الآخر</h5>
          <p class="text-muted small mb-0">كل ما أخبر به الله ورسوله مما يكون بعد الموت؛ من فتنة القبر وعذابه ونعيمه، والبعث، والنشور، والحساب، والمرور على الصراط، والميزان، وشفاعة النبي، والجنة كدار نعيم، والنار كدار عذاب.</p>
        </div>
      </div>
    </div>
    <!-- Rukn 6 -->
    <div class="col-md-6">
      <div class="rukn-card">
        <div class="rukn-num">٦</div>
        <div>
          <h5 style="color:#0a2540;font-weight:700;">الإيمان بالقدر خيره وشره</h5>
          <p class="text-muted small mb-0">العقيدة بأن الله علم مقادير الأشياء وكتبها باللوح المحفوظ، فلا يقع شيء إلا بمشيئته سبحانه، ومن خلقه. مراتب القدر أربعة: العلم، الكتابة، المشيئة، والخلق.</p>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- TAB 3: ASMA -->
<div class="tab-pane fade" id="t-asma">
  <div class="sec-head">
    <span class="tag">وصف الله بما وصف به نفسه</span>
    <h3>الأسماء <span>والصفات</span></h3>
    <p>القواعد الجليلة في أسماء الله الحسنى وصفاته العلى</p>
    <div class="divider"></div>
  </div>

  <div class="row mb-4 align-items-center">
    <div class="col-lg-6">
      <h4 class="mb-3" style="color:#0a2540;font-weight:800;">قواعد الأسماء والصفات عند أهل السنة والجماعة</h4>
      <p style="line-height:2;color:#555;">منهج أهل السنة والجماعة في أسماء الله وصفاته يقوم على الإيمان بكل ما ورد في القرآن الكريم وصحيح السنة النبوية دون إفراط أو تفريط. ويرتكز على أربع لاءات عظيمة:</p>
      
      <ul class="list-unstyled mt-4">
        <li class="mb-3 d-flex align-items-start gap-3">
          <i class="fas fa-times-circle mt-1" style="color:#e74c3c;font-size:1.2rem;"></i>
          <div><strong style="color:#0a2540;">من غير تحريف (تأويل):</strong> لا نغير اللفظ ولا نغير المعنى عن ظاهره كما فعلت بعض الفرق.</div>
        </li>
        <li class="mb-3 d-flex align-items-start gap-3">
          <i class="fas fa-times-circle mt-1" style="color:#e74c3c;font-size:1.2rem;"></i>
          <div><strong style="color:#0a2540;">من غير تعطيل:</strong> لا ننفي الصفة التي أثبتها الله لنفسه ولا نفرغها من محتواها.</div>
        </li>
        <li class="mb-3 d-flex align-items-start gap-3">
          <i class="fas fa-times-circle mt-1" style="color:#e74c3c;font-size:1.2rem;"></i>
          <div><strong style="color:#0a2540;">من غير تكييف:</strong> لا نسأل "كيف؟" ولا نتخيل أو نفترض شكلاً وهيئة معينة للصفة العظيمة.</div>
        </li>
        <li class="mb-3 d-flex align-items-start gap-3">
          <i class="fas fa-times-circle mt-1" style="color:#e74c3c;font-size:1.2rem;"></i>
          <div><strong style="color:#0a2540;">من غير تمثيل:</strong> لا نشبه صفات الخالق بصفات المخلوقين أبداً.</div>
        </li>
      </ul>
    </div>
    <div class="col-lg-6 mt-4 mt-lg-0">
      <div style="background:white;padding:30px;border-radius:20px;box-shadow:0 10px 40px rgba(10,37,64,.08);position:relative;">
        <i class="fas fa-quote-right" style="position:absolute;top:20px;right:25px;font-size:3rem;color:rgba(201,166,107,.15);"></i>
        <h5 class="mb-3" style="color:#15457a;font-weight:700;">القاعدة الذهبية</h5>
        <h3 style="font-family:'Amiri',serif;color:#0a2540;line-height:1.7;" class="text-center my-4">﴿ لَيْسَ كَمِثْلِهِ شَيْءٌ<br><span style="color:var(--gold);">وَهُوَ السَّمِيعُ البَصِيرُ ﴾</span></h3>
        <p class="text-muted small text-center mb-0">نفي المماثلة (التمثيل) في الشطر الأول، ثم إثبات الصفتين (السمع والبصر) في الشطر الثاني.</p>
        <hr class="my-4">
        <h5 class="mb-2" style="color:#15457a;font-weight:700;font-size:.9rem;">قاعدة الإمام مالك في الاستواء:</h5>
        <p class="text-muted small mb-0" style="line-height:1.8;">"الاستواء غير مجهول، والكيف غير معقول، والإيمان به واجب، والسؤال عنه بدعة". وهذه القاعدة تُطبّق على سائر الصفات كالنزول والمجيء واليد وغيرها.</p>
      </div>
    </div>
  </div>

  <h5 class="mt-5 mb-4" style="color:#0a2540;border-right:4px solid var(--gold);padding-right:15px;">من أسماء الله الحسنى ومعانيها (أمثلة)</h5>
  <div class="row g-3">
    <div class="col-md-3 col-6"><div class="p-3 bg-white rounded shadow-sm text-center border-bottom border-warning"><h4 class="ar text-primary">الرحمن</h4><small class="text-muted">ذو الرحمة الواسعة</small></div></div>
    <div class="col-md-3 col-6"><div class="p-3 bg-white rounded shadow-sm text-center border-bottom border-warning"><h4 class="ar text-primary">القدوس</h4><small class="text-muted">المنزه عن كل عيب</small></div></div>
    <div class="col-md-3 col-6"><div class="p-3 bg-white rounded shadow-sm text-center border-bottom border-warning"><h4 class="ar text-primary">المهيمن</h4><small class="text-muted">المطلع الرقيب على كل شيء</small></div></div>
    <div class="col-md-3 col-6"><div class="p-3 bg-white rounded shadow-sm text-center border-bottom border-warning"><h4 class="ar text-primary">الجبار</h4><small class="text-muted">الذي يقهر العباد على ما أراد</small></div></div>
    <div class="col-md-3 col-6"><div class="p-3 bg-white rounded shadow-sm text-center border-bottom border-warning"><h4 class="ar text-primary">الرزاق</h4><small class="text-muted">مُقدر الأرزاق ومعطيها</small></div></div>
    <div class="col-md-3 col-6"><div class="p-3 bg-white rounded shadow-sm text-center border-bottom border-warning"><h4 class="ar text-primary">السميع</h4><small class="text-muted">الذي أحاط سمعه بكل شيء</small></div></div>
    <div class="col-md-3 col-6"><div class="p-3 bg-white rounded shadow-sm text-center border-bottom border-warning"><h4 class="ar text-primary">الحكم</h4><small class="text-muted">الذي إليه الحكم ولا راد لقضائه</small></div></div>
    <div class="col-md-3 col-6"><div class="p-3 bg-white rounded shadow-sm text-center border-bottom border-warning"><h4 class="ar text-primary">اللطيف</h4><small class="text-muted">البر بعباده الرفيق بهم</small></div></div>
  </div>
</div>
"""

with codecs.open(r"C:\Users\ST\Desktop\islamic.encyclopedia\aq_p2.tmp", 'w', 'utf-8') as f:
    f.write(part2)
print("Aqeedah part 2 ready")
