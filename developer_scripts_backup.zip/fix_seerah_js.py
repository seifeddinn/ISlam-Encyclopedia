import codecs

filepath = r"C:\Users\ST\Desktop\islamic.encyclopedia\seerah.html"

with codecs.open(filepath, 'r', 'utf-8') as f:
    html = f.read()

bad_str = """<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
@keyframes spin{from{transform:rotate(0)}to{transform:rotate(360deg)}}
// Timeline scroll animation"""

good_str = """<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<style>@keyframes spin{from{transform:rotate(0)}to{transform:rotate(360deg)}}</style>
<script>
// Timeline scroll animation"""

if bad_str in html:
    html = html.replace(bad_str, good_str)
    with codecs.open(filepath, 'w', 'utf-8') as f:
        f.write(html)
    print("Fixed script error in seerah.html!")
else:
    print("Error string not found. Trying flexible replace...")
    html = html.replace("@keyframes spin{from{transform:rotate(0)}to{transform:rotate(360deg)}}", "")
    html = html.replace("<script>\n// Timeline", "<style>@keyframes spin{from{transform:rotate(0)}to{transform:rotate(360deg)}}</style>\n<script>\n// Timeline")
    with codecs.open(filepath, 'w', 'utf-8') as f:
        f.write(html)
    print("Fixed via flexible replace.")
