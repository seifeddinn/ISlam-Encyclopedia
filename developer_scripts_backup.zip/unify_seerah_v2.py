<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>أكاديمية السيرة النبوية والصحابة - الموسوعة الإسلامية الشاملة</title>
<meta name="description" content="الموسوعة الإسلامية الشاملة - المنصة الرقمية الموثوقة لعلوم القرآن والسنة والفقه والسيرة والتاريخ بعقيدة صحيحة.">
<meta name="keywords" content="قرآن, حديث, إسلام, فقه, عقيدة, سيرة, تاريخ إسلامي, الموسوعة الإسلامية">
<meta name="author" content="لخذاري محمد سيف الدين">
<link href="https://fonts.googleapis.com/css2?family=Amiri:ital,wght@0,400;0,700;1,400&family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root{--gold:#d4af37;--gold-light:#f9f1d8;--gold-dark:#aa8a2a;--dark:#450a0a;--primary:#b91c1c;--secondary:#991b1b;}
body{font-family:'Cairo',sans-serif;background:#f8fafc;color:#1e293b;overflow-x:hidden;}
h1,h2,h3,h4,h5,h6,.amiri,.font-amiri{font-family:'Amiri',serif;}
.line-height-2{line-height:2 !important;}
/* MEGA NAVBAR */
.navbar {background:linear-gradient(135deg,var(--dark),var(--primary))!important;box-shadow:0 4px 30px rgba(0,0,0,.5);z-index:1000;border-bottom:2px solid rgba(212,175,55,0.2);}
.navbar-brand{font-family:'Amiri',serif;font-size:1.8rem;color:white!important;text-shadow:0 2px 10px rgba(212,175,55,0.5);}
.nav-link{color:rgba(255,255,255,.8)!important;font-weight:700;letter-spacing:0.5px;transition:all .3s;}
.nav-link:hover, .nav-link.active{color:var(--gold)!important;transform:translateX(-2px);}

/* MEGA HERO - SEERAH (CRIMSON & GOLD) */
.mega-hero{min-height:90vh;background:radial-gradient(circle at 50% 50%, var(--primary) 0%, var(--dark) 80%);position:relative;overflow:hidden;display:flex;align-items:center;padding:120px 0;}
.hero-glass{background:rgba(69,10,10,0.5);backdrop-filter:blur(15px);border:1px solid rgba(212,175,55,0.3);border-radius:30px;padding:60px 40px;box-shadow:0 20px 50px rgba(0,0,0,0.5);position:relative;z-index:5;text-align:center;}
.hero-pattern{position:absolute;inset:0;background:url('https://www.transparenttextures.com/patterns/arabesque.png');opacity:.1;mix-blend-mode:overlay;}
.hero-eyebrow{display:inline-block;background:linear-gradient(90deg,var(--gold-dark),var(--gold));color:#290202;padding:8px 30px;border-radius:50px;font-weight:bold;font-size:1rem;margin-bottom:25px;box-shadow:0 4px 15px rgba(212,175,55,0.4);}
.mega-hero h1{font-size:5.5rem;font-weight:900;color:white;text-shadow:0 10px 30px rgba(0,0,0,0.8);line-height:1.2;margin-bottom:20px;}
.mega-hero h1 span{background:linear-gradient(135deg,#fff,var(--gold));-webkit-background-clip:text;-webkit-text-fill-color:transparent;}
.tagline{color:#fee2e2;font-size:1.4rem;line-height:2;text-shadow:0 2px 4px rgba(0,0,0,0.5);max-width:800px;margin:0 auto;}

/* ANIMATED ORBS */
.orb{position:absolute;border-radius:50%;filter:blur(120px);opacity:.3;animation:floatOrb 15s ease-in-out infinite alternate;}
.orb-1{width:600px;height:600px;background:var(--gold);top:-150px;right:-100px;}
.orb-2{width:500px;height:500px;background:#ef4444;bottom:-100px;left:-50px;animation-delay:5s;}
@keyframes floatOrb{0%{transform:translate(0,0) scale(1);}100%{transform:translate(50px,50px) scale(1.1);}}

/* STATS MEGA */
.stats-mega{background:linear-gradient(90deg,var(--dark),var(--primary));border-top:2px solid var(--gold-dark);border-bottom:2px solid var(--gold-dark);padding:40px 0;position:relative;z-index:10;margin-top:-5px;}
.stat-box{text-align:center;color:white;padding:20px;border-left:1px solid rgba(212,175,55,0.2);}
.stat-box:last-child{border-left:none;}
.stat-num{font-family:'Amiri',serif;font-size:3.5rem;font-weight:bold;color:var(--gold);line-height:1;margin-bottom:10px;text-shadow:0 5px 15px rgba(212,175,55,0.3);}
.stat-label{font-size:1.1rem;font-weight:bold;letter-spacing:1px;color:#fca5a5;}

/* SECTION HEADERS */
.sec-head{text-align:center;margin-bottom:60px;position:relative;}
.sec-head .tag{display:inline-block;background:rgba(212,175,55,0.1);color:var(--gold-dark);border:1px solid rgba(212,175,55,0.3);border-radius:30px;padding:8px 25px;font-size:1rem;font-weight:bold;margin-bottom:20px;}
.sec-head h3{font-size:3rem;font-family:'Amiri',serif;color:var(--dark);font-weight:900;margin-bottom:15px;}
.sec-head h3 span{color:var(--primary);}
.sec-head p{color:#64748b;font-size:1.2rem;max-width:800px;margin:0 auto;line-height:1.8;}
.sec-head .divider{width:80px;height:5px;background:linear-gradient(90deg,var(--gold),var(--primary));border-radius:5px;margin:25px auto 0;}

/* TABS NAVIGATION MEGA */
.main-tabs-wrapper{background:white;padding:15px;border-radius:20px;box-shadow:0 10px 40px rgba(0,0,0,0.05);margin:40px auto 60px;position:sticky;top:80px;z-index:900;border:1px solid #e2e8f0; max-width:1000px;}
.main-tabs{display:flex;gap:10px;overflow-x:auto;padding-bottom:5px;border-bottom:none; justify-content:center;}
.main-tabs::-webkit-scrollbar{height:0px;}
.main-tabs .nav-link{border:1px solid #e2e8f0;border-radius:15px;color:#475569;font-weight:bold;padding:15px 30px;font-size:1.2rem;white-space:nowrap;transition:all .3s; display:flex; align-items:center; gap:10px;}
.main-tabs .nav-link:hover{background:#f8fafc;border-color:var(--gold-dark);color:var(--dark);transform:translateY(-2px);}
.main-tabs .nav-link.active{background:linear-gradient(135deg,var(--dark),var(--primary));color:white;border-color:transparent;box-shadow:0 10px 20px rgba(153,27,27,0.3);}
.main-tabs .nav-link i {font-size:1.5rem; color:var(--gold);}
.main-tabs .nav-link.active i {color:white;}

/* TIMELINE V2 */
.timeline-v2{position:relative;max-width:1100px;margin:0 auto;padding:40px 0;}
.timeline-v2::before{content:'';position:absolute;top:0;bottom:0;left:50%;width:4px;background:linear-gradient(to bottom, transparent, var(--gold), var(--primary), transparent);transform:translateX(-50%);border-radius:5px;}
.tl2-item{position:relative;margin-bottom:60px;width:50%;}
.tl2-item:nth-child(even){left:50%;padding-left:50px;}
.tl2-item:nth-child(odd){left:0;padding-right:50px;text-align:left;}
.tl2-year{position:absolute; top:20px; width:100px; height:40px; background:var(--dark); color:var(--gold); font-family:'Amiri',serif; font-weight:bold; font-size:1.2rem; display:flex; align-items:center; justify-content:center; border-radius:30px; box-shadow:0 5px 15px rgba(0,0,0,0.2); z-index:2;}
.tl2-item:nth-child(even) .tl2-year{left:-50px;}
.tl2-item:nth-child(odd) .tl2-year{right:-50px;}
@media (max-width:768px){
  .timeline-v2::before{left:30px;}
  .tl2-item{width:100%;left:0!important;padding-left:80px!important;padding-right:0!important;text-align:right!important;}
  .tl2-item .tl2-year{left:10px!important;right:auto!important; width:40px; height:40px; font-size:0.9rem; border-radius:50%;}
}
.tl2-card{background:white;padding:40px;border-radius:24px;box-shadow:0 15px 40px rgba(0,0,0,0.05);border:1px solid #fee2e2;transition:all .4s; position:relative;}
.tl2-card::before {content:''; position:absolute; top:0; left:0; width:100%; height:5px; background:linear-gradient(90deg, var(--primary), var(--gold)); border-radius:24px 24px 0 0;}
.tl2-item:hover .tl2-card{transform:translateY(-10px);box-shadow:0 20px 50px rgba(153,27,27,0.15);border-color:var(--gold);}
.tl2-title{font-family:'Amiri',serif; font-size:1.8rem; font-weight:bold; color:var(--dark); margin-bottom:15px;}

/* MEGA CARDS (MORALS) */
.moral-card{background:white;border-radius:24px;padding:40px 30px;box-shadow:0 15px 35px rgba(0,0,0,0.04);border:1px solid transparent;transition:all .4s;height:100%; text-align:center; position:relative; overflow:hidden;}
.moral-card::after {content:''; position:absolute; bottom:0; left:0; width:100%; height:4px; background:var(--gold); transform:scaleX(0); transition:0.4s; transform-origin:left;}
.moral-card:hover{transform:translateY(-10px);box-shadow:0 25px 50px rgba(153,27,27,0.1); border-color:#fee2e2;}
.moral-card:hover::after {transform:scaleX(1);}
.moral-icon{width:90px; height:90px; border-radius:50%; background:linear-gradient(135deg, rgba(153,27,27,0.1), rgba(212,175,55,0.1)); color:var(--primary); display:inline-flex; align-items:center; justify-content:center; font-size:3rem; margin-bottom:25px; transition:0.4s;}
.moral-card:hover .moral-icon{background:linear-gradient(135deg, var(--primary), var(--dark)); color:white; transform:rotateY(180deg);}

/* SAHABA COMPREHENSIVE GRID */
.sahaba-filter{display:flex; justify-content:center; gap:10px; flex-wrap:wrap; margin-bottom:40px;}
.sahaba-filter button{background:white; color:var(--dark); border:1px solid #e2e8f0; padding:10px 25px; border-radius:30px; font-weight:bold; transition:0.3s;}
.sahaba-filter button.active, .sahaba-filter button:hover{background:var(--primary); color:white; border-color:var(--primary); box-shadow:0 5px 15px rgba(153,27,27,0.3);}

.companion-card{background:linear-gradient(145deg,#fff,#fef2f2);border-radius:20px;padding:30px;text-align:center;box-shadow:0 10px 30px rgba(0,0,0,0.06);border-bottom:5px solid var(--primary);transition:.4s;height:100%; position:relative; overflow:hidden;}
.companion-card::before{content:''; position:absolute; top:-50px; left:-50px; width:100px; height:100px; background:rgba(212,175,55,0.1); border-radius:50%;}
.companion-card:hover{transform:translateY(-10px);border-color:var(--gold);}
.comp-name{font-family:'Amiri',serif;font-size:1.8rem;color:var(--dark);font-weight:bold;margin:15px 0 5px;}
.comp-badge{background:var(--dark);color:var(--gold);padding:5px 15px;border-radius:20px;font-size:0.85rem; font-weight:bold; margin-bottom:15px; display:inline-block;}

/* BATTLE MAPS (RICH) */
.map-interactive-container {background:radial-gradient(circle at center, #fdf6e3, #e8dcc4); border:4px solid var(--gold); border-radius:30px; position:relative; height:500px; overflow:hidden; box-shadow:0 30px 60px rgba(0,0,0,0.15); background-image:url('https://www.transparenttextures.com/patterns/cartographer.png'); padding:40px;}
.map-interactive-container::after {content:''; position:absolute; inset:0; border:15px solid rgba(255,255,255,0.2); border-radius:30px; pointer-events:none;}
.battle-badge {position:absolute; top:30px; right:30px; background:var(--dark); color:var(--gold); font-family:'Amiri',serif; font-size:2rem; font-weight:bold; padding:10px 30px; border-radius:15px; box-shadow:0 10px 20px rgba(0,0,0,0.3); border:2px solid var(--gold-dark); z-index:10;}
.map-team{position:absolute;padding:15px 30px;border-radius:15px;font-weight:bold;font-family:'Amiri',serif; font-size:1.2rem; color:white; box-shadow:0 10px 25px rgba(0,0,0,0.3); z-index:5;}
.team-muslim{background:linear-gradient(135deg, var(--primary), var(--dark)); border:2px solid var(--gold);}
.team-enemy{background:linear-gradient(135deg, #1e293b, #0f172a); border:2px solid #ef4444;}
.map-terrain{position:absolute; color:#92400e; font-size:1.3rem; font-weight:bold; font-family:'Amiri',serif;}
.battle-pulse {position:absolute; width:100px; height:100px; background:radial-gradient(circle, rgba(239,68,68,0.5) 0%, transparent 70%); border-radius:50%; animation:pulseMap 2s infinite;}
@keyframes pulseMap{0%{transform:scale(0.5);opacity:1;}100%{transform:scale(2.5);opacity:0;}}

/* MEGA FOOTER */
.mega-footer{background:linear-gradient(135deg,var(--dark),#020617);color:white;padding:80px 0 30px;margin-top:80px;border-top:3px solid var(--gold-dark);}
.mega-footer-link{color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;}
.mega-footer-link:hover{color:var(--gold);padding-right:5px;}
</style>
</head>
<body>

<!-- MEGA NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-dark sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold" href="index.html"><i class="fas fa-book-open me-2 text-warning"></i>الموسوعة الإسلامية الشاملة</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav1">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="nav1">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link " href="index.html">الرئيسية</a></li>
        <li class="nav-item"><a class="nav-link " href="recitations.html">القرآن والتلاوات</a></li>
        <li class="nav-item"><a class="nav-link " href="hadith.html">الحديث الشريف</a></li>
        <li class="nav-item"><a class="nav-link " href="fiqh.html">الفقه الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="fatwa.html">فتاوى العلماء <i class="fas fa-gavel"></i></a></li>
        <li class="nav-item"><a class="nav-link active" href="seerah.html">السيرة والصحابة</a></li>
        <li class="nav-item"><a class="nav-link " href="aqeedah.html">العقيدة الإسلامية</a></li>
        <li class="nav-item"><a class="nav-link " href="history.html">التاريخ الإسلامي</a></li>
        <li class="nav-item"><a class="nav-link " href="library.html">المكتبة الشاملة</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- MEGA HERO SEERAH -->
<section class="mega-hero">
  <div class="orb orb-1"></div><div class="orb orb-2"></div>
  <div class="hero-pattern"></div>
  <div class="container relative z-10">
    <div class="row justify-content-center text-center">
      <div class="col-lg-11">
        <div class="hero-glass">
            <div class="hero-eyebrow"><i class="fas fa-heart me-2 text-danger"></i>سيرة خير الأنام والجيل الفريد</div>
            <h1>موسوعة <span>السيرة</span> والصحابة</h1>
            <p class="tagline mt-4">رحلة النبوة الطاهرة، وأخلاق المصطفى ﷺ، وتاريخ الغزوات الفاصلة، ومقامات الرعيل الأول من الصحابة المبشرين وأمهات المؤمنين في مكان واحد.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- STATS BAR -->
<div class="stats-mega">
  <div class="container">
    <div class="row w-100 mx-0">
      <div class="col-6 col-md-3 stat-box"><div class="stat-num">23</div><div class="stat-label">سنة في النبوة والوحي</div></div>
      <div class="col-6 col-md-3 stat-box"><div class="stat-num">10</div><div class="stat-label">مبشرون بالجنة يقيناً</div></div>
      <div class="col-6 col-md-3 stat-box"><div class="stat-num">11</div><div class="stat-label">أمهات المؤمنين</div></div>
      <div class="col-6 col-md-3 stat-box"><div class="stat-num">∞</div><div class="stat-label">محبة وشوق للنبي ﷺ</div></div>
    </div>
  </div>
</div>

<div class="container">
  <!-- MEGA TABS NAV (Consolidated to 4 rich tabs) -->
  <div class="main-tabs-wrapper">
    <ul class="nav nav-pills main-tabs" id="seerahTabs" role="tablist">
      <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#tab-timeline"><i class="fas fa-route"></i> تسلسل السيرة</button></li>
      <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-morals"><i class="fas fa-seedling"></i> الشمائل المحمدية</button></li>
      <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-sahaba"><i class="fas fa-users"></i> الصحابة والأزواج</button></li>
      <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-battles"><i class="fas fa-map-marked-alt"></i> المعارك الفاصلة</button></li>
    </ul>
  </div>

  <div class="tab-content pb-5">
    
    <!-- TAB 1: التسلسل (TIMELINE) -->
    <div class="tab-pane fade show active" id="tab-timeline">
      <div class="sec-head">
        <span class="tag">من المولد إلى الرفيق الأعلى</span>
        <h3>التسلسل <span>الزمني</span> للسيرة الطاهرة</h3>
        <p>مراحل تبليغ الرسالة والمواقف الفارقة في حياة أشرف الخلق نبينا محمد ﷺ بطريقة تفاعلية.</p>
        <div class="divider"></div>
      </div>

      <div class="timeline-v2 mt-4">
         <div class="tl2-item">
            <div class="tl2-year">مولده</div>
            <div class="tl2-card">
               <h3 class="tl2-title text-primary"><i class="fas fa-star me-2 text-warning"></i>مولده ونشأته (عام الفيل)</h3>
               <p class="text-muted mb-0 fs-5 line-height-2">وُلد يتيماً بمكة المكرمة قُبيل الفجر يوم الاثنين 12 ربيع الأول في عام الفيل. كفله جده عبد المطلب ثم عمه أبو طالب. عُرف قبل البعثة بالصادق الأمين، واشتغل بالرعي والتجارة، وتزوج السيدة خديجة رضي الله عنها وهو ابن خمس وعشرين.</p>
            </div>
         </div>

         <div class="tl2-item">
            <div class="tl2-year">البعثة</div>
            <div class="tl2-card">
               <h3 class="tl2-title text-primary"><i class="fas fa-book-reader me-2 text-warning"></i>نزول الوحي (40 سنة)</h3>
               <p class="text-muted mb-0 fs-5 line-height-2">نزل عليه الوحي جبريل عليه السلام في غار حراء في رمضان، فكانت "اقرأ" أول كلمات الوحي. بدأت الدعوة سراً، ثم جهراً، وعانى المسلمون الأوائل أشد أنواع العذاب والمقاطعة والثبات في مكة.</p>
            </div>
         </div>

         <div class="tl2-item">
            <div class="tl2-year">الإسراء</div>
            <div class="tl2-card">
               <h3 class="tl2-title text-primary"><i class="fas fa-moon me-2 text-warning"></i>الإسراء والمعراج</h3>
               <p class="text-muted mb-0 fs-5 line-height-2">بعد عام الحزن، أُسري بالنبي ﷺ للمسجد الأقصى، وعُرج به إلى السماوات العُلى تكريماً له، وفُرضت الصلوات الخمس مباشرة من الله تعالى.</p>
            </div>
         </div>

         <div class="tl2-item">
            <div class="tl2-year">الهجرة</div>
            <div class="tl2-card">
               <h3 class="tl2-title text-primary"><i class="fas fa-walking me-2 text-warning"></i>الهجرة إلى المدينة (1 هـ)</h3>
               <p class="text-muted mb-0 fs-5 line-height-2">خرج بصحبة أبي بكر الصديق إلى يثرب، فأنارت بقدومه وأصبحت المدينة المنورة. أسس دعائم الدولة بتشييد المسجد النبوي، والمؤاخاة بين المهاجرين والأنصار.</p>
            </div>
         </div>

         <div class="tl2-item">
            <div class="tl2-year">الفتح</div>
            <div class="tl2-card">
               <h3 class="tl2-title text-primary"><i class="fas fa-kaaba me-2 text-warning"></i>فتح مكة المنتصر (8 هـ)</h3>
               <p class="text-muted mb-0 fs-5 line-height-2">دخل النبي ﷺ مكة المكرّمة فاتحاً متواضعاً مطأطئاً رأسه بعدما نقضت قريش العهد، وحطّم الأصنام حول الكعبة، وعفا عن المكيين قائلاً: "اذهبوا فأنتم الطلقاء".</p>
            </div>
         </div>

         <div class="tl2-item">
            <div class="tl2-year">الوفاة</div>
            <div class="tl2-card">
               <h3 class="tl2-title text-primary"><i class="fas fa-dove me-2 text-warning"></i>الرفيق الأعلى (11 هـ)</h3>
               <p class="text-muted mb-0 fs-5 line-height-2">بعد حجة الوداع وتمام إكمال الدين، اشتد المرض على النبي ﷺ، وانتقلت روحه الطاهرة إلى الرفيق الأعلى ضحى يوم الاثنين، ودُفن في حجرة عائشة بالمسجد النبوي الشريف.</p>
            </div>
         </div>
      </div>
    </div>

    <!-- TAB 2: الشمائل (MORALS) -->
    <div class="tab-pane fade" id="tab-morals">
      <div class="sec-head">
        <span class="tag">وإنك لعلى خلق عظيم</span>
        <h3>الشمائل <span>المحمدية</span></h3>
        <p>أخلاقه وصفاته الخلْقِية والخُلُقية المؤثرة، والتي جعلت منه الأسوة الحسنة للبشرية كافة.</p>
        <div class="divider"></div>
      </div>

      <!-- Feature highlight -->
      <div class="card bg-white border-0 shadow-lg rounded-4 mb-5 p-5">
         <div class="row align-items-center">
            <div class="col-lg-8">
               <h2 class="font-amiri fw-bold text-dark mb-4"><i class="fas fa-quote-right text-primary me-2"></i> كان خُلُقُهُ الْقُرْآن...</h2>
               <p class="fs-4 text-muted line-height-2 mb-0">سُئلت السيدة عائشة رضي الله عنها عن خلق النبي ﷺ فقالت: "كان خلقه القرآن". ما من صفة نبيلة ومحمودة أمر بها القرآن إلا وكان عليه الصلاة والسلام قمتها وتجسيدها العملي، رحيماً ودوداً عادلاً قريباً من القلوب.</p>
            </div>
            <div class="col-lg-4 text-center mt-4 mt-lg-0">
               <i class="fas fa-sun fa-6x text-warning" style="filter: drop-shadow(0 0 20px rgba(212,175,55,0.5));"></i>
            </div>
         </div>
      </div>

      <div class="row g-4">
         <div class="col-lg-6">
            <div class="moral-card">
               <div class="moral-icon"><i class="fas fa-hand-holding-heart"></i></div>
               <h3 class="font-amiri fw-bold text-dark mb-3">الرحمة الشاملة</h3>
               <p class="text-muted fs-5 mb-0">كان أرحم الناس بالناس، بل بالحيوان وحتى الجماد (حنين الجذع). قال تعالى: (وما أرسلناك إلا رحمة للعالمين). شملت رحمته الأعداء والأطفال والمساكين.</p>
            </div>
         </div>
         <div class="col-lg-6">
            <div class="moral-card">
               <div class="moral-icon"><i class="fas fa-balance-scale"></i></div>
               <h3 class="font-amiri fw-bold text-dark mb-3">العدل والتواضع</h3>
               <p class="text-muted fs-5 mb-0">"لو أن فاطمة بنت محمد سرقت لقطعت يدها". كان يخيط ثوبه ويحلب شاته ويجالس الفقراء ولا يرضى بأن يتميز عنهم، ويدخل الغريب فلا يعرفه من بينهم.</p>
            </div>
         </div>
         <div class="col-lg-6">
            <div class="moral-card">
               <div class="moral-icon"><i class="fas fa-shield-alt"></i></div>
               <h3 class="font-amiri fw-bold text-dark mb-3">الشجاعة والثبات</h3>
               <p class="text-muted fs-5 mb-0">في غزوة حنين حين تراجع الجميع ثبت على بغلته منادياً "أنا النبي لا كذب"، وكان الصحابة يحتمون به إذا حمي الوطيس.</p>
            </div>
         </div>
         <div class="col-lg-6">
            <div class="moral-card">
               <div class="moral-icon"><i class="fas fa-smile"></i></div>
               <h3 class="font-amiri fw-bold text-dark mb-3">البشاشة والجمال الخلْقي</h3>
               <p class="text-muted fs-5 mb-0">"ظاهر الوضاءة، أبلج الوجه"، كان يتبسم دائِماً. أبهى الناس وأجملهم، نوره يعلوه كأنه قمر ليلة البدر.</p>
            </div>
         </div>
      </div>
    </div>

    <!-- TAB 3: الصحابة (SAHABA & MOTHERS OF BELIEVERS COMBINED) -->
    <div class="tab-pane fade" id="tab-sahaba">
      <div class="sec-head">
        <span class="tag">نجوم الاهتداء ومصابيح الدجى</span>
        <h3>أبرز الصحابة <span>وأمهات المؤمنين</span></h3>
        <p>الرعيل الأول من المبشرين بالجنة وزوجات النبي الطاهرات رضي الله عنهم أجمعين.</p>
        <div class="divider"></div>
      </div>

      <!-- Filters -->
      <div class="sahaba-filter">
         <button class="active" onclick="filterSahaba(this, 'all')">الكل</button>
         <button onclick="filterSahaba(this, 'ten')">العشرة المبشرون بالجنة</button>
         <button onclick="filterSahaba(this, 'mothers')">أمهات المؤمنين (الزوجات)</button>
      </div>

      <div class="row g-4 justify-content-center" id="sahabaGrid">
         <!-- Khulafa & The Rest of the 10 -->
         <div class="col-lg-4 col-md-6 sahaba-item ten">
            <div class="companion-card">
               <div class="comp-badge">أول الخلفاء وصديق الأمة</div>
               <h3 class="comp-name">أبو بكر الصديق</h3>
               <p class="text-muted mb-0">أول من آمن من الرجال، ورفيق النبي في الغار والهجرة. أفضل البشر بعد الأنبياء وثبّت الأمة عند وفاة النبي ﷺ.</p>
            </div>
         </div>
         <div class="col-lg-4 col-md-6 sahaba-item ten">
            <div class="companion-card">
               <div class="comp-badge">ثاني الخلفاء (الفاروق)</div>
               <h3 class="comp-name">عمر بن الخطاب</h3>
               <p class="text-muted mb-0">أعز الله به الإسلام. بطل الفتوحات الكبرى والعدل الذي فرّ منه الشيطان، وأول من لُقب بأمير المؤمنين.</p>
            </div>
         </div>
         <div class="col-lg-4 col-md-6 sahaba-item ten">
            <div class="companion-card">
               <div class="comp-badge">ثالث الخلفاء (ذو النورين)</div>
               <h3 class="comp-name">عثمان بن عفان</h3>
               <p class="text-muted mb-0">تزوج بنتي الرسول تباعاً. الحييّ الغني السخي الذي جهز جيش العسرة وجُمع المصحف في عهده.</p>
            </div>
         </div>
         <div class="col-lg-4 col-md-6 sahaba-item ten">
            <div class="companion-card">
               <div class="comp-badge">رابع الخلفاء وأبو السبطين</div>
               <h3 class="comp-name">علي بن أبي طالب</h3>
               <p class="text-muted mb-0">ابن عم النبي وزوج السيدة فاطمة. فدائي الهجرة وأمير البيان والشجاعة وبطل النزالات ومعركة خيبر.</p>
            </div>
         </div>
         <div class="col-lg-4 col-md-6 sahaba-item ten">
            <div class="companion-card">
               <div class="comp-badge">أمين الأمة</div>
               <h3 class="comp-name">أبو عبيدة بن الجراح</h3>
               <p class="text-muted mb-0">نزع حلقتي المغفر من وجه النبي بأسنانه يوم أحد، وقائد جيوش الشام وحاكمها الزاهد.</p>
            </div>
         </div>
         <div class="col-lg-4 col-md-6 sahaba-item ten">
            <div class="companion-card">
               <div class="comp-badge">حواري رسول الله</div>
               <h3 class="comp-name">الزبير بن العوام</h3>
               <p class="text-muted mb-0">أول من سلّ سيفاً في سبيل الله، صنديد الفرسان وأشد المدافعين عن العقيدة في كل المشاهد.</p>
            </div>
         </div>
         <div class="col-lg-4 col-md-6 sahaba-item ten">
            <div class="companion-card">
               <div class="comp-badge">طلحة الخير والفيّاض</div>
               <h3 class="comp-name">طلحة بن عبيد الله</h3>
               <p class="text-muted mb-0">الشهيد الحي الذي ألقى بجسده يحمي رسول الله يوم أحد حتى شلّت إصبعه ومُلئ جسده بالجراح.</p>
            </div>
         </div>
         <div class="col-lg-4 col-md-6 sahaba-item ten">
            <div class="companion-card">
               <div class="comp-badge">فاتح العراقين والصياد</div>
               <h3 class="comp-name">سعد بن أبي وقاص</h3>
               <p class="text-muted mb-0">خال النبي مستجاب الدعوة. بطل معركة القادسية وقاهر الإمبراطورية الفارسية الكسروية.</p>
            </div>
         </div>
         <!-- Mothers of Believers -->
         <div class="col-lg-4 col-md-6 sahaba-item mothers">
            <div class="companion-card" style="border-bottom-color:#be123c;">
               <div class="comp-badge" style="background:#be123c; color:white;">أم المؤمنين الأولى</div>
               <h3 class="comp-name">خديجة بنت خويلد</h3>
               <p class="text-muted mb-0">ناصرته وصدقته أول مرّة بمالها ونفسها. لم يتزوج عليها حتى ماتت، وأقرأها الله السلام من فوق سبع سماوات.</p>
            </div>
         </div>
         <div class="col-lg-4 col-md-6 sahaba-item mothers">
            <div class="companion-card" style="border-bottom-color:#be123c;">
               <div class="comp-badge" style="background:#be123c; color:white;">أم المؤمنين والعالمة</div>
               <h3 class="comp-name">عائشة بنت أبي بكر</h3>
               <p class="text-muted mb-0">أحب النساء إليه، والمبرأة من السماء، وحاملة علم الحديث المكثِرة، وتوفي النبي في حجرتها الشريفة.</p>
            </div>
         </div>
         <div class="col-lg-4 col-md-6 sahaba-item mothers">
            <div class="companion-card" style="border-bottom-color:#be123c;">
               <div class="comp-badge" style="background:#be123c; color:white;">أم المؤمنين وحارسة المصحف</div>
               <h3 class="comp-name">حفصة بنت عمر بن الخطاب</h3>
               <p class="text-muted mb-0">المرأة العابدة الصوامة القوامة، أُمِنت على حفظ أول مصحف شريف جمع في عهد الصديق.</p>
            </div>
         </div>
         <div class="col-lg-4 col-md-6 sahaba-item mothers">
            <div class="companion-card" style="border-bottom-color:#be123c;">
               <div class="comp-badge" style="background:#be123c; color:white;">أم المؤمنين وأم المساكين</div>
               <h3 class="comp-name">زينب بنت خزيمة</h3>
               <p class="text-muted mb-0">عُرفت بلقب "أم المساكين" لكثرة إطعامها ورحمتها بهم، توفيت بعد زواجها من النبي بوقت قصير.</p>
            </div>
         </div>
      </div>
    </div>

    <!-- TAB 4: الغزوات (BATTLES) -->
    <div class="tab-pane fade" id="tab-battles">
      <div class="sec-head">
        <span class="tag">أيام الله الخالدة والجهاد النبيل</span>
        <h3>خرائط <span>المعارك الفاصلة</span></h3>
        <p>التصور البصري لأهم الغزوات القرآنية التي أسست لدولة الإسلام السمح.</p>
        <div class="divider"></div>
      </div>

      <div class="row g-5 align-items-center mb-5 pb-4 border-bottom">
         <div class="col-lg-6">
            <div class="map-interactive-container">
               <div class="battle-badge">غزوة بدر الكبرى (2 هـ)</div>
               <!-- Features -->
               <div class="map-terrain" style="top:20px; left:20px;"><i class="fas fa-mountain"></i> العدوة القصوى (قريش)</div>
               <div class="map-terrain" style="bottom:20px; right:20px;"><i class="fas fa-mountain"></i> العدوة الدنيا (المسلمون)</div>
               <div class="map-terrain" style="top:45%; left:30%; color:#0284c7;"><i class="fas fa-tint fa-2x"></i> <br>آبـار بـــــدر</div>
               <!-- Teams -->
               <div class="map-team team-muslim shadow-lg" style="bottom:30%; right:15%;">المسلمون (313)<br><small class="fw-normal">بقيادة: النبي ﷺ</small></div>
               <div class="map-team team-enemy shadow-lg" style="top:30%; left:15%;">قريش (1000)<br><small class="fw-normal">بقيادة: أبو جهل</small></div>
               <!-- Action -->
               <div class="battle-pulse" style="top:35%; left:35%;"></div>
            </div>
         </div>
         <div class="col-lg-6">
            <h2 class="font-amiri fw-bold text-dark mb-3">يوم الفـرقـان الانتصار المدوي</h2>
            <p class="fs-5 text-muted line-height-2 mb-4">أول مواجهة عسكرية كبرى. قصد المسلمون قافلة أبي سفيان فتفاجأوا بجيش مكة بكامل عتاده. بفضل الثبات والإمداد الملائكي، تحقق نصر حاسم قُتل فيه أئمة الكفر وتم أسر 70 مشركاً.</p>
            <div class="d-flex gap-3">
               <span class="badge bg-success px-3 py-2 fs-6 rounded-pill"><i class="fas fa-check-circle me-1"></i> الشهداء: 14</span>
               <span class="badge bg-danger px-3 py-2 fs-6 rounded-pill"><i class="fas fa-skull me-1"></i> خسائر العدو: 70 قتيلا</span>
            </div>
         </div>
      </div>

      <div class="row g-5 align-items-center flex-row-reverse mb-5 pb-4">
         <div class="col-lg-6">
            <div class="map-interactive-container">
               <div class="battle-badge">غزوة الخندق/الأحزاب (5 هـ)</div>
               <!-- Features -->
               <div class="map-terrain text-dark bg-warning px-3 py-1 rounded-pill" style="top:15%; left:20%; border-bottom:5px dashed var(--dark);">الخـــــنـــــدق المانـع</div>
               <div class="map-terrain" style="bottom:30px; right:30px;"><i class="fas fa-building"></i> حصن بني قريظة</div>
               <!-- Teams -->
               <div class="map-team team-muslim" style="top:40%; left:60%; transform:translateX(-50%);">المدينة المنورة<br>(3000 صحابي)</div>
               <div class="map-team team-enemy" style="top:5%; left:30%;">أحزاب قريش وغطفان<br>(10.000 مقاتل)</div>
               <!-- Wind Action -->
               <div class="position-absolute fs-1 text-muted" style="top:35%; left:10%; opacity:0.5;"><i class="fas fa-wind fa-3x"></i><br>رياح العذاب</div>
            </div>
         </div>
         <div class="col-lg-6">
            <h2 class="font-amiri fw-bold text-dark mb-3">الحصار العظيم والنصر الإلهي</h2>
            <p class="fs-5 text-muted line-height-2 mb-4">تحالف كل الكفار واليهود لاجتثاث الإسلام. أشار سلمان الفارسي بحفر الخندق لحماية المدينة المفتوحة. دام الحصار مع برد وجوع وغدر من الداخل، حتى أرسل الله ريحاً عاتية مزقت خيام المشركين وانتهت المواجهة دون قتال.</p>
            <div class="d-flex gap-3">
               <span class="badge bg-secondary px-3 py-2 fs-6 rounded-pill"><i class="fas fa-cloud-showers-heavy me-1"></i> جنود الله (الريح السائدة)</span>
            </div>
         </div>
      </div>

    </div>

  </div> <!-- End Tabs -->
</div>

<!-- MEGA FOOTER -->
<footer class="mega-footer" style="background:linear-gradient(135deg,var(--dark),#020617);color:white;padding:80px 0 30px;margin-top:80px;border-top:3px solid var(--gold-dark);">
  <div class="container">
    <div class="row g-5 mb-5 border-bottom border-light border-opacity-10 pb-5">
      <div class="col-lg-4 text-md-end text-center">
        <i class="fas fa-mosque fa-4x text-warning mb-4 d-block"></i>
        <h4 class="fw-bold font-amiri fs-2 mb-3">الموسوعة الإسلامية الشاملة</h4>
        <p class="opacity-75 fs-6 line-height-2">أضخم صرح رقمي يجمع علوم القرآن العظيم، وأحاديث المصطفى، وفقهاء المذاهب، والتاريخ المجيد في منصة موثقة مصممة بأحدث التقنيات.</p>
      </div>
      <div class="col-lg-4 text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">تصفح الموسوعة</h5>
        <div class="d-flex flex-wrap justify-content-center gap-2">
          <a href="recitations.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">أكاديمية القرآن</a>
          <a href="hadith.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الحديث النبوي</a>
          <a href="seerah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">السيرة والصحابة</a>
          <a href="fiqh.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الفقه وأصوله</a>
          <a href="fatwa.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">فتاوى العلماء</a>
          <a href="aqeedah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">العقيدة الإسلامية</a>
          <a href="history.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">التاريخ المجيد</a>
          <a href="library.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">المكتبة الشاملة</a>
        </div>
      </div>
      <div class="col-lg-4 text-md-start text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">روابط سريعة</h5>
        <a href="contact.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> اتصل بالمطور</a>
        <a href="share.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> شارك الأجر</a>
        <a href="login.html" class="mega-footer-link text-warning mt-3" style="text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-user-circle me-2 ms-1"></i> تسجيل الدخول</a>
      </div>
    </div>
    <div class="text-center font-amiri fs-5 d-flex flex-column gap-2">
      <span class="opacity-75">الموسوعة الإسلامية الشاملة &copy; 2026 تم التصميم للإفادة | عمل مجاني لوجه الله</span>
      <span class="text-warning fw-bold fs-4 mt-2">تصميم وتطوير: لخذاري محمد سيف الدين</span>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    function filterSahaba(btn, category) {
        document.querySelectorAll('.sahaba-item').forEach(item => {
            if(category === 'all') {
                item.style.display = 'block';
            } else {
                if(item.classList.contains(category)) {
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            }
        });
        
        document.querySelectorAll('.sahaba-filter button').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
    }
</script>
</body>
</html>
