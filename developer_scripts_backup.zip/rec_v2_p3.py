
    <!-- TAB 3: MAQAMAT -->
    <div class="tab-pane fade" id="t-maqam">
      <div class="sec-head">
        <span class="tag">جمال الصوت والنغم</span>
        <h3>المقامات <span>القرآنية</span></h3>
        <p>تعرف على المقامات الصوتية السبعة الأساسية (صُنع بسحر) التي يُزين بها القراء أصواتهم لتصوير المعاني القرآنية.</p>
        <div class="divider"></div>
      </div>
      
      <div class="row g-4">
        <!-- Maqam 1: Bayati -->
        <div class="col-lg-4 col-md-6">
          <div class="maqam-card">
            <div class="maqam-header" style="background:linear-gradient(135deg,#05708a,#033547);">
              <h3>مقام البياتي</h3>
              <p class="mb-0 opacity-75">مقام البدايات والخضوع</p>
            </div>
            <div class="maqam-body border-top-0 border shadow-none">
              <div class="maqam-feature"><i class="fas fa-info-circle text-cyan"></i><span>أوسع المقامات انتشاراً، يبدأ به القراء تلاوتهم غالباً لما فيه من وقار وهدوء وسعة.</span></div>
              <div class="maqam-feature"><i class="fas fa-heart text-danger"></i><span>يُشعر المستمع بالخشوع والطمأنينة والتأمل.</span></div>
              <button class="btn-maqam-play mt-3" onclick="alert('سيتم إضافة نموذج للبياتي بصوت مصطفى إسماعيل')"><i class="fas fa-play me-2"></i>استمع لنموذج (البياتي)</button>
            </div>
          </div>
        </div>

        <!-- Maqam 2: Rast -->
        <div class="col-lg-4 col-md-6">
          <div class="maqam-card">
            <div class="maqam-header" style="background:linear-gradient(135deg,#c9a66b,#b08d55);">
              <h3 class="text-white">مقام الرَّسْت</h3>
              <p class="mb-0 opacity-75 text-white">مقام الاستقامة والفخامة</p>
            </div>
            <div class="maqam-body border-top-0 border shadow-none">
              <div class="maqam-feature"><i class="fas fa-info-circle" style="color:#b08d55"></i><span>يعني "المستقيم" بالفارسية. يمتاز بالقوة والفخامة ويناسب الآيات التي تتحدث عن الجنة والأحكام.</span></div>
              <div class="maqam-feature"><i class="fas fa-heart text-danger"></i><span>يبعث على الاستقرار والوضوح والشموخ.</span></div>
              <button class="btn-maqam-play mt-3" style="color:#b08d55;background:rgba(201,166,107,.1);" onclick="alert('سيتم إضافة نموذج للرست بصوت الحصري')"><i class="fas fa-play me-2"></i>استمع لنموذج (الرست)</button>
            </div>
          </div>
        </div>

        <!-- Maqam 3: Nahawand -->
        <div class="col-lg-4 col-md-6">
          <div class="maqam-card">
            <div class="maqam-header" style="background:linear-gradient(135deg,#6366f1,#4f46e5);">
              <h3>مقام النهاوند</h3>
              <p class="mb-0 opacity-75">مقام العاطفة والحنان</p>
            </div>
            <div class="maqam-body border-top-0 border shadow-none">
              <div class="maqam-feature"><i class="fas fa-info-circle" style="color:#6366f1"></i><span>مقام يمتاز بالرقة المتناهية والعذوبة. يستخدم غالباً في الآيات التي تتحدث عن رحمة الله وقصص الأنبياء.</span></div>
              <div class="maqam-feature"><i class="fas fa-heart text-danger"></i><span>يُثير الشجون والعواطف الرقيقة ويسلب القلوب.</span></div>
              <button class="btn-maqam-play mt-3" style="color:#4f46e5;background:rgba(99,102,241,.1);" onclick="alert('سيتم إضافة نموذج للنهاوند بصوت مشاري العفاسي')"><i class="fas fa-play me-2"></i>استمع لنموذج (النهاوند)</button>
            </div>
          </div>
        </div>

        <!-- Maqam 4: Sikah -->
        <div class="col-lg-4 col-md-6">
          <div class="maqam-card">
            <div class="maqam-header" style="background:linear-gradient(135deg,#10b981,#059669);">
              <h3>مقام السيكا</h3>
              <p class="mb-0 opacity-75">مقام الفرح والبطء</p>
            </div>
            <div class="maqam-body border-top-0 border shadow-none">
              <div class="maqam-feature"><i class="fas fa-info-circle" style="color:#10b981"></i><span>مقام ذو طابع شرقي أصيل وبطيء الإيقاع نسبياً، يُصوّر معاني النصر والبشائر.</span></div>
              <div class="maqam-feature"><i class="fas fa-heart text-danger"></i><span>يبعث على السرور والبهجة الهادئة والتأمل في نعم الله.</span></div>
              <button class="btn-maqam-play mt-3" style="color:#059669;background:rgba(16,185,129,.1);" onclick="alert('سيتم إضافة نموذج للسيكا بصوت محمد صديق المنشاوي')"><i class="fas fa-play me-2"></i>استمع لنموذج (السيكا)</button>
            </div>
          </div>
        </div>

        <!-- Maqam 5: Saba -->
        <div class="col-lg-4 col-md-6">
          <div class="maqam-card">
            <div class="maqam-header" style="background:linear-gradient(135deg,#475569,#1e293b);">
              <h3 class="text-white">مقام الصَّبَا</h3>
              <p class="mb-0 opacity-75 text-white">مقام الحزن والخشوع الشديد</p>
            </div>
            <div class="maqam-body border-top-0 border shadow-none">
              <div class="maqam-feature"><i class="fas fa-info-circle" style="color:#475569"></i><span>مقام شجي جداً وحزين، يُستخدم في آيات الوعيد ومشاهد القيامة والزهد.</span></div>
              <div class="maqam-feature"><i class="fas fa-heart text-danger"></i><span>يعصر القلب ويدفع للبكاء والتوبة العميقة والرهبة.</span></div>
              <button class="btn-maqam-play mt-3" style="color:#1e293b;background:rgba(71,85,105,.1);" onclick="alert('سيتم إضافة نموذج للصبا بصوت عبد الباسط عبد الصمد')"><i class="fas fa-play me-2"></i>استمع لنموذج (الصبا)</button>
            </div>
          </div>
        </div>

        <!-- Maqam 6: Hijaz -->
        <div class="col-lg-4 col-md-6">
          <div class="maqam-card">
            <div class="maqam-header" style="background:linear-gradient(135deg,#ef4444,#dc2626);">
              <h3>مقام الحجاز</h3>
              <p class="mb-0 opacity-75">مقام الشوق والحنين</p>
            </div>
            <div class="maqam-body border-top-0 border shadow-none">
              <div class="maqam-feature"><i class="fas fa-info-circle" style="color:#ef4444"></i><span>مقام يُنسب لبلاد الحجاز، له نبرة حزينة ممزوجة بالشوق العظيم والعظمة. يُكثر قراء مكة من استخدامه.</span></div>
              <div class="maqam-feature"><i class="fas fa-heart text-danger"></i><span>يثير في المستمع الشوق العارم، ويناسب قصص الأنبياء.</span></div>
              <button class="btn-maqam-play mt-3" style="color:#dc2626;background:rgba(239,68,68,.1);" onclick="alert('سيتم إضافة نموذج للحجاز')"><i class="fas fa-play me-2"></i>استمع لنموذج (الحجاز)</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- TAB 4: TAJWEED & MAKHARIJ -->
    <div class="tab-pane fade" id="t-taj">
      <div class="sec-head">
        <span class="tag">لغة الضاد والإتقان</span>
        <h3>أحكام التجويد <span>ومخارج الحروف</span></h3>
        <p>الأداة العلمية والعملية لإعطاء كل حرف حقه ومستحقه كما عُلّم النبي ﷺ</p>
        <div class="divider"></div>
      </div>

      <div class="row g-5">
        <div class="col-lg-5">
          <div class="position-sticky" style="top:100px;">
            <div class="bg-white p-4 rounded-4 shadow-sm border border-emerald text-center">
              <h4 class="font-amiri fw-bold text-success mb-3">مخارج الحروف الرئيسية (المواضع الـ 5)</h4>
              <p class="text-muted small mb-4">يخرج منها جميع حروف الهجاء العربية وفقاً لمذهب ابن الجزري</p>
              
              <ul class="list-group list-group-flush text-start mb-4 dir-rtl border-0">
                <li class="list-group-item bg-transparent d-flex align-items-center"><i class="fas fa-circle text-primary mx-2 small"></i><strong>الجوف:</strong> مخرج حروف المد الثلاثة (ا، و، ي).</li>
                <li class="list-group-item bg-transparent d-flex align-items-center"><i class="fas fa-circle text-danger mx-2 small"></i><strong>الحلق:</strong> مخرج (ء، هـ، ع، ح، غ، خ).</li>
                <li class="list-group-item bg-transparent d-flex align-items-center"><i class="fas fa-circle text-success mx-2 small"></i><strong>اللسان:</strong> به 10 مخارج لـ 18 حرفاً (ق، ك، ج، ش، ي، ض...).</li>
                <li class="list-group-item bg-transparent d-flex align-items-center"><i class="fas fa-circle text-warning mx-2 small"></i><strong>الشفتان:</strong> مخرج (ف، ب، م، و).</li>
                <li class="list-group-item bg-transparent d-flex align-items-center"><i class="fas fa-circle text-info mx-2 small"></i><strong>الخيشوم:</strong> التجويف الأنفي، وهو مخرج صفة "الغنة".</li>
              </ul>
              <div class="p-3 bg-light rounded-3 text-center">
                <i class="fas fa-head-side-cough fa-4x text-muted opacity-50 mb-2"></i>
                <p class="small text-muted mb-0">للتطبيق: سكّن الحرف وأدخل عليه همزة وصل (أَبْ، أَمْ، أَقْ) حيث ينقطع الصوت فهو المخرج اليقيني.</p>
              </div>
            </div>
          </div>
        </div>
        
        <div class="col-lg-7">
          <h4 class="font-amiri fw-bold mb-4" style="color:#033547;"><i class="fas fa-book-open text-warning me-2"></i>الأحكام التجويدية الأساسية</h4>
          <div class="tajweed-grid">
            
            <div class="taj-item border-end border-primary">
              <div class="taj-icon text-primary bg-primary bg-opacity-10">نْ</div>
              <h5 class="fw-bold text-dark">أحكام النون الساكنة والتنوين</h5>
              <p class="text-muted small mt-2">لها 4 أحكام حسب الحرف الذي يليها: <strong>الإظهار</strong> (عند حروف الحلق)، <strong>الإدغام</strong> (حروف يرملون)، <strong>القلب</strong> (باء)، و<strong>الإخفاء</strong> (باقي الحروف).</p>
            </div>

            <div class="taj-item border-end border-danger">
              <div class="taj-icon text-danger bg-danger bg-opacity-10">مْ</div>
              <h5 class="fw-bold text-dark">أحكام الميم الساكنة</h5>
              <p class="text-muted small mt-2">لها 3 أحكام: <strong>الإخفاء الشفوي</strong> (عند مجيء الباء)، <strong>الإدغام المتماثل</strong> (عند ميم أخرى)، و<strong>الإظهار الشفوي</strong> (عند بقية الحروف).</p>
            </div>

            <div class="taj-item border-end border-warning">
              <div class="taj-icon text-warning bg-warning bg-opacity-10">~</div>
              <h5 class="fw-bold text-dark">أحكام المدود</h5>
              <p class="text-muted small mt-2">المد الطبيعي يمد حركتان (نوحيها). أما المد الفرعي فيتوقف على سبب إما الهمز (مد متصل ومنفصل وبدل) أو السكون (عارض ولازم ويوصل لـ 6 حركات).</p>
            </div>

            <div class="taj-item border-end border-info">
              <div class="taj-icon text-info bg-info bg-opacity-10">ّ</div>
              <h5 class="fw-bold text-dark">الميم والنون المشددتين</h5>
              <p class="text-muted small mt-2">يجب الغنة فيهما بمقدار حركتين في حالة الوصل والوقف (إنَّ، عمَّ). وهي أكمل ما تكون من مراتب الغنة.</p>
            </div>

            <div class="taj-item border-end border-secondary">
              <div class="taj-icon text-secondary bg-secondary bg-opacity-10">قِ</div>
              <h5 class="fw-bold text-dark">القلقلة</h5>
              <p class="text-muted small mt-2">اضطراب مخرج الحرف عند النطق به ساكناً. حروفها مجموعة في كلمة (قطب جد). وتكون كبرى إذا وقفنا على الحرف، وصغرى في وسط الكلمة.</p>
            </div>

            <div class="taj-item border-end border-success">
              <div class="taj-icon text-success bg-success bg-opacity-10">رَ</div>
              <h5 class="fw-bold text-dark">التفخيم والترقيق</h5>
              <p class="text-muted small mt-2">حروف مفخمة دائماً (خص ضغط قظ). وحروف ترقق دائماً (باقي الحروف). الألف واو راء ولام لفظ الجلالة تدور بين التفخيم والترقيق.</p>
            </div>

          </div>
        </div>
      </div>
    </div>
