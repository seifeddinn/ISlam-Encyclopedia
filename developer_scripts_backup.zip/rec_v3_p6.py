
    <!-- TAB 7: AUDIO LIBRARY MEGA -->
    <div class="tab-pane fade" id="tab-audio">
      <div class="sec-head">
        <span class="tag">إذا قرئ القرآن فاستمعوا له وأنصتوا</span>
        <h3>المكتبة الصوتية <span>الشاملة</span></h3>
        <p>استمع للقرآن الكريم كاملاً (114 سورة) بأصوات كبار قراء العالم الإسلامي برواية حفص عن عاصم، واجعل لسانك رطباً بذكر الله.</p>
        <div class="divider"></div>
      </div>
      
      <!-- Reciters Grid -->
      <div id="recitersGrid" class="row g-4 mb-5">
         <!-- Injected by JS -->
      </div>

      <!-- Reciter Details (Hidden by Default) -->
      <div id="reciterDetails" style="display:none;">
         <div class="d-flex align-items-center justify-content-between mb-4 border-bottom pb-3">
            <h4 class="font-amiri fw-bold text-success mb-0 d-flex align-items-center">
               <i class="fas fa-headphones-alt me-3 fs-3"></i>
               المصحف المرتل للشيخ: <span id="currentReciterTitle" class="ms-2 text-dark"></span>
            </h4>
            <button class="btn btn-outline-danger rounded-pill px-4" onclick="closeReciterDetails()"><i class="fas fa-arrow-right me-2"></i>العودة للقراء</button>
         </div>

         <div class="bg-white p-3 rounded-4 shadow-sm border mb-4 d-flex align-items-center">
            <i class="fas fa-search text-muted ms-3"></i>
            <input type="text" id="libSurahSearch" class="form-control border-0 shadow-none bg-transparent" placeholder="ابحث عن سورة للـاستماع (مثال: الكهف)...">
         </div>

         <div class="row g-3" id="libSurahsGrid">
            <!-- Injected by JS -->
         </div>
      </div>
    </div>


    <!-- TAB 5: LEGENDS & SCHOOLS OF RECITED QURAN -->
    <div class="tab-pane fade" id="tab-legends">
      <div class="sec-head">
        <span class="tag">مدارس الأداء وحناجر الذهب</span>
        <h3>أساطير التلاوة <span>ومدارسها</span></h3>
        <p>نظرة متعمقة على المدارس الكبرى التي أسست فن تلاوة وتجويد القرآن المسجل بالصوت في العصر الحديث.</p>
        <div class="divider"></div>
      </div>
      
      <!-- Schools -->
      <div class="row g-5 mb-5">
        <div class="col-lg-6">
           <div class="mega-card bg-light border-0" style="border-right:6px solid #d4af37;">
              <h4 class="font-amiri fw-bold text-dark mb-3"><i class="fas fa-mosque text-warning me-2"></i>المدرسة المصرية المتأخرة</h4>
              <p class="text-muted fs-5 line-height-2 mb-4">هي المدرسة المؤسسة لفن التلاوة والمتحكمة بإتقان الأحكام والمقامات، تتميز بإظهار جماليات الصوت مع الحفاظ الصارم على أحكام التجويد ومخارج الحروف. أركانها أربعة لا يجاريهم أحد.</p>
              
              <div class="d-flex flex-wrap gap-2">
                 <span class="badge bg-secondary px-3 py-2 rounded-pill fs-6"><i class="fas fa-leaf me-1 text-warning"></i> الحصري (الدقة والتحقيق)</span>
                 <span class="badge bg-secondary px-3 py-2 rounded-pill fs-6"><i class="fas fa-heart me-1 text-danger"></i> المنشاوي (الخشوع والروحانية)</span>
                 <span class="badge bg-secondary px-3 py-2 rounded-pill fs-6"><i class="fas fa-crown me-1 text-warning"></i> عبد الباسط (الطبقة العالية)</span>
                 <span class="badge bg-secondary px-3 py-2 rounded-pill fs-6"><i class="fas fa-music me-1 text-info"></i> مصطفى إسماعيل (المقامات)</span>
              </div>
           </div>
        </div>
        
        <div class="col-lg-6">
           <div class="mega-card bg-light border-0" style="border-right:6px solid #0f766e;">
              <h4 class="font-amiri fw-bold text-dark mb-3"><i class="fas fa-kaaba text-success me-2"></i>المدرسة الحجازية (نجد والحرمين)</h4>
              <p class="text-muted fs-5 line-height-2 mb-4">نشأت في أروقة الحرمين الشريفين، تتميز بالقراءة بمرتبة "الحدر" السريعة المتقنة، وتتسم بالتأثير العاطفي والسهولة والبساطة والتركيز على المعاني دون تكلف في المقامات.</p>
              
              <div class="d-flex flex-wrap gap-2">
                 <span class="badge bg-secondary px-3 py-2 rounded-pill fs-6"><i class="fas fa-star me-1 text-warning"></i> علي جابر</span>
                 <span class="badge bg-secondary px-3 py-2 rounded-pill fs-6"><i class="fas fa-star me-1 text-warning"></i> الحذيفي (الإتقان الحجازي)</span>
                 <span class="badge bg-secondary px-3 py-2 rounded-pill fs-6"><i class="fas fa-star me-1 text-warning"></i> السديس والشريم</span>
                 <span class="badge bg-secondary px-3 py-2 rounded-pill fs-6"><i class="fas fa-star me-1 text-warning"></i> المحيسني</span>
              </div>
           </div>
        </div>
      </div>

      <div class="row g-4 mt-2">
        <!-- Legend Cards -->
        <div class="col-lg-3 col-6">
          <div class="legend-card">
            <div class="l-img" style="background:linear-gradient(135deg,#020617,#1e293b);"><img src="https://upload.wikimedia.org/wikipedia/ar/4/4e/%D9%85%D8%AD%D9%85%D8%AF_%D8%B5%D8%AF%D9%8A%D9%82_%D8%A7%D9%84%D9%85%D9%86%D8%B4%D8%A7%D9%88%D9%8A.jpg" style="width:100%;height:100%;object-fit:cover;opacity:.8;mix-blend-mode:luminosity;"><span class="l-badge">الصوت الباكي</span></div>
            <div class="legend-body">
              <h4 class="font-amiri">محمد صديق المنشاوي</h4>
              <button class="btn btn-sm btn-outline-primary rounded-pill w-100 mt-2" onclick="openAudioLibrary('محمد صديق المنشاوي')">المكتبة الصوتية</button>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-6">
          <div class="legend-card">
            <div class="l-img" style="background:linear-gradient(135deg,#1e1b4b,#312e81);"><img src="https://upload.wikimedia.org/wikipedia/commons/e/ea/Abdulbasit_Abdusamad_MBS.jpg" style="width:100%;height:100%;object-fit:cover;opacity:.8;mix-blend-mode:luminosity;"><span class="l-badge">الحنجرة الذهبية</span></div>
            <div class="legend-body">
              <h4 class="font-amiri">عبد الباسط عبد الصمد</h4>
              <button class="btn btn-sm btn-outline-primary rounded-pill w-100 mt-2" onclick="openAudioLibrary('عبد الباسط عبد الصمد')">المكتبة الصوتية</button>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-6">
          <div class="legend-card">
            <div class="l-img" style="background:linear-gradient(135deg,#422006,#78350f);"><img src="https://upload.wikimedia.org/wikipedia/ar/b/bd/%D9%85%D8%AD%D9%85%D9%88%D8%AF_%D8%AE%D9%84%D9%8A%D9%84_%D8%A7%D9%84%D8%AD%D8%B5%D8%B1%D9%8A.jpg" style="width:100%;height:100%;object-fit:cover;opacity:.8;mix-blend-mode:luminosity;"><span class="l-badge">شيخ المقارئ</span></div>
            <div class="legend-body">
              <h4 class="font-amiri">محمود خليل الحصري</h4>
              <button class="btn btn-sm btn-outline-primary rounded-pill w-100 mt-2" onclick="openAudioLibrary('محمود خليل الحصري')">المكتبة الصوتية</button>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-6">
          <div class="legend-card">
            <div class="l-img" style="background:linear-gradient(135deg,#064e3b,#0f766e);"><img src="https://upload.wikimedia.org/wikipedia/commons/7/77/%D9%85%D8%B4%D8%A7%D8%B1%D9%8A_%D8%A7%D9%84%D8%B9%D9%81%D8%A7%D8%B3%D9%8A.jpg" style="width:100%;height:100%;object-fit:cover;opacity:.8;mix-blend-mode:luminosity;"><span class="l-badge">المزمار الخاشع</span></div>
            <div class="legend-body">
              <h4 class="font-amiri">مشاري بن راشد العفاسي</h4>
              <button class="btn btn-sm btn-outline-primary rounded-pill w-100 mt-2" onclick="openAudioLibrary('مشاري العفاسي')">المكتبة الصوتية</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- TAB 6: IJAZAH CHAIN & MATN -->
    <div class="tab-pane fade" id="tab-ijazah">
      <div class="sec-head">
        <span class="tag">إنا نحن نزلنا الذكر وإنا له لحافظون</span>
        <h3>الإجازة بالسند المتصل <span>ومتون التجويد</span></h3>
        <p>الشهادة القرآنية والشجرة الذهبية التي تفيد بأن القارئ قد قرأ القرآن خِلافة عن النبي ﷺ، والمنظومات التي حفظت العلم.</p>
        <div class="divider"></div>
      </div>
      
      <!-- Poetry Matns -->
      <div class="row g-4 mb-5">
         <div class="col-lg-6">
            <div class="poetry-box">
               <div class="poetry-title">مقدمة الجزرية للحافظ ابن الجزري</div>
               <div class="poetry-line"><span class="poetry-shatr">يَقُـولُ رَاجِـي عَـفْـوِ رَبٍّ سَـامِـعِ</span><span class="poetry-gap"></span><span class="poetry-shatr">مُحَـمَّـدُ بْـنُ الْجَـزَرِيِّ الشَّافِـعِـي</span></div>
               <div class="poetry-line"><span class="poetry-shatr text-danger">إِذْ وَاجِـبٌ عَلَيْـهِـمُ مُحَـتَّـمُ</span><span class="poetry-gap"></span><span class="poetry-shatr text-danger">قَبْـلَ الشُّـرُوعِ أَوَّلاً أَنْ يَعْلَمُـوا</span></div>
               <div class="poetry-line"><span class="poetry-shatr text-success">مَخَـارِجَ الْحُـرُوفِ وَالصِّـفَـاتِ</span><span class="poetry-gap"></span><span class="poetry-shatr text-success">لِيَلْـفِـظُـوا بِأَفْـصَـحِ اللُّـغَـاتِ</span></div>
            </div>
         </div>
         <div class="col-lg-6">
            <div class="poetry-box">
               <div class="poetry-title">تحفة الأطفال للشيخ الجمزوري</div>
               <div class="poetry-line"><span class="poetry-shatr">يَقُولُ رَاجِــــي رَحْمَــــةِ الْغَفُورِ</span><span class="poetry-gap"></span><span class="poetry-shatr">دَوْمًــا سُلَيْمَــــانُ هُــوَ الْجَمْـزُورِي</span></div>
               <div class="poetry-line"><span class="poetry-shatr text-primary">لِلـنُّـــونِ إِن تَسْـكُـنْ وَلِلتَّــــنْـــوِينِ</span><span class="poetry-gap"></span><span class="poetry-shatr text-primary">أَرْبَـعُ أَحْكَــــــامٍ فَخُـــــذْ تَبْيِينِــــــي</span></div>
               <div class="poetry-line"><span class="poetry-shatr text-dark">فَالْأَوَّلُ الْإِظْهَـــــارُ قَبْـــــلَ أَحْرُفِ</span><span class="poetry-gap"></span><span class="poetry-shatr text-dark">لِلْحَلْــــــقِ سِــــــتٌّ رُتِّبَـــتْ فَلْتَعْــرِفِ</span></div>
            </div>
         </div>
      </div>

      <!-- Chain box -->
      <div class="bg-dark text-white rounded-5 p-5 text-center position-relative overflow-hidden mb-5 border border-warning" style="background:linear-gradient(135deg,#0b192c,#033547)!important;">
         <i class="fas fa-link fa-8x position-absolute opacity-10" style="top:50px;right:50px;color:var(--gold);"></i>
         <i class="fas fa-link fa-8x position-absolute opacity-10" style="bottom:50px;left:50px;color:var(--gold);"></i>
         
         <h2 class="font-amiri fw-bold text-warning mb-5">السند القرآني الذهبي المتصل (شجرة الإجازة)</h2>
         
         <div class="d-flex flex-column align-items-center position-relative z-10">
            <div class="bg-warning text-dark px-4 py-2 rounded-pill font-amiri fs-3 fw-bold shadow">الله جل جلاله</div>
            <div style="width:4px;height:40px;background:var(--gold);"></div>
            <div class="border border-warning text-warning px-4 py-2 rounded-pill font-amiri fs-3 fw-bold shadow bg-dark">الروح الأمين جبريل عليه السلام</div>
            <div style="width:4px;height:40px;background:var(--gold);"></div>
            <div class="bg-white text-success px-4 py-2 rounded-pill font-amiri fs-2 fw-bold shadow">خاتم الأنبياء والمرسلين محمد ﷺ</div>
            <div style="width:4px;height:40px;background:var(--gold);"></div>
            <div class="border border-white text-white px-5 py-3 rounded-4 font-amiri fs-4 bg-dark bg-opacity-50">صحابة رسول الله (حفاظ الوحي)<br><small class="fs-6 opacity-75">(عثمان بن عفان، علي بن أبي طالب، أبي بن كعب، ابن مسعود، زيد بن ثابت)</small></div>
            <div style="width:4px;height:40px;background:var(--gold);"></div>
            <div class="border border-white text-white px-5 py-3 rounded-4 font-amiri fs-4 bg-dark bg-opacity-50">أئمة التابعين والقراء العشرة ورواتهم<br><small class="fs-6 opacity-75">(كالتابعي عبد الرحمن السلمي الذي أقرأ عاصم الكوفي، وابن هرمز الذي أقرأ نافع)</small></div>
            <div style="width:4px;height:40px;background:var(--gold);"></div>
            <div class="border border-secondary text-light px-5 py-3 rounded-4 font-amiri fs-4 bg-dark">أئمة التدوين والضبط والإقراء عبر القرون<br><small class="fs-6 opacity-75">(الجزري، الشاطبي، ابن مجاهد... وغيرهم آلاف)</small></div>
            <div style="width:4px;height:40px;background:var(--gold);"></div>
            <div class="border text-muted px-4 py-2 rounded-pill font-amiri fs-5">المشايخ المجيزون وكبار المقرئين الجامعين في عصرنا الحالي</div>
         </div>
      </div>

    </div>

  </div> <!-- End tabs content mega -->
</div>

<!-- Reader Modal -->
<div class="modal fade" id="quranModal" tabindex="-1">
  <div class="modal-dialog modal-xl modal-dialog-scrollable">
    <div class="modal-content border-0 shadow-lg">
      <div class="modal-header text-white" style="background:linear-gradient(135deg,#0b192c,#0f766e);">
        <div>
           <h4 class="modal-title font-amiri fw-bold" id="quranModalTitle"></h4>
           <span class="badge bg-warning text-dark mt-1" id="quranModalDesc"></span>
        </div>
        <div class="ms-auto d-flex gap-2">
           <button class="btn btn-sm btn-outline-light rounded-pill px-3" onclick="toggleTafsir()"><i class="fas fa-book-open me-1"></i> إظهار/إخفاء التفسير</button>
           <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
        </div>
      </div>
      <div class="modal-body quran-reader position-relative" id="quranModalBody" style="background:#fdfbf7;">
        <!-- Watermark -->
        <i class="fas fa-book-open position-absolute fa-10x" style="top:50%;left:50%;transform:translate(-50%,-50%);opacity:0.03;color:#0f766e;pointer-events:none;"></i>
        <!-- text -->
        <div class="quran-text" id="quranTextContent" style="position:relative;z-index:2;padding:20px;line-height:2.5;"></div>
      </div>
    </div>
  </div>
</div>

<!-- Global Audio Player -->
<div class="global-player shadow-lg border-top border-warning" id="globalPlayer" style="background:linear-gradient(90deg, #020617, #0f766e); backdrop-filter:blur(10px);">
  <div class="container d-flex align-items-center justify-content-between position-relative py-2">
    <!-- Close Btn -->
    <button class="btn btn-sm btn-outline-danger position-absolute top-0 end-0 mt-2 border-0" style="padding:2px 8px; border-radius:10px;" onclick="closeAudioPlayer()"><i class="fas fa-times"></i></button>
    
    <div class="d-flex align-items-center gap-3" style="width: 30%;">
      <div class="shadow" style="width:60px;height:60px;background:var(--gold);border-radius:15px;display:flex;align-items:center;justify-content:center;color:var(--dark);font-size:2rem;"><i class="fas fa-compact-disc fa-spin" id="playerDisc"></i></div>
      <div class="text-white text-truncate">
        <h5 class="mb-0 font-amiri text-warning fw-bold text-truncate" id="playerTitle"></h5>
        <small class="opacity-75 text-truncate d-block" id="playerReciter">اضغط زر التشغيل للبدء</small>
      </div>
    </div>

    <!-- Audio Controls Middle -->
    <div class="d-flex flex-column align-items-center" style="width: 40%;">
       <div class="d-flex align-items-center gap-4 mb-2">
           <button class="btn btn-link text-white text-decoration-none fs-5 p-0" onclick="playNextSurah(-1)" title="السورة السابقة"><i class="fas fa-step-forward"></i></button>
           <button class="btn btn-warning rounded-circle shadow-lg" style="width:45px;height:45px;display:flex;align-items:center;justify-content:center;" onclick="togglePlayPause()" id="playPauseBtn"><i class="fas fa-pause fs-5"></i></button>
           <button class="btn btn-link text-white text-decoration-none fs-5 p-0" onclick="playNextSurah(1)" title="السورة التالية"><i class="fas fa-step-backward"></i></button>
       </div>
       <audio id="quranAudio" class="d-none" preload="auto"></audio>
       <div class="w-100 d-flex align-items-center gap-2">
          <small class="text-white opacity-75 font-monospace" id="audioCurrentTime">00:00</small>
          <input type="range" class="form-range flex-grow-1 custom-range" id="audioProgress" value="0" min="0" max="100" step="1">
          <small class="text-white opacity-75 font-monospace" id="audioDuration">00:00</small>
       </div>
    </div>

    <!-- Actions Right -->
    <div class="d-flex align-items-center justify-content-end gap-3" style="width: 30%;">
       <a id="downloadAudioBtn" href="#" download class="btn btn-outline-light rounded-pill px-3" title="تحميل السورة"><i class="fas fa-download me-2"></i> تحميلMP3</a>
    </div>
  </div>
</div>

<style>
/* Custom Range for smooth progress */
.custom-range::-webkit-slider-thumb {background: var(--gold); border: 2px solid white;}
.custom-range::-webkit-slider-runnable-track {background: rgba(255,255,255,0.2); border-radius: 10px; height: 6px;}
/* Verse formatting */
.quran-text .verse {font-size:1.8rem;transition:all .3s;padding:5px;border-radius:10px;}
.quran-text .verse:hover {background:rgba(212,175,55,0.1);color:#0f766e;}
.verse-tafsir {display:none; padding:15px; margin:10px 0; background:#f8fafc; border-right:4px solid #0f766e; border-radius:10px; font-family:'Cairo',sans-serif; font-size:1.1rem; color:#475569;}
.show-tafsir .verse-tafsir {display:block;}
</style>

<!-- MEGA FOOTER -->
<footer class="mega-footer" style="background:linear-gradient(135deg,var(--dark),#020617);color:white;padding:80px 0 30px;margin-top:80px;border-top:3px solid var(--gold-dark);">
  <div class="container">
    <div class="row g-5 mb-5 border-bottom border-light border-opacity-10 pb-5">
      <div class="col-lg-4 text-md-end text-center">
        <i class="fas fa-mosque fa-4x text-warning mb-4 d-block"></i>
        <h4 class="fw-bold font-amiri fs-2 mb-3">الموسوعة الإسلامية الشاملة</h4>
        <p class="opacity-75 fs-6 line-height-2">أضخم صرح رقمي يجمع علوم القرآن العظيم، وأحاديث المصطفى، وفقهاء المذاهب، والتاريخ المجيد في منصة موثقة مصممة بأحدث التقنيات.</p>
      </div>
      <div class="col-lg-4 text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">تصفح الموسوعة</h5>
        <div class="d-flex flex-wrap justify-content-center gap-2">
          <a href="recitations.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">أكاديمية القرآن</a>
          <a href="hadith.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الحديث النبوي</a>
          <a href="seerah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">السيرة والصحابة</a>
          <a href="fiqh.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">الفقه وأصوله</a>
          <a href="fatwa.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">فتاوى العلماء</a>
          <a href="aqeedah.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">العقيدة الإسلامية</a>
          <a href="history.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">التاريخ المجيد</a>
          <a href="library.html" class="btn btn-sm btn-outline-light rounded-pill opacity-75">المكتبة الشاملة</a>
        </div>
      </div>
      <div class="col-lg-4 text-md-start text-center">
        <h5 class="text-warning mb-4 font-amiri fw-bold fs-3">روابط سريعة</h5>
        <a href="contact.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> اتصل بالمطور</a>
        <a href="share.html" class="mega-footer-link" style="color:rgba(255,255,255,.7);text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-chevron-left me-2 ms-1 text-gold small"></i> شارك الأجر</a>
        <a href="login.html" class="mega-footer-link text-warning mt-3" style="text-decoration:none;transition:0.3s;display:block;margin-bottom:10px;"><i class="fas fa-user-circle me-2 ms-1"></i> تسجيل الدخول</a>
      </div>
    </div>
    <div class="text-center font-amiri fs-5 d-flex flex-column gap-2">
      <span class="opacity-75">الموسوعة الإسلامية الشاملة &copy; 2026 تم التصميم للإفادة | عمل مجاني لوجه الله</span>
      <span class="text-warning fw-bold fs-4 mt-2">تصميم وتطوير: لخذاري محمد سيف الدين</span>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
// Quran Data & Logic
const surahs = [
  {"id":1,"name":"الفاتحة","type":"مكية","verses":7,"category":"mufassal"},
  {"id":2,"name":"البقرة","type":"مدنية","verses":286,"category":"tiwal"},
  {"id":3,"name":"آل عمران","type":"مدنية","verses":200,"category":"tiwal"},
  {"id":4,"name":"النساء","type":"مدنية","verses":176,"category":"tiwal"},
  {"id":5,"name":"المائدة","type":"مدنية","verses":120,"category":"tiwal"},
  {"id":6,"name":"الأنعام","type":"مكية","verses":165,"category":"tiwal"},
  {"id":7,"name":"الأعراف","type":"مكية","verses":206,"category":"tiwal"},
  {"id":8,"name":"الأنفال","type":"مدنية","verses":75,"category":"miin"},
  {"id":9,"name":"التوبة","type":"مدنية","verses":129,"category":"miin"},
  {"id":10,"name":"يونس","type":"مكية","verses":109,"category":"miin"},
  {"id":11,"name":"هود","type":"مكية","verses":123,"category":"miin"},
  {"id":12,"name":"يوسف","type":"مكية","verses":111,"category":"miin"},
  {"id":13,"name":"الرعد","type":"مدنية","verses":43,"category":"miin"},
  {"id":14,"name":"إبراهيم","type":"مكية","verses":52,"category":"miin"},
  {"id":15,"name":"الحجر","type":"مكية","verses":99,"category":"miin"},
  {"id":16,"name":"النحل","type":"مكية","verses":128,"category":"miin"},
  {"id":17,"name":"الإسراء","type":"مكية","verses":111,"category":"miin"},
  {"id":18,"name":"الكهف","type":"مكية","verses":110,"category":"miin"},
  {"id":19,"name":"مريم","type":"مكية","verses":98,"category":"mathani"},
  {"id":20,"name":"طه","type":"مكية","verses":135,"category":"mathani"},
  {"id":21,"name":"الأنبياء","type":"مكية","verses":112,"category":"mathani"},
  {"id":22,"name":"الحج","type":"مدنية","verses":78,"category":"mathani"},
  {"id":23,"name":"المؤمنون","type":"مكية","verses":118,"category":"mathani"},
  {"id":24,"name":"النور","type":"مدنية","verses":64,"category":"mathani"},
  {"id":25,"name":"الفرقان","type":"مكية","verses":77,"category":"mathani"},
  {"id":26,"name":"الشعراء","type":"مكية","verses":227,"category":"mathani"},
  {"id":27,"name":"النمل","type":"مكية","verses":93,"category":"mathani"},
  {"id":28,"name":"القصص","type":"مكية","verses":88,"category":"mathani"},
  {"id":29,"name":"العنكبوت","type":"مكية","verses":69,"category":"mathani"},
  {"id":30,"name":"الروم","type":"مكية","verses":60,"category":"mathani"},
  {"id":31,"name":"لقمان","type":"مكية","verses":34,"category":"mathani"},
  {"id":32,"name":"السجدة","type":"مكية","verses":30,"category":"mathani"},
  {"id":33,"name":"الأحزاب","type":"مدنية","verses":73,"category":"mathani"},
  {"id":34,"name":"سبأ","type":"مكية","verses":54,"category":"mathani"},
  {"id":35,"name":"فاطر","type":"مكية","verses":45,"category":"mathani"},
  {"id":36,"name":"يس","type":"مكية","verses":83,"category":"mathani"},
  {"id":37,"name":"الصافات","type":"مكية","verses":182,"category":"mathani"},
  {"id":38,"name":"ص","type":"مكية","verses":88,"category":"mathani"},
  {"id":39,"name":"الزمر","type":"مكية","verses":75,"category":"mathani"},
  {"id":40,"name":"غافر","type":"مكية","verses":85,"category":"mathani"},
  {"id":41,"name":"فصلت","type":"مكية","verses":54,"category":"mathani"},
  {"id":42,"name":"الشورى","type":"مكية","verses":53,"category":"mathani"},
  {"id":43,"name":"الزخرف","type":"مكية","verses":89,"category":"mathani"},
  {"id":44,"name":"الدخان","type":"مكية","verses":59,"category":"mathani"},
  {"id":45,"name":"الجاثية","type":"مكية","verses":37,"category":"mathani"},
  {"id":46,"name":"الأحقاف","type":"مكية","verses":35,"category":"mathani"},
  {"id":47,"name":"محمد","type":"مدنية","verses":38,"category":"mathani"},
  {"id":48,"name":"الفتح","type":"مدنية","verses":29,"category":"mathani"},
  {"id":49,"name":"الحجرات","type":"مدنية","verses":18,"category":"mathani"}
];
// Populate the rest of the 114
const additional = ["ق","الذاريات","الطور","النجم","القمر","الرحمن","الواقعة","الحديد","المجادلة","الحشر","الممتحنة","الصف","الجمعة","المنافقون","التغابن","الطلاق","التحريم","الملك","القلم","الحاقة","المعارج","نوح","الجن","المزمل","المدثر","القيامة","الإنسان","المرسلات","النبأ","النازعات","عبس","التكوير","الانفطار","المطففين","الانشقاق","البروج","الطارق","الأعلى","الغاشية","الفجر","البلد","الشمس","الليل","الضحى","الشرح","التين","العلق","القدر","البينة","الزلزلة","العاديات","القارعة","التكاثر","العصر","الهمزة","الفيل","قريش","الماعون","الكوثر","الكافرون","النصر","المسد","الإخلاص","الفلق","الناس"];
additional.forEach((n, i) => {
  surahs.push({"id": 50 + i, "name": n, "type": (50+i)%2?"مكية":"مدنية", "verses": 0, "category": "mufassal"});
});

// Audio Library API Logic
let allRecitersCache = [];
let currentReciterServer = 'https://server8.mp3quran.net/afs/';
let currentReciterGlobalName = 'مشاري العفاسي';
// Audio Player State
let currentSurahId = 1; 

function renderMegaSurahs(filter = 'all', searchQuery = '') {
  const c = document.getElementById('mega-surah-list');
  c.innerHTML = '';
  const filtered = surahs.filter(s => {
    let matchF = true;
    if(filter !== 'all') {
      if(filter === 'tiwal' && s.category !== 'tiwal') matchF = false;
      if(filter === 'miin' && s.category !== 'miin') matchF = false;
      if(filter === 'mathani' && s.category !== 'mathani') matchF = false;
      if(filter === 'mufassal' && s.category !== 'mufassal') matchF = false;
    }
    let matchS = s.name.includes(searchQuery) || String(s.id).includes(searchQuery);
    return matchF && matchS;
  });

  filtered.forEach(s => {
    c.innerHTML += `
      <div class="col-lg-4 col-md-6">
        <div class="surah-card" onclick="openMegaReader(${s.id}, '${s.name}')">
          <div class="surah-num">${s.id}</div>
          <div class="ms-3">
            <h5 class="fw-bold">${s.name}</h5>
            <span>${s.type} • رقم ${s.id}</span>
          </div>
          <button class="btn-play-s" onclick="event.stopPropagation(); playMegaAudio(${s.id}, '${s.name}', currentReciterServer, currentReciterGlobalName)">
            <i class="fas fa-play"></i>
          </button>
        </div>
      </div>
    `;
  });
}

// ---------------- AUDIO LIBRARY LOGIC ----------------
function initAudioLibrary() {
   const grid = document.getElementById('recitersGrid');
   grid.innerHTML = '<div class="col-12 text-center my-5"><div class="spinner-border text-success" role="status"></div><h5 class="mt-3 font-amiri text-dark">جاري تحميل أكثر من 200 مقرئ من مصادر Mp3Quran المعتمدة...</h5></div>';
   
   fetch('https://www.mp3quran.net/api/v3/reciters?language=ar')
   .then(r => r.json())
   .then(data => {
      allRecitersCache = data.reciters;
      renderReciters(allRecitersCache);
   })
   .catch(err => {
      grid.innerHTML = '<div class="col-12 text-center text-danger"><h5>تعذر الاتصال بالمكتبة الصوتية. يرجى المحاولة لاحقاً.</h5></div>';
   });
}

function renderReciters(reciters) {
   const grid = document.getElementById('recitersGrid');
   let html = '';
   
   // Insert Search Input
   html += `
      <div class="col-12 mb-4">
         <div class="bg-white p-3 rounded-4 shadow-sm border d-flex align-items-center mb-3">
            <i class="fas fa-search text-muted ms-3 fs-5"></i>
            <input type="text" class="form-control border-0 shadow-none bg-transparent fs-5 font-amiri" id="reciterSearchInput" placeholder="ابحث في أكثر من 200 مقرئ (مثال: عبد الباسط، المعيقلي، العفاسي)..." oninput="filterReciters(this.value)">
         </div>
      </div>
   `;
   
   if(reciters.length === 0) {
      html += '<div class="col-12 text-center py-5 text-muted"><i class="fas fa-frown fs-1 mb-3"></i><h4>لم نجد القارئ المطلوب</h4></div>';
      grid.innerHTML = html;
      return;
   }

   reciters.forEach(r => {
      let moshaf = r.moshaf[0];
      html += `
         <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
            <div class="reciter-item" onclick="openReciter('${r.name}', '${moshaf.server}')">
               <div style="background:rgba(15,118,110,0.1);width:60px;height:60px;border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 15px;">
                  <i class="fas fa-microphone-alt text-success fs-3"></i>
               </div>
               <h5 class="fw-bold mb-2 font-amiri" style="font-size: 1.1rem; height: 35px; overflow: hidden; text-overflow:ellipsis;">${r.name}</h5>
               <small class="opacity-75 d-block text-truncate">${moshaf.name}</small>
               <span class="badge bg-light text-dark mt-2 border">${moshaf.surah_total} سورة</span>
            </div>
         </div>
      `;
   });
   grid.innerHTML = html;
}

function filterReciters(query) {
   const val = query.trim().toLowerCase();
   if (!val) {
       renderReciters(allRecitersCache);
       setTimeout(() => document.getElementById('reciterSearchInput').focus(), 10);
       return;
   }
   const filtered = allRecitersCache.filter(r => r.name.toLowerCase().includes(val));
   renderReciters(filtered);
   const input = document.getElementById('reciterSearchInput');
   if(input) { input.value = val; input.focus(); }
}

function openReciter(name, url) {
   document.getElementById('recitersGrid').style.display = 'none';
   document.getElementById('reciterDetails').style.display = 'block';
   document.getElementById('currentReciterTitle').innerText = name;
   
   // Set globally so the Quran Tab also uses this reciter!
   currentReciterServer = url;
   currentReciterGlobalName = name;
   
   renderLibrarySurahs(name, url);
}

function closeReciterDetails() {
   document.getElementById('recitersGrid').style.display = 'flex';
   document.getElementById('reciterDetails').style.display = 'none';
}

function renderLibrarySurahs(reciterName, serverUrl, searchQuery = '') {
   const grid = document.getElementById('libSurahsGrid');
   grid.innerHTML = '';
   
   surahs.filter(s => s.name.includes(searchQuery) || String(s.id).includes(searchQuery)).forEach(s => {
      grid.innerHTML += `
         <div class="col-md-3 col-sm-6">
            <button class="btn btn-outline-dark w-100 text-start d-flex align-items-center justify-content-between p-3" onclick="playMegaAudio(${s.id}, '${s.name}', '${serverUrl}', '${reciterName}')">
               <div><span class="badge bg-light text-dark me-2 border">${s.id}</span><strong class="font-amiri fs-5">${s.name}</strong></div>
               <i class="fas fa-play text-success"></i>
            </button>
         </div>
      `;
   });
}

document.getElementById('libSurahSearch').addEventListener('input', (e) => {
   renderLibrarySurahs(currentReciterGlobalName, currentReciterServer, e.target.value);
});

// Used when coming from Legends tab
function openAudioLibrary(reciterName) {
   const audioTab = new bootstrap.Tab(document.querySelector('button[data-bs-target="#tab-audio"]'));
   audioTab.show();
   // Simple search logic for legends mapping to the 200+ list
   setTimeout(() => {
     let searchInput = document.getElementById('reciterSearchInput');
     if(searchInput) {
        searchInput.value = reciterName.split(' ')[0]; // search by first name
        filterReciters(reciterName.split(' ')[0]);
     }
   }, 1000);
}

// ---------------- GENERAL LOGIC: READER & TAFSIR ----------------

let isTafsirVisible = false;

function openMegaReader(id, name) {
  document.getElementById('quranModalTitle').innerText = 'سورة ' + name;
  const sInfo = surahs.find(s => s.id === id);
  document.getElementById('quranModalDesc').innerText = sInfo.type + ' • آياتها: ' + sInfo.verses;
  document.getElementById('quranTextContent').innerHTML = '<h3 class="text-center font-amiri text-success fw-bold mb-4">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</h3><div class="text-center"><p>جارٍ تحميل الآيات مع التفسير الميسر...</p><div class="spinner-border text-success"></div></div>';
  document.getElementById('quranTextContent').classList.remove('show-tafsir');
  isTafsirVisible = false;
  
  new bootstrap.Modal(document.getElementById('quranModal')).show();
  
  // Fetch Quran Text & Tafsir in parallel
  Promise.all([
     fetch(`https://api.alquran.cloud/v1/surah/${id}/quran-uthmani`).then(r=>r.json()),
     fetch(`https://api.alquran.cloud/v1/surah/${id}/ar.muyassar`).then(r=>r.json())
  ]).then(([quranData, tafsirData]) => {
      let b = `<h3 class="text-center font-amiri text-success fw-bold mb-4">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</h3>`;
      if(id===1 || id===9) b = ''; 
      
      let html = b;
      quranData.data.ayahs.forEach((a, index) => {
         let tafsir = tafsirData.data.ayahs[index].text;
         html += `
            <span class="verse d-inline-block">
               ${a.text} <span class="v-num px-2 text-success fw-bold">﴿${a.numberInSurah}﴾</span>
            </span>
            <div class="verse-tafsir"><strong class="text-success"><i class="fas fa-book-reader me-2"></i>التفسير:</strong> ${tafsir}</div>
         `;
      });
      document.getElementById('quranTextContent').innerHTML = html;
  }).catch(e => {
      document.getElementById('quranTextContent').innerHTML = '<p class="text-danger text-center"><i class="fas fa-exclamation-triangle fa-3x mb-3 d-block"></i>عذراً، فشل الاتصال بالخادم لجلب السورة والتفسير.</p>';
  });
}

function toggleTafsir() {
   const container = document.getElementById('quranTextContent');
   isTafsirVisible = !isTafsirVisible;
   if(isTafsirVisible) {
      container.classList.add('show-tafsir');
   } else {
      container.classList.remove('show-tafsir');
   }
}

// ---------------- ADVANCED AUDIO PLAYER ----------------

const quranAudio = document.getElementById('quranAudio');
const audioProgress = document.getElementById('audioProgress');
const currentTimeDisplay = document.getElementById('audioCurrentTime');
const durationDisplay = document.getElementById('audioDuration');
const playPauseBtn = document.getElementById('playPauseBtn');

function playMegaAudio(id, name, serverUrl, reciterName) {
  document.getElementById('globalPlayer').classList.add('active');
  document.getElementById('playerTitle').innerText = 'سورة ' + name;
  document.getElementById('playerReciter').innerText = reciterName;
  
  currentSurahId = id;
  const numStr = String(id).padStart(3, '0');
  const fileUrl = `${serverUrl}${numStr}.mp3`;
  
  document.getElementById('downloadAudioBtn').href = fileUrl;
  
  quranAudio.src = fileUrl;
  quranAudio.play();
  playPauseBtn.innerHTML = '<i class="fas fa-pause fs-5"></i>';
}

function togglePlayPause() {
   if(quranAudio.paused) {
      quranAudio.play();
      playPauseBtn.innerHTML = '<i class="fas fa-pause fs-5"></i>';
   } else {
      quranAudio.pause();
      playPauseBtn.innerHTML = '<i class="fas fa-play fs-5"></i>';
   }
}

function playNextSurah(direction) {
   let nextId = currentSurahId + direction;
   if(nextId > 114) nextId = 1;
   if(nextId < 1) nextId = 114;
   const nextSurah = surahs.find(s => s.id === nextId);
   playMegaAudio(nextId, nextSurah.name, currentReciterServer, currentReciterGlobalName);
}

function closeAudioPlayer() {
   document.getElementById('globalPlayer').classList.remove('active');
   quranAudio.pause();
}

quranAudio.addEventListener('timeupdate', () => {
   if(quranAudio.duration) {
      const prog = (quranAudio.currentTime / quranAudio.duration) * 100;
      audioProgress.value = prog;
      currentTimeDisplay.innerText = formatTime(quranAudio.currentTime);
   }
});

quranAudio.addEventListener('loadedmetadata', () => {
   durationDisplay.innerText = formatTime(quranAudio.duration);
});

quranAudio.addEventListener('play', () => {
    document.getElementById('playerDisc').classList.add('fa-spin');
});
quranAudio.addEventListener('pause', () => {
    document.getElementById('playerDisc').classList.remove('fa-spin');
});
quranAudio.addEventListener('ended', () => {
    playNextSurah(1); // Auto-play next surah
});

audioProgress.addEventListener('input', (e) => {
   const val = e.target.value;
   if(quranAudio.duration) {
      quranAudio.currentTime = (val / 100) * quranAudio.duration;
   }
});

function formatTime(secs) {
   let minutes = Math.floor(secs / 60) || 0;
   let seconds = Math.floor(secs - minutes * 60) || 0;
   return minutes.toString().padStart(2, '0') + ':' + seconds.toString().padStart(2, '0');
}

// Event Listeners
document.querySelectorAll('#megaFilters .btn').forEach(btn => {
  btn.addEventListener('click', (e) => {
    document.querySelectorAll('#megaFilters .btn').forEach(b => b.classList.remove('active'));
    e.target.classList.add('active');
    renderMegaSurahs(e.target.dataset.filter, document.getElementById('megaSurahSearch').value);
  });
});

document.getElementById('megaSurahSearch').addEventListener('input', (e) => {
  const currentFilter = document.querySelector('#megaFilters .btn.active').dataset.filter;
  renderMegaSurahs(currentFilter, e.target.value);
});

// Initial Render
window.addEventListener('DOMContentLoaded', () => {
    renderMegaSurahs();
    initAudioLibrary();
});
</script>
</body>
</html>
